import type { Router, RouteRecordNormalized } from 'vue-router';
import NProgress from 'nprogress'; // progress bar

import usePermission from '@/hooks/permission';
import { WHITE_LIST, NOT_FOUND } from '../constants';

export default function setupPermissionGuard(router: Router) {
  router.beforeEach(async (to, from, next) => {
    const Permission = usePermission();
    const permissionsAllow = Permission.accessRouter(to);

    console.log('[  ]-12', to.name);
    if (permissionsAllow) {
      next();
    } else {
      // const destination = NOT_FOUND;
      // next(destination);
      next();
    }
    NProgress.done();
  });
}
