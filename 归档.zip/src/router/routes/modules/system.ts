/*
 * @Author: Sam
 * @Date: 2023-01-28 13:58:59
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-09 08:45:12
 */
import { DEFAULT_LAYOUT } from '../base';
import { AppRouteRecordRaw } from '../types';

const SYSTEM: AppRouteRecordRaw = {
  path: '/oms/system',
  name: 'system',
  component: DEFAULT_LAYOUT,
  meta: {
    locale: '系统管理',
    requiresAuth: true,
    order: 0,
  },
  children: [
    {
      path: 'user',
      name: 'oms-system-user',
      component: () => import('@/views/oms/system/user/index.vue'),
      meta: {
        locale: '用户管理',
        requiresAuth: true,
      },
    },
    {
      path: 'role',
      name: 'oms-system-role',
      component: () => import('@/views/oms/system/role/index.vue'),
      meta: {
        locale: '角色管理',
        requiresAuth: true,
      },
    },
    {
      path: 'menu',
      name: 'oms-system-menu',
      component: () => import('@/views/oms/system/menu/index.vue'),
      meta: {
        locale: '菜单管理',
        requiresAuth: true,
      },
    },
    {
      path: 'dictionary',
      name: 'oms-system-dictionary',
      component: () => import('@/views/oms/system/dictionary/index.vue'),
      meta: {
        locale: '数据字典',
        requiresAuth: true,
      },
    },
  ],
};

// export default SYSTEM;
