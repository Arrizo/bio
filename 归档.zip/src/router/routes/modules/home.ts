import { DEFAULT_LAYOUT } from '../base';
import { AppRouteRecordRaw } from '../types';

const HOME: AppRouteRecordRaw = {
  path: '/home',
  name: 'home',
  component: DEFAULT_LAYOUT,
  meta: {
    locale: '首页',
    requiresAuth: true,
    icon: 'icon-home',
    order: 0,
  },
  children: [
    {
      path: 'index',
      name: 'home_index',
      component: () => import('@/views/home/index/index.vue'),
      meta: {
        locale: '首页',
        requiresAuth: true,
        roles: ['*'],
        hideInMenu: true,
      },
    }
  ],
};

export default HOME;
