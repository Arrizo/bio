/*
 * @Author: Sam
 * @Date: 2023-01-29 14:25:35
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-09 08:52:42
 */
import { DEFAULT_LAYOUT } from '../base';
import { AppRouteRecordRaw } from '../types';

// const BASICDATA: AppRouteRecordRaw = {
//   path: '/oms/basicdata',
//   name: 'basicdata',
//   component: DEFAULT_LAYOUT,
//   meta: {
//     locale: '基础资料',
//     requiresAuth: true,
//     order: 0,
//   },
//   children: [
//     {
//       path: 'shop',
//       name: 'oms-basicdata-shop',
//       component: () => import('@/views/oms/basicdata/shop/index.vue'),
//       meta: {
//         locale: '店铺管理',
//         requiresAuth: true,
//       },
//     },
//     {
//       path: 'warehouse',
//       name: 'oms-basicdata-warehouse',
//       component: () => import('@/views/oms/basicdata/warehouse/index.vue'),
//       meta: {
//         locale: '仓库管理',
//         requiresAuth: true,
//       },
//     },
//     {
//       path: 'express',
//       name: 'oms-basicdata-express',
//       component: () => import('@/views/oms/basicdata/express/index.vue'),
//       meta: {
//         locale: '快递管理',
//         requiresAuth: true,
//       },
//     },
//     {
//       path: 'region',
//       name: 'oms-basicdata-region',
//       component: () => import('@/views/oms/basicdata/region/index.vue'),
//       meta: {
//         locale: '行政区域',
//         requiresAuth: true,
//       },
//     },
//   ],
// };

// export default BASICDATA;
