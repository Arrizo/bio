/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-21 10:44:58
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-22 17:27:52
 * @FilePath: \oms-admin\src\directive\dbClick\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
/**
 * 通过指令实现对表格列表的双击
 * 用法：
 * <div
 *    v-double-click:[selector]='tableData'
 *    :doubleCallback='()=>{}'
 *    ></div>
 */
import { DirectiveBinding } from 'vue';
import { computed } from 'vue';

function doubleClick(el: HTMLElement, binding: DirectiveBinding, vnode: any) {
  let { arg } = binding;
  let { props } = vnode;
  let selectIndex = 0;
  // 监听列表
  const dbDataList = computed(() => binding.value);
  let selector = arg ?? '.arco-table-tr';
  let tableTr = el.querySelectorAll(selector);
  let cbData: any = null;
  for (let i = 1; i < tableTr.length; i++) {
    let ElItem = tableTr[i] as HTMLElement;
    ElItem.ondblclick = () => {
      let allEls = el.querySelectorAll('.arco-table-tr');
      for (let j = 0; j < allEls.length; j++) {
        allEls[j].setAttribute('class', 'arco-table-tr');
      }
      if (!!selectIndex) {
        tableTr[selectIndex].classList.remove('selected-row');
      }
      setTimeout(() => {
        ElItem.classList.add('selected-row');
      }, 10);
      selectIndex = i;
      cbData = dbDataList.value[i - 1];
      props['db-call-back'](cbData);
    };
  }
}

export default {
  mounted(el: HTMLElement, binding: DirectiveBinding, vnode: any) {
    doubleClick(el, binding, vnode);
  },
  updated(el: HTMLElement, binding: DirectiveBinding, vnode: any) {
    doubleClick(el, binding, vnode);
  },
};
