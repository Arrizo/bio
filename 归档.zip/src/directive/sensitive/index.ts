import { DirectiveBinding } from 'vue';
import { useUserStore } from '@/store';

function checkSensitive(el: HTMLElement, binding: DirectiveBinding) {
  const { value } = binding;
  const userStore = useUserStore();
  let hasSensitive = false;

  if (Array.isArray(value)) {
    if (value.length === 2) {
      hasSensitive = userStore.permsMap[value[0]]?.includes(value[1]);
    } else {
      hasSensitive = false;
    }
  } else {
    throw new Error(
      `need roles! Like v-Sensitive="['oms_system_user','mobile']"`
    );
  }

  if (!hasSensitive && el.parentNode) {
    el.parentNode.removeChild(el);
  }

  return hasSensitive;
}

export default {
  mounted(el: HTMLElement, binding: DirectiveBinding) {
    checkSensitive(el, binding);
  },
  updated(el: HTMLElement, binding: DirectiveBinding) {
    checkSensitive(el, binding);
  },
};
