/*
 * @Author: Sam
 * @Date: 2023-02-14 08:16:06
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-14 17:18:48
 */
import { DirectiveBinding } from 'vue';

function checkInput(el: any, binding: DirectiveBinding, vnode: any) {
  var ele = el.getElementsByClassName('arco-input');
  if (ele.length === 0) {
    ele = el.getElementsByClassName('arco-textarea');
  }
  const val = ele[0].value;

  vnode.ctx.emit(
    'update:modelValue',
    val.replaceAll(
      binding.value ? binding.value[0] : '#',
      binding.value ? binding.value[1] : ''
    )
  );
}

export default {
  mounted(el: HTMLElement, binding: DirectiveBinding, vnode: any) {
    checkInput(el, binding, vnode);
  },
  updated(el: HTMLElement, binding: DirectiveBinding, vnode: any) {
    checkInput(el, binding, vnode);
  },
};
