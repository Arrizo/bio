import { App } from 'vue';
import permission from './permission';
import permissionElse from './permissionElse';
import sensitive from './sensitive';
import sensitiveElse from './sensitiveElse';
import limitInput from './limitInput';
import doubleClick from './dbClick';

export default {
  install(Vue: App) {
    Vue.directive('permission', permission);
    Vue.directive('permissionElse', permissionElse);
    Vue.directive('sensitive', sensitive);
    Vue.directive('sensitiveElse', sensitiveElse);
    Vue.directive('limitInput', limitInput);
    Vue.directive('dbClick', doubleClick);
  },
};
