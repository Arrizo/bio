/*
 * @Author: Sam
 * @Date: 2023-01-30 15:42:57
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-01 14:35:45
 */

import JsEncrypt from 'jsencrypt';

// 判断是否为数组
export const isArr = (origin: any): boolean => {
  let str = '[object Array]';
  return Object.prototype.toString.call(origin) == str ? true : false;
};

export const deepClone = <T>(
  tSource: T,
  tTarget?: Record<string, any> | T
): T => {
  if (isArr(tSource)) {
    tTarget = tTarget || [];
  } else {
    tTarget = tTarget || {};
  }
  for (const key in tSource) {
    if (Object.prototype.hasOwnProperty.call(tSource, key)) {
      if (typeof tSource[key] === 'object' && typeof tSource[key] !== null) {
        tTarget[key] = isArr(tSource[key]) ? [] : {};
        deepClone(tSource[key], tTarget[key]);
      } else {
        tTarget[key] = tSource[key];
      }
    }
  }
  return tTarget as T;
};

/**
 * Rsa 加密
 */
export function rsaEncrypt(rawData: any, publicPem: string) {
  let data;
  try {
    var rsa = new JsEncrypt();
    rsa.setPublicKey(publicPem);
    data = rsa.encrypt(rawData);
  } catch (error) {
    return '';
  }

  return data;
}

/**
 * 返回格式化的日期字符串
 * 格式形如：'yyyy-MM-dd HH:mm:ss+S q'
 * @param date 日期
 * @param format 日期格式字符串
 * @returns {string}
 */
export function formatDate(date: Date, format: string = 'yyyy-MM-dd HH:mm:ss') {
  var o: any = {
    'M+': date.getMonth() + 1, // 月
    'd+': date.getDate(), // 日
    'H+': date.getHours(),
    'h+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分钟
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    'S': date.getMilliseconds(), // 毫秒
  };
  if (/(y+)/.test(format))
    format = format.replace(
      RegExp.$1,
      (date.getFullYear() + '').substr(4 - RegExp.$1.length)
    );
  for (var k in o) {
    if (new RegExp('(' + k + ')').test(format)) {
      format = format.replace(
        RegExp.$1,
        RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
      );
    }
  }
  return format;
}

//
/**文件流转为文件
 * @param data 文件流
 * @param fileName //下载文件名称
 * @param isTimesTamp //下载文件名称是否携带日期
 */
export function downFile(data: any, fileName: string, isTimesTamp?: boolean) {
  var timestamp = formatDate(new Date(), 'yyyyMMddHHmmss');
  try {
    let blob = new Blob([data], { type: 'application/vnd.ms-excel' });
    let file = isTimesTamp ? `${fileName}_${timestamp}.xls` : `${fileName}.xls`;
    let link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = file;
    link.click();
    window.URL.revokeObjectURL(link.href);
  } catch (error) {
    console.log('下载文件异常！');
  }
}
/**
 *
 * 作用：根据指定的类名查找元素
 *
 * 参数：
 * @param  classname：需要查找的类名（字符串）
 * @param  oParent（可有可无）：需要查找的元素的父级（对象），如果没
 *         传入，默认为document；如果需要缩小范围，提高查找速度，可以
 *         给值（建议给）
 *
 * 函数内局部变量：
 * oChild  根据父级oParent获取到的该标签下的所有标签
 * arr     存储拥有需要查找的classname的元素
 *
 * 步骤：
 * 1.判断是否有传入oParent，如果没有传入，则赋予初始值document
 * 2.获取父级oParent下的所有标签并存储到oChild中
 * 3.定义空数组arr
 * 4.对oChild进行循环，利用字符串函数indexOf对每个元素的类名进行查找（
 *   类名可能不止一个），如果在类名中找到了传入进来的类名，便将拥有该类名
 *   的元素添加到arr中
 * 5.循环完毕，将arr返回
 */
export function getClass(classname: string, oParent?: any) {
  if (!oParent) {
    oParent = document;
  }

  var oChild = oParent.getElementsByTagName('*');
  var arr = [];

  for (var i = 0, len = oChild.length; i < len; i++) {
    // indexOf，在字符串中查找指定字符，如果查找到了，返回该字符
    // 在字符串中的索引；如果没有找到，返回-1
    // 索引有可能为0，所以大于等于0就意味着找到
    const name = JSON.stringify(oChild[i].className);
    if (!name) {
      continue;
    }
    if (name.indexOf(classname) >= 0) {
      arr.push(oChild[i]);
    }
  }
  return arr;
}


/**
 * 对象数组去重
 * @param {*} array  数组
 * @param {*} field  去重字段
 * @returns  返回去重后的数组
 */
export function uniqueArray(array: any, field: string) {
  var obj = {}
  return array.reduce(function (a: any, b: any) {
    obj[b[field]] ? '' : obj[b[field]] = true && a.push(b)
    return a
  }, [])
}
// /**
//  * 阿拉伯数字转为汉字数字
//  *
//  */
// export const arabiaToChinese = (numbers: Array<number> = [], type: 'week' | 'month') => {
//   numbers=numbers.sort()
// }
