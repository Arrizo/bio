// 系统密码校验正则表达式
export const Password = /^[a-zA-Z0-9]{10,16}$/;

// 手机号
export const Mobile = /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;

// 固话号
export const Phone = /^\d{3}-\d{8}|\d{4}-\d{7}$/;