/**
 * 获取泛型 T 指定的对象类型中属性 K 的类型
 */
export type PropertyTypeOf<T extends Object, K extends keyof T> = T[K];