/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 16:49:26
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 16:56:04
 * @ Description: 实体仓库存
 */

/**
 * 实体仓库存查询bo_1
 */
export class PhysicalInventoryReq {
  pageNum?: number=1;
  pageSize?: number=10;
  /**
   * 规格名称
   */
  skuName?: string;
  /**
   * 商品编码
   */
  spuSkuCode?: string;
  spuSkuList?: string[];
  /**
   * 入库仓库
   */
  warehouseCodes?: string[];
}

/**
 * PageResult«实体仓库存VO»_1
 */
export interface PhysicalInventoryRes {
  pageNum?: number;
  pageSize?: number;
  result?: PhysicalInventoryType[];
  totalCount?: number;
  totalPage?: number;
}

/**
* 实体仓库存VO_1
*/
export interface PhysicalInventoryType {
  /**
   * 配货占用
   */
  deliveryQuantityAmount?: number;
  /**
   * 数据id
   */
  id?: number;
  /**
   * 其他占用
   */
  otherQuantityAmount?: number;
  /**
   * 可用库存数
   */
  quantityAmount?: number;
  /**
   * 规格编码
   */
  skuCode?: string;
  /**
   * 规格型号
   */
  skuModel?: string;
  /**
   * 规格名称
   */
  skuTitle?: string;
  /**
   * 商品编码
   */
  spuCode?: string;
  /**
   * 总库存数
   */
  stockAmount?: number;
  /**
   * 在途数
   */
  transitQuantityAmount?: number;
  /**
   * 实体仓名称
   */
  warehouseName?: string;
}