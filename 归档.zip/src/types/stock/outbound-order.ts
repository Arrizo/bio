/**
 * 实体仓库存查询bo_1
 */
export class OutboundOrderReq {
  /**
     * 开始时间
     */
  beginDate?: string = '';
  /**
   * 编码
   */
  code?: string = '';
  /**
   * 创建人名称
   */
  creatorName?: string = '';
  /**
   * 时间类型 1：创建时间 2：审核时间 3：出库时间 4：更新时间
   */
  dateType?: number = 0;
  /**
   * 结束时间
   */
  endDate?: string = '';
  /**
   * 来源单号
   */
  fromCode?: string = '';
  /**
   * 页码
   */
  pageNum?: number = 1;
  /**
   * 分页数
   */
  pageSize?: number = 10;
  /**
   * 规格名称
   */
  skuTitle?: string = '';
  /**
   * 出/入库状态,可用值:NO,PART,ALL
   */
  stockOptStatus?: string = '';
  /**
   * 出/入库单号
   */
  stockOrderNo?: string = '';
  /**
   * 状态,可用值:DRAFT,WAIT_AUDIT,AUDIT_PASS,NO_PASS,NOTIFIED,NOTIFICATION_FAILED,CANCEL,COMPLETED
   */
  stockReceiptStatus?: string = '';
  /**
   * 出库仓库
   */
  virWarehouseIds?: string[] = [];
}

export interface OutboundOrderRes {
  /**
   * 页码
   */
  pageNum: number;
  /**
   * 分页数
   */
  pageSize: number;
  /**
   * 响应结果
   */
  result: OutboundOrderType[];
  /**
   * 总条数
   */
  totalCount: number;
  /**
   * 总页数
   */
  totalPage: number;
}

export interface OutboundOrderType {
  /**
   * 来源单号
   */
  fromCode?: string;
  /**
   * 单据来源
   */
  fromReceipt?: string;
  /**
   * 状态
   */
  status?: string;
  /**
   * 出库单号
   */
  stockNo?: string;
  /**
   * 出库状态
   */
  stockOptStatus?: string;
  /**
   * 出库类型
   */
  stockType?: string;
  /**
   * 更新时间
   */
  updateTime?: string;
  /**
   * 虚拟仓名称
   */
  virtualWarehouseTitle?: string;
  id:number;
}
export class OutboundOrderFrom {
  /**
   * 结算组织
   */
  accountingOrg: string = '';
  /**
   * 地址
   */
  address: string = '';
  /**
   * 区id
   */
  areaId?: number;
  /**
   * 附件地址
   */
  attachment: string = '';
  /**
   * 自动入库
   */
  autoInbound?: boolean;
  /**
   * 业务部门
   */
  businessDept: string = '';
  /**
   * 市id
   */
  cityId?: number;
  /**
   * 联系人
   */
  concat: string = '';
  /**
   * 入库虚拟仓id
   */
  inboundVirWarehouseId?: number;
  /**
   * 入库虚拟仓名称
   */
  inboundVirWarehouseTitle: string = '';
  /**
   * 操作类型 1：提交 2：暂存
   */
  optType?: number;
  /**
   * 出库类型
   */
  outboundType: string = '';
  /**
   * 省id
   */
  provinceId?: number;
  /**
   * 备注
   */
  remark: string = '';
  /**
   * 出入库商品信息
   */
  skus?: Skus[] = [];
  /**
   * 手机号
   */
  tel: string = '';
  /**
   * 出库仓库虚拟仓id
   */
  virtualWarehouseId?: number;
  /**
   * 出库虚拟仓名称
   */
  virtualWarehouseTitle: string = '';
  /**
   * 来源单号
   */
  fromCode?: string = '';
  /**
   * 来源类型
   */
  fromReceipt?: string = '';
  id?: number;
}

export interface Skus {
  /**
   * 实际入库数量
   */
  actualAmount?: number;
  /**
   * 批次号
   */
  batchNo?: string;
  /**
   * 过期日期
   */
  expireDate?: string;
  /**
   * 计划入库数量
   */
  planAmount?: number;
  /**
   * 价格
   */
  price?: number;
  /**
   * 生产日期
   */
  produceDate?: string;
  /**
   * 采购入库时间
   */
  purchaseStockInDate?: string;
  /**
   * 规格编码
   */
  skuCode?: string;
  /**
   * 规格模型
   */
  skuModel?: string;
  /**
   * 规格名称
   */
  skuTitle?: string;
  /**
   * 商品编码
   */
  spuCode?: string;
}