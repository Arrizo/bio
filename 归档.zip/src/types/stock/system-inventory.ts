/**
 * 实体仓库存查询bo
 */
 export class SystemInventoryType {
  pageNum: number=1;
  pageSize: number=10;
  /**
   * 规格名称
   */
  skuName: string='';
  /**
   * 排序字段
   */
  sortField: string='';
  /**
   * 排序
   */
  sortType: string='';
  /**
   * 商品编码
   */
  spuSkuCode: string='';
  spuSkuList: string[]=[];
  /**
   * 库存状态
   */
  stockStatus:string='all';
  /**
   * 入库仓库
   */
  warehouseCodes: string[]=[];
}

/**
* 库存状态
*/
export enum StockStatus {
  Locked = "LOCKED",
  Minus = "MINUS",
  Normal = "NORMAL",
  Plus = "PLUS",
  Zero = "ZERO",
}
/**
 * 实体仓库存VO
 */
 export class SystemInventoryList {
  /**
   * 配货占用
   */
  deliveryQuantityAmount?: number;
  /**
   * 数据id
   */
  id?: number;
  /**
   * 其他占用
   */
  otherQuantityAmount?: number;
  /**
   * 可用库存数
   */
  quantityAmount?: number;
  /**
   * 规格编码
   */
  skuCode?: string;
  /**
   * 规格型号
   */
  skuModel?: string;
  /**
   * 规格名称
   */
  skuTitle?: string;
  /**
   * 商品编码
   */
  spuCode?: string;
  /**
   * 总库存数
   */
  stockAmount?: number;
  /**
   * 在途数
   */
  transitQuantityAmount?: number;
  /**
   * 虚拟仓ID
   */
  virtualWarehouseId?: number;
  /**
   * 虚拟仓名称
   */
  virtualWarehouseName?: string;
  /**
   * 实体仓名称
   */
  warehouseName?: string;
}