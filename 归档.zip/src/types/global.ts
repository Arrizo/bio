/*
 * @Author: Sam
 * @Date: 2023-01-30 15:09:50
 * @Last Modified by: Sam
 * @Last Modified time: 2023-01-30 15:19:58
 */
export interface HttpResponse<T = any> {
  code: string | number;
  message: string;
  success: boolean;
  value: T;
}

export interface AnyObject {
  [key: string]: unknown;
}

export interface Options {
  value: unknown;
  label: string;
}

export interface NodeOptions extends Options {
  children?: NodeOptions[];
}

export interface GetParams {
  body: null;
  type: string;
  url: string;
}

export interface PostData {
  body: string;
  type: string;
  url: string;
}

export interface Pagination {
  current: number;
  pageSize: number;
  total?: number;
}

export type TimeRanger = [string, string];

export interface GeneralChart {
  xAxis: string[];
  data: Array<{ name: string; value: number[] }>;
}
// 日志表格统一字段
export const OperationLogColumns = [
  { title: '操作人', dataIndex: 'operater', width: 100 },
  { title: '操作时间', dataIndex: 'operationTime', width: 200 },
  { title: '操作', dataIndex: 'logType', width: 100 },
  { title: '操作内容', dataIndex: 'msg' }
]