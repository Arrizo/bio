/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 13:53:57
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-06 11:21:32
 * @FilePath: \oms-admin\src\types\goods\brand.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
/**
 * 商品品牌分页查询对象
 */
export class GoodsBrandSearchType {
  /**
   * 品牌名
   */
  chineseName?: string = '';
  pageNum: number = 1;
  pageSize: number = 10;
  /**
   * 状态
   */
  status?: string = 'all';
}
/**
 * PageResult«商品品牌分页返回对象»
 */
export class GoodsBrandListType { /**
  * 品牌中文名
  */
  chineseName?: string='';
  /**
   * 品牌编码
   */
  code?: string='系统自动生成';
  /**
   * 品牌英文名
   */
   englishName?: string='';
  /**
   * id
   */
  id?: string|number='';
  /**
   * 备注
   */
  remark?: string='';
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 更新时间
   */
  updateTime?: Date;
  /**
   * 品牌方
   */
  client?: string='';
  /**
* 品牌logo
*/
  logo: string='';
}