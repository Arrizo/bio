/*
 * @Author: Sam
 * @Date: 2023-01-30 15:11:48
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-10 11:02:22
 */

export interface LoginData {
  /**
   * 用户名
   */
  account: string;
  /**
   * 浏览器
   */
  browser?: string;
  /**
   * 操作系统
   */
  os?: string;
  /**
   * 密码
   */
  password: string;
}

export interface LoginRes {
  /**
   * token
   */
  token: string;
  /**
   * token失效时间
   */
  tokenExpTime: number;
}

/**
 * 用户权限
 */
export class UserInfo {
  /**
   * 岗位编码
   */
  jobCode?: string;
  /**
   * 菜单权限
   */
  menuListVOS: UserMenuItem[] = [];
  /**
   * 手机号
   */
  mobile?: string;
  /**
   * 昵称
   */
  nickname?: string;
  /**
   * 组织id
   */
  orgId?: number;
  /**
   * 组织名称
   */
  orgName?: string;
  /**
   * 用户类型
   */
  type?: string;
  /**
   * 用户名
   */
  userName?: string;

  /**
   * 敏感权限
   */
  permsMap: any;

  /** 非接口返回-顶部首级导航数据 */
  firstMenuList: any[] = [];

  /** 非接口返回-对应的左侧菜单数据 */
  leftMenuList: object = {};

  /** 非接口返回-当前激活的首级菜单 */
  currentFirstMenu: string = '';

  /** 非接口返回-按钮权限列表 */
  permissionList: string[] = [];
}

/**
 * 菜单返回集合对象
 */
export interface UserMenuItem {
  /**
   * 子节点
   */
  children?: UserMenuItem[];
  /**
   * 图标
   */
  icon?: string;
  /**
   * 菜单id
   */
  id?: number;
  /**
   * 菜单名称
   */
  menuName?: string;
  /**
   * 权限标识
   */
  perms: string;
  /**
   * 父级编号
   */
  pid?: number;
  /**
   * 显示状态
   */
  showStatus?: boolean;
  /**
   * 排序
   */
  sort?: number;
  /**
   * 类型
   */
  type?: string;
  /**
   * URL地址
   */
  url?: string;
}
