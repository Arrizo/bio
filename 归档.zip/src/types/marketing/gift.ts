/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-14 15:23:27
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-23 15:10:21
 * @FilePath: \oms-admin\src\types\marketing\gift.ts
 * @Description: 这是默认设置请设置`customMade` 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
export class SpecSearchType{
  pageNum:number= 1
  pageSize:number=10
  products: string=''
  productTitle: string=''
  specs: string=''
  specTitle: string=''
  status: boolean=true
  valid:boolean= true
  auditStatus:string=''
  specCode:string= ''
}
// 赠品搜索类型

export class GiftSearchType {
  activityCode: string = ''
  activityName: string = ''
  activityType: string = ''
  endTime: string = ''
  pageNum: number = 1
  pageSize: number = 10
  startTime: string = ''
  way: string = ''
  auditStatus: string = ''
  time: Array<string> = []
}
// 赠品列表搜索类型
export class GiftListType {
  activityCode: string = ''
  activityName: string = ''
  activityTimeDimensionality: string = ''
  activityTimeRule: string = ''
  activityTimeType: string = ''
  activityType: string = ''
  auditStatus: string = ''
  createTime: string = ''
  endTime: string = ''
  id: string = ''
  isSave:boolean = false
  maxPrice: string = ''
  minPrice: string = ''
  multiGifts: string = ''
  multipleGift: string = ''
  numbers: Array<string> = []
  presentScheduleTimeAndDayBO?: {
    endTime: string
    startTime: string
  }
  remark: string = ''
  scope: string = ''
  sort: string = ''
  startTime: string = ''
  updateTime: string = ''
  way: string = ''
  numberNames:Array<string> = []
}
// 商品明细请求参数
export class GiftActityGoodsSearch {
  [propName: string]: any
  activityId: string = ''
  pageNum: number = 1
  pageSize: number = 10
  type: string = ""
  total=0
}
// 	活动赠品
export class ActivityGiftitemType extends SpecSearchType {
  [propName: string]: any
  limitedNumber: string = ''
  number: string = ''
  skuCode: string = ''
}
//活动商品
export class ActivityGoodsitemType extends SpecSearchType{
  [propName: string]: any
  purchaseNumber: string = ''
  skuCode: string = ''
}
//店铺集合
export class ActivityStoreitemType {
  id: string = ''
  storeCode: string = ''
  storeName: string = ''
  pageNum:number=1
  pageSize:number=10
}
 class timeTypeObj {
  endTime: string=''
  startTime: string=''
}
// 括号关系
export class  lstStrategyConfigAddType {
  backBracket: string=''
  conditionField: string=''
  conditionValue: string=''
  frontBracket: string=''
  logicCharacter: string=''
  relation: string=''
} 
export class AddMarketingGiftType {
  activityName: string = ''
  activityTimeDimensionality: string = ''
  activityTimeRule: string = ''
  activityTimeType: string = ''
  activityType: string = ''
  endTime: string = ''
  fragmentSql: string = ''
  isSave: boolean = false
  maxPrice: any=''
  minPrice: any=''
  id?:any=0
  multiGifts: boolean = false
  multipleGift: boolean = false
  numbers: Array<string> = []
  numberNames: Array<string> = []
  presentActivityPresentAddBOS: Array<ActivityGiftitemType> = []
  presentActivityProducAddBOS: Array<ActivityGoodsitemType> = []
  presentScheduleTimeAndDayBO: timeTypeObj = new timeTypeObj()
  remark: string = ''
  scope: string = ''
  sort?: number
  startTime: string = ''
  stores: Array<ActivityStoreitemType> = []
  way: string = ''
  time:Array<string>=[]
  lstStrategyConfigAdd:Array<lstStrategyConfigAddType>=[]
}

