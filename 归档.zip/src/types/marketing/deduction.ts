/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-20 14:34:06
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-21 09:35:57
 * @FilePath: \oms-admin\src\types\marketing\deduction.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
/**
 * 抵扣策略的字段
 */

export class DeductionSearchType{
  auditStatus: string='all'
  deductionMethod: string=''
  endTime: string=''
  pageNum:number=1
  pageSize:number=10
  startTime: string=''
  strategyCode: string=''
  strategyName:string=''
  time:Array<string>=[]
}

export class DeductionListItemType {
  backBracket: string=''
  conditionField: string=''
  conditionValue: string=''
  frontBracket: string=''
  logicCharacter: string=''
  relation: string=''
}
 export class DeductionListType{
  auditStatus: string=''
  createTime: string=''
  dateType: string=''
  dateTypeName: string=''
  deductionMethod: string=''
  deductionMethodName: string=''
  deductionNum:string=''
  endTime: string=''
  id:string=''
  rejectionRule: string=''
  rejectionRuleName: string=''
  remark: string=''
  sort:string=''
  startTime: string=''
  storeId: string=''
  storeName: string=''
  strategyCode: string=''
  strategyConfigList:Array<DeductionListItemType>=[]
  strategyName: string=''
  updateTime: string=''
}
export class AddDeductionListType {
  dateType: string=''
  deductionMethod: string=''
  deductionNum:  string=''
  endTime: string=''
  id?: any
  rejectionRule: string=''
  remark: string=''
  sort?: number
  startTime: string=''
  storeId:  string=''
  strategyConfigList: Array<DeductionListItemType>=[]
  strategyName: string=''
  submitType: string='1'
}