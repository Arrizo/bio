/**
 * 商品属性分页查询对象
 */
export class CombinationListForm {
  /**
   * 审核状态:STASH-草稿，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过   all-全部
   */
  auditStatus: AuditStatus | string = 'all';
  /**
   * 组合编码
   */
  combinationCode?: string;
  /**
   * 组合名称
   */
  combinationName?: string;
  pageNum: number = 1;
  pageSize: number = 10;
  /**
   * 启用状态   all-全部
   */
  status: boolean | string = "all";
}

/**
 * 审核状态:STASH-暂存，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
 */
export enum AuditStatus {
  AUDIT_PASS = '通过',
  NO_PASS = '不通过',
  STASH = '暂存',
  WAIT_AUDIT = '待审核',
}

/**
 * 1 主商品 2赠品  '
 */
export enum MasterProduct {
  '是' = 1,
  '否',
}

/**
 * PageResult«组合商品分页对象»
 */
export class CombinationListRes {
  pageNum?: number;
  pageSize?: number;
  result?: CombinationData[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 组合商品分页对象
 */
export class CombinationData {
  /**
   * 审核状态:STASH-草稿，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
   */
  auditStatus?: AuditStatus;
  /**
   * 组合编码
   */
  combinationCode?: string;
  /**
   * 组合名称
   */
  combinationName?: string;
  /**
   * ID
   */
  id?: number;
  /**
   * 预包装
   */
  prePackaging?: boolean;
  /**
   * 备注
   */
  remark?: string;
  /**
   * sku随机组合
   */
  skuRandomCombination?: boolean;
  /**
   * 启用状态
   */
  status?: boolean;
  /**
   * 绑定店铺id
   */
  storeId?: number;
  /**
   * 绑定店铺名称
   */
  storeName?: number;
  /**
   * 更新时间
   */
  updateTime?: string;
}

/**
 * 组合商品详情对象_1
 */
export class CombinationDetail {
  /**
   * 附件
   */
  attachment?: string;
  /**
   * 条码
   */
  barcode?: string;
  /**
   * 组合编码
   */
  combinationCode?: string;
  /**
   * 组合名称
   */
  combinationName?: string;
  /**
   * 高（cm）
   */
  height?: number;
  /**
   * ID
   */
  id: number = -1;
  /**
   * 长（cm）
   */
  length?: number;
  /**
   * 主图
   */
  mainPicture?: string;
  /**
   * 图片
   */
  picture?: string;
  /**
   * 预包装
   */
  prePackaging?: boolean;
  /**
   * sku随机组合
   */
  skuRandomCombination?: boolean;
  /**
   * 组合商品集合
   */
  specList?: CombinationSpecDetail[];
  /**
   * 绑定店铺id
   */
  storeId?: number;
  /**
   * 体积
   */
  volume?: number;
  /**
   * 重量（g）
   */
  weight?: number;
  /**
   * 宽（cm）
   */
  width?: number;
}

/**
 * 组合商品详情对象
 */
export class CombinationSpecDetail {
  /**
   * 分摊比例
   */
  apportionmentRatio?: number;
  /**
   * 组合商品表关联ID
   */
  combinationId?: number;
  /**
   * ID
   */
  id?: number;
  /**
   * 主商品标识
   */
  masterProduct?: boolean;
  /**
   * 数量
   */
  number?: number;
  /**
   * 商品编码
   */
  productCode?: string;
  /**
   * 商品ID
   */
  productId?: number;
  /**
   * 规格编码
   */
  specCode?: string;
  /**
   * 规格ID
   */
  specId?: number;
  /**
   * 规格型号
   */
  specModel?: string;
  /**
   * 规格名称
   */
  specName?: string;
}

/**
 * 审核BO
 */
export class AuditByIdListForm {
  /**
   * 审核节点
   */
  auditNode?: string;
  /**
   * 审核状态
   */
  auditStatus: boolean | string = 'true';
  /**
   * 数据ID集合
   */
  id?: number;
  /**
   * 数据ID集合
   */
  lstId?: number[];
  /**
   * 备注
   */
  remark?: string;
}

/**
 * 组合商品审核对象
 */
export class AuditByIdListRes {
  /**
   * 跳过数量
   */
  skipNum?: number;
  /**
   * 审核成功数量
   */
  successNum?: number;
}

/**
 * 组合商品添加或编辑对象
 */
export class AddOrUpdateForm {
  /**
   * 附件
   */
  attachment?: string;
  /**
   * 条码
   */
  barcode?: string;
  /**
   * 组合编码
   */
  combinationCode: string = '';
  /**
   * 组合名称
   */
  combinationName: string = '';
  /**
   * 高（cm）
   */
  height?: number | string;
  /**
   * ID，有值为编辑，没值为新增
   */
  id?: number;
  /**
   * 长（cm）
   */
  length?: number | string;
  /**
   * 图片
   */
  pictureList?: string;
  /**
   * 预包装
   */
  prePackaging?: boolean;
  /**
   * 商品集合
   */
  specList: SpecListItem[] = [];
  /**
   * sku随机组合
   */
  skuRandomCombination?: boolean;
  /**
   * 绑定店铺id
   */
  storeId?: number;
  /**
   * 提交类型 1提交 2暂存
   */
  submitType?: number;
  /**
   * 体积
   */
  volume?: number | string;
  /**
   * 重量（g）
   */
  weight?: number | string;
  /**
   * 宽（cm）
   */
  width?: number | string;

  //多余的，为兼容
  createTime?: string;
  updateTime?: string;
}

/**
 * 组合商品规格对象
 */
export class SpecListItem {
  /**
   * 分摊比例
   */
  apportionmentRatio?: number;
  /**
   * 组合商品表关联ID
   */
  combinationId?: number;
  /**
   * 编辑时传值
   */
  id?: number;
  /**
   * 主商品标识
   */
  masterProduct: number | string = '';
  /**
   * 商品编码
   */
  productCode?: string;
  /**
   * 商品名称
   */
  productTitle?: string;
  /**
   * 商品ID
   */
  productId?: number;
  /**
   * 规格编码
   */
  specCode: string = '';
  /**
   * 规格型号
   */
  specModel: string = '';
  /**
   * 规格名称
   */
  specName: string = '';
  /**
   * 规格ID
   */
  specId?: number;
  /**
   * 数量
   */
  number?: number;

  //单元格合并
  rowSpan?: number;
}

/**
 * 商品和规格规格列表信息
 */
export class ProductSpecItem {
  /**
   * 商品编码
   */
  productCode?: string;
  /**
   * 商品名称
   */
  productTitle?: string;
  /**
   * 规格编码
   */
  specsCode: string = '';
  /**
   * 规格型号
   */
  specsModel: string = '';
  /**
   * 规格名称
   */
  specsTitle: string = '';
  /**
   * 数量
   */
  number?: number;
  //单元格合并
  rowSpan?: number;
}
