/**
 * @ Author: Sam
 * @ Create Time: 2023-02-28 09:08:42
 * @ Modified by: Sam
 * @ Modified time: 2023-03-15 09:51:24
 * @ Description: 商品档案-类型
 */

/**
 * 商品档案搜索bo
 */
export class GoodsSearchForm {
  /**
   * 审核状态
   */
  auditStatus: AuditStatus | '' = AuditStatus.All;
  /**
   * 分类id
   */
  categoryId?: number | '' = '';
  /**
   * 编码
   */
  code?: string;
  /**
   * 是否代发
   */
  dispatch?: string | 'all' = 'all';
  /**
   * 文件名称
   */
  fileName?: string;
  /**
   * k3推送状态
   */
  k3PushStatus: K3PushStatus | '' = K3PushStatus.All;
  /**
   * 页码
   */
  pageNum: number = 1;
  /**
   * 页条数
   */
  pageSize: number = 10;
  /**
   * 是否启用
   */
  status?: string | 'all' = 'all';
  /**
   * 名称
   */
  title: string = '';
  /**
   * wms 同步状态
   */
  wmsSyncStatus: WmsSyncStatus | '' = WmsSyncStatus.All;
}

/**
 * PageResult«商品概览vo»
 */
export interface GoodsListRes {
  pageNum?: number;
  pageSize?: number;
  result?: GoodsListItem[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 商品概览vo
 */
export interface GoodsListItem {
  /**
   * 商品条码
   */
  barCode?: string;
  /**
   * 品牌名称
   */
  brandName?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 推送k3状态
   */
  k3Status?: K3Status;
  /**
   * 主图
   */
  mainPicture?: string;
  /**
   * 商品编码
   */
  productCode?: string;
  /**
   * 商品名称
   */
  productTitle?: string;
  /**
   * 启用状态
   */
  status?: boolean;
  /**
   * 同步wms状态
   */
  syncWmsStatus?: SyncWmsStatus;
  /**
   * 更新时间
   */
  updateTime?: Date;
}

/**
 * 推送k3状态
 */
export enum K3Status {
  PART_SUCCESS = '部分成功',
  PUSH_FAIL = '推送失败',
  PUSHED = '推送完成',
  PUSHING = '推送中',
  UN_PUSH = '未推送',
}

/**
 * 同步wms状态
 */
export enum SyncWmsStatus {
  NO_SYNC = '未同步',
  PART_SUCCESS = '部分成功',
  SYNC_FAIL = '同步失败',
  SYNCHRONIZED = '已同步',
  SYNCHRONIZING = '同步中',
}

/**
 * 审核状态
 */
export enum AuditStatusList {
  AUDIT_PASS = '通过',
  NO_PASS = '不通过',
  STASH = '暂存',
  WAIT_AUDIT = '待审核',
}

/**
 * 审核状态
 */
export enum AuditStatus {
  All = 'all',
  AuditPass = 'AUDIT_PASS',
  NoPass = 'NO_PASS',
  Stash = 'STASH',
  WaitAudit = 'WAIT_AUDIT',
}

/**
 * k3推送状态
 */
export enum K3PushStatus {
  All = 'all',
  PartSuccess = 'PART_SUCCESS',
  PushFail = 'PUSH_FAIL',
  Pushed = 'PUSHED',
  Pushing = 'PUSHING',
  UnPush = 'UN_PUSH',
}

/**
 * wms 同步状态
 */
export enum WmsSyncStatus {
  All = 'all',
  NoSync = 'NO_SYNC',
  PartSuccess = 'PART_SUCCESS',
  SyncFail = 'SYNC_FAIL',
  Synchronized = 'SYNCHRONIZED',
  Synchronizing = 'SYNCHRONIZING',
}

/**
 * 商品添加bo
 */
export class GoodsForm {
  productCode?: string;
  /**
   * 附件
   */
  attachment?: string;
  /**
   * 商品条码
   */
  barCode?: string;
  /**
   * 品牌id
   */
  brandId?: number;
  /**
   * 分类id
   */
  categoryId?: number;
  /**
   * 默认税率id
   */
  defaultTaxRateId?: number;
  /**
   * 是否一件代发
   */
  dispatch: boolean = false;
  /**
   * 启用效期批次管理
   */
  effectiveBatch?: boolean;
  /**
   * 有效期：天
   */
  effectiveDay?: number;
  /**
   * 英文名称
   */
  englishTitle: string = '';
  /**
   * 毛重
   */
  grossWeight?: number;
  /**
   * 高度
   */
  height?: number;
  /**
   * 京东分类id
   */
  jdCategoryId?: number;
  /**
   * 长度
   */
  length?: number;
  /**
   * 主图
   */
  mainPicture: string = '';
  pictures: string[] = [];
  /**
   * 图片
   */
  picture: string[] = [];
  /**
   * 商品名称
   */
  productTitle: string = '';
  /**
   * 商品类型 PHYSICAL:实物商品  VIRTUAL:虚拟商品  PACKAGING:包装材料  ACCESSORY:辅料耗材
   */
  productType?: ProductType;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 商品简称
   */
  shortTitle: string = '';
  /**
   * 净重
   */
  suttle?: number;
  /**
   * 启用唯一码管理
   */
  uniqueCode?: boolean;
  /**
   * 计量单位id
   */
  unitId?: number;
  /**
   * 体积
   */
  volume?: number | string;
  /**
   * 宽度
   */
  width?: number;
}

/**
 * 商品类型 PHYSICAL:实物商品  VIRTUAL:虚拟商品  PACKAGING:包装材料  ACCESSORY:辅料耗材
 */
export enum ProductType {
  Accessory = 'ACCESSORY',
  Packaging = 'PACKAGING',
  Physical = 'PHYSICAL',
  Virtual = 'VIRTUAL',
}

/**
 * 商品规格vo
 */
export interface SpecsListItem {
  /**
   * 审核状态
   */
  auditStatus?: string;
  /**
   * 条码
   */
  barCode?: string;
  /**
   * 代发采购价
   */
  dispatchPurchasePrice?: number;
  /**
   * 集采入仓价
   */
  focusPurchasePrice?: number;
  /**
   * 规格id
   */
  id?: number;
  /**
   * 推送k3状态
   */
  k3Status?: string;
  /**
   * 主图
   */
  mainPicture?: string;
  /**
   * 商品id
   */
  productId?: number;
  /**
   * 发货箱规
   */
  shippingBoxGauge?: string;
  /**
   * 规格编码
   */
  specsCode?: string;
  /**
   * 型号
   */
  specsModel?: string;
  /**
   * 规格名称
   */
  specsTitle?: string;
  /**
   * 启用状态
   */
  status?: boolean;
  /**
   * 同步wms状态
   */
  syncWmsStatus?: string;
  /**
   * 吊牌价/面值
   */
  tagPrice?: number;
}

/**
 * 规格新增
 */
export class SpecForm {
  pictures: string[] = [];
  specsCode?: string;
  /**
   * 附件
   */
  attachment?: string;
  /**
   * 条码
   */
  barCode?: string;
  /**
   * 包装纸箱编码
   */
  cartonPackagingCode?: string;
  /**
   * 纸箱规格型号
   */
  cartonPackagingModel?: string;
  /**
   * 包装纸箱skuId
   */
  cartonPackagingSkuId?: number;
  /**
   * 开发者用户id
   */
  developerId?: number;
  /**
   * 开发者名称
   */
  developerName?: string;
  /**
   * 代发采购价
   */
  dispatchPurchasePrice?: number;
  /**
   * 集采入仓价
   */
  focusPurchasePrice?: number;
  /**
   * 毛重
   */
  grossWeight?: number;
  /**
   * 高度
   */
  height?: number;
  /**
   * 长度
   */
  length?: number;
  /**
   * 物流保价
   */
  logisticsInsured?: number;
  /**
   * 操作类型 1：提交  2：暂存
   */
  operateType?: number;
  /**
   * 图片
   */
  picture?: string[];
  /**
   * 商品id
   */
  productId?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 发货箱规
   */
  shippingBoxGauge?: number;
  /**
   * 型号
   */
  specsModel?: string;
  /**
   * 规格名称
   */
  specsTitle: string = '';
  /**
   * 建议零售价
   */
  suggestRetailPrice?: number;
  /**
   * 净重
   */
  suttle?: number;
  /**
   * 吊牌价/面值
   */
  tagPrice?: number;
  /**
   * 体积
   */
  volume?: number;
  /**
   * 宽度
   */
  width?: number;
}

/**
 * 待审核sku查询
 */
export class AuditSkuSearchForm {
  /**
   * 编码
   */
  code?: string = '';
  /**
   * 名称
   */
  name?: string = '';
  /**
   * 页码
   */
  pageNum: number = 1;
  /**
   * 分页数
   */
  pageSize: number = 10;
}

/**
 * PageResult«商品规格vo»
 */
export interface AuditSkuRes {
  pageNum?: number;
  pageSize?: number;
  result: AuditSkuListItem[];
  totalCount: number;
  totalPage?: number;
}

/**
 * 商品规格vo
 */
export interface AuditSkuListItem {
  /**
   * 审核状态
   */
  auditStatus?: string;
  /**
   * 条码
   */
  barCode?: string;
  /**
   * 代发采购价
   */
  dispatchPurchasePrice?: number;
  /**
   * 集采入仓价
   */
  focusPurchasePrice?: number;
  /**
   * 规格id
   */
  id?: number;
  /**
   * 推送k3状态
   */
  k3Status?: string;
  /**
   * 主图
   */
  mainPicture?: string;
  /**
   * 商品id
   */
  productId?: number;
  /**
   * 发货箱规
   */
  shippingBoxGauge?: string;
  /**
   * 规格编码
   */
  specsCode?: string;
  /**
   * 型号
   */
  specsModel?: string;
  /**
   * 规格名称
   */
  specsTitle?: string;
  /**
   * 启用状态
   */
  status?: boolean;
  /**
   * 同步wms状态
   */
  syncWmsStatus?: string;
  /**
   * 吊牌价/面值
   */
  tagPrice?: number;
}

/**
 * sku审核bo
 */
export class BatchAuditForm {
  /**
   * 审核状态 true：通过  false：失败
   */
  auditStatus: boolean | string = 'true';
  /**
   * 备注
   */
  remark?: string;
  /**
   * skuId
   */
  skuId?: number[];
}

/**
 * 商品规格详情
 */
export interface SpecDetail {
  suppliers: any[];
  pictures: string[];
  /**
   * 附件
   */
  attachment?: string;
  /**
   * 条码
   */
  barCode?: string;
  /**
   * 包装纸箱编码
   */
  cartonPackagingCode?: string;
  /**
   * 纸箱规格型号
   */
  cartonPackagingModel?: string;
  /**
   * 包装纸箱skuId
   */
  cartonPackagingSkuId?: number;
  /**
   * 开发者用户id
   */
  developerId?: number;
  /**
   * 开发者名称
   */
  developerName?: string;
  /**
   * 代发采购价
   */
  dispatchPurchasePrice?: number;
  /**
   * 集采入仓价
   */
  focusPurchasePrice?: number;
  /**
   * 毛重
   */
  grossWeight?: number;
  /**
   * 高度
   */
  height?: number;
  /**
   * id
   */
  id?: number;
  /**
   * 长度
   */
  length?: number;
  /**
   * 物流保价
   */
  logisticsInsured?: number;
  /**
   * 主图
   */
  mainPicture?: string;
  /**
   * 图片
   */
  picture?: string[];
  /**
   * 商品id
   */
  productId?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 发货箱规
   */
  shippingBoxGauge?: string;
  /**
   * 规格编码
   */
  specsCode?: string;
  /**
   * 型号
   */
  specsModel?: string;
  /**
   * 规格名称
   */
  specsTitle?: string;
  /**
   * 启用状态
   */
  status?: boolean;
  /**
   * 建议零售价
   */
  suggestRetailPrice?: number;
  /**
   * 净重
   */
  suttle?: number;
  /**
   * 吊牌价/面值
   */
  tagPrice?: number;
  /**
   * 体积
   */
  volume?: number;
  /**
   * 宽度
   */
  width?: number;
}

/**
 * 供应商列表VO_1
 */
export interface SupplierItem {
  defaultSupplier?: boolean;
  /**
   * ID
   */
  id?: number;
  /**
   * 供应商编码
   */
  supplierCode?: string;
  /**
   * 供应商名称
   */
  supplierName?: string;
}

/**
 * 规格供应商添加BO
 */
export interface AddSupplierForm {
  /**
   * 操作类型
   */
  optType?: number;
  /**
   * 规格id
   */
  skuId?: number;
  /**
   * 供应商信息
   */
  suppliers?: SupplierInfo[];
}

/**
 * 供应商添加信息
 */
export interface SupplierInfo {
  /**
   * 是否默认
   */
  defaultSupplier?: boolean;
  /**
   * 供应商id
   */
  supplierId?: number;
}

/**
 * 商品属性vo
 */
export interface AttrItem {
  dictionaryType?: string;
  id: string;
  /**
   * 属性名称
   */
  attrName?: string;
  /**
   * 属性值
   */
  content?: string[];
  /**
   * 类型
   */
  type?: string;
}
