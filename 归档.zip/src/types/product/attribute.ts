/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-03 17:56:00
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-06 10:55:40
 * @FilePath: \oms-admin\src\types\product\attribute.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
/**
 * 商品属性分页查询对象_1
 */
 export class AttributeSearchType {
  /**
   * 属性名称
   */
  attrName?: string='';
  pageNum: number=1;
  pageSize: number=10;
  /**
   * 状态
   */
  status?: any='all';
}
/**
 * 商品属性对象
 */
 export class AttributeDetailsType {
  /**
   * 属性名称
   */
  attrName?: string;
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 数据字典名称
   */
  dictionaryName?: string;
  /**
   * 数据字典类型
   */
  dictionaryType: string='';
  /**
   * ID
   */
  id?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 输入类型1:字典 2:文本
   */
  inputType: string='dataDictionary';
  /**
   * 更新时间
   */
  updateTime?: Date;
    /**
   * 日志
   */
  logCode:string=''
}