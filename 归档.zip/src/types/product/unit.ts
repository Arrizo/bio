/**
 * @ Author: Sam
 * @ Create Time: 2023-02-25 13:36:08
 * @ Modified by: Sam
 * @ Modified time: 2023-03-09 09:35:57
 * @ Description: 计量单位-类型
 */

/**
 * 计量单位BO
 */
export class UnitForm {
  /**
   * 单位编码
   */
  code: string = '';
  /**
   * id
   */
  id: number = NaN;
  /**
   * 单位名称
   */
  name?: string;
  /**
   * 备注
   */
  remark?: string;
}

export class UnitSearchForm {
  /**
   * 单位名称
   */
  name?: string = '';
  pageNum?: number = 1;
  pageSize?: number = 10;
  /**
   * 状态
   */
  status: string = 'all';
}

/**
 * PageResult«计量单位»
 */
export interface UnitListRes {
  pageNum?: number;
  pageSize?: number;
  result: UnitItem[];
  totalCount: number;
  totalPage?: number;
}

/**
 * 计量单位
 */
export interface UnitItem {
  /**
   * 单位编码
   */
  code?: string;
  createTime?: Date;
  creatorId?: number;
  id?: number;
  /**
   * 单位名称
   */
  name?: string;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 状态
   */
  status?: boolean;
  updaterId?: number;
  updateTime?: Date;
  valid?: boolean;
  version?: number;
}
