/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-23 15:05:47
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-17 14:53:50
 * @FilePath: \oms-admin\src\types\product\purchase.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
/**
 * AdjustPricePageBO
 */
export class PurchaseSeachType {
  /**
   * 审核状态
   */
  auditStatus?: string = 'all';
  /**
   * spu/sku编码
   */
  code?: string = '';
  /**
   * spu/sku名称
   */
  name?: string = '';
  /**
   * 采购组织
   */
  organization?: string = '';
  pageNum: number = 1;
  pageSize: number = 10;
  /**
   * 状态
   */
  status?: string = 'all';
  /**
   * 供应商编码/名称
   */
  supplier?: string;
  startTime: string = ''
  endTime: string = ''
  time: Array<string> = []
}



/**
* AdjustPricePageVO
*/
export class PurchaseListType {
  [propName: string]: any
  /**
   * 审核id
   */
  id?: number;
  /**
   * 审核状态
   */
  auditStatus?: string;
  /**
   * 编码标识符，用来查询日志
   */
  code?: string;
  /**
   * 采购组织
   */
  organization?: string;
  /**
   * 采购价
   */
  price: any;
  /**
   * 规格编码
   */
  skuCode?: string;
  /**
   * 规格名称
   */
  skuName?: string;
  /**
   * 规格型号
   */
  skuType?: string;
  /**
   * 商品编码
   */
  spuCode?: string;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 供应商编码
   */
  supplierCode?: string;
  /**
   * 供应商名称
   */
  supplierName?: string;
  /**
   * 税率
   */
  taxRate?: string;
  /**
   * 单位
   */
  unit?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
}
/**
 * AdjustPriceAddBO 新增
 */
export class AddjustPriceType {
  adjustPriceRecordAddBO: AdjustPriceRecordAddBO = new AdjustPriceRecordAddBO();
  /**
   * 采购组织
   */
  organization?: string;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 规格编码
   */
  skuCode: string = '';
  /**
   * 商品编码
   */
  spuCode?: string;
  /**
   * 供应商编码
   */
  supplierCode: string = ''
  supplierName: string = ''
  specsModel: string = ''
  specsTitle: string = ''
}

/**
* AdjustPriceRecordAddBO
*/
export class AdjustPriceRecordAddBO {
  [propName: string]: any
  /**
   * 调价原因
   */
  cause: string='';
  /**
   * 折扣
   */
  discount: string = '';
  /**
   * 失效时间
   */
  endTime: string = '';
  /**
   * 调价记录表Id(无id为新增，有id为编辑)
   */
  id?: number;
  /**
   * 阶梯数量最大值
   */
  maxNum: string|number='';
  /**
   * 价格上限
   */
  maxPrice: string = '';
  /**
   * 阶梯数量最小值
   */
  minNum: string|number = '';
  /**
   * 价格下限
   */
  minPrice: string = '';
  /**
   * 采购价
   */
  price: string = '';
  /**
   * 调价表标识Id
   */
  relationId?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 生效时间
   */
  startTime: string = '';
  /**
   * 店铺编码
   */
  storeCode: string='';
  /**
   * 店铺名称
   */
  storeName?: string;
  /**
   * 标识
   */
  tag?: string;
  /**
   * 税率
   */
  taxRate: string = '';
  /**
   * 调价类型
   */
  type?: string;
  /**
   * 单位
   */
  unit?: string;
  /**
   * 单位
   */
  auditStatus?: number;
}
//商品列表數據類型
// 表格数据类型
export class goodsTableDataType {
  productCode: string = ''
  productTitle: string = ''
  specsCode: string = ''
  specsModel: string = ''
  specsTitle: string = ''
}
// 供应商表格数据类型
export class SupplierTableDataType {
  id: number = 0
  supplierCode: string = ""
  supplierName: string = ""
}
/**
 * 调价审核
 */
export class PurchaseAuditType {
  /**
   * 审核节点
   */
  auditNode: string = '';
  /**
   * 审核状态
   */
  auditStatus: any = 1;
  /**
   * 数据ID集合
   */
  id: string='';
  /**
   * 数据ID集合
   */
  lstId: number[] = [];
  /**
   * 备注
   */
  remark: string='';
}

/**
 * AdjustPriceRecordPageBO
 */
export class AdjustRecordSearch {
  [propName: string]: any
  /**
   * 审核状态 0-暂存，1-待审核，2-审核不通过，3-待确认，4-确认不通过，5-上线，6-下线
   */
  auditStatus: any='all';
  /**
   * 失效时间
   */
  endTime:string='';
  /**
   * 最大采购价
   */
  maxPrice: string = '';
  /**
   * 最小采购价
   */
  minPrice: string = '';
  pageNum: number = 1;
  pageSize: number = 10000;
  /**
   * 调价表Id
   */
  relationId: string = '';
  /**
   * 生效时间
   */
  startTime: string='';
}
export class PriceRecordAuditPageClass {
  /**
 * 审核状态 0-暂存，1-待审核，2-审核不通过，3-待确认，4-确认不通过，5-上线，6-下线
 */
  auditStatus?: number;
  code: string = ''
  organization: string = ''
  pageNum: number = 1
  pageSize: number = 10000
  skuName: string = ''
  supplier: string = ''
}
export class AuditTypeClass {
  [propName: string]: any
  titleName?: string
  lableName?: string
  content?: string
  auditNode: string = ''
  lstId: Array<string> = []

}
