/**
 * @ Author: Sam
 * @ Create Time: 2023-02-25 13:36:08
 * @ Modified by: Sam
 * @ Modified time: 2023-03-13 17:47:56
 * @ Description: 商品分类-类型
 */

export class CategorySearcForm {
  status: string = 'all';
  title: string = '';
}

/**
 * 商品分类
 */
export interface CategoryListItem {
  children?: CategoryListItem[];
  code?: string;
  createTime?: Date;
  creatorId?: number;
  id?: number;
  pid?: number;
  remark?: string;
  sort?: number;
  status?: boolean;
  title?: string;
  updaterId?: number;
  updateTime?: Date;
  valid?: boolean;
  version?: number;
}

/**
 * 商品分类添加bo
 */
export class CategoryForm {
  code?: string;
  id?: number;
  /**
   * 上级品类id
   */
  pid?: number | '';
  /**
   * 备注
   */
  remark?: string;
  /**
   * 排序号
   */
  sort?: number = 99;
  /**
   * 名称
   */
  title: string='';
}
