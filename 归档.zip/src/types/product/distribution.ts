/**
 * 列表查询
 */
export class DistributionReq {
  /**
   * 审核状态
   */
  auditStatus?: number | string = 'all';
  /**
   * 业务类型
   */
  businessType?: string;
  /**
   * 编码
   */
  code?: string;
  /**
   * 店铺编码
   */
  lstStoreCode?: string[] = [];
  /**
   * 名称
   */
  name?: string = '';
  pageNum?: number = 1;
  pageSize?: number = 10;
  /**
   * 状态 true启用 false禁用
   */
  status?: boolean | string = 'all';
}

// 查询店铺列表
export class ShopSelectItem {
  id: string = '';
  storeCode: string = '';
  storeName: string = '';
  owner: string = '';
  show:boolean=false;
  status:boolean=false;
}

/**
 * PageResult«DistributionType»
 */
export interface DistributionRes {
  pageNum?: number;
  pageSize?: number;
  result?: DistributionType[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 列表查询类型
 */
export class DistributionType {
  /**
   * 审核状态
   */
  auditStatus?: number;
  /**
   * 业务类型
   */
  businessType?: string;
  /**
   * 业务类型名称
   */
  businessTypeName?: string;
  /**
   * 是否组合商品
   */
  combination?: boolean;
  /**
   * 生效时间
   */
  effectiveTime?: Date;
  /**
   * 数据id
   */
  id?: number;
  /**
   * 失效时间
   */
  invalidTime?: Date;
  /**
   * 平台商品ID
   */
  platformProductId?: string;
  /**
   * 平台商品名称
   */
  platformProductName?: string;
  /**
   * 平台规格ID
   */
  platformSkuId?: string;
  /**
   * 平台规格名称
   */
  platformSkuName?: string;
  /**
   * 铺货单价
   */
  price?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 商品/组合编码
   */
  skuCode?: string;
  /**
   * 商品/组合名称
   */
  skuName?: string;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 店铺编码
   */
  storeCode?: string;
  /**
   * 店铺名称
   */
  storeName?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
}

/**
 * 调价记录列表查询
 */
export class PriceRecordReq {
  /**
   * 审核状态
   */
  auditStatus?: number | string = 'all';
  /**
   * 业务类型
   */
  businessType?: string = 'all';
  /**
   * 生效时间
   */
  effectiveTime?: Date | string;
  /**
   * 失效时间
   */
  invalidTime?: Date | string;
  /**
   * 铺货单价最大值
   */
  maxPrice?: number;
  /**
   * 铺货单价最小值
   */
  minPrice?: number;
  /**
   * 铺货关系ID
   */
  mpId?: number;
  pageNum?: number = 1;
  pageSize?: number = 10;
}

/**
 * PageResult«MallPricePageVO»
 */
export interface PriceRecordRes {
  pageNum?: number;
  pageSize?: number;
  result?: PriceRecordType[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 调价记录列表查询类型
 */
export interface PriceRecordType {
  /**
   * 审核状态
   */
  auditStatus?: number;
  /**
   * 业务类型
   */
  businessType?: string;
  /**
   * 业务类型名称
   */
  businessTypeName?: string;
  /**
   * 生效时间
   */
  effectiveTime?: Date;
  /**
   * 数据id
   */
  id?: number;
  /**
   * 失效时间
   */
  invalidTime?: Date;
  /**
   * 日志编码
   */
  logCode?: string;
  /**
   * 铺货单价
   */
  price?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
}

/**
 * 新增铺货关系
 */
export class DistributionFrom {
  /**
   * 业务类型
   */
  businessType?: string;
  /**
   * 是否组合
   */
  combination: string = '';
  /**
   * 生效时间
   */
  effectiveTime?: Date;
  /**
   * 失效时间
   */
  invalidTime?: Date;
  /**
   * 负责人
   */
  owner?: string;
  /**
   * 平台商品ID
   */
  platformProductId?: string;
  /**
   * 平台商品名称
   */
  platformProductName?: string;
  /**
   * 平台规格ID
   */
  platformSkuId?: string;
  /**
   * 平台规格名称
   */
  platformSkuName?: string;
  /**
   * 铺货单价
   */
  price?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 负责部门
   */
  responsibleDept?: string;
  /**
   * 商品/组合编码
   */
  skuCode: string='';
  /**
   * 商品/组合名称
   */
  skuName?: string;
  /**
   * 店铺编码
   */
  storeCode?: string;
  /**
   * 店铺名称
   */
  storeName?: string;
  storeId?: number;
}
/**
 * 编辑铺货关系
 */
export class DistributionEditFrom {
  /**
   * 数据ID
   */
  id?: number;
  /**
   * 平台商品名称
   */
  platformProductName?: string;
  /**
   * 平台规格名称
   */
  platformSkuName?: string;
  /**
   * 备注
   */
  remark?: string = '';
  /**
   * 负责部门
   */
  responsibleDept?: string;
}

/**
 *铺货关系审核
 */
export class AuditMappingFrom {
  /**
   * 审核节点
   */
  auditNode?: string;
  /**
   * 审核状态
   */
  auditStatus?: boolean | string = '';
  /**
   * 数据ID集合
   */
  id?: number;
  /**
   * 数据ID集合
   */
  lstId: number[] = [];
  /**
   * 备注
   */
  remark?: string;
}

/**
 * 调价审核列表查询
 */
export class AuditPageReq {
  /**
   * 审核状态
   */
  auditStatus?: number;
  /**
   * 业务类型
   */
  businessType?: string = 'all';
  /**
   * 编码
   */
  code?: string;
  /**
   * 店铺编码
   */
  lstStoreCode?: string[];
  /**
   * 名称
   */
  name?: string;
  pageNum?: number = 1;
  pageSize?: number = 10;
  /**
   * 状态
   */
  status?: boolean;
}

/**
 * PageResult«ProductMappingPageVO»
 */
export interface AuditPageRes {
  pageNum?: number;
  pageSize?: number;
  result?: AuditPageType[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * ProductMappingPageVO
 */
export class AuditPageType {
  /**
   * 审核状态
   */
  auditStatus?: number;
  /**
   * 业务类型
   */
  businessType?: string;
  /**
   * 业务类型名称
   */
  businessTypeName?: string;
  /**
   * 是否组合商品
   */
  combination?: boolean;
  /**
   * 生效时间
   */
  effectiveTime?: Date;
  /**
   * 数据id
   */
  id?: number;
  /**
   * 失效时间
   */
  invalidTime?: Date;
  /**
   * 平台商品ID
   */
  platformProductId?: string;
  /**
   * 平台商品名称
   */
  platformProductName?: string;
  /**
   * 平台规格ID
   */
  platformSkuId?: string;
  /**
   * 平台规格名称
   */
  platformSkuName?: string;
  /**
   * 铺货单价
   */
  price?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 商品/组合编码
   */
  skuCode?: string;
  /**
   * 商品/组合名称
   */
  skuName?: string;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 店铺编码
   */
  storeCode?: string;
  /**
   * 店铺名称
   */
  storeName?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
}

/**
 * 申请调价
 */
export class AddPricesReq {
  /**
   * 业务类型
   */
  businessType?: string;
  /**
   * 生效时间
   */
  effectiveTime?: Date;
  /**
   * 调价id
   */
  id?: number;
  /**
   * 失效时间
   */
  invalidTime?: Date;
  /**
   * 铺货关系id
   */
  mpId?: number;
  /**
   * 铺货单价
   */
  price?: number;
  /**
   * 备注
   */
  remark?: string;
}

/**
 * 商品属性分页查询对象
 */
export class CombinationReq {
  /**
   * 审核状态:STASH-草稿，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
   */
  auditStatus?: AuditStatus;
  /**
   * 组合编码
   */
  combinationCode?: string;
  /**
   * 组合名称
   */
  combinationName?: string;
  pageNum?: number;
  pageSize?: number;
  /**
   * 启用状态
   */
  status?: boolean;
}

/**
 * 审核状态:STASH-草稿，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
 */
export enum AuditStatus {
  AuditPass = 'AUDIT_PASS',
  NoPass = 'NO_PASS',
  Stash = 'STASH',
  WaitAudit = 'WAIT_AUDIT',
}
export class CombinationTableDataType {
  /**
   * 审核状态:STASH-草稿，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
   */
  auditStatus?: AuditStatus;
  /**
   * 组合编码
   */
  combinationCode?: string;
  /**
   * 组合名称
   */
  combinationName?: string;
  /**
   * ID
   */
  id?: number;
  /**
   * 预包装
   */
  prePackaging?: boolean;
  /**
   * 备注
   */
  remark?: string;
  /**
   * sku随机组合
   */
  skuRandomCombination?: boolean;
  /**
   * 启用状态
   */
  status?: boolean;
  /**
   * 绑定店铺id
   */
  storeId?: number;
  /**
   * 绑定店铺名称
   */
  storeName?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
}
