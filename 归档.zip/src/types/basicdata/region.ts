/**
 * 行政区域列表VO
 */
export class RegionData {
  /**
   * 创建时间
   */
  createdTime?: string;
  /**
   * 区域ID
   */
  id?: number;
  /**
   * 层级 1省 2市 3区 4街道
   */
  level?:    number;
  parentId?: number;
  /**
   * 区域编码
   */
  regionCode: string = "";
  /**
   * 区域名称
   */
  regionName?: string;
  /**
   * 区域简称
   */
  shortName?: string;
  /**
   * 更新时间
   */
  updateTime?: string;

  //是否子节点
  isLeaf?: boolean;

  key:string = "";

  children?: RegionData[]
}


/**
 * 地址下拉选项BO
 */
export class GetAddressSelectReq {
  /**
   * 区域最低级别
   */
  level?: number;
  /**
   * 上级ID
   */
  parentId?: number;
}


/**
 * 地址下拉选项返回VO
 */
export class GetAddressSelectRes {
  /**
   * 子区域
   */
  child?: GetAddressSelectRes[];
  /**
   * 区域ID
   */
  id?: number;
  /**
   * 层级
   */
  level?: number;
  parentId?: number;
  /**
   * 区域名称
   */
  regionName?: string;
  /**
   * 区域简称
   */
  shortName?: string;
}


/**
 * 行政区域添加或编辑BO
 */
export class AddOrUpdateRegionReq {
  /**
   * 区域ID
   */
  id?: number | string = "";
  /**
   * 上级ID
   */
  parentId: number | string = "";
  /**
   * 区域编码
   */
  regionCode: string = "";
  /**
   * 区域名称
   */
  regionName?: string;
  /**
   * 区域简称
   */
  shortName?: string;
}
