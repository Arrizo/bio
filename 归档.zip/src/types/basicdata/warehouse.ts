/**
 * 仓库查询bo
 */
export class WarehouseSearchReq {
  /**
   * 页码
   */
  pageNum?: number = 1;
  /**
   * 分页数
   */
  pageSize?: number = 10;
  /**
   * 状态
   */
  status?: boolean|string = 'all';
  /**
   * 实体仓编码
   */
  warehouseCode?: string = '';
  /**
   * 实体仓名称
   */
  warehouseName?: string = '';
  /**
   * 实体仓类型（取字典id）
   */
  warehouseType?: number | string = 'all';
}
/**
 * PageResult«仓库vo»
 */
export interface WarehouseListRes {
  pageNum: number;
  pageSize: number;
  result: WarehouseListItem[];
  totalCount: number;
  totalPage: number;
}

/**
 * 仓库列表
 */
export interface WarehouseListItem {
  /**
   * 详细地址
   */
  address?: string;
  /**
   * 区
   */
  area?: string;
  /**
   * 区id
   */
  areaId?: number;
  /**
   * 市
   */
  city?: string;
  /**
   * 市id
   */
  cityId?: number;
  /**
   * 所属公司字典id
   */
  company?: number;
  /**
   * 货主编码
   */
  consignorCode?: string;
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 单日最大单量
   */
  dayOrderMaxAmount?: number;
  /**
   * 是否支持配货（1：是  0：否）
   */
  distribution?: boolean;
  /**
   * 邮箱
   */
  email?: string;
  /**
   * 默认快递id
   */
  expressId?: number;
  /**
   * 仓库id
   */
  id: number;
  /**
   * 仓库负责人
   */
  owner?: string;
  /**
   * 省
   */
  province?: string;
  /**
   * 省id
   */
  provinceId?: number;
  /**
   * 是否推荐包材（1：是  0：否）
   */
  recommendPackage?: boolean;
  /**
   * -1：删除  0：禁用  1：启用
   */
  status?: boolean;
  /**
   * 仓储供应商名称
   */
  supplierName?: string;
  /**
   * 联系方式
   */
  tel?: string;
  /**
   * 第三方仓库编码
   */
  thirdWarehouseCode?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
  /**
   * 仓库编码
   */
  warehouseCode?: string;
  /**
   * 仓库名称
   */
  warehouseName?: string;
  /**
   * 仓库类型
   */
  warehouseType?: number;
}
/**
 * 禁用启用快递
 */
export class WarehouseStatusForm {
  'id': string = '';
  'status': boolean | string;
}
/**
 * 仓库vo
 */
export class WarehouseDetail {
  /**
   * 详细地址
   */
  address?: string;
  /**
   * 区
   */
  area?: string;
  /**
   * 区id
   */
  areaId?: number;
  /**
   * 市
   */
  city?: string;
  /**
   * 市id
   */
  cityId?: number;
  /**
   * 所属公司字典id
   */
  company?: number;
  /**
   * 所属公司名称
   */
  companyName?: string;
  /**
   * 货主编码
   */
  consignorCode?: string;
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 单日最大单量
   */
  dayOrderMaxAmount?: number;
  /**
   * 是否支持配货（1：是  0：否）
   */
  distribution?: boolean;
  /**
   * 邮箱
   */
  email?: string;
  /**
   * 默认快递id
   */
  expressId?: number;
  /**
   * 仓库id
   */
  id?: number;
  /**
   * 仓库负责人
   */
  owner?: string;
  /**
   * 省
   */
  province?: string;
  /**
   * 省id
   */
  provinceId?: number;
  /**
   * 是否推荐包材（1：是  0：否）
   */
  recommendPackage?: boolean;
  /**
   * -1：删除  0：禁用  1：启用
   */
  status?: boolean;
  /**
   * 仓储供应商名称
   */
  supplierName?: string;
  /**
   * 联系方式
   */
  tel?: string;
  /**
   * 第三方仓库编码
   */
  thirdWarehouseCode?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
  /**
   * 仓库编码
   */
  warehouseCode?: string;
  /**
   * 仓库名称
   */
  warehouseName?: string;
  /**
   * 仓库类型id
   */
  warehouseType?: number;
  /**
   * 仓库类型名称
   */
  warehouseTypeName?: string;
}
/**
 * 仓库添加
 */
export class AddWarehouse {
  /**
   * 详细地址
   */
  address: string = '';
  /**
   * 区
   */
  area: string = '';
  /**
   * 区id
   */
  areaId: number | string = '';
  /**
   * 市
   */
  city: string = '';
  /**
   * 市id
   */
  cityId: number | string = '';
  /**
   * 所属公司（取字典id）
   */
  company: number | string = '';
  /**
   * 货主编码
   */
  consignorCode: string = '';
  /**
   * 单日最大单量
   */
  dayOrderMaxAmount?: number ;
  /**
   * 是否支持配货（1：是  0：否）
   */
  distribution: string = '';
  /**
   * 邮箱
   */
  email: string = '';
  /**
   * 默认快递id
   */
  expressId: number | string = '';
  /**
   * 仓库负责人
   */
  owner: string = '';
  /**
   * 省
   */
  province: string = '';
  /**
   * 省id
   */
  provinceId: number | string = '';
  /**
   * 是否推荐包材（1：是  0：否）
   */
  recommendPackage: string = '';
  /**
   * 仓储供应商名称
   */
  supplierName: string = '';
  /**
   * 联系方式(为空不传)
   */
  tel: string = '';
  /**
   * 第三方仓库编码
   */
  thirdWarehouseCode?: string;
  /**
   * 仓库编码
   */
  warehouseCode: string = '';
  /**
   * 仓库名称
   */
  warehouseName: string = '';
  /**
   * 仓库类型
   */
  warehouseType?: number;
  /**
   * 数据id
   */
  id?: number;
  expressArr:(number)[]=[]
}
/**
 * 虚拟仓vo
 */
export interface VirtualWarehouseType {
  /**
   * 创建时间
   */
  createTime: Date;
  /**
   * 虚拟仓id
   */
  id: number;
  /**
   * 状态（-1：删除  0：禁用  1：启用）
   */
  status: string;
  /**
   * 更新时间
   */
  updateTime: Date;
  /**
   * 虚拟仓编码
   */
  virtualWarehouseCode: string;
  /**
   * 虚拟仓名称
   */
  virtualWarehouseName: string;
  /**
   * 虚拟仓类型
   */
  virtualWarehouseType: number;
  /**
   * 虚拟仓类型名称
   */
  virtualWarehouseTypeName: string;
  /**
   * 仓库id
   */
  warehouseId: number;
}
/**
 * 虚拟仓添加bo
 */
export class AddVirtualForm {
  /**
   * 虚拟仓编码
   */
  virtualWarehouseCode: string = '';
  /**
   * 虚拟仓名称
   */
  virtualWarehouseName: string = '';
  /**
   * 虚拟仓类型（取数据字典）
   */
  virtualWarehouseType: number | string = '';
  /**
   * 实体仓id
   */
  warehouseId?: number ;
  /**
   * 虚拟仓id
   */
  id?: number|string;
}
