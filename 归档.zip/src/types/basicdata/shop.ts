/**
 * 店铺分页查询业务对象
 */
 export class StoreSearchForm {
  /**
   * 所属公司
   */
   companyCode?: string='';
  /**
   * 所属客户
   */
  customer?: string='';
  pageNum?: number=1;
  pageSize?: number=10;
  /**
   * 店铺状态 1开启 0禁用
   */
  status: string='all';
  /**
   * 店铺编码
   */
  storeCode?: string='';
  /**
   * 店铺名称
   */
  storeName?: string='';
}
/**
 * PageResult«店铺管理分页VO»
 */
 export class StoreSearchFormList {
  pageNum?: number;
  pageSize?: number;
  result?: StoreSearchFormListItem[];
  totalCount?: number;
  totalPage?: number;
}

/**
* 店铺管理分页VO
*/
export class StoreSearchFormListItem {
  /**
   * 公司编码
   */
  companyCode?: string;
  /**
   * 公司名称
   */
  companyName?: string;
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 所属客户
   */
  customer?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 负责人
   */
  owner?: string;
  /**
   * 店铺状态 1开启 0禁用
   */
  status?: boolean;
  /**
   * 店铺编码
   */
  storeCode: string='';
  /**
   * 店铺名称
   */
  storeName?: string;
  /**
   * 店铺类型
   */
  storeType?: string;
  /**
   * 修改时间
   */
  updateTime?: Date;
}

/**
 * 店铺管理VO
 */
 export class StoreDetails {
    /**
     * 重新配货延迟时间
     */
     againDelayTime?: string;
     /**
      * 公司编码
      */
     companyCode?: string;
     /**
      * 公司名称
      */
     companyName?: string;
     /**
      * 所属客户
      */
     customer?: string;
     /**
      * 配置延迟时间
      */
     delayTime?: string;
     /**
      * 默认发货人
      */
     deliverer?: string;
     /**
      * 默认退货仓库id  以后直接查仓库使用
      */
     delivererWarehouseId?: string|number='';
     /**
      * 默认退货仓库
      */
     delivererWarehouseName?: string;
     /**
      * 配货方式
      */
     distributionMode?: string;
     /**
      * id
      */
     id?: number;
     /**
      * 默认发货电话
      */
     mobile?: string;
     /**
      * 负责人
      */
     owner?: string;
     /**
      * 价格来源
      */
     priceSource?: string;
     /**
      * 店铺编码
      */
     storeCode?: string;
     /**
      * 店铺名称
      */
     storeName?: string;
     /**
      * 店铺类型
      */
     storeType?: string;
     /**
      * 默认发货仓库id  以后直接查仓库使用
      */
     warehouseId?: string|number='';
     /**
      * 默认发货仓库
      */
     warehouseName?: string;
}
// 操作日志字段
/**
 * OperationLogDTO
 */
 export class OperationLogType {
  businessCode?: string;
  businessType?: string;
  logType?: string;
  msg?: string;
  operater?: string;
  operationTime?: Date;
}
export  class initDataType{
  dictionaryTitle?:string
  dictionaryType?:string
  dictionaryValue?:string
  id?:string
  nickname?:string
  virtualWarehouseName?:string
}
//策略配置列表字段
export class PolicyConfigType {
  createTime:string=''
  status: boolean=false
  strategyId: number=0
  title: string=''
  type: string=''
  updateTime: string=''
}
/**
 * 店铺策略添加
 */
 export class AddPolicyConfigType {
  /**
   * 店铺id
   */
  storeId: string='';
  /**
   * 策略类型id
   */
  strategyId: string='';
  /**
   * 策略类型名称
   */
  strategyType: string='';

  storeCode?: string;

  originalStrategyId?: string;
}
/**
 * 店铺策略删除
 */
 export class DelPolicyConfigType {
  /**
   * 店铺id
   */
   storeCode?: string;
  /**
   * 策略类型id
   */
   storeId?: number;
  /**
   * 策略类型名称
   */
   strategyId?: number;
}


