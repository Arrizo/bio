/**
 * 供应商查询
 */
export class SupplierReq {
  /**
   * 审核状态
   */
  auditStatus?: string = 'all';
  /**
   * 采购人员Id
   */
  buyerIdList?: number[];
  /**
   * 开发人员Id
   */
  developerIdList?: number[];
  /**
   * 推送k3状态
   */
  k3Status?: string = 'all';
  pageNum?: number = 1;
  pageSize?: number = 10;
  /**
   * 启用状态
   */
  status?: boolean | string = 'all';
  /**
   * 供应商属性
   */
  supplierAttr?: string = 'all';
  /**
   * 供应商编码
   */
  supplierCode?: string = '';
  /**
   * 供应商名称
   */
  supplierName?: string = '';
  /**
   * 供应商类别
   */
  supplierType?: string = 'all';
}

/**
 * PageResult«供应商列表VO»
 */
export interface SupplierRes {
  pageNum?: number;
  pageSize?: number;
  result?: SupplierType[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 供应商列表VO
 */
export interface SupplierType {
  /**
   * 审核状态:STASH-草稿，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
   */
  auditStatus?: AuditStatus;
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * ID
   */
  id?: number;
  /**
   * 推送k3状态
   */
  k3Status?: string;
  /**
   * 简称
   */
  shortName?: string;
  /**
   * 启用状态
   */
  status?: boolean;
  /**
   * 供应商编码
   */
  supplierCode?: string;
  /**
   * 供应商名称
   */
  supplierName?: string;
  /**
   * 供应商类型 formal正式供应商 latent潜在供应商
   */
  supplierType?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
}

/**
 * 审核状态:STASH-草稿，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
 */
export enum AuditStatus {
  AuditPass = 'AUDIT_PASS',
  NoPass = 'NO_PASS',
  Stash = 'STASH',
  WaitAudit = 'WAIT_AUDIT',
}

export class BankCardFrom {
  accountName: string = ''; //账户名称
  bankBranchName: string = ''; //开户银行
  bankCardNo: string = ''; //银行卡号
  interbankNo: string = ''; //联行号
  id?: number; //编辑时传
}

export interface BankCardType {
  accountName: string; //账户名称
  bankBranchName: string; //开户银行
  bankCardNo: string; //银行卡号
  interbankNo: string; //联行号
  id?: number; //编辑时传
}

export class BrandType {
  /**
   * 代理品牌
   */
  agentBrand?: string;
  /**
   * 授权级别
   */
  authorizeLevel?: string;
  /**
   * 授权结束时间
   */
  endTime?: Date;
  /**
   * 编辑时传
   */
  id?: number;
  /**
   * 授权级别名称
   */
  authorizeLevelName?: string;
  /**
   * 授权开始时间
   */
  startTime?: Date;
}

export class BrandForm {
  /**
   * 代理品牌
   */
  agentBrand: string = '';
  /**
   * 授权级别
   */
  authorizeLevel: string = '';
  /**
   * 授权结束时间
   */
  endTime: Date | string = '';
  /**
   * 编辑时传
   */
  id?: number;
  /**
   * 授权级别名称
   */
  authorizeLevelName: string = '';
  /**
   * 授权开始时间
   */
  startTime: Date | string = '';
}

export interface ContactsType {
  contacts: string; //联系人
  fixedPhone: string; //固定电话
  job: string; //职务
  mail: string; //邮箱
  mobile: string; //手机号码
  id?: number; //编辑时传
}
export class ContactsFrom {
  contacts: string = ''; //联系人
  fixedPhone: string = ''; //固定电话
  job: string = ''; //职务
  mail: string = ''; //邮箱
  mobile: string = ''; //手机号码
  id?: number; //编辑时传
}

export interface CooperationType {
  /**
   * 账期
   */
  accountingPeriod?: number;
  /**
   * 售后支持选项值
   */
  afterSupport?: string;
  /**
   * 售后支持名称
   */
  afterSupportName?: string;
  /**
   * 合作模式选项值
   */
  cooperationMode?: string;
  /**
   * 合作模式名称
   */
  cooperationModeName?: string;
  /**
   * 发货时效选项值
   */
  deliveryTimeliness?: string;
  /**
   * 发货时效名称
   */
  deliveryTimelinessName?: string;
  /**
   * 编辑时传
   */
  id?: number;
  /**
   * 结算方式选项值
   */
  settlementMethod?: string;
  /**
   * 结算方式名称
   */
  settlementMethodName?: string;
}

export class CooperationForm {
  /**
   * 账期
   */
  accountingPeriod?: number;
  /**
   * 售后支持选项值
   */
  afterSupport: string = '';
  /**
   * 售后支持名称
   */
  afterSupportName: string = '';
  /**
   * 合作模式选项值
   */
  cooperationMode: string = '';
  /**
   * 合作模式名称
   */
  cooperationModeName: string = '';
  /**
   * 发货时效选项值
   */
  deliveryTimeliness: string = '';
  /**
   * 发货时效名称
   */
  deliveryTimelinessName: string = '';
  /**
   * 编辑时传
   */
  id?: number;
  /**
   * 结算方式选项值
   */
  settlementMethod?: string;
  /**
   * 结算方式名称
   */
  settlementMethodName?: string;
}

export interface FileType {
  /**
   * 附件名称
   */
  fileName?: string;
  /**
   * 附件类型
   */
  fileType?: string;
  /**
   * 附件类型名称
   */
  fileTypeName?: string;
  /**
   * 编辑时传
   */
  id?: number;
  /**
   * 附件链接
   */
  url?: string;
}

export class FileFrom {
  /**
   * 附件名称
   */
  fileName: string = '';
  /**
   * 附件类型
   */
  fileType: string = '';
  /**
   * 附件类型名称
   */
  fileTypeName: string = '';
  /**
   * 编辑时传
   */
  id?: number;
  /**
   * 附件链接
   */
  url: string = '';
}

export class SupplierFrom {
  'bankCardList': BankCardType[] = [];
  'brandList': BrandType[] = [];
  'businessScope': string = '';
  'buyerId': number[] | string[];
  'developerName': string = '';
  'buyerName': string = '';
  'contactsList': ContactsType[] = [];
  'cooperationModeList': CooperationType[] = [];
  'detailAddr': string = '';
  'developerId': number[] | string[];
  'fileList': FileType[] = [];
  'id': number;
  'incorporationTime': string = '';
  'legalRepresentative': string = '';
  'regionId': number;
  'registeredCapital': number;
  'registeredCapitalCurrency': string = 'RMB';
  'remark': string = '';
  'shortName': string = '';
  'socialCreditCode': string = '';
  'submitType': number;
  'supplierAttr': string = '';
  'supplierCategory': string = 'purchase';
  'supplierName': '';
}
