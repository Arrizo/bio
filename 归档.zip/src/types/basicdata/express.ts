/**
 * 快递列表查询查询对象
 */
export class ExpressSearchForm {
  'expressCode'?: string = ''; //快递编码
  'standardExpressId'?: string = 'all'; //标准快递编码id
  'expressName'?: string = ''; //快递名称
  'pageNum'?: number = 1;
  'pageSize'?: number = 10;
  'status'?: boolean|string = 'all'; //状态
}
/**
 * PageResult«com-pflm-auth-core-entity-basic-Express»
 */
export interface ExpressListRes {
  pageNum: number;
  pageSize: number;
  result: ExpressItem[];
  totalCount: number;
  totalPage: number;
}

/**
 * 快递列表返回集合对象
 */
export interface ExpressItem {
  /**
   * 创建时间
   */
  createTime: Date;
  /**
   * 快递编码
   */
  expressCode: string;
  /**
   * 快递名称
   */
  expressName: string;
  /**
   * id
   */
  id: number;
  /**
   * 标准快递编码
   */
  standardExpressDictCode: string;
  /**
   * 快递状态（-1：删除  0：禁用  1：启用）
   */
  status: boolean;
  /**
   * 更新时间
   */
  updateTime: Date;
}

/**
 * 禁用启用快递
 */
export class ExpressStatusForm {
  'id': string = '';
  'status': boolean;
}

/**
 * 新增快递
 */
export class ExpressForm {
  'expressCode': string = ''; //快递编码
  'standardExpress': string = ''; //标准快递(取字典id)
  'expressName': string = ''; //快递名称
  'id'?: number;
}
/**
 * 限发区域配置
 */
export class LimitConfigsReq {
  /**
   * 快递id
   */
  expressId?:string='';
  /**
   * 搜索关键字
   */
  keyword?: string='';
  /**
   * 页码
   */
  pageNum?: number=1;
  /**
   * 分页数
   */
  pageSize?: number=10;
}
/**
 * PageResult«限发区域配置»
 */
export interface LimitConfigsRes {
  pageNum: number;
  pageSize: number;
  result: LimitConfigsResItem[];
  totalCount: number;
  totalPage: number;
}

/**
* 限发区域配置
*/
export interface LimitConfigsResItem {
  /**
   * 区
   */
  area?: string;
  /**
   * 区id
   */
  areaId?: number;
  /**
   * 市
   */
  city?: string;
  /**
   * 市id
   */
  cityId?: number;
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 快递id
   */
  expressId?: number;
  /**
   * 限发id
   */
  id?: number;
  /**
   * 限发原因字典id
   */
  limitReason?: number;
  /**
   * 省
   */
  province?: string;
  /**
   * 省id
   */
  provinceId?: number;
  /**
   * 更新时间
   */
  updateTime?: Date;
}
/**
 * 限发快递配置
 */
export class AddReasonReq {
  /**
   * 快递id
   */
  expressId: number|string='';
  /**
   * 快递限发地址
   */
  expressLimitAddressBOS: AddReasonBo[]=[];
  /**
   * 限发原因 (字典id)
   */
  limitReason: number|string='';
  expressArr:Array<(string|number)[]>=[];
  id?:string|number//编辑时候用
}

/**
* 快递限发地址BO
*/
export class AddReasonBo {
  /**
   * 区
   */
  area: string = '';
  /**
   * 区id
   */
  areaId: number=0;
  /**
   * 市名称
   */
  city: string='';
  /**
   * 市id
   */
  cityId: number=0;
  /**
   * 省
   */
  province: string='';
  /**
   * 省id
   */
  provinceId: number=0;
}

export interface CascaderType {
  id: string ;
  regionName: string;
  child?: CascaderType[]
}