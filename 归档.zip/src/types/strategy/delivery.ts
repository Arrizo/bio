/**
 * @ Author: Sam
 * @ Create Time: 2023-03-18 09:52:40
 * @ Modified by: Sam
 * @ Modified time: 2023-03-18 10:26:54
 * @ Description:
 */

/**
 * 配货策略分页查询BO
 */
export class DeliverySearchForm {
  pageNum: number = 1;
  pageSize: number = 10;
  strategyId?: number;
}

/**
 * PageResult«策略VO»
 */
export interface DeliveryListRes {
  pageNum?: number;
  pageSize?: number;
  result: DeliveryListItem[];
  totalCount: number;
  totalPage?: number;
}

/**
 * 抵扣策略VO
 */
export interface DeliveryListItem {
  /**
   * 创建时间
   */
  createTime?: string;
  /**
   * 策略配置vo
   */
  elements?: ElementItem[];
  /**
   * 配货名称
   */
  expressTitle?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 优先级
   */
  sort?: number;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 更新时间
   */
  updateTime?: string;
}

/**
 * 策略条件VO
 */
export interface ElementItem {
  /**
   * 后括号
   */
  backBracket?: string;
  /**
   * 条件字段
   */
  conditionField?: string;
  /**
   * 条件值
   */
  conditionValue?: string;
  /**
   * 前括号
   */
  frontBracket?: string;
  /**
   * 逻辑连接符
   */
  logicCharacter?: string;
  /**
   * 条件关系
   */
  relation?: string;
}

export class DeliveryForm {
  /**
   * 快递策略Id
   */
  expressStrategyId?: number;
  /**
   * 快递策略名称
   */
  expressStrategyName?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 优先级
   */
  level?: number;
  /**
   * 策略条件
   */
  lstStrategyConfigAdd: StrategyElement[] = [new StrategyElement()];
  /**
   * 策略id
   */
  strategyId?: number;
  /**
   * 仓库id
   */
  warehouseId?: number;
  /**
   * 仓库名称
   */
  warehouseName?: string;
}

/** 策略元素新增 */
export class StrategyElement {
  /**
   * 后括号
   */
  backBracket: string = ')';
  /**
   * 条件字段
   */
  conditionField: string = '';
  /**
   * 条件值
   */
  conditionValue: string = '';
  /**
   * 前括号
   */
  frontBracket: string = '(';
  /**
   * 逻辑连接符
   */
  logicCharacter: string = 'and';
  /**
   * 条件关系
   */
  relation: string = '';
}
