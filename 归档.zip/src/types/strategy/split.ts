/**
 * @ Author: Sam
 * @ Create Time: 2023-03-16 14:35:48
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 16:00:43
 * @ Description:
 */

/**
 * 拆分策略分页查询BO
 */
export class SplitSearchForm {
  pageNum: number = 1;
  pageSize: number = 10;
  strategyId?: number;
}

/**
 * PageResult«抵扣策略VO»
 */
export interface SplitListRes {
  pageNum?: number;
  pageSize?: number;
  result: SplitListItem[];
  totalCount: number;
  totalPage?: number;
}

/**
 * 抵扣策略VO
 */
export interface SplitListItem {
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * ID
   */
  id?: number;
  /**
   * 优先级
   */
  sort?: number;
  /**
   * 拆分方式
   */
  splitMethod?: string;
  /**
   * 拆分方式名称
   */
  splitMethodName?: string;
  /**
   * 拆分数量
   */
  splitNum?: number;
  /**
   * 关联策略编码
   */
  strategyCode?: number;
  /**
   * 策略条件
   */
  strategyConfigList?: ElementItem[];
  /**
   * 关联策略id
   */
  strategyId?: number;
  /**
   * 更新时间
   */
  updateTime?: Date;
}

/**
 * 策略条件VO
 */
export interface ElementItem {
  /**
   * 后括号
   */
  backBracket?: string;
  /**
   * 条件字段
   */
  conditionField?: string;
  /**
   * 条件值
   */
  conditionValue?: string;
  /**
   * 前括号
   */
  frontBracket?: string;
  /**
   * 逻辑连接符
   */
  logicCharacter?: string;
  /**
   * 条件关系
   */
  relation?: string;
}

export class SplitForm {
  strategyConfigList: StrategyElement[] = [new StrategyElement()];
  /**
   * 数据id,有值时为编辑
   */
  id?: number;
  /**
   * 优先级
   */
  sort?: number;
  /**
   * 拆分方式
   */
  splitMethod: string = 'number';
  /**
   * 拆分数量
   */
  splitNum?: number;
  /**
   * 关联策略id
   */
  strategyId?: number;
}

/** 策略元素新增 */
export class StrategyElement {
  /**
   * 后括号
   */
  backBracket: string = ')';
  /**
   * 条件字段
   */
  conditionField: string = '';
  /**
   * 条件值
   */
  conditionValue: string = '';
  /**
   * 前括号
   */
  frontBracket: string = '(';
  /**
   * 逻辑连接符
   */
  logicCharacter: string = 'and';
  /**
   * 条件关系
   */
  relation: string = '';
}
