/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-22 10:20:12
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-23 15:51:36
 * @ Description:包装方案
 */
/**
 * BpPackageSearchBO
 */
export class PackagingReq {
  /**
   * 快递ID集合
   */
  lstExpressId?: number[]=[];
  /**
   * 店铺ID集合
   */
  lstStoreId?: number[]=[];
  /**
   * 仓库ID集合
   */
  lstWarehouseId?: number[]=[];
  /**
   * 包材编码
   */
  materialCode?: string;
  pageNum?: number=1;
  pageSize?: number=10;
  /**
   * 规格编码
   */
  skuCode?: string;
  /**
   * 规格名称
   */
  skuName?: string;
  /**
   * 商品编码
   */
  spuCode?: string;
}

/**
 * PageResult«PackageSchemeVO»
 */
export interface PackagingRes {
  pageNum?: number;
  pageSize?: number;
  result?: PackagingType[];
  totalCount?: number;
  totalPage?: number;
}

/**
* PackageSchemeVO
*/
export interface PackagingType {
  createTime?: Date;
  expressIds?: string;
  /**
   * 适用快递
   */
  expressName?: string;
  /**
   * 商品毛重
   */
  grossWeight?: number;
  /**
   * 高度
   */
  height?: number;
  /**
   * 长度
   */
  length?: number;
  /**
   * 日志编码
   */
  logCode?: string;
  /**
   * 包材编码
   */
  materialCode?: string;
  /**
   * 包材名称
   */
  materialName?: string;
  /**
   * 包材重量
   */
  materialWeight?: number;
  /**
   * 包装重量
   */
  packageWeight?: number;
  /**
   * 图片
   */
  picture?: string;
  /**
   * 规格编码
   */
  skuCode?: string;
  /**
   * 规格名称
   */
  skuName?: string;
  /**
   * 商品编码
   */
  spuCode?: string;
  storeIds?: string;
  /**
   * 适用店铺
   */
  storeName?: string;
  updateTime?: Date;
  warehouseIds?: string;
  /**
   * 适用仓库
   */
  warehouseName?: string;
  /**
   * 宽度
   */
  width?: number;
  id?:number
}
/**
 * BpPackageSchemeBO
 */
export class PackagingFrom {
  /**
   * 商品毛重
   */
  grossWeight?: number;
  /**
   * 高度
   */
  height?: number;
  id?: number;
  /**
   * 长度
   */
  length?: number;
  /**
   * 日志编码
   */
  logCode?: string;
  /**
   * 快递ID集合
   */
  lstExpressId?: number[];
  /**
   * 店铺ID集合
   */
  lstStoreId?: number[];
  /**
   * 仓库ID集合
   */
  lstWarehouseId?: number[];
  /**
   * 包材编码
   */
  materialCode: string='';
  /**
   * 包材名称
   */
  materialName?: string;
  /**
   * 包材重量
   */
  materialWeight?: number;
  /**
   * 包装重量
   */
  packageWeight?: number;
  /**
   * 图片
   */
  picture?: string;
  /**
   * 规格编码
   */
  skuCode: string='';
  /**
   * 规格名称
   */
  skuName?: string;
  /**
   * 商品编码
   */
  spuCode?: string;
  /**
   * 宽度
   */
  width?: number;
}