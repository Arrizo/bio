export class ConditionSearchTpye {
  fieldName: string = ''
  lstApplicationModel: Array<string> = []
  name: string = ''
  pageNum: number = 1
  pageSize: number = 10
  status: string = 'all'
}
export class ConditionListType {
  applicationModel?: string=''
  chineseName: string=''
  createTime?: string=''
  creatorId?:number= 0
  displayName: string=''
  fieldName: string=''
  id:string= ''
  logCode?: string=''
  paramValue: string=''
  status?:boolean= true
  type: string=''
  updateTime?: string=''
  updaterId?:number= 0
  valid?: boolean= true
  version?:number= 0
  exit?:boolean= false
  lstApplicationModel?: Array<string> = []
}