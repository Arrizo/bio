/**
 * @ Author: Sam
 * @ Create Time: 2023-03-14 14:24:09
 * @ Modified by: Sam
 * @ Modified time: 2023-03-24 09:41:21
 * @ Description:
 */

/**
 * 策略搜索bo
 */
export class DocReviewSearchForm {
  /**
   * 策略编码
   */
  code: string = '';
  pageNum: number = 1;
  pageSize: number = 10;
  /**
   * 状态
   */
  status: boolean | string = 'all';
  /**
   * 类型
   */
  strategyType?: StrategyType;
  /**
   * 策略名称
   */
  title: string = '';
}

/**
 * 类型
 */
export enum StrategyType {
  /** 拆分策略 */
  Cfcl = 'CFCL',
  /** 抵扣策略 */
  Dkcl = 'DKCL',
  /** 快递策略 */
  Kdcl = 'KDCL',
  /** 配货策略 */
  Phcl = 'PHCL',
  /** 审单策略 */
  Sdcl = 'SDCL',
  /** 赠品 */
  Zphd = 'ZPHD',
}

/**
 * PageResult«分类vo»
 */
export interface DocReviewListRes {
  pageNum: number;
  pageSize: number;
  result: DocReviewListItem[];
  totalCount: number;
  totalPage?: number;
}

/**
 * 分类vo
 */
export interface DocReviewListItem {
  /**
   * 编码
   */
  code?: string;
  /**
   * 所属公司编码
   */
  companyCode?: string;
  /**
   * 所属公司名称
   */
  companyName?: string;
  /**
   * 创建时间
   */
  createTime?: Date;
  creatorId?: number;
  /**
   * id
   */
  id?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 启用状态
   */
  status?: boolean;
  /**
   * 策略名称
   */
  title?: string;
  updaterId?: number;
  /**
   * 更新时间
   */
  updateTime?: Date;
  version?: number;
}

/**
 * StrategyCondition
 */
export interface StrategyModalRes {
  /**
   * 应用模块
   */
  applicationModel?: string;
  /**
   * 中文名称
   */
  chineseName?: string;
  createTime?: Date;
  creatorId?: number;
  /**
   * 显示名称
   */
  displayName?: string;
  /**
   * 字段名称
   */
  fieldName?: string;
  id?: number;
  logCode?: string;
  /**
   * 参数值
   */
  paramValue?: string;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 类型
   */
  type: string;
  updaterId?: number;
  updateTime?: Date;
  valid?: boolean;
  version?: number;
}

/**
 * 审单策略添加bo
 */
export class DocReviewForm {
  id?: number;
  /**
   * 策略配置元素
   */
  elements: StrategyElement[] = [new StrategyElement()];
  /**
   * 备注
   */
  remark: string = '';
  /**
   * 名称
   */
  title: string = '';
}

/** 策略元素新增 */
export class StrategyElement {
  lstConditionValue: string[] = [];
  lstConditionId: string[] | number[] = [];
  /**
   * 后括号
   */
  backBracket: string = ')';
  /**
   * 条件字段
   */
  conditionField: string = '';
  /**
   * 条件值
   */
  conditionValue: string | number = '';
  /**
   * 前括号
   */
  frontBracket: string = '(';
  /**
   * 逻辑连接符
   */
  logicCharacter: string = 'and';
  /**
   * 条件关系
   */
  relation: string = '';
}

/**
 * StrategyConfigSearchBO
 */
export interface QueryStrategyConfigForm {
  /**
   * 关联策略id
   */
  strategyId: number;
  /**
   * 策略类型
   */
  strategyType: string;
}

/**
 * StrategyConfig
 */
export interface QueryStrategyConfigFormRes {
  /**
   * 后括号
   */
  backBracket?: string;
  /**
   * 条件字段
   */
  conditionField?: string;
  /**
   * 条件值
   */
  conditionValue?: string;
  /**
   * 前括号
   */
  frontBracket?: string;
  /**
   * 逻辑连接符
   */
  logicCharacter?: string;
  /**
   * 条件关系
   */
  relation?: string;
  /**
   * 关联策略id
   */
  strategyId?: number;
  /**
   * 策略类型
   */
  strategyType?: StrategyType;
}
