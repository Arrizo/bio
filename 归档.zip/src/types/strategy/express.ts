/**
 * @ Author: Sam
 * @ Create Time: 2023-03-16 14:35:48
 * @ Modified by: Sam
 * @ Modified time: 2023-03-24 14:54:43
 * @ Description:
 */

/**
 * 快递策略分页查询BO
 */
export class ExpressSearchForm {
  pageNum: number = 1;
  pageSize: number = 10;
  strategyId?: number;
}

/**
 * PageResult«抵扣策略VO»
 */
export interface ExpressListRes {
  pageNum?: number;
  pageSize?: number;
  result: ExpressListItem[];
  totalCount: number;
  totalPage?: number;
}

/**
 * 抵扣策略VO
 */
export interface ExpressListItem {
  /**
   * 创建时间
   */
  createTime?: string;
  /**
   * 策略配置vo
   */
  elements?: ElementItem[];
  /**
   * 快递名称
   */
  expressTitle?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 优先级
   */
  sort?: number;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 更新时间
   */
  updateTime?: string;
}

/**
 * 策略条件VO
 */
export interface ElementItem {
  /**
   * 后括号
   */
  backBracket?: string;
  /**
   * 条件字段
   */
  conditionField?: string;
  /**
   * 条件值
   */
  conditionValue?: string;
  /**
   * 前括号
   */
  frontBracket?: string;
  /**
   * 逻辑连接符
   */
  logicCharacter?: string;
  /**
   * 条件关系
   */
  relation?: string;
}

export class ExpressForm {
  expressStrategyId?: number;
  id?: number;
  /**
   * 策略配置元素
   */
  elements: StrategyElement[] = [new StrategyElement()];
  /**
   * 快递id
   */
  expressId?: number;
  /**
   * 快递名称
   */
  expressTitle: string = '';
  /**
   * 优先级
   */
  sort?: number;
  /**
   * 策略id
   */
  strategyId?: number;
}

/** 策略元素新增 */
export class StrategyElement {
  /**
   * 后括号
   */
  backBracket: string = ')';
  /**
   * 条件字段
   */
  conditionField: string = '';
  /**
   * 条件值
   */
  conditionValue: string = '';
  /**
   * 前括号
   */
  frontBracket: string = '(';
  /**
   * 逻辑连接符
   */
  logicCharacter: string = 'and';
  /**
   * 条件关系
   */
  relation: string = '';
}
