/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-16 11:35:13
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-20 17:12:32
 * @ Description:规则管理
 */

/**
 * 规则列表分页BO
 */
export class RuleManagementReq {
  /**
   * 规则名称
   */
  name?: string;
  /**
   * 模板ID
   */
  templateId?: number|string='all';
  pageNum?: number = 1;
  pageSize?: number = 10;
}
/**
 * PageResult«规则列表pageVO»
 */
export interface RuleManagementRes {
  pageNum?: number;
  pageSize?: number;
  result?: RuleManagementType[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 规则列表RuleManagementType
 */
export class RuleManagementType {
  createTime?: Date;
  /**
   * id
   */
  id?: number;
  /**
   * 对外商品APPID
   */
  outMerchantId?: string;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 规则名称
   */
  ruleName?: string;
  /**
   * 业务类型id(1订单导入实物,9订单导入虚拟)
   */
  ruleType?: number;
  /**
   * 店铺名称
   */
  storeName?: string;
  /**
   * 模版名称
   */
  templateName?: string;
  updateTime?: Date;
}

/**
 * 导入模板规则bo
 */
export class SaveRule {
  /**
   * 补充市区
   */
  addMissAddress?: boolean;
  /**
   * 组合支付时间
   */
  combPayTime?: boolean;
  /**
   * 计算单价
   */
  computeUnitPrice?: boolean;
  /**
   * 客服确认
   */
  customerService?: boolean;
  /**
   * 获取省市+详细地址区
   */
  fetchCityDetailsDistrict?: boolean;
  id?: number;
  /**
   * 拦截无运单订单
   */
  interceptExpressNo?: boolean;
  /**
   * 组合地址
   */
  joinAddress?: boolean;
  /**
   * id集合-删除时用
   */
  lstId?: number[];
  /**
   * spu集合
   */
  lstRuleSpu?: ErpRuleSpu[];
  /**
   * 外部商户id
   */
  outMerchantId?: string;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 规则名称
   */
  ruleName?: string;
  /**
   * 业务类型-1订单导入实物,9订单导入虚拟
   */
  ruleType?: number;
  /**
   * 是否拆分详细地址
   */
  splitAddress?: boolean;
  /**
   * 拆分单元格
   */
  splitCell?: boolean;
  /**
   * 是否拆分省市区
   */
  splitToArea?: boolean;
  /**
   * 按SPU确认
   */
  spuConfirm?: boolean;
  /**
   * 规则名称
   */
  storeId?: number;
  /**
   * 模版id
   */
  templateId?: number;
  /**
   * 虚拟收件信息
   */
  virtualInfo?: boolean;
}

/**
 * ErpRuleSpu
 */
export interface ErpRuleSpu {
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 创建人名称
   */
  creator?: string;
  id?: number;
  /**
   * 商品编码
   */
  productCode?: string;
  /**
   * 商品名称
   */
  productName?: string;
  /**
   * 规则Id
   */
  ruleId?: number;
}

/**
 * ErpOrderImportRuleDetailVO
 */
export class RuleDetailsType {
  /**
   * 补充市区
   */
  addMissAddress?: boolean;
  /**
   * 组合支付时间
   */
  combPayTime?: boolean;
  /**
   * 计算单价
   */
  computeUnitPrice?: boolean;
  /**
   * 客服确认
   */
  customerService?: boolean;
  /**
   * 获取省市+详细地址区
   */
  fetchCityDetailsDistrict?: boolean;
  id?: number;
  /**
   * 拦截无运单订单
   */
  interceptExpressNo?: boolean;
  /**
   * 组合地址
   */
  joinAddress?: boolean;
  /**
   * 拦截状态
   */
  lstOrderStatus?: string[];
  /**
   * 外部商户id
   */
  outMerchantId?: string;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 规则名称
   */
  ruleName?: string;
  /**
   * 业务类型-1订单导入实物,9订单导入虚拟
   */
  ruleType?: number;
  /**
   * 是否拆分详细地址
   */
  splitAddress?: boolean;
  /**
   * 拆分单元格
   */
  splitCell?: boolean;
  /**
   * 是否拆分省市区
   */
  splitToArea?: boolean;
  /**
   * 按SPU确认
   */
  spuConfirm?: boolean;
  /**
   * 店铺编码
   */
  storeId?: number;
  /**
   * 店铺名称
   */
  storeName?: string;
  /**
   * 模版id
   */
  templateId?: number;
  /**
   * 虚拟收件信息
   */
  virtualInfo?: boolean;
}
/**
 * TemplateSelectVO
 */
export interface TemType {
  /**
   * 模板id
   */
  id?: number;
  /**
   * 模板名称
   */
  name?: string;
}

/**
 * 拦截配置
 */
export class RuleStatusReq {
  pageNum?: number=1;
  pageSize?: number=10;
  /**
   * 状态名称
   */
  statusName?: string='';
}
/**
 * PageResult«ErpRuleOrderStatusPageVO»
 */
export interface RuleStatusRes {
  pageNum?: number;
  pageSize?: number;
  result?: RuleStatusListType[];
  totalCount?: number;
  totalPage?: number;
}

/**
* RuleStatusListType
*/
export interface RuleStatusListType {
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 创建人
   */
  creator?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 状态名称
   */
  statusName?: string;
}

/**
 * 确认商品
 */
export class RuleSpuReq {
  /**
   * 编码/名称
   */
  key?: string;
  pageNum?: number=1;
  pageSize?: number=10;
  /**
   * 规则id
   */
  ruleId?: number;
}
/**
 * PageResult«ErpRuleSpu»
 */
export interface RuleSpuRes {
  pageNum?: number;
  pageSize?: number;
  result?: RuleSpuListType[];
  totalCount?: number;
  totalPage?: number;
}

/**
* ErpRuleSpu
*/
export interface RuleSpuListType {
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 创建人名称
   */
  creator?: string;
  id?: number;
  /**
   * 商品编码
   */
  productCode?: string;
  /**
   * 商品名称
   */
  productName?: string;
  /**
   * 规则Id
   */
  ruleId?: number;
}