/**
 * @ Author: Sam
 * @ Create Time: 2023-03-16 10:36:34
 * @ Modified by: Sam
 * @ Modified time: 2023-03-17 14:54:30
 * @ Description: 策略管理
 */

/**
 * 策略添加bo
 */
export class StrategyForm {
  id?: number;
  /**
   * 所属公司
   */
  companyCode: string = '';
  /**
   * 备注
   */
  remark: string = '';
  /**
   * 类型
   */
  strategyType?: StrategyType;
  /**
   * 名称
   */
  title: string = '';
}

/**
 * 类型
 */
export enum StrategyType {
  Cfcl = 'CFCL',
  Dkcl = 'DKCL',
  Kdcl = 'KDCL',
  Phcl = 'PHCL',
  Sdcl = 'SDCL',
  Zphd = 'ZPHD',
}
