/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:25:54
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-21 17:02:27
 * @ Description:导入导出模版
 */


/**
 * 模板查询bo
 */
export class searchReq {
  /**
   * 模板名称
   */
  name?: string = '';
  /**
   * 页码
   */
  pageNum?: number = 1;
  /**
   * 页条数
   */
  pageSize?: number = 10;
  /**
   * 作业类型(1导入0导出)
   */
  taskType?: string = '1';
}

/**
 * PageResult«模板列表Vo»
 */
export interface ExportImportList {
  pageNum?: number;
  pageSize?: number;
  result?: ExportImportListType[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 模板列表Vo
 */
export interface ExportImportListType {
  /**
   * 创建时间
   */
  createdTime?: Date;
  /**
   * 创建人
   */
  creator?: string;
  /**
   * 模板id
   */
  id?: number;
  /**
   * 修改时间
   */
  modifiedTime?: Date;
  /**
   * 修改人
   */
  modifier?: string;
  /**
   * 模板名称
   */
  name?: string;
  /**
   * 作业类型
   */
  taskType?: number;
}

/**
 * 模板保存Bo
 */
export class SaveFromData {
  /**
   * 业务类型Code
   */
  businessTypeCode?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 批量删除时用
   */
  lstId?: number[];
  /**
   * 模板映射
   */
  mapResult: string='';
  /**
   * id
   */
  name?: string;
  /**
   * 原始excel的所有表头
   */
  originTableTitle: string='';
  /**
   * 规则id
   */
  ruleId?: number;
  /**
   * 作业类型(1导入,0导出)
   */
  taskType: number=1;
  /**
   * id
   */
  templateDescribe?: string;
  /**
   * 表头结束行
   */
  titleEndRow: number=1;
  /**
   * 表头开始行
   */
  titleStartRow: number=1;
  /**
   * 上传的模板文件名称
   */
  uploadTemplateName?: string;
  /**
   * 上传的模板文件路径
   */
  uploadTemplateUrl?: string;
  userToken?: UserToken;
}

/**
 * UserToken
 */
export interface UserToken {
  nickname?: string;
  realIp?: string;
  roleIdList?: number[];
  storeIdList?: number[];
  userId?: number;
  username?: string;
}

//根据业务类型获取模板类型对应的内部字段
export interface TemplateFieldType {
  templateFieldId?: string;
  innerField?: string;
  innerTitle?: string;
  importRequired?: boolean;
  exportRequired?: boolean;
  seq?: string;
  type?: string;
}
