/**
 * 采购订单分页查询BO
 */
export class NoticeSearchType {
  /**
     * 批次号
     */
  batchNo?: string;
  /**
   * 单号,多个用英文,分割
   */
  code: string = '';
  /**
   * 单号类型 notice:通知单号 purchase:采购单号 wms:wms单号
   */
  codeType: string = 'notice';
  /**
   * 时间类型值 lastInTime：最后入库日期，updateTime：更新时间，createTime：通知单生成时间
   */
  dateType: string = 'lastInTime';
  /**
   * 结束时间
   */
  endTime: string = '';
  /**
   * 入库状态: NOT_NOTIFIED-未通知，NOTIFIED-已通知，NOTIFICATION_FAILED-通知失败，ALL-全部入库，PART-部分入库，NOT-未入库
   */
  inStatus?: string = 'all';
  pageNum: number = 1;
  pageSize: number = 10;
  /**
   * 采购员名称
   */
  purchaser?: string;
  /**
   * 开始时间
   */
  startTime: string = '';
  /**
   * 状态 NOT_NOTIFIED-未通知 NOTIFIED-已通知 NOTIFICATION_FAILED-通知失败 CANCELLATION-已取消 COMPLETED-已完结
   */
  status: string = 'all';
  /**
   * 入库虚拟仓库ID列表
   */
  virtualWarehouseIdList?: number[];
  time: Array<string> = []
}

/**
* 入库状态: NOT_NOTIFIED-未通知，NOTIFIED-已通知，NOTIFICATION_FAILED-通知失败，ALL-全部入库，PART-部分入库，NOT-未入库
*/
export enum InStatus {
  All = "ALL",
  Not = "NOT",
  NotNotified = "NOT_NOTIFIED",
  NotificationFailed = "NOTIFICATION_FAILED",
  Notified = "NOTIFIED",
  Part = "PART",
}

/**
* 通知状态：ALL-全部通知，PART-部分通知，NOT-未通知
*/
export enum NoticeStatus {
  All = "ALL",
  Not = "NOT",
  Part = "PART",
}

/**
* 状态 STASH-暂存，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过，CANCELLATION-已作废，COMPLETED-已完结
*/
export enum Status {
  AuditPass = "AUDIT_PASS",
  Cancellation = "CANCELLATION",
  Completed = "COMPLETED",
  NoPass = "NO_PASS",
  Stash = "STASH",
  WaitAudit = "WAIT_AUDIT",
}
export interface NoticeListType {
  /**
   * 到货日期
   */
  arrivalDate?: Date;
  /**
   * 来源单号
   */
  fromCode?: string;
  /**
   * 来源单据
   */
  fromReceipt?: string;
  /**
   * ID
   */
  id?: number;
  /**
   * 入库状态: NOT_NOTIFIED-未通知，NOTIFIED-已通知，NOTIFICATION_FAILED-通知失败，ALL-全部入库，PART-部分入库，NOT-未入库
   */
  inStatus?: InStatus;
  /**
   * 入库状态名称
   */
  inStatusName?: string;
  /**
   * 最后入库时间
   */
  lastInTime?: Date;
  /**
   * 通知状态：ALL-全部通知，PART-部分通知，NOT-未通知
   */
  noticeStatus?: NoticeStatus;
  /**
   * 通知状态名称
   */
  noticeStatusName?: string;
  /**
   * 采购日期
   */
  purchaseDate?: Date;
  /**
   * 采购单号
   */
  purchaseOrderCode?: string;
  /**
   * 采购组织名称
   */
  purchaseOrgName?: string;
  /**
   * 采购员
   */
  purchaser?: string;
  /**
   * 采购类型名称
   */
  purchaseTypeName?: string;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 状态 STASH-暂存，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过，CANCELLATION-已作废，COMPLETED-已完结
   */
  status?: Status;
  /**
   * 状态名称
   */
  statusName?: string;
  /**
   * 供应商名称
   */
  supplierName?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
  /**
   * 仓库名称
   */
  virtualWarehouseName?: string;
  /**
   * 仓库id
   */
  warehouseId?: number;
}
export class ProductDetailType {
  /**
   * 批次号
   */
  batchNo: string = '';
  /**
   * spu/sku编码,多个用英文,分割
   */
  code: string = '';
  /**
   * 采购通知单ID
   */
  purchaseNoticeOrderId: string = '';
  /**
   * 采购订单ID
   */
  purchaseOrderId: string = '';
  /**
   * 商品规格名称
   */
  skuName: string = '';
}
export class SerialNumberType {
  /**
  * 批次号
  */
  batchNo: string = '';
  pageNum: number = 1;
  pageSize: number = 10;
  /**
   * 采购通知单ID
   */
  purchaseNoticeOrderId: string = '';
  /**
   * 规格编码,多个用英文,分割
   */
  skuCode: string = '';
}

