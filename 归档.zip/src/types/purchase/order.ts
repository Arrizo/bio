/**
 * @ Author: Sam
 * @ Create Time: 2023-03-30 09:02:03
 * @ Modified by: Sam
 * @ Modified time: 2023-03-30 14:01:16
 * @ Description: 采购订单
 */

/**
 * 采购订单分页查询BO
 */
export class PurchaseOrderSearchForm {
  /**
   * 单号,多个用英文,分割
   */
  code?: string;
  /**
   * 单号类型 from:来源单号 purchase:采购单号
   */
  codeType: string = 'purchase';
  /**
   * 时间类型值 purchase：采购日期，arrival：到货日期
   */
  dateType: string = 'purchase';
  /**
   * 结束时间
   */
  endTime?: Date;
  /**
   * 入库状态: NOT_NOTIFIED-未通知，NOTIFIED-已通知，NOTIFICATION_FAILED-通知失败，ALL-全部入库，PART-部分入库，NOT-未入库
   */
  inStatus: InStatus = InStatus.Own;
  /**
   * 供应商名称/采购员名称
   */
  name?: string;
  /**
   * 查询条件名称类型 supplierName供应商名称，purchaser采购员
   */
  nameType: string = 'supplierName';
  /**
   * 通知状态：ALL-全部通知，PART-部分通知，NOT-未通知
   */
  noticeStatus: NoticeStatus = NoticeStatus.Own;
  pageNum: number = 1;
  pageSize: number = 10;
  /**
   * 开始时间
   */
  startTime?: Date;
  timeTemp: any[] = [];
  /**
   * 状态 STASH-暂存，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过，CANCELLATION-已作废，COMPLETED-已完结
   */
  status: Status = Status.Own;
  /**
   * 入库虚拟仓库ID列表
   */
  virtualWarehouseId?: number[];
}

/**
* 入库状态: NOT_NOTIFIED-未通知，NOTIFIED-已通知，NOTIFICATION_FAILED-通知失败，ALL-全部入库，PART-部分入库，NOT-未入库
*/
export enum InStatus {
  Own = "",
  All = "ALL",
  Not = "NOT",
  NotNotified = "NOT_NOTIFIED",
  NotificationFailed = "NOTIFICATION_FAILED",
  Notified = "NOTIFIED",
  Part = "PART",
}

/**
* 通知状态：ALL-全部通知，PART-部分通知，NOT-未通知
*/
export enum NoticeStatus {
  Own = "",
  All = "ALL",
  Not = "NOT",
  Part = "PART",
}

/**
* 状态 STASH-暂存，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过，CANCELLATION-已作废，COMPLETED-已完结
*/
export enum Status {
  Own = "",
  AuditPass = "AUDIT_PASS",
  Cancellation = "CANCELLATION",
  Completed = "COMPLETED",
  NoPass = "NO_PASS",
  Stash = "STASH",
  WaitAudit = "WAIT_AUDIT",
}

/**
 * PageResult«采购订单分页VO»
 */
export interface PurchaseOrderListRes {
  pageNum?: number;
  pageSize?: number;
  result: PurchaseOrderListItem[];
  totalCount: number;
  totalPage?: number;
}

/**
* 采购订单分页VO
*/
export interface PurchaseOrderListItem {
  /**
   * 到货日期
   */
  arrivalDate?: Date;
  /**
   * 来源单号
   */
  fromCode?: string;
  /**
   * 来源单据
   */
  fromReceipt?: string;
  /**
   * ID
   */
  id?: number;
  /**
   * 入库状态: NOT_NOTIFIED-未通知，NOTIFIED-已通知，NOTIFICATION_FAILED-通知失败，ALL-全部入库，PART-部分入库，NOT-未入库
   */
  inStatus?: InStatus;
  /**
   * 入库状态名称
   */
  inStatusName?: string;
  /**
   * 最后入库时间
   */
  lastInTime?: Date;
  /**
   * 通知状态：ALL-全部通知，PART-部分通知，NOT-未通知
   */
  noticeStatus?: NoticeStatus;
  /**
   * 通知状态名称
   */
  noticeStatusName?: string;
  /**
   * 采购日期
   */
  purchaseDate?: Date;
  /**
   * 采购单号
   */
  purchaseOrderCode?: string;
  /**
   * 采购组织名称
   */
  purchaseOrgName?: string;
  /**
   * 采购员
   */
  purchaser?: string;
  /**
   * 采购类型名称
   */
  purchaseTypeName?: string;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 状态 STASH-暂存，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过，CANCELLATION-已作废，COMPLETED-已完结
   */
  status?: Status;
  /**
   * 状态名称
   */
  statusName?: string;
  /**
   * 供应商名称
   */
  supplierName?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
  /**
   * 仓库名称
   */
  virtualWarehouseName?: string;
  /**
   * 仓库id
   */
  warehouseId?: number;
}