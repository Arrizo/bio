/*
 * @Author: Sam
 * @Date: 2023-01-30 09:12:25
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-17 13:56:18
 */

/**
 * 用户列表分页查询BO
 */
export class UserSearchForm {
  /**
   * 用户姓名
   */
  nickname?: string = '';
  /**
   * 组织id
   */
  orgId?: number | '' = '';
  pageNum?: number = 1;
  pageSize?: number = 10;
  /**
   * 状态
   */
  status?: boolean | 'all' | '' = 'all';
  /**
   * 用户账号
   */
  username?: string = '';
}

/**
 * PageResult«用户列表返回集合对象»
 */
export interface UserSearchListRes {
  pageNum: number;
  pageSize: number;
  result: UserSearchListItem[];
  totalCount: number;
  totalPage?: number;
}

/**
 * 用户列表返回集合对象
 */
export interface UserSearchListItem {
  /**
   * 创建时间
   */
  createTime?: Date;
  id?: number;
  /**
   * 岗位编码
   */
  jobCode?: string;
  /**
   * 岗位名称
   */
  jobName?: string;
  /**
   * 手机号
   */
  mobile?: string;
  /**
   * 用户姓名
   */
  nickname?: string;
  /**
   * 组织名称
   */
  orgName?: string;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 用户类型
   */
  typeName?: string;
  /**
   * 更新时间
   */
  updateTime?: Date;
  /**
   * 用户账号
   */
  username?: string;
}

/**
 * 组织树返回集合对象
 */
export interface OrganizationListItem {
  /**
   * 子集
   */
  children?: OrganizationListItem[];
  /**
   * 组织id
   */
  id?: number;
  /**
   * 组织编码
   */
  orgCode?: string;
  /**
   * 组织名称
   */
  orgName?: string;
  /**
   * 父id
   */
  parentId?: number;
}

/**
 * 组织表单
 */
export class OrganizationForm {
  /**
   * 组织id
   */
  id?: number;
  /**
   * 组织编码
   */
  orgCode: string = '';
  /**
   * 组织名称
   */
  orgName?: string = '';
  /**
   * 上级组织
   */
  parentId?: number | string | '' = 1;
  /**
   * 排序编号
   */
  sort?: number | 0 = 0;
}

/**
 * 用户添加BO
 */
export class UserForm {
  /**
   * 岗位编码
   */
  jobCode?: string;
  /**
   * 岗位名称
   */
  jobName?: string;
  /**
   * 角色授权集合
   */
  lstRoleId?: number[];
  /**
   * 店铺授权集合
   */
  lstStoreId?: number[];
  /**
   * 仓库授权集合
   */
  lstWarehouseId?: number[];
  /**
   * 手机号码
   */
  mobile?: string;
  /**
   * 用户姓名
   */
  nickname?: string;
  /**
   * 所属组织id
   */
  orgId?: number;
  /**
   * 所属组织名称
   */
  orgName?: string;
  /**
   * 用户类型编码
   */
  type?: string;
  /**
   * 用户类型名称
   */
  typeName?: string;
  /**
   * 用户账号
   */
  userName?: string;
}
