/*
 * @Author: Sam
 * @Date: 2023-01-31 08:57:15
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-13 15:51:40
 */

/**
 * 角色表单
 */
export class RoleForm {
  /**
   * ID
   */
  id?: number;
  /**
   * 菜单ID
   */
  menuIdList?: number[];
  /**
   * 备注
   */
  remark?: string;
  /**
   * 角色名称
   */
  roleName?: string;
}

/**
 * 角色下拉选项
 */
export interface RoleSelectItem {
  /**
   * 区域ID
   */
  id?: number;
  /**
   * 区域名称
   */
  roleName?: string;
}

/**
 * 角色字段授权BO
 */
export interface RoleAuthForm {
  /**
   * 选中菜单ID
   */
  menuIdList?: number[];
  /**
   * 角色ID
   */
  roleIdList?: number[];
}

/**
 * 角色详情
 */
export interface RoleInfoItem {
  /**
   * ID
   */
  id?: number;
  /**
   * 已勾选的菜单ID
   */
  menuIdList?: number[];
  /**
   * 备注
   */
  remark?: string;
  /**
   * 角色名称
   */
  roleName?: string;
}

/**
 * 角色分页查询
 */
export class RoleSearchForm {
  pageNum?: number = 1;
  pageSize?: number = 10;
  /**
   * 角色名称
   */
  roleName?: string = '';
  /**
   * 状态 true启用 false禁用
   */
  status?: boolean | string = 'all';
}

/**
 * PageResult«角色分页VO»
 */
export interface RoleSearchRes {
  pageNum: number;
  pageSize: number;
  result: RoleSearchResResultItem[];
  totalCount: number;
  totalPage: number;
}

/**
 * 角色分页VO_1
 */
export interface RoleSearchResResultItem {
  /**
   * 创建时间
   */
  // createdTime?: Date;
  createTime: Date, // 不知道什么时候改的字段
  /**
   * ID
   */
  id: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 角色名称
   */
  roleName?: string;
  /**
   * 状态 true启用 false禁用
   */
  status?: boolean;
  /**
   * 更新时间
   */
  updateTime?: Date;
  /**
   * 授权用户数
   */
  userNum?: number;
}

/**
 * 角色用户分页BO
 */
export class RoleUserSearch {
  /**
   * 用户名称
   */
  nickname?: string = '';
  pageNum?: number = 1;
  pageSize?: number = 10;
  /**
   * 角色ID
   */
  roleId?: number;
  /**
   * 用户账号
   */
  username?: string = '';
}

/**
 * PageResult«角色分页VO»_1
 */
export interface RoleUserRes {
  pageNum?: number;
  pageSize?: number;
  result: RoleUserResResultItem[];
  totalCount: number;
  totalPage?: number;
}

/**
 * 角色分页VO_2
 */
export interface RoleUserResResultItem {
  /**
   * ID
   */
  id?: number;
  /**
   * 用户名称
   */
  nickname?: number;
  /**
   * 所属组织
   */
  orgName?: string;
  /**
   * 用户账号
   */
  username?: string;
}

/**
 * 角色字段授权BO
 */
export class RoleFunctionAuthForm {
  /**
   * 选中菜单ID
   */
  menuIdList?: number[] = [];
  /**
   * 角色ID
   */
  roleIdList?: number[] = [];
}

/**
 * 角色字段授权选项BO
 */
export class RoleAuthParamsForm {
  /**
   * 权限标识
   */
  perms?: string;
  /**
   * 角色ID
   */
  roleId?: number;
}

/**
 * 角色字段授权返回集合对象
 */
export interface RoleAuthParamsRes {
  /**
   * 字段名称
   */
  dataTitleName?: string;
  /**
   * 字段编码
   */
  dictionaryValue?: string;
  /**
   * 权限标识
   */
  perms?: string;
  /**
   * 角色id
   */
  roleId?: number;
  /**
   * 勾选项 1：敏感 2：监控 null说明没勾选
   */
  type: number | '';
}

/**
 * 添加角色字段授权BO
 */
export class RoleParamsForm {
  /**
   * 字段授权列表
   */
  list: RoleParamsFormList[] = [];
  /**
   * 角色ID
   */
  roleId: number = NaN;
}

/**
 * 角色字段授权BO_1
 */
export class RoleParamsFormList {
  /**
   * 字段编码
   */
  dictionaryValue?: string;
  /**
   * 权限标识
   */
  perms?: string;
  /**
   * 勾选项 1：敏感 2：监控 null说明没勾选
   */
  type?: number | '';
}
