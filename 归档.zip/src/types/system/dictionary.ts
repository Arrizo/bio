/**
 * 数字字典查询对象
 */
export class DictionarySearchForm {
  'dictionaryCategory'?: string = 'all'; //字典分类
  'dictionaryName'?: string = ''; //字典名称
  'dictionaryType'?: string = ''; //	字典类型
  'endTime'?: string = ''; //结束时间
  'pageNum'?: number = 1; //
  'pageSize'?: number = 10; //
  'startTime'?: string = ''; //开始时间
  'status'?: boolean|string = 'all'; //状态
}
export class DictionaryPropsForm {
  'id': string = ''; //id
  'dictionaryName': string = ''; //字典名称
  'dictionaryType': string = ''; //	字典类型
}

/**
 * PageResult«数据字典返回»
 */
export interface DictionaryRes {
  pageNum?: number;
  pageSize?: number;
  result?: DictionaryItem[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 数字字典返回集合对象
 */
export class DictionaryItem {
  createTime?: string; //创建时间
  dictionaryCategory?: string; //字典分类
  dictionaryName?: string; //字典名称
  dictionaryType?: string; //	字典类型
  id?: number; //id
  remark?: string; //	备注
  status?: boolean; //状态
  subDictionaryType?: string; //上级字典类型
  titleCount?: number; //字典标签数量
}

/**
 * 数字字典项查询对象
 */
export class DictionarySearchListForm {
  /**
   * 字典标签
   */
  dictionaryTitle?: string;
  /**
   * 数据字典类型
   */
  dictionaryType?: string;
  /**
   * 结束时间
   */
  endTime?: Date;
  pageNum?: number = 1;
  pageSize?: number = 10;
  /**
   * 开始时间
   */
  startTime?: Date;
  /**
   * 状态
   */
  status?: boolean;
}
/**
 * PageResult«数据字典标签分页返回»
 */
export interface DictionaryListRes {
  pageNum?: number;
  pageSize?: number;
  result?: DictionaryListItem[];
  totalCount?: number;
  totalPage?: number;
}

/**
 * 数据字典标签分页返回
 */
export interface DictionaryListItem {
  /**
   * 创建时间
   */
  createTime?: Date;
  /**
   * 字典标签
   */
  dictionaryTitle?: string;
  /**
   * 字典键值
   */
  dictionaryValue?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 上级字典项Id
   */
  pid?: number;
  /**
   * 备注
   */
  remark?: string;
  /**
   * 排序
   */
  sort?: number;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 上级字典键值
   */
  subDictionaryValue?: string;
  /**
   * 修改时间
   */
  updateTime?: Date;
}

/**
 * 字典分类
 */
export interface DictionaryType {
  /**
   * 字典标签
   */
  dictionaryTitle?: string;
  /**
   * 数据字典类型
   */
  dictionaryType?: string;
  /**
   * 字典键值
   */
  dictionaryValue?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 排序
   */
  sort?: number;
  /**
   * 状态
   */
  status?: boolean;
}

/**
 * 数字字典新增编辑
 */
export class DictionaryForm {
  /**
   * 字典分类
   */
  dictionaryCategory?: string;
  dictionaryCategoryCode?:string;
  /**
   * 字典名称
   */
  dictionaryName?: string;
  /**
   * 字典类型
   */
  dictionaryType: string='';
  /**
   * 备注
   */
  remark?: string;
  /**
   * 状态
   */
  status?: boolean;
  /**
   * 上级字典类型
   */
  subDictionaryType?: string;
  /**
   * 新增时不传或传null
   */
  id?: number;
}

/**
 * 数据字典项新增编辑
 */
export class DictionaryTitleForm {
  /**
   * 字典标签
   */
  dictionaryTitle?: string = '';
  dictionaryName?: string = '';
  /**
   * 数据字典ID
   */
  dictionaryTypeId?: string = '';
  /**
   * 字典键值,编辑时不传或传null
   */
  dictionaryValue: string='';
  /**
   * 新增时不传或传null
   */
  id?: number;
  /**
   * 上级字典项ID
   */
  pid?: number | string = '';
  /**
   * 备注
   */
  remark?: string = '';
  /**
   * 排序
   */
  sort?: number;
  /**
   * 状态
   */
  status?: boolean;
}
/**
 * 数据字典新增上级字典
 */
export interface AddPidType {
  /**
   * 字典名称
   */
  dictionaryName?: string;
  /**
   * 字典类型
   */
  dictionaryType?: string;
  /**
   * id
   */
  id?: number;
}

/**
 * 字典标签名称返回
 */
export interface PidType {
  /**
   * 字典标签
   */
  dictionaryTitle?: string;
  /**
   * 字典键值
   */
  dictionaryValue?: string;
  /**
   * id
   */
  id?: number;
}
/**
 * 标准快递
 */
export interface DictionaryTitleType {
  /**
   * 字典标签
   */
  dictionaryTitle?: string;
  /**
   * 字典编码
   */
  dictionaryType?: string;
  /**
   * 字典项编码
   */
  dictionaryValue?: string;
  /**
   * id
   */
  id?: number;
  /**
   * 排序
   */
  sort?: number;
  /**
   * 状态
   */
  status?: boolean;
}