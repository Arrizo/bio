import axios from 'axios';
import type { AxiosRequestConfig, AxiosResponse } from 'axios';
import { Message } from '@arco-design/web-vue';
import { getToken } from '@/utils/auth';
import router from '@/router';
import { HttpResponse } from '@/types/global';
import { useUserStore } from '@/store';

if (import.meta.env.VITE_API_BASE_URL) {
  axios.defaults.baseURL = import.meta.env.VITE_API_BASE_URL;
}

/** Request 请求拦截 */
axios.interceptors.request.use(
  (config: AxiosRequestConfig) => {
    if (!config.headers) {
      config.headers = {};
    }

    /** 请求携带用户 Token 处理 */
    const token = getToken();
    if (token) {
      config.headers.Authorization = `${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

/** Response 响应处理 */
axios.interceptors.response.use(
  (response: AxiosResponse<HttpResponse>) => {
    if (response.status == 200) {
      return response.data as HttpResponse;
    }
  },
  (error) => {
    const { response } = error;

    if ([500, 503].includes(response.status)) {
      throw new Error(`${response.status}网络繁忙，请稍后再试`);
    }

    if ([405].includes(response.status)) {
      throw new Error(`${response.status}请求方式错误，请检查后重试`);
    }

    if ([404].includes(response.status)) {
      throw new Error('404-接口不存在');
    }

    if ([400].includes(response.status)) {
      throw new Error('400-参数错误');
    }

    if ([401].includes(response.status)) {
      const useStore = useUserStore();
      useStore.logout();
      router.replace('/login');
      Message.error('登录已失效，请重新登录');
    }

    return Promise.resolve({
      code: 0,
      msg: '',
    });
  }
);
