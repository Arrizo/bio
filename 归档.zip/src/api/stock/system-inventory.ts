/**
 * 系统仓库接口
 */
 import axios from 'axios';
 import { HttpResponse } from '@/types/global';
 import {SystemInventoryType } from '@/types/stock/system-inventory';

 // 列表查询
 export function getList(data: SystemInventoryType) {
   return axios.post<any, HttpResponse>('/order-core/warehouseStock/findVirtualWarehouseStock', data);
 }
 // 获取已启用实体仓下的已启用虚拟仓
 export function getActiveVirtual() {
   return axios.get<any, HttpResponse>('/auth-core/warehouse/activeVirtual');
 }