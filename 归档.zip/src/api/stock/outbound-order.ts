/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-30 14:19:20
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-30 14:22:22
 * @ Description: 出库单
 */


import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { OutboundOrderReq, OutboundOrderRes, OutboundOrderFrom } from '@/types/stock/outbound-order';

// 列表查询
export function queryPage(data: OutboundOrderReq) {
  return axios.post<any, HttpResponse<OutboundOrderRes>>(
    '/auth-core/stockOut/list',
    data
  );
}

// 添加出库单
export function addList(data: OutboundOrderFrom) {
  return axios.post<any, HttpResponse>(
    '/auth-core/stockOut/add',
    data
  );
}

// 修改出库单
export function updateList(data: OutboundOrderFrom) {
  return axios.post<any, HttpResponse>(
    '/auth-core/stockOut/update',
    data
  );
}