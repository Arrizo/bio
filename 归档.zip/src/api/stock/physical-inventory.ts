/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 16:49:26
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 17:12:45
 * @ Description: 实体仓库存
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { PhysicalInventoryReq, PhysicalInventoryRes } from '@/types/stock/physical-inventory';

// 列表查询
export function queryPage(data: PhysicalInventoryReq) {
  return axios.post<any, HttpResponse<PhysicalInventoryRes>>(
    '/auth-core/warehouseStock/findWarehouseStock',
    data
  );
}

// 导出
export function exportStock(data: PhysicalInventoryReq) {
  return axios.post<any, HttpResponse>(
    '/auth-core/warehouseStock/export',
    data
  );
}
