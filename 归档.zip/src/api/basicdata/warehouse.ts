import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { AddVirtualForm, AddWarehouse, WarehouseListRes, WarehouseSearchReq, WarehouseStatusForm } from '@/types/basicdata/warehouse';

// 数据字典名称列表
export function queryList(data: WarehouseSearchReq) {
  return axios.post<any, HttpResponse<WarehouseListRes>>(
    '/auth-core/warehouse/list',
    data
  );
}

// 仓库禁用-启用
export function getStatusUpdate(data: WarehouseStatusForm) {
  return axios.post<any, HttpResponse>('/auth-core/warehouse/enable', data);
}

// 仓库详情
export function getDetail(id:string|number) {
  return axios.get<any, HttpResponse>(`/auth-core/warehouse/detail?id=${id}`);
}

// 虚拟仓查询
export function getVirtualList(id:string|number) {
  return axios.get<any, HttpResponse>(`/auth-core/warehouse/virtual?warehouseId=${id}`);
}

//默认快递
export function getDefaultExpressList() {
  return axios.get<any, HttpResponse>(`/auth-core/express/active`);
}

// 启用-禁用虚拟仓库
export function getEnableVirtualUpdate(data: WarehouseStatusForm) {
  return axios.post<any, HttpResponse>('/auth-core/warehouse/enableVirtual', data);
}

// 仓库新增
export function addWarehouse(data: AddWarehouse) {
  return axios.post<any, HttpResponse<HttpResponse>>('/auth-core/warehouse/add', data);
}

// 仓库编辑
export function updateWarehouse(data: AddWarehouse) {
  return axios.post<any, HttpResponse<HttpResponse>>('/auth-core/warehouse/update', data);
}

// 添加虚拟仓
export function addVirtual(data: AddVirtualForm) {
  return axios.post<any, HttpResponse<HttpResponse>>('/auth-core/warehouse/addVirtual', data);
}

// 修改虚拟仓
export function updateVirtual(data: AddVirtualForm) {
  return axios.post<any, HttpResponse<HttpResponse>>('/auth-core/warehouse/updateVirtual', data);
}