import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  StoreSearchForm,
  StoreDetails,
  DelPolicyConfigType,
  AddPolicyConfigType
} from '@/types/basicdata/shop';

// 查询店铺列表
export function getStoreList(data:StoreSearchForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/store/getPage', data);
}
// 更新店铺状态
export function updateStoreStatus(id:number|undefined) {
  return axios.get<any, HttpResponse>(`/auth-core/system/store/storeStatusUpdate?id=${id}`);
}
// 更新店铺状态
export function findStoreDetail(id:number|undefined) {
  return axios.get<any, HttpResponse>(`/auth-core/system/store/findStoreDetail?id=${id}`);
}
// 操作日志
export function quaryRangeLog(code:string,type:string) {
  return axios.get<any, HttpResponse>(`/auth-core/loki/quaryRange?businessCode=${code}&businessType=${type}`);
}
// 操作日志
export function storeInitData() {
  return axios.get<any, HttpResponse>(`/auth-core/system/store/initData`);
}
// 详情保存
export function storeInfoSave(data:StoreDetails) {
  return axios.post<any, HttpResponse>(`/auth-core/system/store/storeEdit`,data);
}
// 策略列表
export function findStoreRelevance(code:string) {
  return axios.get<any, HttpResponse>(`/order-core/strategy/findStoreRelevance?storeCode=${code}`);
}
// 删除策略
export function deleteCategory(data:DelPolicyConfigType) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/deleteStoreRelevance`,data);
}
// 查询店铺下可选的策略列表
export function storeStrategySelect(data:{storeId:string,strategyType:string}) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/storeStrategySelect`,data);
}
// 店铺配置新增
export function addStoreRelevance(data:AddPolicyConfigType) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/addStoreRelevance`,data);
}
// 店铺配置编辑
export function updateStoreRelevance(data:AddPolicyConfigType) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/updateStoreRelevance`,data);
}