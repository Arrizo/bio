import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  ExpressItem,
  ExpressSearchForm,
  ExpressForm,
  ExpressListRes,
  ExpressStatusForm,
  LimitConfigsReq,
  LimitConfigsRes,
  AddReasonReq,
} from '@/types/basicdata/express';

// 快递新增
export function addExpress(data: ExpressForm) {
  return axios.post<any, HttpResponse>('/auth-core/express/add', data);
}

// 快递禁用-启用
export function getStatusUpdate(data: ExpressStatusForm) {
  return axios.post<any, HttpResponse>('/auth-core/express/enable', data);
}

// 删除限发区域配置
export function delLimitConfig(ids: string[]) {
  return axios.post<any, HttpResponse>(`/auth-core/express/deleteLimitConfig`, ids);
}

// 快递修改
export function editExpress(data: ExpressForm) {
  return axios.post<any, HttpResponse>('/auth-core/express/update', data);
}

// 快递列表查询
export function queryList(data: ExpressSearchForm) {
  return axios.post<any, HttpResponse<ExpressListRes>>('/auth-core/express/list', data);
}

// 查询限发区域配置
export function limitConfigs(data: LimitConfigsReq) {
  return axios.post<any, HttpResponse<LimitConfigsRes>>('/auth-core/express/limitConfigs', data);
}

// 添加限发配置
export function addLimitConfig(data: AddReasonReq) {
  return axios.post<any, HttpResponse<HttpResponse>>('/auth-core/express/addLimitConfig', data);
}

// 修改限发区域配置
export function updateLimitConfig(data: AddReasonReq) {
  return axios.post<any, HttpResponse<HttpResponse>>('/auth-core/express/updateLimitConfig', data);
}

//获取所有省份
export function getProvince() {
  return axios.get<any, HttpResponse>('/auth-core/address/province');
}

// 省市区关联接口
export function getChildAddress() {
  return axios.get<any, HttpResponse>('/auth-core/address/childAddress');
}

// 根据父级ID获取下级
export function getChildList(parentId:string|number) {
  return axios.get<any, HttpResponse>(`/auth-core/address/getList/${parentId}`);
}

// 导入文件
export function expressLimitUpload(data:FormData) {
  return axios.post<any, HttpResponse>('/auth-core/express/expressLimitUpload',data);
}

//minio文件下载
export function getFileOutputStream(uploadUrl:string) {
  return axios.get<any>(`/task-core/task/getFileOutputStream?uploadUrl=${uploadUrl}`,{responseType:'blob'});
}