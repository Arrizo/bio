import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  SupplierFrom,
  SupplierReq,
  SupplierRes,
} from '@/types/basicdata/supplier';
import { AuditMappingFrom } from '@/types/product/distribution';

// 分页查询
export function queryList(data: SupplierReq) {
  return axios.post<any, HttpResponse<SupplierRes>>(
    '/auth-core/supplier/getPage',
    data
  );
}

// 开发人员、采购人员
export function findOpenStatusInnerUserList() {
  return axios.get<any, HttpResponse<SupplierRes>>(
    `/auth-core/system/user/findOpenStatusInnerUserList`
  );
}

//新增或编辑
export function addOrUpdate(data: SupplierFrom) {
  return axios.post<any, HttpResponse>('/auth-core/supplier/addOrUpdate', data);
}

//组合商品详情
export function getDetailInfo(data: { id: number; isUpdate: boolean }) {
  return axios.post<any, HttpResponse>(`/auth-core/supplier/detail`, data);
}

// 提交
export function submitSupplier(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/supplier/submit/${id}`);
}

// 删除
export function deleteSupplier(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/supplier/delete/${id}`);
}

// 启用/禁用
export function onOrDrop(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/supplier/onOrDrop/${id}`);
}

//铺货调价审核
export function auditByIdList(data: AuditMappingFrom) {
  return axios.post<any, HttpResponse>(
    '/auth-core/supplier/auditByIdList',
    data
  );
}