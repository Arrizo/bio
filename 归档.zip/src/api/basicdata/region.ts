import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  RegionData,
  GetAddressSelectReq,
  GetAddressSelectRes,
  AddOrUpdateRegionReq
} from '@/types/basicdata/region';

// 获取所有省份
export function getProvinceList(){
  return axios.get<any, HttpResponse>('/auth-core/address/province');
}
// 根据父级ID获取下级
export function getRegionChild(parentId:number){
  return axios.get<any, HttpResponse>(`/auth-core/address/getList/${parentId}`);
}
// 获取地址下拉选项
export function getAddressSelect(data:GetAddressSelectReq){
  return axios.post<any, HttpResponse>(`/auth-core/address/getAddressSelect`,data);
}
// 删除
export function removeRegion(idList:Array<string>){
  return axios.post<any, HttpResponse>(`/auth-core/address/delete`, idList);
}
// 新增或编辑
export function addOrUpdateRegion(data:AddOrUpdateRegionReq){
  return axios.post<any, HttpResponse>(`/auth-core/address/addOrUpdate`,data);
}

// 临时方案： 获取所有省份及子级
export function getAddressTree(level:number = 4){
  return axios.get<any, HttpResponse>('/auth-core/address/getRelationChildren/' + level);
}