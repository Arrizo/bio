/**
 * @ Author: Sam
 * @ Create Time: 2023-03-14 15:48:05
 * @ Modified by: Sam
 * @ Modified time: 2023-03-24 09:41:23
 * @ Description:
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { DocReviewForm, DocReviewListRes, DocReviewSearchForm, QueryStrategyConfigForm, QueryStrategyConfigFormRes, StrategyElement, StrategyModalRes } from '@/types/strategy/order';

// 模板查询列表
export function queryByModel(model: string) {
  return axios.get<any, HttpResponse<StrategyModalRes[]>>(
    `/order-core/strategy/condition/queryByModel?model=${model}`
  );
}

// 策略添加
export function addDocReview(data: DocReviewForm) {
  return axios.post<any, HttpResponse>(`/order-core/docReview/add`, data);
}

// 策略查询
export function updateDocReview(data: DocReviewForm) {
  return axios.post<any, HttpResponse>(`/order-core/docReview/update`, data);
}

// 策略删除
export function delDocReview(id: number) {
  return axios.get<any, HttpResponse>(`/order-core/docReview/delete?id=${id}`);
}

// 启用/禁用
export function statusDocReview(data: any) {
  return axios.post<any, HttpResponse>(`/order-core/docReview/enable`, data);
}

// 策略查询
export function getDocReviewList(data: DocReviewSearchForm) {
  return axios.post<any, HttpResponse<DocReviewListRes>>(`/order-core/docReview/list`, data);
}

// 查询条件列表
export function queryStrategyConfig(data: QueryStrategyConfigForm) {
  return axios.post<any, HttpResponse<StrategyElement[]>>(`/order-core/strategy/queryStrategyConfig`, data);
}
