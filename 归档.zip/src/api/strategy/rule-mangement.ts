/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-16 11:32:36
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-22 16:06:09
 * @ Description:规则管理API
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  RuleManagementReq,
  RuleManagementRes,
  RuleSpuReq,
  RuleSpuRes,
  RuleStatusReq,
  RuleStatusRes,
  SaveRule,
} from '@/types/strategy/rule-mangement';

// 规则列表
export function queryPage(data: RuleManagementReq) {
  return axios.post<any, HttpResponse<RuleManagementRes>>(
    '/order-core/import/rule/list',
    data
  );
}

// 规则保存接口
export function saveRule(data: SaveRule) {
  return axios.post<any, HttpResponse>('/order-core/import/rule/save', data);
}

// 查询规则详情
export function getRuleDetail(ruleId: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/import/rule/queryDetail/${ruleId}`
  );
}

// 删除规则
export function delRule(lstId: number[]) {
  return axios.post<any, HttpResponse>(`/order-core/import/rule/delRule`, {
    lstId: lstId,
  });
}

// 查询全部模版下拉
export function queryTemSelect() {
  return axios.post<any, HttpResponse>(`/order-core/template/queryTemSelect`);
}

// 添加拦截状态
export function addStatus(data: { id: number; statusName: string }) {
  return axios.post<any, HttpResponse>(
    `/order-core/import/rule/addStatus`,
    data
  );
}

// 查询拦截配置列表
export function listStatus(data: RuleStatusReq) {
  return axios.post<any, HttpResponse<RuleStatusRes>>(
    `/order-core/import/rule/listStatus`,
    data
  );
}

// 删除拦截状态
export function delStatus(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/import/rule/delStatus/${id}`
  );
}

// 启用拦截订单
export function enableStatus(data: { ruleId: number; statusName: string }) {
  return axios.post<any, HttpResponse<RuleSpuRes>>(
    `/order-core/import/rule/enableStatus`,
    data
  );
}

// 查询商品列表
export function listSpu(data: RuleSpuReq) {
  return axios.post<any, HttpResponse<RuleSpuRes>>(
    `/order-core/import/rule/listSpu`,
    data
  );
}

// 添加spu
export function addSpu(data: SaveRule) {
  return axios.post<any, HttpResponse>(`/order-core/import/rule/addSpu`, data);
}

//删除商品
export function delSpu(lstId: number[] | string[]) {
  return axios.post<any, HttpResponse>(`/order-core/import/rule/delSpu`, {
    lstId: lstId,
  });
}

//删除商品
export function uploadSpu(data: FormData) {
  return axios.post<any, HttpResponse>(`/order-core/import/rule/upload`, data);
}
