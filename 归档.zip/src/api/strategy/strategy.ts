/**
 * @ Author: Sam
 * @ Create Time: 2023-03-16 10:36:34
 * @ Modified by: Sam
 * @ Modified time: 2023-03-16 10:41:50
 * @ Description: 策略管理
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { StrategyForm } from '@/types/strategy/strategy';

// 策略添加
export function addStrategy(data: StrategyForm) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/add`, data);
}

// 策略编辑
export function updateStrategy(data: StrategyForm) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/update`, data);
}