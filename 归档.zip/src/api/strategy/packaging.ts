/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-22 10:19:55
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-23 14:34:43
 * @ Description:包装方案api
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  PackagingFrom,
  PackagingReq,
  PackagingRes,
} from '@/types/strategy/packaging';

// 列表查询
export function queryPage(data: PackagingReq) {
  return axios.post<any, HttpResponse<PackagingRes>>(
    '/order-core/package/scheme/queryPage',
    data
  );
}

// 添加包装方案
export function addPackaging(data: PackagingFrom) {
  return axios.post<any, HttpResponse>('/order-core/package/scheme/add', data);
}

// 更新包装方案
export function editPackaging(data: PackagingFrom) {
  return axios.post<any, HttpResponse>('/order-core/package/scheme/edit', data);
}

// 删除方案
export function delPackaging(id: number[]) {
  return axios.post<any, HttpResponse>(
    `/order-core/package/scheme/del`,{lstId:id}
  );
}

// 查询详情
export function queryDetail(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/package/scheme/queryDetail?id=${id}`
  );
}

//适用仓库
export function queryWarehouseAndStatus() {
  return axios.get<any, HttpResponse>(
    `/auth-core/warehouse/queryWarehouseAndStatus`
  );
}

//适用店铺
export function queryStoreAndStatus() {
  return axios.get<any, HttpResponse>(
    `/auth-core/system/store/queryStoreAndStatus`
  );
}

//适用快递
export function findExpressAndStatus() {
  return axios.get<any, HttpResponse>(
    `/auth-core/express/findExpressAndStatus`
  );
}

// 包材信息查询
export function findPackageSku( code: string ) {
  return axios.get<any, HttpResponse>(`/auth-core/specs/findPackageSku?materialCode=${code}`);
}

// 包装方案规格信息查询
export function findSkuScheme( code: string ) {
  return axios.get<any, HttpResponse>(`/auth-core/specs/findSkuScheme?skuCode=${code}`);
}
