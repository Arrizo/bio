/**
 * @ Author: Sam
 * @ Create Time: 2023-03-18 09:52:16
 * @ Modified by: Sam
 * @ Modified time: 2023-03-20 09:14:28
 * @ Description:
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { DeliverySearchForm, DeliveryListRes, DeliveryForm } from '@/types/strategy/delivery';
import { StrategyType } from '@/types/strategy/order';

// 新增
export function addDeliverysConfig(data: DeliveryForm) {
  return axios.post<any, HttpResponse>(
    `/order-core/strategy/delivery/add`,
    data
  );
}

// 编辑
export function editDeliverysConfig(data: DeliveryForm) {
  return axios.post<any, HttpResponse>(
    `/order-core/strategy/delivery/edit`,
    data
  );
}

// 分页查询
export function getPage(data: DeliverySearchForm) {
  return axios.post<any, HttpResponse<DeliveryListRes>>(
    `/order-core/strategy/delivery/queryConfigPage`,
    data
  );
}

// 删除
export function delDelivery(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/strategy/delivery/del?id=${id}`
  );
}

// 详情
export function getDeliveryDetail(id: number) {
  return axios.get<any, HttpResponse>(`/order-core/strategy/delivery/queryDetail?id=${id}`);
}

// 启用/禁用
export function deliveryStatus(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/strategy/delivery/updateStatus?id=${id}`
  );
}

// 查询所属公司下的虚拟仓
export function queryVirtualByCompany(company: number) {
  return axios.get<any, HttpResponse>(
    `/auth-core/warehouse/queryVirtualByCompany?company=${company}`
  );
}

// 根据类型查询策略下拉
export function querySelectByModel(strategyType: StrategyType) {
  return axios.get<any, HttpResponse>(
    `/order-core/strategy/querySelectByModel?strategyType=${strategyType}`
  );
}
