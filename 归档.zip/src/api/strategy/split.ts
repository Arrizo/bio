/**
 * @ Author: Sam
 * @ Create Time: 2023-03-16 14:58:49
 * @ Modified by: Sam
 * @ Modified time: 2023-03-17 09:21:29
 * @ Description:
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  SplitForm,
  SplitListRes,
  SplitSearchForm,
} from '@/types/strategy/split';

// 新增或编辑
export function addOrUpdateSplit(data: SplitForm) {
  return axios.post<any, HttpResponse>(
    `/order-core/strategy/split/addOrUpdate`,
    data
  );
}

// 分页查询
export function getPage(data: SplitSearchForm) {
  return axios.post<any, HttpResponse<SplitListRes>>(
    `/order-core/strategy/split/getPage`,
    data
  );
}

// 删除
export function delSplit(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/strategy/split/delete/${id}`
  );
}

// 详情
export function getSplitDetail(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/strategy/split/detail/${id}`
  );
}

// 启用/禁用
export function splitStatus(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/strategy/split/onOrDrop/${id}`
  );
}
