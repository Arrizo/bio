/**
 * @ Author: Sam
 * @ Create Time: 2023-03-16 14:58:49
 * @ Modified by: Sam
 * @ Modified time: 2023-03-20 14:39:17
 * @ Description:
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { ExpressForm, ExpressListRes } from '@/types/strategy/express';
import { ExpressSearchForm } from '@/types/basicdata/express';

// 新增
export function addExpressConfig(data: ExpressForm) {
  return axios.post<any, HttpResponse>(
    `/order-core/expressStrategy/add`,
    data
  );
}

// 编辑
export function editExpressConfig(data: ExpressForm) {
  return axios.post<any, HttpResponse>(
    `/order-core/expressStrategy/update`,
    data
  );
}

// 分页查询
export function getPage(data: ExpressSearchForm) {
  return axios.post<any, HttpResponse<ExpressListRes>>(
    `/order-core/expressStrategy/list`,
    data
  );
}

// 删除
export function delExpress(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/expressStrategy/delete?id=${id}`
  );
}

// 详情
export function getExpressDetail(id: number) {
  return axios.get<any, HttpResponse>(`/order-core/expressStrategy/${id}`);
}

// 启用/禁用
export function expressStatus(data: any) {
  return axios.post<any, HttpResponse>(
    `/order-core/expressStrategy/enable`,
    data
  );
}