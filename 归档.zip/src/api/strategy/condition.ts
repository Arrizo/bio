import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {ConditionSearchTpye,ConditionListType} from '@/types/strategy/condition'
// 策略条件查询列表
export function queryConditionList(data: ConditionSearchTpye) {
  return axios.post<any, HttpResponse>('/order-core/strategy/condition/queryPage', data);
}
// 查询条件详情
export function queryConditionDetail(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/strategy/condition/queryDetail?id=${id}`);
}
// 查询条件详情更新
export function updateCondition(data: ConditionListType) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/condition/edit`,data);
}
// 查询条件详情新增
export function addCondition(data: ConditionListType) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/condition/add`,data);
}
// 查询条件启用禁用
export function updateStatus(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/strategy/condition/updateStatus?id=${id}`);
}
// 查询条件删除
export function conditionDel(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/strategy/condition/del?id=${id}`);
}

