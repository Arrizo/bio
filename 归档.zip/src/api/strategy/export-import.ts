/**
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:25:54
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-16 11:34:15
 * @ Description:导入导出模版API
 */


import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  ExportImportList,
  SaveFromData,
  searchReq,
  TemplateFieldType,
} from '@/types/strategy/export-import';

// 模板查询列表
export function queryPage(data: searchReq) {
  return axios.post<any, HttpResponse<ExportImportList>>('/order-core/template/list', data);
}

// 模板保存接口
export function saveTemplate(data: SaveFromData) {
  return axios.post<any, HttpResponse>('/order-core/template/save', data);
}

// 模板编辑接口
export function uploadTemplate(data: SaveFromData) {
  return axios.post<any, HttpResponse>(
    '/order-core/template/uploadTemplate',
    data
  );
}

// 模板删除接口
export function delTemplate(ids: number[]) {
  return axios.post<any, HttpResponse>(
    `/order-core/template/del`,
    {lstId:ids}
  );
}

// 获取模板类型对应的内部字段
export function getTemplateField(type: string) {
  return axios.get<any, HttpResponse>(
    `/order-core/template/getTemplateField?type=${type}`
  );
}

// 模板详情接口
export function getDetail(id: number) {
  return axios.get<any, HttpResponse>(
    `/order-core/template/getDetail?id=${id}`
  );
}
