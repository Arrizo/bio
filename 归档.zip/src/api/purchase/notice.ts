import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { NoticeSearchType, ProductDetailType,SerialNumberType } from '@/types/purchase/notice'
// 列表查询
export function getList(data: NoticeSearchType) {
  return axios.post<any, HttpResponse>('/order-core/purchase/notice/order/getPage', data);
}
// 查询虚拟仓库
export function getActiveVirtual() {
  return axios.get<any, HttpResponse>('/order-core/warehouse/activeVirtual');
}
// 查询虚拟仓库
export function sendNoticeWms(data: Array<string>) {
  return axios.post<any, HttpResponse>('/order-core/purchase/notice/order/noticeWms', { idList: data });
}
// 查询商品明细
export function queryGoodsDetail(data: ProductDetailType) {
  return axios.post<any, HttpResponse>('/order-core/purchase/notice/order/queryPurchaseOrderProductDetail', data);
}
// 查询商品明细
export function queryStockDetail(data: ProductDetailType) {
  return axios.post<any, HttpResponse>('/order-core/purchase/notice/order/queryPurchaseNoticeOrderProductDetail', data);
}
// 查询序列号
export function querySerialNumber(data: SerialNumberType) {
  return axios.post<any, HttpResponse>('/order-core/purchase/notice/order/queryWarehousingSerialNumber', data);
}