/**
 * @ Author: Sam
 * @ Create Time: 2023-03-30 10:18:22
 * @ Modified by: Sam
 * @ Modified time: 2023-03-30 10:33:05
 * @ Description: 采购订单
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { PurchaseOrderListRes, PurchaseOrderSearchForm } from '@/types/purchase/order';

// 获取已启用实体仓下的已启用虚拟仓
export function getActiveVirtualList() {
  return axios.get<any, HttpResponse>('/auth-core/warehouse/activeVirtual');
}

// 分页查询
export function getPage(data: PurchaseOrderSearchForm) {
  return axios.post<any, HttpResponse<PurchaseOrderListRes>>('/order-core/purchase/order/getPage', data);
}