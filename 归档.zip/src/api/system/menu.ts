/*
 * @Author: Sam
 * @Date: 2023-01-31 08:52:38
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-07 09:38:10
 */
import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { MenuForm, MenuSearchForm } from '@/types/system/menu';
import { MenuDataItem } from '@arco-design/web-vue/es/menu/interface';

// 添加菜单
export function addMenu(data: MenuForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/menu/menuAdd', data);
}

// 删除菜单
export function delMenu(id: number) {
  return axios.get<any, HttpResponse>(
    `/auth-core/system/menu/menuDel?id=${id}`
  );
}

// 编辑菜单
export function editMenu(data: MenuForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/menu/menuEdit', data);
}

// 菜单列表
export function queryMenu(data: MenuSearchForm) {
  return axios.post<any, HttpResponse<MenuDataItem[]>>(
    '/auth-core/system/menu/menuList',
    data
  );
}
