import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  DictionaryForm,
  DictionaryType,
  DictionarySearchForm,
  DictionarySearchListForm,
  DictionaryRes,
  DictionaryListRes,
  DictionaryTitleForm,
  DictionaryTitleType,
} from '@/types/system/dictionary';

// 添加数据字典
export function addDictionary(data: DictionaryForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/dataDictionary/add', data);
}

// 删除数据字典
export function delDictionary(id: string) {
  return axios.get<any, HttpResponse>(`/auth-core/system/dataDictionary/delete?id=${id}`);
}

// 编辑数据字典
export function editDictionary(data: DictionaryForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/dataDictionary/edit', data);
}

// 数据字典名称列表
export function queryPage(data: DictionarySearchForm) {
  return axios.post<any, HttpResponse<DictionaryRes>>(
    '/auth-core/system/dataDictionary/getPage',
    data
  );
}

// 数据字典名称列表
export function queryList(data: DictionarySearchListForm) {
  return axios.post<any, HttpResponse<DictionaryListRes>>(
    '/auth-core/system/dataDictionaryTitle/getPage',
    data
  );
}

//获取所有字典分类（包含禁用）
export function queryType(dictionaryType:string) {
  return axios.post<any, HttpResponse<DictionaryType[]>>(
    '/auth-core/system/dataDictionary/getValidDictionaryTitle',
    {
      dictionaryType
    }
  );
}

// 添加数据字典项
export function addDictionaryTitle(data: DictionaryTitleForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/dataDictionaryTitle/add', data);
}

// 编辑数据字典项
export function editDictionaryTitle(data: DictionaryTitleForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/dataDictionaryTitle/edit', data);
}

// 通过字典ID获取上级数据字典的标签列表
export function getPidList(dictionaryTypeId: number|string) {
  return axios.get<any, HttpResponse>(`/auth-core/system/dataDictionaryTitle/getSubDictionaryTitleByDictionaryTypeId/${dictionaryTypeId}`);
}

// 获取新增字典里的上级字典
export function getNameList() {
  return axios.post<any, HttpResponse>(
    '/auth-core/system/dataDictionary/getNameList',
  );
}

// 数据字典启用禁用
export function getStatusUpdate(id: string) {
  return axios.get<any, HttpResponse>(`/auth-core/system/dataDictionary/dictionaryStatusUpdate/${id}`);
}

// 数据字典启用禁用
export function getTitleStatusUpdate(id: string) {
  return axios.get<any, HttpResponse>(`/auth-core/system/dataDictionaryTitle/dictionaryTitleStatusUpdate/${id}`);
}

//通过字典类型获取一级字典标签(有效且上架中)----目前用在快递管理的标准快递
export function getDictionaryTitle(dictionaryType:string) {
  return axios.post<any, HttpResponse<DictionaryTitleType[]>>(
    '/auth-core/system/dataDictionary/getDictionaryTitle',
    {
      dictionaryType
    }
  );
}