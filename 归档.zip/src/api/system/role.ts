/*
 * @Author: Sam
 * @Date: 2023-02-01 15:21:57
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-07 15:35:45
 */
import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { RoleAuthParamsForm, RoleAuthParamsRes, RoleForm, RoleFunctionAuthForm, RoleInfoItem, RoleSearchForm, RoleSearchRes, RoleSelectItem, RoleUserRes, RoleUserSearch } from '@/types/system/role';

// 角色分页列表
export function queryRoleList(data: RoleSearchForm) {
  return axios.post<any, HttpResponse<RoleSearchRes>>('/auth-core/role/getPage', data);
}

// 新增或编辑
export function submitRoleForm(data: RoleForm) {
  return axios.post<any, HttpResponse>('/auth-core/role/addOrUpdate', data);
}

// 获取角色所拥有菜单权限的下拉选项
export function getRoleMenuSelect(data: {roleId:number}) {
  return axios.post<any, HttpResponse<RoleSelectItem[]>>('/auth-core/role/getRoleMenuSelect', data);
}

// 功能授权
export function batchRoleMenu(data: RoleFunctionAuthForm) {
  return axios.post<any, HttpResponse>('/auth-core/role/batchRoleMenu', data);
}

// 角色用户分页列表
export function getRoleUserPage(data: RoleUserSearch) {
  return axios.post<any, HttpResponse<RoleUserRes>>('/auth-core/role/getRoleUserPage', data);
}

// 角色详情
export function getRoleDetail(id: string) {
  return axios.get<any, HttpResponse<RoleInfoItem>>(`/auth-core/role/detail/${id}`);
}

// 通过ID删除
export function delRole(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/role/delete/${id}`);
}

// 角色启用/禁用
export function onOrDropRole(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/role/onOrDrop/${id}`);
}

// 获取角色字段授权信息
export function getRoleDataPermissions(data: RoleAuthParamsForm) {
  return axios.post<any, HttpResponse<RoleAuthParamsRes[]>>('/auth-core/role/getRoleDataPermissions', data);
}

// 保存角色字段授权信息
export function saveRoleDataPermissions(data: RoleAuthParamsForm) {
  return axios.post<any, HttpResponse>('/auth-core/role/saveRoleDataPermissions', data);
}

// 获取角色下拉选项
export function getRoleList(data = {}) {
  return axios.post<any, HttpResponse>('/auth-core/role/getRoleSelect', data);
}

// 查询指定用户已经被授予的角色
export function getUserRoleList(userId: string) {
  return axios.get<any, HttpResponse>(`/auth-core/system/user/queryRoleByUserId?id=${userId}`);
}

// 角色授权参数类型
export class RoleAuthParameterType {
  // 被授权用户的ID
  id: string[] = [];
  // 授予角色的ID
  lstRoleId: string[] = [];
}
// 给指定用户授权角色
export function roleAuth(data: RoleAuthParameterType) {
  if (Array.isArray(data?.id) && data?.id?.length > 1) {
    // 批量用户授权
    return axios.post<any, HttpResponse>('/auth-core/system/user/batchRoleAuth', {
      lstId: data.id,
      lstRoleId: data.lstRoleId
    });
  } else {
    // 单个用户授权
    return axios.post<any, HttpResponse>('/auth-core/system/user/roleAuth', {
      id: data.id[0],
      lstRoleId: data.lstRoleId
    });
  }
}

// 获取店铺下拉选项
export function getShopList(data = {}) {
  return axios.get<any, HttpResponse>('/auth-core/system/store/queryStoreSelect', data);
}

// 查询指定用户已经被授权的店铺
export function getUserShopList(userId: string) {
  return axios.get<any, HttpResponse>(`/auth-core/system/user/queryStoreByUserId?id=${userId}`);
}

// 店铺授权参数类型
export class ShopAuthParameterType {
  // 被授权用户的ID
  id: string[] = [];
  // 授予店铺的ID
  lstStoreId: string[] = [];
}
// 给指定用户授予指定店铺权限
export function shopAuth(data: ShopAuthParameterType) {
  if (Array.isArray(data?.id) && data?.id?.length > 1) {
    // 批量店铺授权
    return axios.post<any, HttpResponse>('/auth-core/system/user/batchStoreAuth', {
      lstId: data.id,
      lstStoreId: data.lstStoreId
    });
  } else {
    // 单个店铺授权
    return axios.post<any, HttpResponse>('/auth-core/system/user/storeAuth', {
      id: data.id[0],
      lstStoreId: data.lstStoreId
    });
  }
}

// 查询指定用户已经被授权的仓库
export function getUserStoreList(userId: string) {
  return axios.get<any, HttpResponse>(`/auth-core/system/user/queryWarehouseByUserId?id=${userId}`);
}

// 获取仓库下拉选项
export function getStoreList(data = {}) {
  return axios.get<any, HttpResponse>('/auth-core/warehouse/queryWarehouseSelect', data);
}

// 仓库授权参数类型
export class StoreAuthParameterType {
  // 被授权用户的ID
  id: string[] = [];
  // 授予仓库的ID
  lstWarehouseId: string[] = [];
}
// 给指定用户授权指定仓库权限
export function storeAuth(data: StoreAuthParameterType) {
  if (Array.isArray(data?.id) && data?.id?.length > 1) {
    // 批量仓库授权
    return axios.post<any, HttpResponse>('/auth-core/system/user/batchWarehouseAuth', {
      lstId: data.id,
      lstWarehouseId: data.lstWarehouseId
    });
  } else {
    // 单个仓库授权
    return axios.post<any, HttpResponse>('/auth-core/system/user/warehouseAuth', {
      id: data.id[0],
      lstWarehouseId: data.lstWarehouseId
    });
  }
}