/*
 * @Author: Sam
 * @Date: 2023-02-09 10:23:47
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-09 17:15:08
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  OrganizationForm,
  OrganizationListItem,
  UserForm,
  UserSearchForm,
  UserSearchListRes,
} from '@/types/system/user';

// 用户列表查询
export function getUserPage(data: UserSearchForm) {
  return axios.post<any, HttpResponse<UserSearchListRes>>(
    '/auth-core/system/user/userPage',
    data
  );
}

// 查询组织树结构
export function getOrgTree() {
  return axios.get<any, HttpResponse<OrganizationListItem[]>>(
    '/auth-core/system/user/getOrgTree'
  );
}

// 添加组织
export function addOrg(data: OrganizationForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/user/addOrg', data);
}

// 添加用户
export function addUser(data: UserForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/user/addUser', data);
}

// 修改用户
export function editUser(data: UserForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/user/editUser', data);
}

// 切换用户状态为启用或禁用
export function toggleUserStatus(userId: string) {
  return axios.get<any, HttpResponse>('/auth-core/system/user/updateStatus', {
    params: {
      id: userId
    }
  });
}

// 批量切换用户状态为启用或禁用
export function batchToggleUserStatus(userIdList: string[], status: boolean) {
  return axios.post<any, HttpResponse>('/auth-core/system/user/batchUpdateStatus', {
    lstId: userIdList,
    status: status
  })
}

// 删除用户
export function deleteUser(userIdList: Number[]) {
  return axios.post<any, HttpResponse>('/auth-core/system/user/batchDel', {
    lstId: userIdList
  })
}

// 重置用户默认密码
export function resetPassword(userId: string) {
  return axios.get<any, HttpResponse>('/auth-core/system/user/resetPwd', {
    params: {
      id: userId
    }
  })
}

// 更新组织
export function updateOrg(data: OrganizationForm) {
  return axios.post<any, HttpResponse>('/auth-core/system/user/updateOrg', data);
}

// 删除组织
export function delOrg(id: number) {
  return axios.post<any, HttpResponse>('/auth-core/system/user/delOrg', { id });
}

// 用户管理初始下拉数据
export function initData() {
  return axios.get<any, HttpResponse>('/auth-core/system/user/initData');
}

// 查询用户详情
export function userDetail(id: string | number) {
  return axios.get<any, HttpResponse>(`/auth-core/system/user/userDetail?id=${id}`);
}
