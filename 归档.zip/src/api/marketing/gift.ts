/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-15 14:17:49
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-21 20:01:24
 * @FilePath: \oms-admin\src\api\marketing\gift.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  GiftSearchType,
  SpecSearchType,
  ActivityStoreitemType,
  AddMarketingGiftType,
  GiftActityGoodsSearch
} from '@/types/marketing/gift'
import { PurchaseAuditType } from '@/types/product/purchase'

// 查询列表
export function queryPresentActivityPage(data: GiftSearchType) {
  return axios.post<any, HttpResponse>('/order-core/present/activity/queryPresentActivityPage', data);
}

// 查询规格商品
export function querySpecProductPage(data: SpecSearchType) {
  return axios.post<any, HttpResponse>('/order-core/present/activity/queryCombinationProductAndProductPage', data);
}
// 查询规店铺
export function queryStoreList(data: ActivityStoreitemType) {
  return axios.post<any, HttpResponse>('/order-core/present/activity/queryStorePage', data);
}
// 新增赠品活动
export function productActivityAdd(data: AddMarketingGiftType) {
  return axios.post<any, HttpResponse>('/order-core/present/activity/productActivityAdd', data);
}
// 编辑赠品活动
export function productActivityEdit(data: AddMarketingGiftType) {
  return axios.post<any, HttpResponse>('/order-core/present/activity/productActivityEdit', data);
}
// 赠品活动作废
export function cancellation(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/present/activity/cancellation?id=${id}`);
}
// 赠品活动审核
export function auditGift(data: PurchaseAuditType) {
  return axios.post<any, HttpResponse>(`/order-core/present/activity/audit`, data);
}
// 查询活动店铺
export function queryPresentActivityStore(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/present/activity/queryPresentActivityStore?activityId=${id}`);
}
// 查询活动商品
export function queryPresentActivityProductPage(data: GiftActityGoodsSearch) {
  return axios.post<any, HttpResponse>(`/order-core/present/activity/queryPresentActivityProductPage`, data);
}
// 通过id查询详情
export function queryPresentActivityDetail(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/present/activity/queryPresentActivityDetail?id=${id}`);
}
// 通过id查询详情
export function batchInputPresentActivityProduct(data: FormData, type: string = 'activity') {
  let url = `/order-core/present/activity/${type == 'activity' ? 'batchInputPresentActivityProduct' : 'batchInputPresentActivityPresent'}`
  return axios.post<any, HttpResponse>(url, data);
}
// 通过id提交
export function productActivitySubmit(id:string) {
  return axios.get<any, HttpResponse>(`/order-core/present/activity/submit?id=${id}`);
}