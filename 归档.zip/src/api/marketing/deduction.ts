/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-20 14:33:35
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-20 17:23:23
 * @FilePath: \oms-admin\src\api\marketing\deduction.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { DeductionSearchType } from '@/types/marketing/deduction'
import { PurchaseAuditType } from '@/types/product/purchase'
import {AddDeductionListType} from '@/types/marketing/deduction'

// 查询列表
export function queryDeductionPage(data: DeductionSearchType) {
  return axios.post<any, HttpResponse>('/order-core/strategy/deduction/getPage', data);
}
// 提交
export function deductionSubmit(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/strategy/deduction/submit/${id}`);
}
// 作废
export function deductionOnOrDrop(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/strategy/deduction/cancel/${id}`);
}
// 审核 
export function deductionAudit(data: PurchaseAuditType) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/deduction/auditById`,data);
}
// 详情
export function deductionDetail(id: string) {
  return axios.get<any, HttpResponse>(`/order-core/strategy/deduction/detail/${id}`);
}
// 查询授权的店铺
export function queryUserStore() {
  return axios.get<any, HttpResponse>(`/auth-core/system/store/queryUserStore`);
}
// 新增或更新
export function addOrUpdate(data:AddDeductionListType) {
  return axios.post<any, HttpResponse>(`/order-core/strategy/deduction/addOrUpdate`,data);
}