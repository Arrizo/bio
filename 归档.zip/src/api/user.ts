/*
 * @Author: Sam
 * @Date: 2023-01-31 08:52:42
 * @Last Modified by: Sam
 * @Last Modified time: 2023-02-09 15:41:08
 */
import axios from 'axios';
import { UserState } from '@/store/modules/user/types';
import { UserInfo, LoginData, LoginRes } from '@/types/user';
import { HttpResponse } from '@/types/global';

// 管理端-登录
export function login(data: LoginData) {
  return axios.post<any, HttpResponse<LoginRes>>('/auth-core/auth/login', data);
}

// 根据Token获取管理用户session
export function getAdminToken() {
  return axios.get<UserState>('/auth-core/auth/getAdminToken');
}

// 获取用户登陆权限
export function getMenu() {
  return axios.get<any, HttpResponse<UserInfo>>('/auth-core/auth/getMenu');
}

// 管理端-退出登录
export function logout() {
  return axios.get('/auth-core/auth/logout');
}

// RSA加密公钥
export function getRsaPublicKey() {
  return axios.get<any, HttpResponse<string>>('/auth-core/auth/getRsaPublicKey');
}

// 修改用户密码
export function changePassword(
  oldPassword: string,
  newPassword: string,
  confirmPassword: string
) {
  return axios.post<any, HttpResponse>('/auth-core/system/user/updatePwd', {
    oldPassword,
    newPassword,
    confirmPassword,
  });
}

/** 获取当前资源的版本号 */
export function getVersion() {
  return axios.get<any, { version: string }>(
    `https://${window.location.host}/version.json`
  );
}
