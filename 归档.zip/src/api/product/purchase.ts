/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-23 16:08:42
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-10 18:06:22
 * @FilePath: \oms-admin\src\api\product\purchase.ts
 */
import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
PurchaseSeachType,
AddjustPriceType,
PurchaseAuditType,
AdjustPriceRecordAddBO,
AdjustRecordSearch,
PriceRecordAuditPageClass,
PurchaseListType
} from '@/types/product/purchase';
// 获取品牌列表
export function queryPurchaseList(data?:PurchaseSeachType){
  return axios.post<any, HttpResponse>('/auth-core/adjust/price/getPage',data);
}
// 更改状态
export function adjustPriceStatus(id:string){
  return axios.get<any, HttpResponse>(`/auth-core/adjust/price/adjustPriceStatus?id=${id}`);
}
// 查询商品
export function queryProductAndSpecList(data:any){
  return axios.post<any, HttpResponse>(`/auth-core/product/queryProductAndSpecList`,data);
}
// 查询供应商
export function querySupplierList(key:string,code:string){
  return axios.get<any, HttpResponse>(`/auth-core/supplier/querySupplierList?keyWord=${key}&skuCode=${code}`);
}
// 添加调价
export function adjustPriceAdd(data:AddjustPriceType){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/adjustPriceAdd`,data);
}
// 采购调价审核
export function adjustPriceAudit(data:PurchaseAuditType){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/auditMapping`,data);
}
// 采购调价详情
export function queryAdjustPriceDetail(id:string){
  return axios.get<any, HttpResponse>(`/auth-core/adjust/price/queryAdjustPriceDetail?id=${id}`);
}
// 添加采购调价
export function adjustPriceRecordAdd(data:Array<AdjustPriceRecordAddBO>){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/record/adjustPriceRecordAdd`,data);
}
// 采购调价分页列表
export function queryRecordList(data:AdjustRecordSearch){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/record/getPage`,data);
}
// 采购调价记录审核分页列表
export function findAdjustPriceRecordAuditPage(data:PriceRecordAuditPageClass){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/record/findAdjustPriceRecordAuditPage`,data);
}
// 采购调价记录上下线
export function adjustPriceRecordOnOrOff(data:PurchaseAuditType){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/record/onOrOff`,data);
}
// 编辑采购调价记录
export function adjustPriceRecordEdit(data:PurchaseListType){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/record/adjustPriceRecordEdit`,data);
}
// 导入采购调价
export function importAdjustPrice(data:FormData){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/batchInputAdjustPrice`,data);
}
// 调价审核跟确认
export function auditMapping(data:PurchaseAuditType){
  return axios.post<any, HttpResponse>(`/auth-core/adjust/price/record/auditMapping`,data);
}
// 采购调价记录详情
export function queryAdjustRecordPriceDetail(id:string){
  return axios.get<any, HttpResponse>(`/auth-core/adjust/price/record/findAdjustPriceRecordDetail?id=${id}`);
}