/**
 * @ Author: Sam
 * @ Create Time: 2023-02-28 09:08:01
 * @ Modified by: Sam
 * @ Modified time: 2023-03-15 08:22:41
 * @ Description: 商品档案-请求
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  AddSupplierForm,
  AttrItem,
  AuditSkuRes,
  AuditSkuSearchForm,
  BatchAuditForm,
  GoodsForm,
  GoodsSearchForm,
  SpecDetail,
  SpecForm,
  SpecsListItem,
  SupplierItem,
} from '@/types/product/goods';

// 商品列表
export function getList(data: GoodsSearchForm) {
  return axios.post<any, HttpResponse>('/auth-core/product/list', data);
}

// 导出商品
export function outputGoods(data: any) {
  return axios.post<any, HttpResponse>('/auth-core/product/export', data);
}

// 添加商品
export function addProduct(data: GoodsForm) {
  return axios.post<any, HttpResponse>('/auth-core/product/add', data);
}

// 商品详情
export function getProductDetail(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/product/${id}`);
}

// 更新商品
export function updateProduct(data: GoodsForm) {
  return axios.post<any, HttpResponse>('/auth-core/product/update', data);
}

// 商品新增信息初始化
export function initSpu() {
  return axios.get<any, HttpResponse>('/auth-core/product/init');
}

// 规格新增信息初始化
export function initSku() {
  return axios.get<any, HttpResponse>('/auth-core/specs/init');
}

// 商品所属规格
export function getSpecs(productId: number) {
  return axios.get<any, HttpResponse<SpecsListItem[]>>(
    `/auth-core/specs/relation/${productId}`
  );
}

// 导入商品
export function uploadGoods(data: FormData) {
  return axios.post<any, HttpResponse>('/auth-core/product/import', data);
}

// 导入商品
export function getUnAudit(data: AuditSkuSearchForm) {
  return axios.post<any, HttpResponse<AuditSkuRes>>(
    '/auth-core/specs/unAuditSku',
    data
  );
}

// 批量审核
export function batchAudit(data: BatchAuditForm) {
  return axios.post<any, HttpResponse>('/auth-core/specs/batchAudit', data);
}

// 查询规格详情
export function getSpecsDetail(skuId: number) {
  return axios.get<any, HttpResponse<SpecDetail>>(`/auth-core/specs/${skuId}`);
}

// 添加商品规格
export function addSpecs(data: SpecForm) {
  return axios.post<any, HttpResponse>('/auth-core/specs/add', data);
}

// 修改商品规格
export function updateSpecs(data: SpecForm) {
  return axios.post<any, HttpResponse>('/auth-core/specs/update', data);
}

// 查询sku对应的供应商信息
export function getSupplierBySku(skuId: number) {
  return axios.get<any, HttpResponse<SupplierItem[]>>(
    `/auth-core/specs/supplier/${skuId}`
  );
}

// 查询有效并且启用的供应商 keyWord 供应商编码或者供应商名称
export function getSupplierList(keyWord: string, skuId: any) {
  return axios.get<any, HttpResponse<SupplierItem[]>>(
    `/auth-core/supplier/queryOtherSupplier?skuId=${skuId}&keyWord=${keyWord}`
  );
}

// 修改商品规格
export function addSupplierApi(data: AddSupplierForm) {
  return axios.post<any, HttpResponse>('/auth-core/specs/addSupplier', data);
}

// 查询包材sku信息
export function getPackingSku(title: string) {
  return axios.get<any, HttpResponse<SupplierItem[]>>(
    `/auth-core/specs/packingSku?title=${title}`
  );
}

// 启用/禁用商品规格
export function updateSkuStatus(id: number, status: boolean) {
  return axios.post<any, HttpResponse>(`/auth-core/specs/enable`, {
    id,
    status,
  });
}

// 启用/禁用商品
export function updateSpuStatus(id: number, status: boolean) {
  return axios.post<any, HttpResponse>(`/auth-core/product/enable`, {
    id,
    status,
  });
}

// 查询包材sku信息
export function getSpecsAttr() {
  return axios.get<any, HttpResponse<AttrItem[]>>(`/auth-core/specs/attr`);
}

// 商品档案导出模板
export function downTemplate() {
  return axios.get<any, HttpResponse<AttrItem[]>>(
    `/auth-core/product/template`
  );
}
