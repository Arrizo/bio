import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { AddPricesReq, AuditMappingFrom, AuditPageReq, AuditPageRes, CombinationReq, DistributionEditFrom, DistributionFrom, DistributionReq, DistributionRes, PriceRecordReq, PriceRecordRes } from '@/types/product/distribution';

// 列表查询
export function queryPage(data: DistributionReq) {
  return axios.post<any, HttpResponse<DistributionRes>>(
    '/auth-core/product/mapping/queryPage',
    data
  );
}

// 新增铺货关系
export function addDistribution(data: DistributionFrom) {
  return axios.post<any, HttpResponse>(
    '/auth-core/product/mapping/add',
    data
  );
}

// 编辑铺货关系
export function editDistribution(data: DistributionEditFrom) {
  return axios.post<any, HttpResponse>(
    '/auth-core/product/mapping/edit',
    data
  );
}

// 查询详情
export function queryDetail(data: number) {
  return axios.get<any, HttpResponse>(
    `/auth-core/product/mapping/queryDetail?id=${data}`
  );
}


// 启用禁用
export function updateStatus(data: number) {
  return axios.get<any, HttpResponse>(
    `/auth-core/product/mapping/updateStatus?id=${data}`
  );
}

// 导入铺货关系
export function uploadMapping(data:FormData) {
  return axios.post<any, HttpResponse>('/auth-core/product/mapping/uploadMapping',data);
}

// 铺货关系审核
export function auditMapping(data: AuditMappingFrom) {
  return axios.post<any, HttpResponse>(
    '/auth-core/product/mapping/auditMapping',
    data
  );
}

// 调价记录列表查询
export function queryPricePage(data: PriceRecordReq) {
  return axios.post<any, HttpResponse<PriceRecordRes>>(
    '/auth-core/product/mapping/queryPricePage',
    data
  );
}

// 调价记录列表查询
export function queryAuditPage(data: AuditPageReq) {
  return axios.post<any, HttpResponse<AuditPageRes>>(
    '/auth-core/product/mapping/queryAuditPage',
    data
  );
}

//申请调价
export function addPrices(data: AddPricesReq) {
  return axios.post<any, HttpResponse>(
    '/auth-core/product/mapping/addPrices',
    data
  );
}

//上线下线
export function onOrOff(data: AuditMappingFrom) {
  return axios.post<any, HttpResponse>(
    '/auth-core/product/mapping/onOrOff',
    data
  );
}

//编辑调价
export function editPrices(data: AddPricesReq) {
  return axios.post<any, HttpResponse>(
    '/auth-core/product/mapping/editPrices',
    data
  );
}

//铺货调价审核
export function auditPrice(data: AuditMappingFrom) {
  return axios.post<any, HttpResponse>(
    '/auth-core/product/mapping/auditPrice',
    data
  );
}

//查询调价详情
export function queryPricesDetail(data: number) {
  return axios.get<any, HttpResponse>(
    `/auth-core/product/mapping/queryPricesDetail?id=${data}`
  );
}

//
export function getCombinationPage(data: CombinationReq) {
  return axios.post<any, HttpResponse>(
    '/auth-core/combination/product/getPage',
    data
  );
}

//查询用户授权下拉店铺
export function queryUserStore() {
  return axios.get<any, HttpResponse>(
    `/auth-core/system/store/queryUserStore`
  );
}
