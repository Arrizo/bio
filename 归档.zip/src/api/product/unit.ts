/**
 * @ Author: Sam
 * @ Create Time: 2023-02-25 13:36:08
 * @ Modified by: Sam
 * @ Modified time: 2023-02-27 08:53:38
 * @ Description: 商品分类-请求
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { UnitForm, UnitListRes, UnitSearchForm } from '@/types/product/unit';

// 列表查询
export function getList(data: UnitSearchForm) {
  return axios.post<any, HttpResponse<UnitListRes>>('/auth-core/product/unit/queryPage', data);
}

// 添加计量单位
export function addUnit(data: UnitForm) {
  return axios.post<any, HttpResponse>('/auth-core/product/unit/add', data);
}

// 编辑计量单位
export function editUnit(data: UnitForm) {
  return axios.post<any, HttpResponse>('/auth-core/product/unit/edit', data);
}

// 查询详情
export function queryDetail(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/product/unit/queryDetail?id=${id}`);
}

// 启用禁用
export function updateStatus(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/product/unit/updateStatus?id=${id}`);
}
