import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { CombinationListForm, AuditByIdListForm , AddOrUpdateForm } from '@/types/product/combination';


// 组合商品分页列表
export function getCombinationList(data: CombinationListForm) {
  return axios.post<any, HttpResponse>('/auth-core/combination/product/getPage', data);
}

// 启用/禁用
export function updateStatus(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/combination/product/onOrDrop/${id}`);
}

// 组合商品详情
export function getCombinationDetail(id: number) {
  return axios.get<any, HttpResponse>(`/auth-core/combination/product/detail/${id}`);
}

// 审核
export function auditByIdList(data: AuditByIdListForm) {
  return axios.post<any, HttpResponse>(`/auth-core/combination/product/auditByIdList`, data);
}

// 添加或编辑组合商品
export function addOrUpdate(data: AddOrUpdateForm) {
  return axios.post<any, HttpResponse>(`/auth-core/combination/product/addOrUpdate`, data);
}

// 查询操作日志记录
export function quaryRangeLog(code:string,type:string) {
  return axios.get<any, HttpResponse>(`/auth-core/loki/quaryRange?businessCode=${code}&businessType=${type}`);
}

// 获取店铺下拉选项
export function queryUserStore(data = {}) {
  return axios.get<any, HttpResponse>('/auth-core/system/store/queryUserStore', data);
}
