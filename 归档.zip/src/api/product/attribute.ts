import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  AttributeSearchType,
  AttributeDetailsType
} from '@/types/product/attribute'
// 属性列表
export function getAttributeList(data: AttributeSearchType) {
  return axios.post<any, HttpResponse>('/auth-core/product/attr/getPage', data);
}
// 修改属性状态
export function setAttributeOnOrDrop(id: string) {
  return axios.get<any, HttpResponse>(`/auth-core/product/attr/onOrDrop/${id}`);
}
// 查询属性详情
export function getAttributeDetails(id: string) {
  return axios.get<any, HttpResponse>(`/auth-core/product/attr/detail/${id}`);
}
// 更新属性详情
export function attributeAddOrUpdate(data: AttributeDetailsType) {
  return axios.post<any, HttpResponse>('/auth-core/product/attr/addOrUpdate', data);
}