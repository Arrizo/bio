/**
 * @ Author: Sam
 * @ Create Time: 2023-02-25 13:36:08
 * @ Modified by: Sam
 * @ Modified time: 2023-03-09 08:44:42
 * @ Description: 商品分类-请求
 */

import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  CategorySearcForm,
  CategoryListItem,
  CategoryForm,
} from '@/types/product/category';

// 商品分类列表
export function getList(data: CategorySearcForm) {
  return axios.get<any, HttpResponse<CategoryListItem[]>>(
    '/auth-core/prodCategory/list',
    {
      params: data,
    }
  );
}

// 新增分类
export function addCategory(data: CategoryForm) {
  return axios.post<any, HttpResponse>('/auth-core/prodCategory/add', data);
}

// 编辑分类
export function editCategory(data: CategoryForm) {
  return axios.post<any, HttpResponse>('/auth-core/prodCategory/update', data);
}

// 启用禁用
export function updateStatus(data: any) {
  return axios.post<any, HttpResponse>(
    `/auth-core/prodCategory/updateStatus`,
    data
  );
}
