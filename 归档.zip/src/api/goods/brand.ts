/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 13:53:20
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-02-23 10:11:46
 * @FilePath: \oms-admin\src\api\goods\brand.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import axios from 'axios';
import { HttpResponse } from '@/types/global';
import {
  GoodsBrandListType,
  GoodsBrandSearchType
} from '@/types/goods/brand';
// 获取品牌列表
export function queryBrandList(data:GoodsBrandSearchType){
  return axios.post<any, HttpResponse>('/auth-core/product/brand/getPage',data);
}
// 修改品牌列表转态
export function brandStatusUpdate(id:string){
  return axios.get<any, HttpResponse>(`/auth-core/product/brand/productBrandStatusUpdate?id=${id}`);
}
// 修改品牌详情
export function findBrandDetail(id?:string){
  return axios.get<any, HttpResponse>(`/auth-core/product/brand/findStoreDetail?id=${id}`);
}
// 添加品牌
export function productBrandAdd(data:any){
    let url:string=data.id?'/auth-core/product/brand/productBrandEdit':`/auth-core/product/brand/productBrandAdd`
  return axios.post<any, HttpResponse>(url,data);
}