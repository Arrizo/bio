<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-10 15:47:51
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-14 09:35:19
 * @ Description:操作日志
 -->

<template>
  <a-modal v-if="state.logType === 'modal'" :mask-closable="false" @close="handleCancel" :title="state.title"
    width="862px" v-model:visible="isShow" title-align="start" :footer="false" unmountOnClose>
    <oms-table :loading="loading" style="margin-bottom: 4px;">
      <a-table stripe :scroll="{ x: 300, y: 440 }" :data="(list as any)" :pagination="false"
        :bordered="{ wrapper: false }">
        <template #columns>
          <a-table-column title="操作时间" :width="140" data-index="operationTime"></a-table-column>
          <a-table-column title="操作人" :width="80" data-index="operater"></a-table-column>
          <a-table-column title="操作" :width="80" data-index="logType"></a-table-column>
          <a-table-column title="内容" ellipsis tooltip :width="300" data-index="msg"></a-table-column>
        </template>
      </a-table>
    </oms-table>
  </a-modal>
  <a-table v-if="state.logType === 'page'" stripe :bordered="{ wrapper: false }" :data="(list as any)" :pagination="false"
    :scroll="{ x: 300, y: 420 }" :loading="loading">
    <template #columns>
      <a-table-column title="操作时间" :width="140" data-index="operationTime"></a-table-column>
      <a-table-column title="操作人" :width="80" data-index="operater"></a-table-column>
      <a-table-column title="操作" :width="80" data-index="logType"></a-table-column>
      <a-table-column title="内容" ellipsis tooltip :width="300" data-index="msg"></a-table-column>
    </template>
  </a-table>
</template>
<script setup lang="ts" name="system-supplier-finance-info">
import { OperationLogType } from '@/types/basicdata/shop';
import { quaryRangeLog } from '@/api/basicdata/shop';
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { Message } from '@arco-design/web-vue';

const emits = defineEmits<{
  (e: "close"): void,
}>();

const loading = ref<boolean>(false);//加载loading
const list = ref<OperationLogType[]>();//操作日志数据
const isShow = ref<boolean>(false);//是否弹框
const state = reactive({
  code: "",
  type: "",
  logType: "",
  title: "",
});

const handleCancel = () => {
  isShow.value = false;
  emits('close')
}

const getQuaryRangeLog = async () => {
  if (!state.code) return;

  loading.value = true;
  try {
    const res = await quaryRangeLog(state.code, state.type)
    loading.value = false;
    if (res.code != 0) {
      throw new Error(res.message)
    }
    list.value = res.value
  } catch (error) {
    Message.error((error as Error).message)
    loading.value = false;
  } finally {
    loading.value = false;
  }
}

/**
 * 初始化
 * @param code  编码，接口请求传参
 * @param type  类型，接口请求传参
 * @param logType  日志类型（页面、弹框），默认弹框
 * @param title  日志标题，弹框形式选传，默认名称为日志
 */
const init = (code: string, type: string, logType: "modal" | "page" = "modal", title: string = "日志") => {
  state.code = code;
  state.title = title;
  state.type = type;
  state.logType = logType;

  logType === 'modal' && (isShow.value = !!code);

  getQuaryRangeLog();
}

defineExpose({
  init
})
</script>