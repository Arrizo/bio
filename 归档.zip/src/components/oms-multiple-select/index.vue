<!-- 统一封装多选下拉选择器 -->
<template>
  <a-select v-model="val" placeholder="请选择" multiple :disabled="disabled" @change="onChange" allow-clear
    :max-tag-count="maxTagCount" :format-label="handleLabel">
    <template v-for="v in optionList">
      <a-option :value="(v as any)[props.value]" :disabled="v.disabled">{{ (v as any)[props.label] }}</a-option>
    </template>
    <template #header v-if="optionList.length >= 3">
      <div style="padding: 6px 12px;">
        <a-checkbox v-model="isSelect" @change="onSelectAllChange">全选</a-checkbox>
      </div>
    </template>
  </a-select>
</template>

<script setup lang="ts" name="oms-multiple-select">
import { SelectOptionData } from '@arco-design/web-vue';
import { PropType, ref, watch } from 'vue';

const props = defineProps({
  modelValue: { type: Array as PropType<(number | string)[]>, default: () => [] },
  optionList: { type: Array as PropType<{ value: string | number, label: string | number, disabled: boolean }[]>, default: () => [] },
  value: { type: String, default: "value" },
  label: { type: String, default: "label" },
  maxTagCount: { type: Number, default: 4 },
  disabled: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: "update:modelValue", data: string | number | Record<string, any> | (string | number | Record<string, any>)[]): void
}>();

const isSelect = ref<boolean>(false);

const val = ref<(number | string)[]>([]);

const onSelectAllChange = (v: boolean | (string | number | boolean)[]) => {
  val.value = [];

  if (!v) {
    emits("update:modelValue", val.value);
    return;
  };
  for (let i = 0; i < props.optionList.length; i++) {
    if (!props.optionList[i].disabled) {
      val.value.push(props.optionList[i][props.value]);
    }
  }
  emits("update:modelValue", val.value);
}

const onChange = (value: string | number | Record<string, any> | (string | number | Record<string, any>)[]) => {
  isSelect.value = val.value.length === props.optionList.length;
  emits("update:modelValue", val.value);
}

//处理label字段太长换行问题
const handleLabel = (data: SelectOptionData) => {
  if (props.maxTagCount === 1) {
    let idx = props.optionList.findIndex(item => item[props.value] == data.value);
    if (idx === -1) return ''
    return substringName(props.optionList[idx][props.label], 7)
  }
  return data.label;
}

//超出几个字省略号
const substringName = (value: string, num: number) => {
  let count = 0;
  count = num;
  if (val.value.length === 1) count = 10

  if (!value) return '';
  if (value.length > count) {
    return value.slice(0, count) + "...";
  }
  return value;
}

watch(() => props.modelValue, () => {
  val.value = props.modelValue;
  isSelect.value = val.value.length !== 0 && val.value.length === props.optionList.length;
}, {
  immediate: true,
  deep: true
});
</script>