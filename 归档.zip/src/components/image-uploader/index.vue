<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-22 09:01:51
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 19:57:12
 * @ Description: 图片上传组件
 -->
<template>
  <div style="width: 74px;height: 74px;" v-if="!show"></div>
  <a-upload v-if="show" list-type="picture-card" v-model:file-list="bindList" :default-file-list="fileList" auto-upload
    :action="actionUrl" :multiple="limit > 1" :disabled="disabled" :custom-request="customRequest" :limit="limit"
    image-preview :on-before-upload="onBeforeUpload" @error="onError" @success="onSuccess" @before-remove="beforeRemove"
    @exceed-limit="onLimit">
    <template #preview-icon>
      <icon-zoom-in />
    </template>
    <template #upload-button>
      <div :class="['upload-inner', { 'upload-inner-disabled': disabled }]">
        <i class="iconfont icon-tianjia"></i>
        <p>上传图片</p>
      </div>
    </template>
  </a-upload>
</template>

<script setup lang="ts" name="image-upload">
import Sortable from 'sortablejs';
import { FileItem, Message, RequestOption } from "@arco-design/web-vue";
import { computed, PropType, nextTick, ref, toRaw, watch } from "vue";
import { BindValue, ImageType } from "./type";
import { actionUrl, getImageSize, checkResolutionRatio } from "./useImageUpload";
import { deepClone } from '@/utils/helper';

const props = defineProps({
  /** v-model绑定值，单个图片链接或者是他们的数组集合，若为多图上传，需要设定 limit 大于 1 */
  modelValue: { type: [String, Array] as PropType<BindValue>, default: "", required: true },
  // 接口需要使用的字段
  module: { type: String, default: "GENERAL" },
  /** 图片文件类型 */
  type: { type: Array as PropType<ImageType[]>, default: ["image/jpeg", "image/jpg", "image/png", "image/gif"] },
  /** 最多选择数量, 为 1 时单图, 绑定值为 string, 大于 1 时多图, 绑定值为 string[], 为 0 不限制 */
  limit: { type: Number, default: 1 },
  /** 禁用状态 */
  disabled: { type: Boolean, default: false },
  /** 单个文件体积限制，默认 50MB（接口亦如此）*/
  size: { type: Number, default: 1024 * 1024 * 50 },
  /** 分辨率限制, 长度为 2 的数组, 分别对应宽和高限制取值或范围
   * 示例1：限制 1920*1080 :resolution-ratio="[1920, 1080]"
   * 示例2：示例1 的基础上容错 10px :resolution-ratio="[[1915, 1925], [1075, 1085]]"
   * */
  resolutionRatio: { type: Array, default: [] }
});

const emits = defineEmits<{
  (e: "update:modelValue", data: BindValue): void
}>();

/** 默认图片列表 */
const fileList = ref<FileItem[]>([]);
const bindList = ref<FileItem[]>([]);
/** 是否单张图片 */
const isLimitOne = computed(() => props.limit === 1);
const show = ref(false);

/** 初始化组件数据 */
const init = () => {
  // https://arco.design/vue/component/upload#API
  // 由于 a-upload 绑定类型为 FileItem[] 因此需要处理单图和多图下的数据格式
  show.value = false;
  setTimeout(() => {
    show.value = true;
    nextTick(() => {
      initSortable();
    });
  }, 1);
  fileList.value = [];
  bindList.value = [];
  if (isLimitOne.value && props.modelValue) {
    fileList.value = [{ uid: "0", url: props.modelValue as string }];
    bindList.value = [{ uid: "0", url: props.modelValue as string }];
    return;
  }
  for (let i = 0; i < props.modelValue.length; i++) {
    fileList.value.push({ uid: i + '', url: props.modelValue[i] });
    bindList.value.push({ uid: i + '', url: props.modelValue[i] });
  }
}

/** 初始化排序 */
const initSortable = () => {
  var el = document.getElementsByClassName('arco-upload-list')[0] as HTMLElement;
  Sortable.create(el, {
    group: "name",
    handle: ".arco-upload-list-picture-mask",
    draggable: ".arco-upload-list-picture",
    sort: true,
    animation: 450,
    easing: "cubic-bezier(0.33, 1, 0.68, 1)",
    swapThreshold: 1,
    onEnd: (evt: { newIndex: any; oldIndex: any }) => {
      const oldArr = toRaw(deepClone(bindList.value));
      oldArr.splice(evt.newIndex, 0, oldArr.splice(evt.oldIndex, 1)[0]);
      const newArr = oldArr.slice(0);
      nextTick(() => {
        fileList.value = deepClone(newArr);
        updateValue();
      });
    },
  });
}

/**
 * 上传超出限制触发
 * @param fileList
 * @param files
 */
const onLimit = (fileList: FileItem[], files: File[]): any => {
  if (files.length > props.limit) {
    Message.error(`最多上传${props.limit}张图片`);
  }
}

/**
 * 上传前校验
 * @param file
 * @return Promise<boolean>
 */
const onBeforeUpload = (file: any): Promise<boolean> => {
  return new Promise(async (resolve, reject) => {
    // 分辨率检查
    const len = props.resolutionRatio.length;
    if (len === 2) {
      const { width, height } = await getImageSize(file);
      try {
        checkResolutionRatio(width, height, props.resolutionRatio);
      } catch (err) {
        Message.error(`${(err as Error).message}`);
        reject(`[ImageUploader]-Image resolutionRatio is error`)
      }
    }
    // 格式检查
    if (!props.type.includes(file.type as ImageType)) {
      Message.error(`图片格式不支持`);
      reject(`[ImageUploader]-Image type is error: ${file.type}`)
    }
    // 体积检查
    if (file.size > props.size) {
      Message.error(`图片体积超出限制`);
      reject(`[ImageUploader]-File size is over ${props.size}`)
    }
    resolve(true);
  });
}

/**
 * 自定义上传
 * @param option
 */
const customRequest = (option: RequestOption) => {
  const { onProgress, onError, fileItem } = option
  const xhr = new XMLHttpRequest();
  if (xhr.upload) {
    xhr.upload.onprogress = function (event) {
      let percent: any;
      if (event.total > 0) {
        percent = event.loaded / event.total;
      }
      onProgress(percent, event);
    };
  }
  xhr.onerror = function error(e) {
    onError(e);
  };
  xhr.onload = function onload() {
    if (xhr.status < 200 || xhr.status >= 300) {
      return onError(xhr.responseText);
    }
    const res = JSON.parse(xhr.response);
    if (res.code != 0) {
      return onError(xhr.response)
    }

    return onSuccess(xhr as any);
  };
  try {
    const formData = new FormData();
    formData.append('file', fileItem.file as Blob);
    formData.append('fileType', '1');
    formData.append('module', props.module);
    xhr.open('post', actionUrl, true);
    xhr.setRequestHeader('Authorization', localStorage.getItem("token") || '');
    xhr.send(formData);
  } catch (error) {
    Message.error((error as Error).message);
  }
  return {
    abort() {
      xhr.abort()
    }
  }
};

/**
 * 失败触发-错误处理-提示
 * @param file
 */
const onError = (file: FileItem) => Message.error(JSON.parse(file.response).message);

/**
 * 上传成功触发
 * @param file
 */
const onSuccess = (file: FileItem) => {
  const res = JSON.parse(file.response);
  fileList.value.push({ uid: file.uid || props.modelValue.length + '', url: res.value });

  return updateValue();
}

const beforeRemove = (file: FileItem): Promise<boolean> => {
  return new Promise((resolve) => {
    if (isLimitOne.value) {
      fileList.value = [];
    } else {
      for (let i = 0; i < fileList.value.length; i++) {
        if (file.uid === fileList.value[i].uid) {
          fileList.value.splice(i, 1);
        }
      }
    }
    updateValue();
    resolve(true);
  });
};

/** 更新绑定值 */
const updateValue = () => {
  let finalValue: BindValue = isLimitOne.value ? '' : [];

  // 针对 a-upload 绑定格式和业务需要格式，需要处理成 BindValue 进行响应
  for (let i = 0; i < fileList.value.length; i++) {
    isLimitOne.value ? finalValue = fileList.value[i].url || '' : (finalValue as string[]).push(fileList.value[i].url || '')
  }
  emits("update:modelValue", finalValue);
}

watch(() => props.modelValue, (v) => {
  nextTick(() => {
    init();
  });
}, {
  immediate: true,
  deep: true
});
</script>

<style lang="less" scoped>
:deep(.arco-upload-list-picture) {
  width: 74px !important;
  height: 74px !important;
  margin-right: 12px;
  margin-bottom: 0 !important;
}

.upload-inner {
  width: 74px;
  height: 74px;
  border: 1px solid #EDEDED;
  border-radius: 2px;
  display: flex;
  flex-wrap: wrap;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;

  // &:hover {
  //   border: 1px solid #507AFD;

  //   p,
  //   .iconfont {
  //     color: #507AFD;
  //   }
  // }

  p,
  .iconfont {
    color: #B1B1B1;
  }

  p {
    font-size: 12px;
    font-weight: 400;
    margin: 0;
  }

  .iconfont {
    font-size: 22px;
  }
}

.upload-inner-disabled {
  opacity: .8;
  cursor: not-allowed;
  pointer-events: none;
}
</style>