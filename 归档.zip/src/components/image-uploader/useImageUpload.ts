/**
 * @ Author: Sam
 * @ Create Time: 2023-02-23 16:00:19
 * @ Modified by: Sam
 * @ Modified time: 2023-02-24 16:57:24
 * @ Description: 图片上传组件核心方法
 */

import { isNumber } from 'lodash';

/** 上传接口地址 */
export const actionUrl = `${
  import.meta.env.VITE_API_BASE_URL
}/task-core/task/upload`;

/**
 * 获取图片宽度和高度
 * @param file
 * @returns Promise<{ width: number; height: number }>
 */
export const getImageSize = (
  file: File
): Promise<{ width: number; height: number }> => {
  return new Promise((resolve, reject) => {
    try {
      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onloadend = function (e) {
        let image = new Image();
        image.src = e?.target?.result as string;
        image.onload = function () {
          let width = image.width;
          let height = image.height;
          resolve({ width, height });
        };
      };
    } catch (e) {
      reject(e);
    }
  });
};

/**
 * 校验图片宽高
 * @param width
 * @param height
 * @param resolutionRatio
 */
export const checkResolutionRatio = (
  width: number,
  height: number,
  resolutionRatio: any[]
) => {
  const widthLimit: any = isNumber(resolutionRatio[0])
    ? [resolutionRatio[0], resolutionRatio[0]]
    : resolutionRatio[0];
  const widthMatch = width >= widthLimit[0] && width <= widthLimit[1];
  if (!widthMatch) {
    throw new Error('图片宽度不符合要求');
  }

  const heightLimit: any = isNumber(resolutionRatio[1])
    ? [resolutionRatio[1], resolutionRatio[1]]
    : resolutionRatio[1];
  const heightMatch = height >= heightLimit[0] && height <= heightLimit[1];
  if (!heightMatch) {
    throw new Error('图片高度不符合要求');
  }
};
