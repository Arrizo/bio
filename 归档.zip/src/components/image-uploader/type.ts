/**
 * @ Author: Sam
 * @ Create Time: 2023-02-22 09:04:46
 * @ Modified by: Sam
 * @ Modified time: 2023-02-24 14:19:36
 * @ Description: 图片上传组件类型定义
 */

/** 绑定值 */
export type BindValue = string | string[];

/** 图片格式类型 */
export type ImageType = 'image/jpeg' | 'image/jpg' | 'image/png' | 'image/gif';
