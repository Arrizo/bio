<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-01 17:05:44
 * @ Modified by: Sam
 * @ Modified time: 2023-03-30 15:49:33
 * @ Description: 文件上传组件
 -->

<template>
  <a-upload v-if="!modelValue" auto-upload :accept="accept" :show-file-list="false" ref="uploadRef" :disabled="disabled"
    :on-before-upload="onBeforeUpload" @error="onError" @success="onSuccess" :custom-request="customRequest">
    <template #upload-button>
      <a-link :disabled="disabled">
        <template #icon>
          <i class="iconfont icon-icon_shangchuanwenjian" style="font-size: 12px;position: relative;top: -1px;"></i>
        </template>
        <template v-if="percent">
          正在上传 {{ Number(percent * 100).toFixed() }}%
        </template>
        <template v-else>
          选择文件
        </template>
      </a-link>
    </template>
  </a-upload>
  <div v-else class="custom-file-box">
    <a-input disabled :model-value="name || fileName" :style="`width:${width}`">
      <template #suffix>
        <a-space>
          <i class="iconfont icon-xiazai" @click="onDownload" v-if="download"></i>
          <i class="iconfont icon-shanchu" @click="delFile"></i>
        </a-space>
      </template>
    </a-input>
  </div>
</template>

<script setup lang="ts" name="file-uploader">
import { computed, ref } from 'vue';
import { FileItem, Message, RequestOption } from '@arco-design/web-vue';

const props = defineProps({
  /** v-model绑定值，文件链接地址 */
  modelValue: { type: String, default: "" },
  // 接口需要使用的字段
  module: { type: String, default: "GENERAL" },
  accept: { type: String, default: "*" },
  // 接口需要使用的字段，type: 1：图片，2：文件， 3：压缩文件
  fileType: { type: [String, Number], default: "" },
  width: { type: String, default: "300px" },
  /** 限制文件类型 */
  // type: {
  //   type: Array, default: ['application/zip',
  //     'application/x-zip-compressed',
  //     'application/vnd.ms-excel',
  //     'application/pdf',
  //     'application/wps-writer',
  //     'application/msword',
  //     'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']
  // },
  /** 禁用状态 */
  disabled: { type: Boolean, default: false },
  /** 单个文件体积限制，默认 50MB（接口亦如此）*/
  size: { type: Number, default: 1024 * 1024 * 50 },
  /** 是否允许下载 */
  download: { type: Boolean, default: false },
  /** 展示的文件名称，不传则走 fileName */
  name: { type: String, default: "" },
});

const emits = defineEmits<{
  (e: "update:modelValue", data: string): void
  (e: "on-success", data: any): void
  (e: "delSuccess"): void
}>();

/** 上传接口地址 */
const actionUrl = `${import.meta.env.VITE_API_BASE_URL}/task-core/task/upload`;
const uploadRef = ref();
const percent = ref();

let localFile = ref();//导入导出模板需要表格相应数据进行操作处理

/**
 * 上传前校验
 * @param file
 * @return Promise<boolean>
 */
const onBeforeUpload = (file: any): Promise<boolean> => {
  return new Promise(async (resolve, reject) => {
    // 格式检查
    if (props.accept !== '*' && !props.accept.includes(file.name.split(".")[file.name.split(".").length - 1])) {
      Message.error(`${file.name}-文件格式不支持`);
      reject(`[FileUploader]-File type is error: ${file.type}`)
    }
    // 体积检查
    if (file.size > props.size) {
      Message.error(`文件体积超出限制`);
      reject(`[FileUploader]-File size:${props.size} is over`)
    }
    resolve(true);
  });
}

/**
 * 自定义上传
 * @param option
 */
const customRequest = (option: RequestOption) => {
  const { onProgress, onError, onSuccess, fileItem } = option
  localFile.value = fileItem;
  const xhr = new XMLHttpRequest();
  if (xhr.upload) {
    xhr.upload.onprogress = function (event) {
      if (event.total > 0) {
        percent.value = event.loaded / event.total;
      }
      onProgress(percent.value, event);
    };
  }
  xhr.onerror = function error(e) {
    percent.value = null;
    onError(e);
  };
  xhr.onload = function onload() {
    if (xhr.status < 200 || xhr.status >= 300) {
      return onError(xhr.responseText);
    }
    const res = JSON.parse(xhr.response);
    if (res.code != 0) {
      percent.value = null;
      return onError(xhr.response)
    }
    percent.value = null;
    onSuccess(xhr.response);
  };
  try {
    const formData = new FormData();
    formData.append('file', fileItem.file as Blob);
    formData.append('fileType', props.fileType as string);
    formData.append('module', props.module);
    xhr.open('post', actionUrl, true);
    xhr.setRequestHeader('Authorization', localStorage.getItem("token") || '');
    xhr.send(formData);
  } catch (error) {
    percent.value = null;
    Message.error((error as Error).message);
  }
  return {
    abort() {
      xhr.abort()
    }
  }
};

/**
* 失败触发-错误处理-提示
* @param file
*/
const onError = (file: FileItem) => Message.error(JSON.parse(file.response).message);

/**
 * 上传成功触发
 * @param file
 */
const onSuccess = (file: FileItem) => {
  const res = JSON.parse(file.response);
  emits("update:modelValue", res.value);

  let data = {
    uploadTemplateUrl: res.value,
    fileObj: localFile.value,
  };
  emits("on-success", data)
}

const fileName = computed(() => {
  if (props.modelValue) {
    // 老规则
    // return props.modelValue.split("/")[5].split('__')[1]

    // 后面改的：文件名 = ${动态文件名}__时间戳.后缀名
    let str = props.modelValue.split("/")[5].split("_")[0] + '.' + props.modelValue.split("/")[5].split("_")[1].split(".")[1];
    return str;
  }
  return "";
});

const onDownload = () => {
  return window.location.href = props.modelValue;
}

const delFile = () => {
  emits('update:modelValue', '');
  emits('delSuccess')
}

defineExpose({
  fileName
});
</script>

<style lang="less" scoped>
.custom-file-box {
  :deep(.arco-input-suffix) {
    .arco-space-item {
      opacity: .6;
      cursor: pointer;

      &:hover {
        opacity: 1;
      }
    }
  }
}
</style>