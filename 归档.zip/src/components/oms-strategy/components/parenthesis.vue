<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-14 10:46:25
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 17:35:45
 * @ Description: 括号组件
 -->

<template>
  <a-select :disabled="disabled" style="width: 54px;" v-model="val" @change="handleChange">
    <a-option v-for="v in 4" :label="`${typeData[type].repeat(v)}`" :value="`${typeData[type].repeat(v)}`"></a-option>
  </a-select>
</template>

<script setup lang="ts" name="strategy-parenthesis">
import { PropType, ref, watch } from 'vue';

const props = defineProps({
  modelValue: { type: String, default: "" },
  disabled: { type: Boolean, default: false },
  type: { type: String as PropType<"left" | "right">, default: "left" }
});
const emits = defineEmits<{
  (e: "update:modelValue", data: any): void
}>();

const val = ref();

const handleChange = (v: any) => {
  emits("update:modelValue", v);
}

/** 针对类型定义括号内容 */
const typeData = { left: "(", right: ")" };

watch(() => props.modelValue, () => {
  val.value = props.modelValue;
}, {
  immediate: true
});
</script>
