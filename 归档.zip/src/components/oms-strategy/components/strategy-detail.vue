<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-17 11:08:50
 * @ Modified by: Sam
 * @ Modified time: 2023-03-21 09:00:33
 * @ Description: 查看条件
 -->

<template>
  <a-modal title="查看条件" width="740px" v-model:visible="modal.show" title-align="start" unmountOnClose
    :esc-to-close="false" :mask-closable="false" :footer="false">
    <oms-strategy ref="omsStrategyRef" :id="id" edit-type="detail" :type="type" :fixed-height="false"></oms-strategy>
  </a-modal>
</template>

<script setup lang="ts" name="strategy-detail">
import { StrategyType } from '@/types/strategy/order';
import { reactive, ref } from 'vue';
import omsStrategy from "../index.vue";

interface Modal {
  show: boolean;
}
const modal = reactive<Modal>({
  show: false,
});

const id = ref();
const type = ref<StrategyType>();

const open = (s_id: number, s_type: StrategyType) => {
  id.value = s_id;
  type.value = s_type;
  modal.show = true;
}

defineExpose({
  open
});
</script>