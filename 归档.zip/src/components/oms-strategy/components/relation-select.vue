<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-14 15:20:08
 * @ Modified by: Sam
 * @ Modified time: 2023-03-24 09:42:52
 * @ Description: 条件关系
 -->

<template>
  <a-select :disabled="disabled" style="width: 91px;" v-model="val" @change="handleChange">
    <a-option v-for="v in typeObj[type]" :label="v.label" :value="v.value"></a-option>
  </a-select>
</template>

<script setup lang="ts" name="relation-select">
import { ref, watch } from 'vue';

const props = defineProps({
  modelValue: { type: String, default: "" },
  disabled: { type: Boolean, default: false },
  type: { type: String, default: "" }
});
const emits = defineEmits<{
  (e: "update:modelValue", data: any): void
}>();

const val = ref();

const handleChange = (v: any) => {
  emits("update:modelValue", v);
}

watch(() => props.modelValue, () => {
  val.value = props.modelValue;
}, {
  immediate: true
});

const typeObj = {
  // 数字
  number: [{ label: "等于", value: "=" }, { label: "不等于", value: "!=" }, { label: "大于", value: ">" }, { label: "大于等于", value: ">=" }, { label: "小于", value: "<" }, { label: "小于等于", value: "<=" }, { label: "为空", value: "is null" }, { label: "不为空", value: "is not null" }],
  // 文本输入
  input: [{ label: "等于", value: "=" }, { label: "不等于", value: "!=" }, { label: "包含于", value: "in" }, { label: "不包含", value: "not in" }, { label: "为空", value: "is null" }, { label: "不为空", value: "is not null" }],
  // 日期选择
  dateSelect: [{ label: "等于", value: "=" }, { label: "不等于", value: "!=" }, { label: "大于", value: ">" }, { label: "大于等于", value: ">=" }, { label: "小于", value: "<" }, { label: "小于等于", value: "<=" }, { label: "为空", value: "is null" }, { label: "不为空", value: "is not null" }],
  // 时间选择
  timeSelect: [{ label: "等于", value: "=" }, { label: "不等于", value: "!=" }, { label: "大于", value: ">" }, { label: "大于等于", value: ">=" }, { label: "小于", value: "<" }, { label: "小于等于", value: "<=" }, { label: "为空", value: "is null" }, { label: "不为空", value: "is not null" }],
  // 下拉搜索单选
  selectSingle: [{ label: "等于", value: "=" }, { label: "不等于", value: "!=" }, { label: "为空", value: "is null" }, { label: "不为空", value: "is not null" }],
  // 下拉搜索多选
  selectMultiple: [{ label: "包含于", value: "in" }, { label: "不包含", value: "not in" }, { label: "为空", value: "is null" }, { label: "不为空", value: "is not null" }],
  // 弹窗搜索多选
  popMultiple: [{ label: "包含于", value: "in" }, { label: "不包含", value: "not in" }, { label: "为空", value: "is null" }, { label: "不为空", value: "is not null" }],
  // 级联多选
  cascaderMultiple: [{ label: "包含于", value: "in" }, { label: "不包含", value: "not in" }, { label: "为空", value: "is null" }, { label: "不为空", value: "is not null" }],
}
</script>