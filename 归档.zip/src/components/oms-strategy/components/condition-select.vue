<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-14 17:02:49
 * @ Modified by: Sam
 * @ Modified time: 2023-03-29 08:39:18
 * @ Description: 条件值
 -->

<template>
  <div>
    <!-- 默认 && 文本输入 -->
    <a-input v-if="['input', ''].includes(type)" :placeholder="disabled ? '' : `请输入`" style="width: 172px;" v-model="val"
      allow-clear :disabled="disabled"></a-input>

    <!-- 数字 -->
    <a-input-number v-if="type === 'number'" :placeholder="disabled ? '' : `请输入`" style="width: 172px;" v-model="val"
      allow-clear hide-button :disabled="disabled" :precision="2" />

    <!-- 日期选择 -->
    <a-date-picker v-if="type === 'dateSelect'" style="width: 172px;" v-model="val" allow-clear :disabled="disabled" />

    <!-- 时间选择 -->
    <a-time-picker v-if="type === 'timeSelect'" style="width: 172px;" v-model="val" allow-clear :disabled="disabled" />

    <!-- 级联选择 -->
    <a-cascader v-if="type === 'cascaderMultiple'" ref="cascaderRef" v-model="lst"
      :field-names="{ value: 'id', label: 'regionName', children: 'child' }" :disabled="disabled" :max-tag-count="1"
      :options="addressList" :style="{ width: '172px', height: '32px' }" multiple :placeholder="disabled ? '' : `请选择`" />

    <!-- 弹窗多选，目前之后商品规格选择，其他需要定制开发 -->
    <div class="pop-multiple" v-if="type === 'popMultiple'" @click="onPopSelectClick">
      <span class="placeholder" v-if="lstId.length === 0">点击选择</span>
      <span class="value-text" v-else>{{ lstId.join() }}</span>
      <span class="pop-icon-inner">
        <i class="iconfont icon-dianjixuanzeanniu"></i>
      </span>
    </div>

    <!-- 单选，TODO: 目前没有该类型，以后定制开发 -->
    <!-- <a-select v-if="type === 'selectSingle'" style="width: 172px;" v-model="val" allow-search :disabled="disabled" -->
    <!-- :placeholder="disabled ? '' : `请选择`"></a-select> -->

    <!-- 多选，TODO: 目前没有该类型，以后定制开发 -->
    <!-- <oms-multiple-select v-if="type === 'selectMultiple'" v-model="val" :style="{ width: '172px' }" :option-list="[]" -->
    <!-- :max-tag-count="1" :disabled="disabled"></oms-multiple-select> -->

    <!-- 弹窗多选 -->
    <condition-modal ref="conditionModalRef" @on-ok="onModalOk"></condition-modal>
  </div>
</template>

<script setup lang="ts" name="condition-select">
import { nextTick, ref, watch } from 'vue';
// import omsMultipleSelect from "@/components/oms-multiple-select/index.vue";
import { Message } from '@arco-design/web-vue';
import { getChildAddress } from '@/api/basicdata/express';
import { CascaderType } from '@/types/basicdata/express';
import conditionModal from './condition-modal.vue';

const props = defineProps({
  modelValue: { type: [String, Number, Array], default: "" },
  lstId: { type: Array, default: () => [] },
  type: { type: String, default: "" },
  disabled: { type: Boolean, default: false }
});
const emits = defineEmits<{
  (e: "update:modelValue", data: any): void,
  (e: "update:lstId", data: any): void,
  (e: "lstConditionValue", data: any): void
}>();

const val = ref();
const lst = ref<any[]>([]);
const cascaderRef = ref();
const conditionModalRef = ref();
const addressList = ref<CascaderType[]>([]);

const updateValue = () => {
  emits("update:modelValue", val.value);
}

const updateLstId = () => {
  const lstValue: any = [];
  nextTick(() => {
    if (cascaderRef.value) {
      const arr = cascaderRef.value.selectViewValue;
      for (let i = 0; i < arr.length; i++) {
        const { label } = arr[i];
        lstValue.push(label);
      }
    }
    emits("lstConditionValue", lstValue);
  });

  emits("update:lstId", lst.value);
}

const init = () => {
  /** 级联类型目前只支持地址选择，肖总说先这么处理 */
  if (props.type === 'cascaderMultiple') {
    getAddressList();
  }
}

/** 触发多选弹窗打开 */
const onPopSelectClick = () => {
  conditionModalRef.value.open(lst.value);
}

/** 弹窗多选确定回调 */
const onModalOk = (data: any[]) => {
  lst.value = data;
  emits("lstConditionValue", lst.value);
  emits("update:lstId", lst.value);
}

//获取地址信息
const getAddressList = async () => {
  try {
    const res = await getChildAddress();

    if (res.code != 0) {
      throw new Error(res.message);
    }
    addressList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

watch(() => props.type, () => {
  init();
}, {
  immediate: true,
  deep: true
});

watch(() => props.modelValue, () => {
  val.value = props.modelValue;
}, {
  immediate: true,
  deep: true
});
watch(() => props.lstId, () => {
  lst.value = props.lstId;
}, {
  immediate: true,
  deep: true
});

watch(() => val.value, () => {
  updateValue()
}, {
  immediate: true,
  deep: true
});

watch(() => lst.value, () => {
  if (props.type === 'cascaderMultiple') {
    updateLstId();
  }
}, {
  immediate: true,
  deep: true
});
</script>

<style lang="less" scoped>
:deep(.arco-select-view-multiple.arco-select-view-size-medium .arco-select-view-tag) {
  &:first-child {
    display: inline-block;
  }
  width: 143px;
  white-space: nowrap;
  word-break: break-all;
  overflow: hidden;
  text-overflow: ellipsis;
}

:deep(.arco-select-view-tag) {
  padding: 0 5px;

  .arco-tag-close-btn {
    display: none;
  }

  &:not(:first-child) {
    display: none;
  }
}

:deep(.arco-select-view-input) {
  display: none;
}

.pop-multiple {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 172px;
  height: 32px;
  border: 1px solid #EDEDED;
  opacity: 1;
  color: #B1B1B1;
  padding: 0 11px;
  cursor: pointer;

  .value-text {
    color: #3A3A3A;
    width: 120px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
}</style>