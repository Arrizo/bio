<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-14 10:02:38
 * @ Modified by: Sam
 * @ Modified time: 2023-03-14 10:27:57
 * @ Description: 策略条件头部位置
 -->
<template>
  <a-row :gutter="10" class="strategy-header">
    <a-col :flex="v.width" v-for="v in headers">
      <div :style="`width:${v.width};${v.title ? '' : 'height: 20px;'}`">
        <p class="title-inner">{{ v.title }}</p>
      </div>
    </a-col>
  </a-row>
</template>

<script setup lang="ts" name="strategy-header">
interface HeaderItem {
  title?: string;
  width: string;
}

const headers: HeaderItem[] = [
  { width: "46px" },
  { width: "158px", title: "条件字段" },
  { width: "91px", title: "条件关系" },
  { width: "172px", title: "条件值" },
  { width: "46px" },
  { width: "80px" },
  { width: "80px" },
];
</script>

<style lang="less" scoped>
.strategy-header {
  .title-inner {
    font-size: 13px;
    font-weight: 400;
    line-height: 1;
    color: #3A3A3A;
  }
}
</style>