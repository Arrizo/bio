<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-23 13:52:26
 * @ Modified by: Sam
 * @ Modified time: 2023-03-24 11:29:00
 * @ Description: 弹窗多选，目前之后商品规格选择，其他需要定制开发
 -->

<template>
  <a-modal title="商品规格" width="846px" v-model:visible="modal.show" title-align="start" unmountOnClose
    :esc-to-close="false" :mask-closable="false" :on-before-ok="onOk">
    <a-form :model="form" layout="inline" ref="searchRef">
      <a-form-item field="code" label="编码：">
        <a-input v-model="form.code" placeholder="spu/sku编码" allow-clear :max-length="20" :style="{ width: '200px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="name" label="名称：">
        <a-input v-model="form.name" placeholder="spu/sku名称" allow-clear :max-length="20" :style="{ width: '200px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
    </a-form>
    <oms-table :loading="loading" :total="total" :current="form.pageNum" :size="form.pageSize" @reload="handleSearch">
      <a-table v-model:selected-keys="selectedkeys" :data="dataList" :pagination="false"
        @selection-change="selectionChange" hide-expand-button-on-empty :scroll="{ y: 550, }" stripe row-key="specsCode"
        :bordered="{ wrapper: false }" :row-selection="rowSelection">
        <template #columns>
          <a-table-column title="商品编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.specsCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.specsTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格型号" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.specsModel || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </a-modal>
</template>

<script setup lang="ts" name="condition-modal">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { Message, TableRowSelection } from '@arco-design/web-vue';
import { queryProductAndSpecList } from '@/api/product/purchase';

interface Modal {
  show: boolean;
  data?: any
}
const modal = reactive<Modal>({
  show: false,
  data: null
});

class goodsFormClass {
  code: string = ''
  name: string = ''
  pageNum: number = 1
  pageSize: number = 10
}
const form = ref<goodsFormClass>(new goodsFormClass());
const loading = ref(false);
const total = ref(0);
const dataList = ref<any[]>([]);
const selectData = ref<any[]>([]);
const selectedkeys = ref();
const searchRef = ref();
const rowSelection = reactive<TableRowSelection>({
  type: 'checkbox',
  fixed: true,
  showCheckedAll: true
});

const emits = defineEmits<{
  (e: "on-ok", data: any): void
}>();

const handleSearch = async (data?: any) => {
  try {
    loading.value = true;
    form.value = { ...form.value, ...data };
    const { code, message, value } = await queryProductAndSpecList(form.value);
    if (code != 0) {
      throw new Error(message);
    }
    dataList.value = value.result;
    total.value = value.totalCount;
  } catch (error) {
    Message.error((error as Error).message);
  } finally {
    loading.value = false;
  }
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  if (selectData.value.length === 0) {
    Message.error("请选择商品规格");
    return false;
  }

  emits("on-ok", selectData.value);
  return true;
};

const selectionChange = (rowKeys: Array<string | number>) => {
  selectData.value = rowKeys;
}

const handleReset = (type?: any) => {
  form.value.pageNum = 1;
  form.value.pageSize = 10;
  searchRef.value.resetFields();
  handleSearch();
}

const open = (list: any[] = []) => {
  modal.show = true;
  handleSearch();
  selectData.value = JSON.parse(JSON.stringify(list));
}

defineExpose({
  open
});
</script>
