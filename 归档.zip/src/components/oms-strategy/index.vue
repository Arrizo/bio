<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-14 09:29:37
 * @ Modified by: Sam
 * @ Modified time: 2023-03-28 20:04:26
 * @ Description: 策略条件组件
 -->

<template>
  <div class="oms-strategy"
    :style="`${editType !== 'detail' ? 'margin-left: 17px;' : 'margin: 0 0 30px 10px ;padding-top: 14px;'}`">
    <a-spin :loading="loading" dot v-if="editType !== 'detail'">
      <strategy-header></strategy-header>
    </a-spin>

    <div :class="['strategy-list', { 'fixed-height': fixedHeight }]" :style="`height:${height};max-height:${maxHeight}`">
      <a-row :gutter="7" v-for="(v, i) in   val" class="strategy-item">
        <!-- 左括号 -->
        <a-col flex="46px">
          <strategy-parenthesis :disabled="isDetail" type="left" v-model="v.frontBracket"></strategy-parenthesis>
        </a-col>
        <!-- 条件字段 -->
        <a-col flex="158px">
          <a-select :disabled="isDetail" style="width: 158px;" placeholder="请选择" v-model="v.conditionField"
            @change="handleConditionChange(i)">
            <a-option v-for="field in conditionFieldList" :label="field.displayName || field.chineseName"
              :value="field.fieldName"></a-option>
          </a-select>
        </a-col>
        <!-- 条件关系 -->
        <a-col flex="91px">
          <relation-select :disabled="isDetail" v-model="v.relation"
            :type="getRelationType(v.conditionField)"></relation-select>
        </a-col>
        <!-- 条件值 -->
        <a-col flex="172px">
          <a-input v-if="['is null', 'is not null'].includes(v.relation)" disabled></a-input>
          <condition-select v-else :disabled="isDetail" v-model="v.conditionValue" v-model:lstId="v.lstConditionId"
            :type="getRelationType(v.conditionField)"
            @lstConditionValue="onLstConditionValue($event, v)"></condition-select>
        </a-col>
        <!-- 右括号 -->
        <a-col flex="46px">
          <strategy-parenthesis :disabled="isDetail" type="right" v-model="v.backBracket"></strategy-parenthesis>
        </a-col>
        <!-- 关系 -->
        <a-col flex="91px">
          <a-select :disabled="isDetail" style="width: 91px;" v-model="v.logicCharacter">
            <a-option label="并且" value="and"></a-option>
            <a-option label="或者" value="or"></a-option>
          </a-select>
        </a-col>
        <!-- 增删按钮 -->
        <a-col flex="86px" v-if="editType !== 'detail'">
          <div class="option-btn">
            <span :class="['iconfont icon-shanchu1', { 'iconfont-disabled': val.length <= 1 || isDetail }]"
              @click="onAction('del', i)"></span>
            <span :class="['iconfont icon-tianjia1', { 'iconfont-disabled': isDetail }]"
              @click="onAction('add', i)"></span>
          </div>
        </a-col>
      </a-row>
    </div>
  </div>
</template>

<script setup lang="ts" name="oms-strategy">
import strategyHeader from "./components/strategy-header.vue";
import strategyParenthesis from "./components/parenthesis.vue";
import relationSelect from "./components/relation-select.vue";
import conditionSelect from "./components/condition-select.vue";
import { computed, PropType, ref, watch } from "vue";
import { StrategyElement, StrategyModalRes, StrategyType } from "@/types/strategy/order";
import { queryByModel, queryStrategyConfig } from "@/api/strategy/order";
import { Message } from "@arco-design/web-vue";
import { deepClone } from "@/utils/helper";

const props = defineProps({
  /** 操作类型，仅新增、编辑、查看 */
  editType: { type: String as PropType<"add" | "edit" | "detail">, default: "add" },
  /** 策略类型枚举值 */
  type: { type: String as PropType<StrategyType>, default: "" },
  /** 对应的策略配置 ID，在查看时需要 */
  id: { type: Number, default: NaN },
  /** 是否固定高度（UI 支持）查看模式下不需要 */
  fixedHeight: { type: Boolean, default: true },
  height: { type: String, default: "" },
  maxHeight: { type: String, default: "" },
});

const val = ref<StrategyElement[]>([new StrategyElement()]);
const loading = ref<boolean>(false);
const conditionFieldList = ref<StrategyModalRes[]>([]);
const isDetail = computed(() => props.editType === 'detail');

const init = async () => {
  if (conditionFieldList.value.length === 0) {
    try {
      const res = await queryByModel(props.type);
      if (res.code != 0) {
        throw new Error(res.message);
      }

      conditionFieldList.value = res.value;
    } catch (err) {
      Message.error((err as Error).message);
    }
  };

  if (["edit", "detail"].includes(props.editType)) {
    try {
      if (!props.id) return;

      loading.value = true;
      const res = await queryStrategyConfig({ strategyId: props.id, strategyType: props.type });

      if (res.code != 0) {
        throw new Error(res.message);
      }

      val.value = res.value.length === 0 ? [new StrategyElement()] : res.value;

      for (let i = 0; i < val.value.length; i++) {
        // 数字类型值的处理，接口返回的是字符串，这里需要处理下
        const { conditionField, conditionValue } = val.value[i];
        if (getRelationType(conditionField) === 'number') {
          val.value[i].conditionValue = Number(conditionValue);
        }
      }
    } catch (err) {
      Message.error((err as Error).message);
    } finally {
      loading.value = false;
    }
  }
}

/** 切换时清空值 */
const handleConditionChange = (index: number) => {
  val.value[index].conditionValue = "";
  val.value[index].lstConditionId = [];
  val.value[index].lstConditionValue = [];
}

const onLstConditionValue = (e: any, v: any) => {
  v.lstConditionValue = deepClone(e);
}

/** 获取对应类型 */
const getRelationType = (conditionField: any) => {
  for (let i = 0; i < conditionFieldList.value.length; i++) {
    if (conditionField === conditionFieldList.value[i].fieldName) {
      return conditionFieldList.value[i].type;
    }
  }
}

const onAction = (type: "add" | "del", index?: number) => {
  if (isDetail.value || (val.value.length === 1 && type === 'del')) return;

  if (type === 'add') {
    val.value.push(new StrategyElement());
  }
  if (type === 'del') {
    val.value.splice(index as number, 1);
  }
}

const getValue = () => {
  // 不配置策略
  if (val.value.length === 1 && !val.value[0].conditionField) {
    return [];
  }

  for (let i = 0; i < val.value.length; i++) {
    const { conditionField, relation, conditionValue, lstConditionId = [] } = val.value[i];
    if (!conditionField || !relation || ((!conditionValue && (!lstConditionId || lstConditionId.length === 0)) && !['is null', 'is not null'].includes(relation))) {
      throw new Error(`请完善第${i + 1}行的策略条件内容`);
    }
    if (['is null', 'is not null'].includes(relation)) {
      val.value[i].conditionValue = "";
      val.value[i].lstConditionId = [];
      val.value[i].lstConditionValue = [];
    }
  }
  return val.value;
}

watch(() => props.id, () => {
  init()
}, {
  immediate: true,
});

defineExpose({
  val,
  getValue
});
</script>

<style lang="less" scoped>
.strategy-list {
  min-height: 100px;
  max-height: 336px;
  // overflow-y: auto;
  // overflow-x: hidden;
}

.fixed-height {
  height: 228px;
  max-height: 228px;
}

:deep(.arco-select-view-suffix) {
  padding: 0;
}

.strategy-item {
  margin-bottom: 10px;

  .option-btn {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 60px;
    padding: 0 4px;

    .iconfont {
      color: #999999;
      font-size: 20px;
      opacity: 1;
      cursor: pointer;

      &:hover {
        color: #3e6cfe;
      }

      &:active {
        color: #1d4ff1;
      }
    }

    .iconfont-disabled {
      color: #DBDBDB;
      cursor: no-drop;

      &:hover {
        color: #DBDBDB;
      }

      &:active {
        color: #DBDBDB;
      }
    }
  }
}
</style>