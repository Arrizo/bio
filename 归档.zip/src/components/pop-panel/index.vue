<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-29 11:02:50
 * @ Modified by: Sam
 * @ Modified time: 2023-03-29 13:47:22
 * @ Description: 需要底部联动的面板
 -->

<template>
  <div class="pop-panel" style="height: 100%;">
    <div class="top-panel" :class="showPop ? `min-heigth` : `full-height`">
      <slot name="top"></slot>
    </div>
    <div :class="['bottom-panel', { 'pop-panel-show': showPop }]">
      <slot name="bottom"></slot>
    </div>
  </div>
</template>

<script setup lang="ts" name="pop-panel">
const props = defineProps({
  showPop: { type: Boolean, default: false }
});
</script>
<style lang="less">
.min-heigth {
  height: calc(100% - 31%);
  overflow-y: auto;
}

.full-heigth {
  height: 100%;
}

.bottom-panel {
  position: absolute;
  bottom: -30%;
  right: 14px;
  left: 210px;
  height: 30%;
  min-height: 300px;
  background: #fff;
  overflow: auto;
  box-shadow: 0px -2px 13px 0px #e5e5e5;
  z-index: 999;
  display: none;
  transition: all .2s ease;
}

.pop-panel-show {
  display: block;
  bottom: 0;
  transition: all .2s ease;
}</style>