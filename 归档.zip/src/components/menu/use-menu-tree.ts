import { computed } from 'vue';
import { RouteRecordRaw, RouteRecordNormalized } from 'vue-router';
import { useUserStore } from '@/store';
import { cloneDeep } from 'lodash';
import { DEFAULT_LAYOUT } from '@/router/routes/base';

export default function useMenuTree() {
  const userStore = useUserStore();
  const appRoute = computed(() => {
    const menuList = userStore.leftMenuList[userStore.currentFirstMenu];
    let modules = import.meta.glob('../../../views/**/*.vue');

    let finalMenuList = [];

    function setMenuInfo(arr: any[], is_level_one: boolean = false): any[] {
      let newArr = [];
      for (let i = 0; i < arr?.length; i++) {
        const hasChildren = arr[i].children && arr[i].children.length > 0;

        let raw: any = {};
        if (arr[i].type === 'PAGE') {
          const str = `views${arr[i].url}/index`;
          raw = {
            name: arr[i].perms,
            path: arr[i].url,
            component: is_level_one
              ? DEFAULT_LAYOUT
              : modules[`../../${str}.vue`],
            meta: {
              locale: arr[i].menuName,
              requiresAuth: true,
              icon: arr[i].icon,
            },
          };
        } else if (arr[i].type === 'BUTTON') {
          userStore.permissionList.push(arr[i].perms);
        }

        if (hasChildren) {
          var data = setMenuInfo(arr[i].children);
          if (JSON.stringify(data[0]) !== '{}') {
            raw.children = [];
            raw.children = data;
          }
        }
        newArr.push(raw);
      }
      return newArr;
    }

    finalMenuList = setMenuInfo(menuList, true);
    return finalMenuList;
  });
  const menuTree = computed(() => {
    const copyRouter = cloneDeep(appRoute.value) as RouteRecordNormalized[];
    copyRouter.sort((a: RouteRecordNormalized, b: RouteRecordNormalized) => {
      return (a.meta.order || 0) - (b.meta.order || 0);
    });
    function travel(_routes: RouteRecordRaw[], layer: number) {
      if (!_routes) return null;

      const collector: any = _routes.map((element) => {
        // no access
        // if (!permission.accessRouter(element)) {
        //   return null;
        // }

        // leaf node
        if (element.meta?.hideChildrenInMenu || !element.children) {
          element.children = [];
          return element;
        }

        // route filter hideInMenu true
        element.children = element.children.filter(
          (x) => x.meta?.hideInMenu !== true
        );

        // Associated child node
        const subItem = travel(element.children, layer + 1);

        if (subItem.length) {
          element.children = subItem;
          return element;
        }
        // the else logic
        if (layer > 1) {
          element.children = subItem;
          return element;
        }

        // if (element.meta?.hideInMenu === false) {
        //   return element;
        // }

        return null;
      });
      return collector.filter(Boolean);
    }
    return travel(copyRouter, 0);
  });

  return {
    menuTree,
    appRoute,
  };
}
