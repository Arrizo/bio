<!-- 统一封装格式的警告/二次确认弹窗 -->
<template>
  <a-modal class="warning-modal" :mask-closable="false" v-model:visible="visible" title-align="start" width="400px" :on-before-ok="onBeforeOk" @cancel="handleCancel">
    <template #title>
      {{ modalInfo.title }}
    </template>
    <div class="content-area-warning">
      <icon-exclamation-circle-fill />
      <div class="content-inner" v-html="modalInfo.content"></div>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="oms-warning">
import { reactive, ref } from 'vue';

const props = defineProps({
  title: { type: String, default: "提示" },
  content: { type: String, default: "" },
  onBeforeOk: { type: null, default: null }
});

const emits = defineEmits<{
  (e: "on-ok"): void;
  (e: "on-cancle"): void;
}>();

const visible = ref<boolean>(false);
const modalInfo = reactive({
  title: props.title,
  content: props.content
});

// 默认提示信息
const default_data = {
  delete: {
    title: "提示",
    content: `此操作将删除选中数据, 是否继续？<br><span>数据删除后将无法恢复</span>`
  }
  // more...
}

/**
 * 打开提示框
 * @param option
 */
const open = (option = { type: 'delete', title: "提示", content: "" }) => {
  const { type, title, content } = option;
  const { title: t, content: c } = default_data[type] || { title, content };

  modalInfo.title = t;
  modalInfo.content = c;
  visible.value = true;
}

const handleOk = () => emits("on-ok");
const handleCancel = () => emits("on-cancle");

defineExpose({
  open,

  // other params
  modalInfo,
  visible,
});
</script>

<style lang="less">
.content-area-warning {
  display: flex;
  margin-top: -10px;

  .arco-icon-exclamation-circle-fill {
    color: #FF3E3E;
    font-size: 26px;
    margin-right: 6px;
  }

  .content-inner {
    font-size: 13px;
    color: #3A3A3A;
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    justify-content: center;
    line-height: 1.8;

    span {
      font-size: 12px;
      color: #999999;
    }
  }
}
.warning-modal{
  .arco-modal-header{
    border-bottom: none;
  }
}
</style>