<!--
 * @ Author: QIUJIAJIA
 * @ Create Time: 2023-02-28 09:25:30
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-02-28 18:36:22
 * @ Description: 统一封装标签
 -->

<template>
  <div :class="['oms-tag-container', type]" v-text="content"></div>
</template>

<script setup lang="ts" name="oms-tag">
import { PropType} from 'vue';

const props = defineProps({
  content: { type: String, default: "" },
  type: { type: String , default: "normal" },
});

</script>

<style lang="less" scoped>
.oms-tag-container {
  display: inline-block;
  padding: 0px 10px;
  min-width: 48px;
  text-align: center;
  font-size: 12px;
  opacity: 1;
  border-radius: 166px;
  background: rgba(255, 255, 255, 0.39);
}

//默认
.normal {
  border: 1px solid #EDEDED;
  color: #3A3A3A;
}

//正在进行中
.progress {
  border: 1px solid rgba(62, 108, 254, 0.302);
  color: #3E6CFE;
}

// 警告
.warring {
  border: 1px solid rgba(255, 62, 62, 0.302);
  color: #FF3E3E;
}

//已失效
.efficacy {
  color: #C2C2C2;
  border: 1px solid #EDEDED;
}
</style>