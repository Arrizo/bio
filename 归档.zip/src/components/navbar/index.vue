<template>
  <div class="navbar">
    <div class="left-side">
      <a-space>
        <div class="logo"
          style="width:176px;display: flex;justify-content: center;height: 22px;border-right:1px solid #ececec">
          <img src="@/assets/images/login/logo.png" style="height:28px">
        </div>
        <a-typography-title :style="{ margin: 0, fontSize: '18px' }" :heading="5">
        </a-typography-title>
        <icon-menu-fold v-if="appStore.device === 'mobile'" style="font-size: 22px; cursor: pointer"
          @click="toggleDrawerMenu" />
      </a-space>

      <!-- 首级菜单列表 -->
      <div class="first-menu-list">
        <div :class="['first-menu-item', { 'active': userStore.currentFirstMenu === v.perms }]"
          v-for="v in userStore.firstMenuList" @click="onFirstMenuClick(v)">
          <span :class="['iconfont', `icon-${v.icon}`]" v-if="v.icon"></span>
          <p>{{ v.menuName }}</p>
        </div>
      </div>
    </div>

    <ul class="right-side">
      <!-- <li>
          <a-tooltip :content="isFullscreen ? '退出全屏' : '全屏'">
            <a-button class="nav-btn" type="outline" :shape="'circle'" @click="toggleFullScreen">
              <template #icon>
                <icon-fullscreen-exit v-if="isFullscreen" />
                <icon-fullscreen v-else />
              </template>
            </a-button>
          </a-tooltip>
        </li> -->
      <a-dropdown trigger="click">
        <li>
          <a-avatar :size="32" :style="{ marginRight: '8px', cursor: 'pointer' }">
            <img alt="avatar" src="../../assets/images/default_avatar.png" />
          </a-avatar>
          <div class="user-info-block">
            <div class="user-name">
              <p class="name">{{ userStore.nickname }}</p>
              <p class="job">{{ userStore.orgName }}</p>
            </div>
            <icon-down />
          </div>
        </li>
          <template #content>
            <a-doption>
              <a-space @click="handleChangePassword">
                <span> 修改密码 </span>
              </a-space>
            </a-doption>
            <a-doption>
              <a-space @click="handleLogout">
                <span> 退出登录 </span>
              </a-space>
            </a-doption>
          </template>
      </a-dropdown>
    </ul>
    <change-password v-model:visible="changPasswordVisible"></change-password>
  </div>
</template>

<script lang="ts" setup>
import { inject, ref } from 'vue';
import { useAppStore, useUserStore } from '@/store';
import useUser from '@/hooks/user';
import ChangePassword from './change-password.vue';

const appStore = useAppStore();
const userStore = useUserStore();
const { logout } = useUser();

const onFirstMenuClick = (data: any) => {
  userStore.currentFirstMenu = data.perms;
  localStorage.setItem('currentFirstMenu', data.perms);
}

const changPasswordVisible = ref(false);
const handleChangePassword = () => {
  changPasswordVisible.value = true;
}

const handleLogout = () => {
  logout();
};
const toggleDrawerMenu = inject('toggleDrawerMenu') as () => void;
</script>

<style scoped lang="less">
.navbar {
  display: flex;
  justify-content: space-between;
  height: 100%;
  background-color: var(--color-bg-2);
  border-bottom: 1px solid var(--color-border);

}

.left-side {
  display: flex;
  align-items: center;
  padding-left: 20px;

  .first-menu-list {
    display: flex;
    height: 56px;

    .first-menu-item {
      display: flex;
      align-items: center;
      margin: 0 30px;
      cursor: pointer;
      border-bottom: 2px solid #f8f8f8;

      .iconfont {
        margin-right: 6px;
        font-weight: 400;
        color: #707070;
        font-size: 20px;
      }

      &:hover {
        .iconfont {
          color: #507AFD;
        }

        p {
          color: #507AFD;
        }
      }

      p {
        font-size: 13px;
        line-height: 60px;
        font-weight: 400;
        color: #3A3A3A;
      }
    }

    .active {
      border-bottom: 2px solid #507AFD;

      .iconfont {
        color: #507AFD;
      }

      p {
        font-weight: 600;
        color: #507AFD;
      }
    }
  }
}

.right-side {
  display: flex;
  padding-right: 20px;
  list-style: none;

  :deep(.locale-select) {
    border-radius: 20px;
  }

  li {
    display: flex;
    align-items: center;
    padding: 0 10px;
  }

  a {
    color: var(--color-text-1);
    text-decoration: none;
  }

  .user-info-block {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;

    .user-name {
      line-height: 6px;

      .name {
        font-size: 13px;
        font-weight: 400;
        color: #333333;
      }

      .job {
        font-size: 12px;
        font-weight: 400;
        color: #888888;
      }
    }

    .arco-icon-down {
      color: #AEAEAE;
      margin-left: 10px;
    }
  }

  .nav-btn {
    border-color: rgb(var(--gray-2));
    color: rgb(var(--gray-8));
    font-size: 16px;
  }

  .trigger-btn,
  .ref-btn {
    position: absolute;
    bottom: 14px;
  }

  .trigger-btn {
    margin-left: 14px;
  }
}
</style>

<style lang="less">
.message-popover {
  .arco-popover-content {
    margin-top: 0;
  }
}
</style>
