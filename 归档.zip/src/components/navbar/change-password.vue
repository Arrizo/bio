<template>
  <a-modal
    unmountOnClose
    title="修改密码"
    :mask-closable="false"
    title-align="start"
    v-model:visible="innerVisible"
    :on-before-ok="handleConfirm"
    @cancel="handleClose">
    <a-form
      ref="formRef"
      layout="horizontal"
      :model="formData"
      :rules="formRules">
      <!-- 原密码 -->
      <a-form-item
        label="原密码："
        label-col-flex="100px"
        field="oldPassword">
        <a-input-password
          allow-clear
          :max-length="16"
          @keyup.enter="handleConfirm"
          placeholder="请输入原密码"
          v-limit-input
          v-model.trim="formData.oldPassword">
        </a-input-password>
      </a-form-item>
      <!-- 新密码 -->
      <a-form-item
        label="新密码："
        label-col-flex="100px"
        field="newPassword">
        <a-input-password
          allow-clear
          :max-length="16"
          @keyup.enter="handleConfirm"
          placeholder="请输入新密码"
          v-limit-input
          v-model.trim="formData.newPassword">
        </a-input-password>
      </a-form-item>
      <!-- 确认密码 -->
      <a-form-item
        label="确认密码："
        label-col-flex="100px"
        field="confirmPassword">
        <a-input-password
          allow-clear
          :max-length="16"
          @keyup.enter="handleConfirm"
          placeholder="请再次输入新密码"
          v-limit-input
          v-model.trim="formData.confirmPassword">
        </a-input-password>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="change-password">
import { ref, watch } from 'vue';
import { changePassword } from '@/api/user';
import { Message } from '@arco-design/web-vue';
import { Password } from '@/utils/regex';

// 修改用户密码
class FormData {
  // 旧密码
  oldPassword: string = '';
  // 新密码
  newPassword: string = '';
  // 确认密码
  confirmPassword: string = '';
}
const formRef = ref();
const formData = ref<FormData>(new FormData());
const formRules = {
  oldPassword: [
    { required: true, message: '请输入原密码'},
    { match: Password,  message: '请输入长度在10到16之间的字母、数字组合' }
  ],
  newPassword: [
    { required: true, message: '请输入新密码'},
    { match: Password,  message: '请输入长度在10到16之间的字母、数字组合' }
  ],
  confirmPassword: [
    { required: true, message: '请再次输入新密码'},
    { match: Password,  message: '请输入长度在10到16之间的字母、数字组合' },
    { validator: ( value: string, callback: (error?: string) => void ) => {
      if (formData.value.newPassword !== formData.value.confirmPassword) {
        callback('两次输入密码不一致');
      }
    }}
  ]
}

// 弹窗相关
const innerVisible = ref(false);
const props = defineProps<{ visible?: boolean }>();
watch(() => props.visible, () => {
  formData.value = new FormData();
  innerVisible.value = Boolean(props.visible);
}, {
  immediate: true
})
const emits = defineEmits(['update:visible']);
const handleConfirm = async()  => {
  try {
    if (await formRef.value.validate()) {
      return false;
    }
    let response = await changePassword(formData.value.oldPassword, formData.value.newPassword, formData.value.confirmPassword);
    if (response?.success) {
      Message.success('密码修改成功');
      emits('update:visible', false);
      return true;
    } else {
      Message.warning(response?.message || '密码修改失败');
      return false;
    }
  } catch (e) {
    console.error(e);
    Message.warning('修改密码失败');
    return false;
  }
}
const handleClose = () => {
  innerVisible.value = false;
  emits('update:visible', false);
}

</script>