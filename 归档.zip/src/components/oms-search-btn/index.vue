<!-- 通用筛选区域的查询按钮组 -->
<template>
  <div class="oms-search-btn" style="margin-bottom: 14px;">
    <a-space size="medium">
      <a-button :loading="loading" type="primary" status="normal" @click="emits('search')">
        <template #icon>
          <icon-search />
        </template>
        查询
      </a-button>
      <a-button :disabled="loading" @click="emits('clear')">
        <template #icon>
          <icon-refresh style="color:#818181" />
        </template>
        重置</a-button>

      <!-- 可自定义追加其他内容 -->
      <slot></slot>
    </a-space>
  </div>
</template>

<script setup lang="ts" name="oms-search-btn">
const props = defineProps({
  loading: { type: Boolean, default: false },
});

const emits = defineEmits<{
  (e: 'search'): void;
  (e: 'clear'): void;
}>();
</script>

<style lang="less" scoped>
:deep(.arco-btn) {
  &:hover {
    .arco-icon-refresh {
      color: rgb(62, 108, 254) !important;
    }
  }
}
</style>
