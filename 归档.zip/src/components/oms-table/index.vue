<!-- 通用表格面板 -->
<template>
  <div class="oms-table">
    <!-- 头部区域 -->
    <div class="header" v-if="slots['header-left'] || slots['header-right']">
      <div class="left">
        <template v-if="!slots['header-left']">
          <a-button type="primary" @click="emits('on-add')">
            <template #icon>
              <icon-plus />
            </template>
            {{ addText }}
          </a-button>
        </template>

        <slot name="header-left"></slot>
      </div>
      <div class="right">
        <slot name="header-right"></slot>
      </div>
    </div>

    <!-- 内容区域，通常放表格 -->
    <a-spin :loading="loading">
      <slot></slot>
    </a-spin>

    <!-- 分页组件 -->
    <div class="pagination" v-if="current && total !== 0">
      <a-pagination :total="total" :current="CurrentPageNum" :page-size="CurrentPageSize"
        :page-size-options="pageSizeOptions" show-total :show-jumper="!simplePagination"
        :show-page-size="!simplePagination" @change="pageChange" @page-size-change="sizeChange" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive, useSlots,computed } from 'vue';
const slots = useSlots();

const props = defineProps({
  addText: { type: String, default: '新增' },
  loading: { type: Boolean, default: false },
  current: { type: Number, default: 1 },
  size: { type: Number, default: 10 },
  total: { type: Number, default: 0 },
  simplePagination: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: 'reload', data: { pageNum: number; pageSize: number }): void;
  (e: 'on-add'): void;
}>();

const paginationInfo = reactive<{ pageNum: number; pageSize: number }>({
  pageNum: props.current,
  pageSize: props.size,
});
const CurrentPageNum = computed(()=>props.current)
const CurrentPageSize = computed(()=>props.size)
const pageSizeOptions: number[] = [10, 50, 100];

const pageChange = (v: number) => {
  paginationInfo.pageNum = v;
  handleReload();
};

const sizeChange = (v: number) => {
  paginationInfo.pageSize = v;
  handleReload();
};

const handleReload = () => {
  emits('reload', paginationInfo);
};
</script>

<style lang="less" scoped>
.arco-spin {
  display: block;
}

.oms-table {
  position: relative;
  width: 100%;

  .header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 2px;
  }

  .pagination {
    display: flex;
    justify-content: flex-end;
    margin:0px;
		padding: 14px 0px 4px;
  }
}
</style>
