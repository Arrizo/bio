<template>
  <div class="oms-panel">
    <div class="header" v-if="slot.header || title">
      <div class="title" v-if="title" v-text="title"></div>
      <slot name="header"></slot>
    </div>
    <div class="content" ref="panelRef">
      <div class="content-inner">
        <slot></slot>
      </div>
      <!-- 拖动块 -->
      <div class="drag-bar" v-if="allowDrop">
        <div class="drag-bar-inner" @mousedown="dragEagle"></div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, useSlots } from 'vue';

const slot = useSlots();
const props = defineProps({
  title: { type: String, default: '' },
  allowDrop: { type: Boolean, default: false }
});

const panelRef = ref();

function dragEagle(e: any) {
  if (!props.allowDrop) return;

  var targetDiv = panelRef.value;
  var targetDivHeight = targetDiv.offsetHeight;
  var startX = e.clientX
  var startY = e.clientY
  document.onmousemove = function (e) {
    e.preventDefault()
    var distY = Math.abs(e.clientY - startY)
    // 往下方拖动：
    if (e.clientY > startY) {
      targetDiv.style.height = targetDivHeight + distY + 'px'
    }
    // 往上方拖动：
    if (e.clientX > startX && e.clientY < startY) {
      targetDiv.style.height = targetDivHeight - distY + 'px'
    }
    if (parseInt(targetDiv.style.height) <= 100) {
      targetDiv.style.height = 300 + 'px'
    }
  }
  document.onmouseup = function () {
    document.onmousemove = null
  }
}
</script>

<style lang="less" scoped>
.oms-panel {
  position: relative;
  background-color: #fff;
  border-radius: 2px;
  margin-bottom: 10px;
  border: 1px solid #f3f3f3 !important;

  .header {
    padding: 16px 16px 0 16px;
    border-bottom: 1px solid #ECECEC;

    .title {
      padding: 0 16px;
      color: #3c3c3c;
      font-weight: bold;
      font-size: 14px;
    }

    :deep(.arco-form .arco-select) {
      width: 208px;
    }

    :deep(.arco-form .arco-form-item-content) {
      width: 208px;
    }
  }

  .content {
    &-inner {
      padding: 16px 16px;
      height: 100%;
    }

    overflow-y: auto;
    overflow-x: hidden;
  }

  .drag-bar {
    position: absolute;
    bottom: -4px;
    left: 50%;
    cursor: ns-resize;

    &:hover {
      .drag-bar-inner {
        opacity: 1;
        transition: all .2s ease;
      }
    }

    &-inner {
      margin-left: -40px;
      border-radius: 4px;
      width: 80px;
      height: 8px;
      background-color: #dcdcdc;
      opacity: 0;
      transition: all .2s ease;
    }
  }
}
</style>
