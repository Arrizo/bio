<!-- 统一封装导入弹窗 -->
<template>
  <a-modal :mask-closable="false" @cancel="handleCancel" :width="580" unmountOnClose v-model:visible="visible"
    title-align="start">
    <template #title>
      {{ state.title }}
    </template>
    <div class="content-import">
      <slot name="select"></slot>
      <div class="content-sign">只能上传{{ state.whiteList.join('/') }}文件，限制{{ state.uploadSize }}MB。请按模板格式上传数据
        <span class="upload" @click="downloadTemplate">下载模版</span>
      </div>
      <a-upload v-if="!state.interfaceName" ref="uploadRef" :show-file-list="false" draggable :limit="state.limitNum"
        :on-before-upload="beforeUpload">
        <template #upload-button>
          <div class="uploadStyle">
            <div class="upload-img">
              <span class="iconfont icon-kongneirong1"></span>
            </div>
            <div>
              <span style="color: #3370FF"> 点击</span>
              或将文件拖拽到这里上传
            </div>
          </div>
        </template>
      </a-upload>
      <!-- 文件存在的时候 -->
      <div class="uploadStyle" v-if="state.interfaceName">
        <div class="upload-img"><span class="iconfont icon-kongneirong1"></span></div>
        <template v-if="state.interfaceName">
          <!-- 页面展示 -->
          <div v-if="!isUpload" class="file-list">
            <div v-if="state.interfaceName" v-text="state.interfaceName"></div>
            <span class="iconfont icon-shanchu delStyle" @click="delFile"></span>
          </div>
          <!-- 上传显示 -->
          <div v-if="isUpload">
            文件上传中...
          </div>
          <a-button type="outline" v-if="state.errorData" @click="uploadErrorData" class="errorFileBtn">下载异常文件</a-button>
        </template>
      </div>
    </div>
    <template #footer>
      <a-space :size="14">
        <a-button @click="handleCancel">取消</a-button>
        <a-button type="primary" :loading="isUpload" @click="submit" :disabled="!!state.errorData">确认</a-button>
      </a-space>
    </template>
  </a-modal>
</template>

<script setup lang="ts" name="oms-import">
import { reactive, ref } from 'vue';
import { FileItem, Message, RequestOption } from '@arco-design/web-vue';
import { downFile } from '@/utils/helper';
import { getFileOutputStream } from '@/api/basicdata/express';
const props = defineProps({
  title: { type: String, default: "导入" },
  whiteList: { type: Array, default: () => ['xls', 'xlsx'] },//上传类型
  limitNum: { type: Number, default: 1 },//上传数量
  uploadSize: { type: Number, default: 5 },//上传大小
  templateUrl: { type: String, default: "" },//存在则跳转，不存在则请求接口
  uploadType: { type: String, default: 'stream' },//下载方式：链接link、文件流stream
  paramsObj: { type: Object, default: {} },//需要额外携带的参数{key1:value1,key2:value2...}
  importApi: { type: Function },// 自定义上传方法
  uploadUrl: { type: String, default: "" },//下载模版，模版参数（文件流形式）
  uploadUrlName: { type: String, default: "文件名称_" },//下载模版，模版参数（文件流形式）
  isCheckParams: {
    type: Array, default: () => []
  }//插槽里需要校验数据信息
});

const emits = defineEmits<{
  (e: "onSuccess"): void;//上传成功
  (e: "on-cancle"): void;
  (e: "clear"): void;//清空插槽里面的值
  (e: "onFileChange", data?: {}): void,//文件上传
}>();

const visible = ref<boolean>(false);
const isUpload = ref<boolean>(false)
const uploadRef = ref()
const state = reactive({
  title: props.title,
  whiteList: props.whiteList,
  limitNum: Number(props.limitNum),
  uploadSize: Number(props.uploadSize),
  templateUrl: props.templateUrl,
  uploadUrl: props.uploadUrl,
  interfaceName: '',
  uploadUrlName: props.uploadUrlName,
  file: {},
  errorData: '',//异常数据
  uploadType: props.uploadType,
  isCheckParams: props.isCheckParams,
});

const handleCancel = () => {
  visible.value = false;
  isUpload.value = false;
  state.errorData = '';
  state.interfaceName = '';
  emits('clear');
};

//上传前校验
const beforeUpload = (file: File) => {
  return new Promise<boolean | File>(function (resolve, reject) {
    const suffix = file.name.substring(file.name.lastIndexOf('.') + 1);
    const isLt5M = file.size / 1024 / 1024 > state.uploadSize
    const isSuffix = state.whiteList.indexOf(suffix) === -1;

    if (isSuffix) {
      Message.error('只能上传.xls、.xlsx文件')
      return reject();
    }
    if (isLt5M) {
      Message.error(`只能上传.xls、.xlsx文件，且不可超过${state.uploadSize}M`)
      return reject();
    }
    state.interfaceName = file.name;
    state.file = file;

  })
}

//点击确认调接口
const submit = async () => {
  if (!state.interfaceName) {
    return Message.error('请选择上传文件');
  }


  // //组装开始上传
  let formData: FormData = new FormData()
  formData.append('file', state.file as Blob)
  formData.append('filePath', state.interfaceName)

  // 遍历插槽中的值
  if (state.isCheckParams.length > 0) {
    for (let i = 0; i < state.isCheckParams.length; i++) {
      const item = state.isCheckParams[i] as any;
      if (!item.value && item.isRequired) return Message.error(item.errMessage);
      formData.append(item.name, item.value)
    }
  }

  //获取自定义传值
  for (const key in props.paramsObj) {
    if (Object.prototype.hasOwnProperty.call(props.paramsObj, key)) {
      const item = props.paramsObj[key];
      formData.append(key, item)
    }
  }
  isUpload.value = true;
  //上传
  try {
    if (typeof props.importApi === 'function') {
      const res = await props.importApi(formData)
      if (res.code != 0) {
        throw new Error(res.message);
      }
      isUpload.value = false;
      if (res.value) {//有异常数据情况
        state.errorData = res.value;
        return
      }
      //成功上传完
      Message.success(res.message);
      visible.value = false;
      state.interfaceName = '';
      state.errorData = '';
      emits('onSuccess');
    }
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  } finally {
    isUpload.value = false;
  }
}

//下载异常数据
const uploadErrorData = () => {
  if (state.errorData) {
    handleStreamFile(state.errorData, state.errorData.replace(/[^\u4E00-\u9FA5]/g, ''));
  }
}

//删除文件（前端删除）
const delFile = () => {
  state.interfaceName = '';
  state.errorData = '';
  isUpload.value = false;
}

// 下载模版
const downloadTemplate = async () => {
  //链接形式
  if (!props.templateUrl && props.uploadType === 'link') {
    return Message.error('下载模版不存在');
  }
  //文件流形式
  if (!props.uploadUrl && props.uploadType === 'stream') {
    return Message.error('下载模版不存在');
  }
  if (props.uploadType == 'link') {
    //链接下载
    return window.location.href = props.templateUrl as string
  } else {
    //文件流
    handleStreamFile(props.uploadUrl, props.uploadUrlName);
  }
}

//文件流下载模版
const handleStreamFile = async (val: string, name: string) => {
  try {
    const res = await getFileOutputStream(val)
    downFile(res, name);
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}
defineExpose({
  visible,
  isUpload
});
</script>

<style lang="less" scoped>
.content-import {
  color: #3A3A3A;
  font-size: 13px;

  .uploadStyle {
    padding: 24px 0 36px 0;
    background-color: #fafdff;
    color: #3A3A3A;
    border: 1px dashed #3E6CFE;
    width: 100%;
    font-size: 14px;
    border-radius: 2;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    .upload-img {
      margin-bottom: 34px;
      width: 48px;
      height: 42px;

      span {
        font-size: 42px;
        color: #3E6CFE;
      }
    }

    .errorFileBtn {
      margin-top: 12px;
    }

    .file-list {
      display: flex;
      align-items: center;

      .delStyle {
        margin-left: 8px;
        cursor: pointer;
      }
    }
  }

  .content-sign {
    margin-bottom: 14px;

    .upload {
      color: #3E6CFE;
      margin-left: 12px;
      cursor: pointer;
    }
  }
}


.arco-btn-outline {
  color: #FF9E20 !important;
  border: 1px solid #FF9E20 !important;
}
</style>