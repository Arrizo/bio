import { getDictionaryTitle, queryType } from "@/api/system/dictionary";
import { Message } from '@arco-design/web-vue';
//获取有效字典数据
//BUSINESS_TYPE(业务类型)、AFFI_COMPANY(所属公司)、DICTIONARY_CATEGORY(字典分类)、WAREHOUSE_TYPE(实体仓类型)、VIRTUAL_WAREHOUSE_TYPE(虚拟仓类型)、RESTRICTION_REASON(限发原因)、STANDARD_EXPRESS(标准快递)、PRICE_SOURCE(价格来源)、DISTRIBUTION_METHOD(配货方式)、
export const getDictionaryList = async (val:string)=>{
  try {
    const res = await getDictionaryTitle(val);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    return res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

//获取所有的数据字典
export const getValidDictionaryList = async (val:string)=>{
  try {
    const res = await queryType(val);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    return res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}


