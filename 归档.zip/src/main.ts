import { createApp } from 'vue';
import ArcoVue from '@arco-design/web-vue';
import ArcoVueIcon from '@arco-design/web-vue/es/icon';
import globalComponents from '@/components';
import router from './router';
import store from './store';
import directive from './directive';
// import './mock';

// 自定义主题
import '@arco-themes/vue-oms-ui/index.less';
import '@/assets/style/global.less';
import '@/assets/font/iconfont.css';
import '@/api/interceptor';

import App from './App.vue';
import print from 'vue3-print-nb'
const app = createApp(App);

app.use(ArcoVue, {});
app.use(ArcoVueIcon);

app.use(router);
app.use(store);
app.use(print);
app.use(globalComponents);
app.use(directive);

app.mount('#app');
