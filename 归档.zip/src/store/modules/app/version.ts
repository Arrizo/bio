/**
 * @ Author: Sam
 * @ Create Time: 2023-02-21 09:07:52
 * @ Modified by: Sam
 * @ Modified time: 2023-02-21 11:02:04
 * @ Description:
 */

import { defineStore } from 'pinia';
import { getVersion } from '@/api/user';
import { Modal } from '@arco-design/web-vue';

const useVersionStore = defineStore('version', {
  state: () => {
    return {
      /** 上一版本（其实就是当前版本） */
      last_version: '',
      /** 上次检查更新时间（时间戳） */
      last_check_timestamp: 0,
      /** 检查更新时间间隔 */
      time_space: 10,
    };
  },
  actions: {
    /** 获取最新版本号，默认初始为当前版本赋值 */
    async getLatest() {
      if (import.meta.env.MODE === 'dev') {
        return;
      }
      const nowStamp = Date.parse(new Date().toString()) / 1000;
      if (
        this.last_check_timestamp &&
        nowStamp - this.last_check_timestamp <= this.time_space
      ) {
        return;
      }

      const { version } = await getVersion();
      this.last_check_timestamp = nowStamp;

      // 首次初始化当前版本
      if (!this.last_version) {
        this.last_version = version;
        return;
      }

      if (this.isNeedToUpdate(version)) {
        Modal.open({
          title: '更新提示',
          content: '检测到客户端有版本更新，请手动刷新页面',
          okText: '立即更新',
          hideCancel: true,
          closable: false,
          maskClosable: false,
          onOk: () => {
            window.location.href = `https://${window.location.host}`;
          },
        });
      }
    },
    /**
     * 是否需要提示更新
     * 目前直接对比版本号是否一致
     * @param version 获取得最新版本号
     * @returns boolean
     */
    isNeedToUpdate(version: string) {
      return this.last_version && this.last_version !== version;
    },
  },
});

export default useVersionStore;
