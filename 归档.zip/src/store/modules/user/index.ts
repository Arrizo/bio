import { defineStore } from 'pinia';
import {
  login as userLogin,
  getMenu,
  getRsaPublicKey,
  logout as userLogout,
} from '@/api/user';
import { setToken, clearToken } from '@/utils/auth';
import { removeRouteListener } from '@/utils/route-listener';
import useAppStore from '../app';
import { LoginData, UserInfo, UserMenuItem } from '@/types/user';
import { rsaEncrypt } from '@/utils/helper';
import { DEFAULT_LAYOUT } from '@/router/routes/base';
import router from '@/router';
import Modal from '@arco-design/web-vue/es/modal';
import { Message } from '@arco-design/web-vue';

const useUserStore = defineStore('user', {
  state: (): UserInfo => ({
    jobCode: '',
    menuListVOS: [],
    mobile: '',
    nickname: '',
    orgId: 0,
    orgName: '',
    type: '',
    userName: '',
    permsMap: {},
    firstMenuList: [],
    leftMenuList: {},
    currentFirstMenu: '',
    permissionList: [],
  }),
  actions: {
    // 回填用户信息、菜单、路由等数据
    setInfo(partial: Partial<UserInfo>) {
      this.$patch(partial);
      this.firstMenuList = [];

      for (let i = 0; i < this.menuListVOS.length; i++) {
        // 提取首级菜单
        const { id, menuName, perms, icon, type, url, children } =
          this.menuListVOS[i];
        if (this.menuListVOS[i].type === 'MENU') {
          this.firstMenuList.push({ id, menuName, perms, icon, type, url });
          // 生成对应首级菜单的左侧菜单数据映射
          this.leftMenuList[perms] = children;
        }
      }

      const local_csm = localStorage.getItem('currentFirstMenu');

      if (this.firstMenuList.length) {
        this.currentFirstMenu = local_csm || this.firstMenuList[0].perms;
        localStorage.setItem('currentFirstMenu', this.currentFirstMenu);
      }
    },
    async setRoute(menuListVOS: UserMenuItem[]) {
      return new Promise((resolve) => {
        let modules = import.meta.glob('../../../views/**/*.vue');
        function setMenuInfo(arr: any[], is_level_one: boolean = false) {
          let newArr = [];
          for (let i = 0; i < arr.length; i++) {
            const hasChildren = arr[i].children && arr[i].children.length > 0;

            let raw: any = {};
            if (arr[i].type === 'PAGE') {
              const str = `views${arr[i].url}/index`;
              raw = {
                name: arr[i].perms,
                path: arr[i].url,
                component:
                  is_level_one && hasChildren
                    ? DEFAULT_LAYOUT
                    : modules[`../../../${str}.vue`],
                meta: {
                  locale: arr[i].menuName,
                  requiresAuth: true,
                },
              };
            }

            if (hasChildren) {
              var data = setMenuInfo(arr[i].children, arr[i].type === 'MENU');
              if (JSON.stringify(data[0]) !== '{}') {
                raw.children = [];
                raw.children = data;
              }
            }

            if (JSON.stringify(raw) !== '{}' && raw.name) {
              router.addRoute(raw);
            }
            newArr.push(raw);
          }
          return newArr;
        }

        resolve(setMenuInfo(menuListVOS));
      });
    },
    // Reset user's information
    resetInfo() {
      this.$reset();
    },
    async info() {
      // try {
      const res = await getMenu();
      if (res.code != 0) {
        throw new Error(res.message);
      } else {
        if (res?.value?.menuListVOS?.length === 0) {
          Message.error('暂无权限，请联系系统管理员分配权限');
          this.logout();
          throw new Error('暂无权限');
        }

        this.setInfo(res.value);
      }

      // } catch (err) {
      // router.replace("/login");
      // Message.error((err as Error).message);
      // }
    },
    // Login
    async login(loginForm: LoginData) {
      try {
        // 获取公钥
        const keyData = await getRsaPublicKey();
        if (keyData.code != 0) {
          throw new Error(keyData.message);
        }

        const res = await userLogin({
          account: loginForm.account,
          password: rsaEncrypt(loginForm.password, keyData.value) as string,
        });
        if (res.code != 0) {
          throw new Error(res.message);
        }
        setToken(res.value.token);
      } catch (err) {
        clearToken();
        throw err;
      }
    },
    logoutCallBack() {
      const appStore = useAppStore();
      this.resetInfo();
      clearToken();
      removeRouteListener();
      appStore.clearServerMenu();
    },
    // Logout
    async logout() {
      try {
        // await userLogout();
        this.logoutCallBack();
      } finally {
        this.logoutCallBack();
      }
    },
  },
});

export default useUserStore;
