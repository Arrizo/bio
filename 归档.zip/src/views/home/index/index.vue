<template>
  <oms-panel style="height:100%">
    <div class="default-empty">
      <img src="../../../assets/images/default-bg.png" style="max-width:554px;max-height: 80%;">
      <p>欢迎使用金文业务中台~</p>
    </div>
  </oms-panel>
</template>

<script setup lang="ts" name="home-index">
import OmsPanel from '@/components/oms-panel/index.vue';
</script>

<style lang="less" scoped>
.default-empty {
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  height: 100%;
  width: 100%;

  p {
    font-size: 26px;
    font-weight: 400;
    line-height: 35px;
    color: #3A3A3A;
    opacity: 1;
  }
}
</style>