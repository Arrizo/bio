<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-16 13:48:37
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 15:48:07
 * @ Description: 配货策略-行详情
 -->

<template>
  <div class="delivery-row-detail">
    <a-tabs :style="{ width: '100%' }">
      <template #extra>
        <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
      </template>
      <a-tab-pane key="config" title="策略配置">
        <oms-table :loading="loading" :total="total" :current="searchForm.pageNum" :size="searchForm.pageSize"
          @reload="queryPage" simple-pagination>
          <template #header-left>
            <a-button v-permission="['oms:strategy:deliveryconfig:add']" type="primary" status="normal"
              @click="handleAddClick" style="margin-bottom: 10px;">新增</a-button>
          </template>
          <a-table stripe :data="(list as any)" :pagination="false" hide-expand-button-on-empty row-key="id"
            :bordered="{ wrapper: false }">
            <template #columns>
              <a-table-column title="虚拟仓库" ellipsis tooltip>
                <template #cell="{ record }"> {{ record.warehouseName || '--' }} </template>
              </a-table-column>
              <a-table-column title="快递策略" ellipsis tooltip>
                <template #cell="{ record }">
                  <a-link v-permission="['oms:strategy:deliveryconfig:express']" @click="handleExpress(record)">{{
                    record.expressStrategyName }}</a-link>
                  <a-link v-permission-else="['oms:strategy:deliveryconfig:express']" disabled>{{
                    record.expressStrategyName }}</a-link>
                </template>
              </a-table-column>
              <a-table-column title="优先级" ellipsis tooltip>
                <template #cell="{ record }"> {{ record.level }} </template>
              </a-table-column>
              <a-table-column title="状态">
                <template #cell="{ record, rowIndex }">
                  <div v-permission="['oms:strategy:deliveryconfig:status']">
                    <a-switch v-model="(list as any)[rowIndex].status" @focus="onSwitchForce(record, rowIndex)">
                      <template #checked>
                        启用
                      </template>
                      <template #unchecked>
                        禁用
                      </template>
                    </a-switch>
                  </div>
                  <div v-permission-else="['oms:strategy:deliveryconfig:status']">{{ record.status ? '启用' : '禁用' }}</div>
                </template>
              </a-table-column>
              <a-table-column title="策略条件" ellipsis tooltip>
                <template #cell="{ record }">
                  <div v-if="record.exitConfig">
                    <a-link v-permission="['oms:strategy:deliveryconfig:detail']"
                      @click="handleDetail(record)">查看条件</a-link>
                    <a-link v-permission-else="['oms:strategy:deliveryconfig:detail']" disabled>查看条件</a-link>
                  </div>
                  <div v-else>--</div>
                </template>
              </a-table-column>
              <a-table-column title="创建时间" ellipsis tooltip>
                <template #cell="{ record }"> {{ record.createTime || '--' }} </template>
              </a-table-column>
              <a-table-column title="修改时间" ellipsis tooltip>
                <template #cell="{ record }"> {{ record.updateTime || '--' }} </template>
              </a-table-column>
              <a-table-column title="操作" :width="140" fixed="right">
                <template #cell="{ record }">
                  <a-space :size="14">
                    <a-link v-permission="['oms:strategy:deliveryconfig:edit']" v-if="!record.status"
                      @click="handleActoin('edit', record)" type="text">编辑</a-link>
                    <a-link v-permission="['oms:strategy:deliveryconfig:del']" v-if="!record.status"
                      @click="handleActoin('del', record)" status="danger" type="text">删除</a-link>
                    <a-link v-permission="['oms:strategy:deliveryconfig:log']" @click="handleActoin('log', record)"
                      type="text">日志</a-link>
                  </a-space>
                </template>
              </a-table-column>
            </template>
          </a-table>
        </oms-table>
      </a-tab-pane>
    </a-tabs>
  </div>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleUpdateStatus"></oms-warning>

  <!-- 删除二次确认 -->
  <oms-warning ref="delRef" :on-before-ok="handleDelete"></oms-warning>

  <!-- 日志 -->
  <oms-log ref="logRef"></oms-log>

  <!-- 表单 -->
  <strategy-form ref="strategyFormRef" @reload="init(searchForm.strategyId, strategyData)"></strategy-form>

  <!-- 查看条件 -->
  <strategy-detail ref="strategyDetailRef"></strategy-detail>

  <!-- 查看快递策略 -->
  <express-modal ref="expressModalRef"></express-modal>
</template>

<script setup lang="ts" name="delivery-row-detail">
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import { Message } from '@arco-design/web-vue';
import OmsLog from '@/components/oms-log/index.vue';
import strategyForm from "./strategy-form.vue";
import expressModal from './express-modal.vue';
import { reactive, ref } from 'vue';
import strategyDetail from '@/components/oms-strategy/components/strategy-detail.vue';
import { getPage, delDelivery, deliveryStatus } from '@/api/strategy/delivery';
import { StrategyType } from '@/types/strategy/order';
import { DeliveryListItem, DeliverySearchForm } from '@/types/strategy/delivery';

const emits = defineEmits<{
  (e: "close"): void,
}>();

const list = ref<DeliveryListItem[]>([]);
const loading = ref<boolean>(false);
const total = ref<number>(0);
const delRef = ref();
const logRef = ref();
const expressModalRef = ref();
const delId = ref();
const strategyFormRef = ref();
const switchRef = ref();
const searchForm = ref<DeliverySearchForm>(new DeliverySearchForm());
const strategyData = ref();
const strategyDetailRef = ref();
const statusData = reactive({
  id: NaN,
  index: NaN,
  status: false
});

/** 组件初始化赋值，并执行查询 */
const init = async (id: any, data: any) => {
  strategyData.value = data;
  searchForm.value.strategyId = id;
  queryPage({ strategyId: searchForm.value.strategyId });
}

/**
 * 查询配置列表
 * @param data
 */
const queryPage = async (data?: any) => {
  try {
    loading.value = true;
    searchForm.value = { ...searchForm.value, ...data };
    const res = await getPage(searchForm.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

/** 查看条件 */
const handleDetail = (record: any) => {
  strategyDetailRef.value.open(record.id, StrategyType.Phcl);
}

/** 查看快递策略 */
const handleExpress = (record: any) => {
  expressModalRef.value.open(record.expressStrategyId);
}

/** 新增策略配置触发 */
const handleAddClick = () => {
  strategyFormRef.value.handleShowModal("add", {}, strategyData.value);
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: any, index: number) => {
  statusData.id = record?.id;
  statusData.index = index;
  statusData.status = record?.status;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "edit" | "del" | "log", data: any) => {
  if (type === "edit") {
    strategyFormRef.value.handleShowModal("edit", data, strategyData.value);
    return;
  }
  if (type === 'del') {
    delId.value = data?.id || NaN;
    delRef.value.open();
    return;
  }
  logRef.value.init(data.logCode, "配货策略");
};

// 修改状态
const handleUpdateStatus = async () => {
  try {
    const res = await deliveryStatus(statusData.id);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    queryPage();
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delDelivery(delId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    queryPage();
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

//关闭详情
const closeDetails = () => {
  emits('close')
}

defineExpose({
  init
})
</script>
<style lang="less">
.delivery-row-detail {
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  .arco-tabs-content {
    padding-left: 16px;
    padding-right: 16px;
  }

  .arco-tabs-nav {
    padding: 0 16px;
  }

  .arco-form .arco-select {
    width: 208px;
  }
}
</style>