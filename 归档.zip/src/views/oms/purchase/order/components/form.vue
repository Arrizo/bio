<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-30 14:42:04
 * @ Modified by: Sam
 * @ Modified time: 2023-03-30 15:51:49
 * @ Description: 采购订单-表单
 -->

<template>
  <a-modal :title="`${editModal.type === 'add' ? '新增' : '编辑'}采购单`" fullscreen v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" unmountOnClose :esc-to-close="false" :mask-closable="false">
    <div style="padding: 0 6px 0 2px;">
      <p class="form-title" style="margin-top: 0;margin-bottom: 16px;">基本信息</p>
      <a-form ref="formRef" :model="form">
        <a-row>
          <a-col :span="8">
            <a-form-item field="companyCode" label="采购日期：" label-col-flex="120px"
              :rules="[{ required: true, message: '请选择采购日期' }]">
              <a-date-picker style="width: 280px;" />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="到货日期：" label-col-flex="120px">
              <a-date-picker style="width: 280px;" />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="入库仓库：" label-col-flex="120px">
              <a-select placeholder="请选择" style="width: 280px;"></a-select>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="8">
            <a-form-item field="companyCode" label="来源单据：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请选择"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="源单号：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请选择"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="采购类型：" label-col-flex="120px"
              :rules="[{ required: true, message: '请选择采购类型' }]">
              <a-select placeholder="请选择" style="width: 280px;"></a-select>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="8">
            <a-form-item field="companyCode" label="供应商：" label-col-flex="120px"
              :rules="[{ required: true, message: '请选择供应商' }]">
              <div class="pop-multiple">
                <span class="placeholder">点击选择</span>
                <!-- <span class="value-text" v-else>{{ lstId.join() }}</span> -->
                <span class="pop-icon-inner">
                  <i class="iconfont icon-dianjixuanzeanniu"></i>
                </span>
              </div>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="供应商联系人：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="供应商联系电话：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="8">
            <a-form-item field="companyCode" label="采购组织：" label-col-flex="120px"
              :rules="[{ required: true, message: '请选择采购组织' }]">
              <a-select placeholder="请选择" style="width: 280px;"></a-select>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="采购部门：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="店铺：" label-col-flex="120px">
              <a-select placeholder="请选择" style="width: 280px;"></a-select>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="8">
            <a-form-item field="companyCode" label="合同号：" label-col-flex="120px"
              :rules="[{ required: true, message: '请选择采购组织' }]">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="结算方式：" label-col-flex="120px">
              <a-select placeholder="请选择" style="width: 280px;"></a-select>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="快递费：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="8">
            <a-form-item field="companyCode" label="仓库收货人：" label-col-flex="120px"
              :rules="[{ required: true, message: '请选择采购组织' }]">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="收货人电话：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="收货人身份证号：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="8">
            <a-form-item field="companyCode" label="采购员：" label-col-flex="120px"
              :rules="[{ required: true, message: '请选择采购组织' }]">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item field="companyCode" label="收货人区域：" label-col-flex="120px">
              <a-input disabled style="width: 280px;" placeholder="请输入"></a-input>
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="24">
            <a-form-item field="remark" label="详细地址：" label-col-flex="120px">
              <a-input v-limit-input show-word-limit :max-length="200" v-model="form.remark" placeholder="请输入"
                allow-clear />
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="24">
            <a-form-item field="remark" label="备注：" label-col-flex="120px">
              <a-textarea v-limit-input show-word-limit :max-length="200" v-model="form.remark" placeholder="请输入"
                allow-clear />
            </a-form-item>
          </a-col>
        </a-row>
        <a-row>
          <a-col :span="24">
            <a-form-item field="attachment" label="上传附件：" label-col-flex="100px">
              <div style="flex-direction: column;align-items: start;top: 3px;position: relative;">
                <file-uploader accept=".zip,.rar,.7z" download file-type="3" :size="50 * 1024 * 1024"></file-uploader>
                <p style="font-size: 13px;color: #B1B1B1;margin:0;">支持pdf/xls/word/png/jpg/bmp等格式</p>
              </div>
            </a-form-item>
          </a-col>
        </a-row>
      </a-form>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="strategy-delivery-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import fileUploader from '@/components/file-uploader/index.vue';
import { StrategyForm, StrategyType } from '@/types/strategy/strategy';
import { addStrategy, updateStrategy } from '@/api/strategy/strategy';
import { DictionaryTitleType } from '@/types/system/dictionary';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const form = ref<StrategyForm>(new StrategyForm());
const companyList = ref<DictionaryTitleType[]>([]);

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const api = editModal.type === 'add' ? addStrategy : updateStrategy;
    // const res = await api(form.value);

    // if (res.code != 0) {
    //   Message.error(res.message);
    //   return false;
    // }
    // Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: any) => {
  editModal.type = type;
  editModal.show = true;

  if (type === 'add') {
    form.value = new StrategyForm();
  }

  if (type === "edit") {
    try {

    } catch (err) {
      Message.error((err as Error).message);
    }
  }
}

defineExpose({
  handleShowModal
});
</script>

<style lang="less" scoped>
.form-title {
  color: #3A3A3A;
  font-size: 13px;
  font-weight: bold;
  line-height: 17px;
}

.pop-multiple {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 280px;
  height: 32px;
  border: 1px solid #EDEDED;
  opacity: 1;
  color: #B1B1B1;
  padding: 0 11px;
  cursor: pointer;

  .value-text {
    color: #3A3A3A;
    width: 120px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
}
</style>