<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-29 14:33:23
 * @ Modified by: Sam
 * @ Modified time: 2023-03-30 13:57:54
 * @ Description: 采购订单-搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="code" hide-label style="width: 280px;">
      <a-input-group>
        <a-select v-model="form.codeType" :style="{ width: '100px' }" placeholder="请选择">
          <a-option value="purchase">采购单号</a-option>
          <a-option value="from">来源单号</a-option>
        </a-select>
        <a-input v-model="form.code" :style="{ width: '200px' }" placeholder="多个用英文逗号分隔" />
      </a-input-group>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="(form.status as string)">
        <a-option :value="Status.Own">全部</a-option>
        <a-option :value="Status.Stash">暂存</a-option>
        <a-option :value="Status.WaitAudit">待审核</a-option>
        <a-option :value="Status.AuditPass">通过</a-option>
        <a-option :value="Status.NoPass">不通过</a-option>
        <a-option :value="Status.Cancellation">已作废</a-option>
        <a-option :value="Status.Completed">已完结</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="inStatus" label="入库状态：">
      <a-select placeholder="请选择" v-model="(form.inStatus as string)">
        <a-option :value="InStatus.Own">全部</a-option>
        <a-option :value="InStatus.Not">未入库</a-option>
        <a-option :value="InStatus.Part">部分入库</a-option>
        <a-option :value="InStatus.All">全部入库</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="noticeStatus" label="通知状态：">
      <a-select placeholder="请选择" v-model="(form.noticeStatus as string)">
        <a-option :value="NoticeStatus.Own">全部</a-option>
        <a-option :value="NoticeStatus.Not">未通知</a-option>
        <a-option :value="NoticeStatus.All">全部通知</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="name" hide-label style="width: 280px;">
      <a-input-group>
        <a-select v-model="form.nameType" :style="{ width: '100px' }" placeholder="请选择">
          <a-option value="supplierName">供应商名称</a-option>
          <a-option value="purchaser">采购员</a-option>
        </a-select>
        <a-input v-model="form.name" :style="{ width: '200px' }" placeholder="请输入" />
      </a-input-group>
    </a-form-item>
    <a-form-item field="virtualWarehouseId" label="入库仓库：">
      <oms-multiple-select v-model="form.virtualWarehouseId" :option-list="warehouseList" value="id"
        label="virtualWarehouseName" :max-tag-count="1"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="timeTemp" hide-label style="width: 400px;">
      <a-input-group>
        <a-select v-model="form.dateType" :style="{ width: '100px' }" placeholder="请选择">
          <a-option value="purchase">采购日期</a-option>
          <a-option value="arrival">到货日期</a-option>
        </a-select>
        <a-range-picker v-model="form.timeTemp" showTime />
      </a-input-group>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="strategy-delivery-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"
import { PurchaseOrderSearchForm, Status, InStatus, NoticeStatus } from '@/types/purchase/order';
import { deepClone } from '@/utils/helper';
import { onMounted, ref } from 'vue';
import { getActiveVirtualList } from "@/api/purchase/order";
import { Message } from '@arco-design/web-vue';

const props = defineProps({
  loading: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: "on-search", data: any, isReset: boolean): void;
}>();

const formRes = ref();
const form = ref<PurchaseOrderSearchForm>(new PurchaseOrderSearchForm());
const warehouseList = ref([]);

const init = async () => {
  try {
    const res = await getActiveVirtualList();
    if (res.code != 0) {
      throw new Error(res.message);
    }
    warehouseList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

// 执行搜索
const handleSearch = () => {
  const data = deepClone(form.value);

  emits("on-search", data, true);
};

// 重置搜索条件
const handleReset = () => {
  form.value = new PurchaseOrderSearchForm();
}

onMounted(() => {
  init();
  handleSearch();
});
</script>