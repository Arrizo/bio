<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-29 14:33:23
 * @ Modified by: Sam
 * @ Modified time: 2023-03-30 15:27:00
 * @ Description: 列表
 -->

<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onTableReload">
    <template #header-left>
      <a-space>
        <a-button v-permission="['oms:strategy:delivery:add']" type="primary" status="normal" @click="handleAddClick"
          style="margin-bottom: 10px;"> 新增 </a-button>
        <a-button v-permission="['oms:strategy:delivery:add']" type="outline" status="normal" @click="handleAddClick"
          style="margin-bottom: 10px;"> 审核 </a-button>
      </a-space>
    </template>

    <a-table v-db-click="list" stripe :db-call-back="handleDbClick" :data="(list as any)" :pagination="false"
      hide-expand-button-on-empty row-key="id" :bordered="{ wrapper: false }" :scroll="{ x: 1400 }">
      <template #columns>
        <a-table-column title="采购单号" ellipsis tooltip :width="120">
          <template #cell="{ record }"> {{ record.purchaseOrderCode || '--' }} </template>
        </a-table-column>
        <a-table-column title="状态" :width="120">
          <template #cell="{ record }">
            <oms-tag v-if="!!record.status" :type="StatusTagObj[record.status]" :content="record.statusName"></oms-tag>
            <span v-else>--</span>
          </template>
        </a-table-column>
        <a-table-column title="入库状态" :width="120">
          <template #cell="{ record }">
            <oms-tag v-if="!!record.inStatus" :type="InStatusTag[record.inStatus]"
              :content="record.inStatusName"></oms-tag>
            <span v-else>--</span>
          </template>
        </a-table-column>
        <a-table-column title="通知状态" :width="120">
          <template #cell="{ record }">
            <oms-tag v-if="!!record.noticeStatus" :type="NoticeStatusTag[record.noticeStatus]"
              :content="record.noticeStatusName"></oms-tag>
            <span v-else>--</span>
          </template>
        </a-table-column>
        <a-table-column title="采购日期" :width="180">
          <template #cell="{ record }"> {{ record.purchaseDate || '--' }} </template>
        </a-table-column>
        <a-table-column title="到货日期" :width="180">
          <template #cell="{ record }"> {{ record.arrivalDate || '--' }} </template>
        </a-table-column>
        <a-table-column title="供应商" :width="120">
          <template #cell="{ record }"> {{ record.supplierName || '--' }} </template>
        </a-table-column>
        <a-table-column title="采购组织" :width="120">
          <template #cell="{ record }"> {{ record.purchaseOrgName || '--' }} </template>
        </a-table-column>
        <a-table-column title="采购类型" :width="120">
          <template #cell="{ record }"> {{ record.purchaseTypeName || '--' }} </template>
        </a-table-column>
        <a-table-column title="来源类型" :width="120">
          <template #cell="{ record }"> {{ record.fromReceipt || '--' }} </template>
        </a-table-column>
        <a-table-column title="来源单号" :width="120">
          <template #cell="{ record }"> {{ record.fromCode || '--' }} </template>
        </a-table-column>
        <a-table-column title="采购员" :width="120">
          <template #cell="{ record }"> {{ record.purchaser || '--' }} </template>
        </a-table-column>
        <a-table-column title="最后入库时间" :width="180">
          <template #cell="{ record }"> {{ record.remark || '--' }} </template>
        </a-table-column>
        <a-table-column title="备注" ellipsis tooltip :width="140">
          <template #cell="{ record }"> {{ record.purchaseOrderCode || '--' }} </template>
        </a-table-column>
        <a-table-column title="最后更新时间" ellipsis tooltip :width="180">
          <template #cell="{ record }"> {{ record.updateTime || '--' }} </template>
        </a-table-column>
        <a-table-column title="操作" :width="240" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link @click="handleActoin('edit', record)" type="text">编辑</a-link>
              <a-link @click="handleActoin('edit', record)" type="text">审核</a-link>
              <a-link @click="handleActoin('edit', record)" type="text">完结</a-link>
              <a-link @click="handleActoin('edit', record)" type="text">通知</a-link>
              <a-link @click="handleActoin('del', record)" status="danger" type="text">作废</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 作废二次确认 -->
  <oms-warning ref="delRef" :on-before-ok="handleDelete"></oms-warning>

  <!-- 采购订单表单 -->
  <order-form ref="formRef"></order-form>
</template>

<script setup lang="ts" name="strategy-delivery-list">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import omsTag from "@/components/oms-tag/index.vue";
import { Message } from '@arco-design/web-vue';
import { statusDocReview, delDocReview } from '@/api/strategy/order';
import OrderForm from "./form.vue";

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  total: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload", data?: any): void,
  (e: "on-db-click", data: any): void,
}>();

const delRef = ref();
const delId = ref();
const switchRef = ref();
const formRef = ref();
const statusData = reactive({
  id: NaN,
  index: NaN,
  status: false
});

// 「新增」按钮点击触发
const handleAddClick = () => {
  formRef.value.handleShowModal("add");
};

/** 行双击触发 */
const handleDbClick = (data: any) => {
  emits("on-db-click", data);
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: any, index: number) => {
  statusData.id = record?.id;
  statusData.index = index;
  statusData.status = record?.status;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

// 表格分页触发
const onTableReload = (data: { pageNum: number; pageSize: number }) => {
  emits('reload', data);
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "edit" | "del", data: any) => {
  if (type === "edit") {
    formRef.value.handleShowModal("edit", data);
    return;
  }
  if (type === 'del') {
    delId.value = data?.id || NaN;
    delRef.value.open();
    return;
  }
};

// 修改状态
const handleUpdateStatus = async () => {
  try {
    const res = await statusDocReview({
      id: statusData.id,
      status: !statusData.status
    });
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delDocReview(delId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

const InStatusTag = {
  "ALL": "progress",
  "NOT": "normal",
  "NOT_NOTIFIED": "warring",
  "NOTIFICATION_FAILED": "warring",
  "NOTIFIED": "normal",
  "PART": "progress",
}
const NoticeStatusTag = {
  "ALL": "normal",
  "NOT": "progress",
  "PART": "progress",
}
const StatusTagObj = {
  "AUDIT_PASS": "normal",
  "CANCELLATION": "warring",
  "COMPLETED": "normal",
  "NO_PASS": "warring",
  "STASH": "progress",
  "WAIT_AUDIT": "progress",
}
</script>