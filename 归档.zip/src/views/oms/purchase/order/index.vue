<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-29 14:24:39
 * @ Modified by: Sam
 * @ Modified time: 2023-03-30 13:59:10
 * @ Description: 采购订单
 -->

<template>
  <a-row :gutter="10" style="height: 100%;">
    <a-col :span="24" style="height: 100%;">
      <oms-panel allow-drop :style="rowData ? `` : `height:100%`">
        <template #header>
          <search :loading="loading" @on-search="init"></search>
        </template>
        <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
          @reload="init" @on-db-click="onDbClick"></list>
      </oms-panel>

      <!-- 行详情 -->
      <div style="margin-top:10px" v-if="rowData">
        <!-- <row-detail ref="rowDetialRef" @close="onDetailClose"></row-detail> -->
      </div>
    </a-col>
  </a-row>
</template>

<script setup lang="ts" name="oms-purchase-index">
import { nextTick, ref } from 'vue';
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import rowDetail from './components/row-detail.vue';
import { Message } from '@arco-design/web-vue';
import { deepClone } from '@/utils/helper';
import { getPage } from "@/api/purchase/order";
import { PurchaseOrderListItem } from '@/types/purchase/order';

const loading = ref<boolean>(false);
const list = ref<PurchaseOrderListItem[]>([{}]);
const total = ref<number>(0);
const rowData = ref();
const rowDetialRef = ref();
const form = ref<any>({});

const init = async (data?: any) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);

    const res = await getPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

/** 双击触发展示详情 */
const onDbClick = (data: any) => {
  rowData.value = data;
  nextTick(() => {
    // rowDetialRef.value.init(data.id, data);
  });
}

/** 行详情关闭 */
const onDetailClose = () => {
  rowData.value = null;
}
</script>