<template>
  <div class="panel-height">
    <oms-panel :class="{ 'panel-height': !showTabs }">
      <template #header>
        <search :loading="loading" @on-search="initMethod"></search>
      </template>
      <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" @reload="initMethod"
        :data-list="dataList" @show-record="showRecord"> </list>
    </oms-panel>
    <!-- 双击表格tabs栏目 -->
    <div class="shop-config" v-show="showTabs">
      <a-tabs default-active-key="1">
        <template #extra>
          <icon-close @click="showTabs = false" />
        </template>
        <a-tab-pane key="1" title="商品明细 ">
          <goods-details ref="goodsDetailsRef"></goods-details>
        </a-tab-pane>
        <a-tab-pane key="2" title="入库明细">
          <stock-details ref="stockDetailsRef"></stock-details>
        </a-tab-pane>
        <a-tab-pane key="5" title="操作日志">
          <oms-log ref="omsLogRef"></oms-log>
        </a-tab-pane>
      </a-tabs>
    </div>
  </div>
</template>
<script lang="ts" setup name="gift-index">
import commonData from '@/views/oms/marketing/commonData/initData'
import OmsPanel from '@/components/oms-panel/index.vue'
import { ref, reactive } from 'vue'
import Search from './components/search.vue'
import List from './components/list.vue'
import GoodsDetails from './components/goods-details.vue'
import StockDetails from './components/stock-details.vue'
import { StrategyType } from "@/types/strategy/order";
// import OmsStrategy from '@/components/oms-strategy/index.vue'
// import ActivityStore from './components/activity-store.vue'
import {
  NoticeSearchType,
  NoticeListType
} from '@/types/purchase/notice'
import {
  getList,
} from '@/api/purchase/notice'
import { Message } from "@arco-design/web-vue"
import omsLog from '@/components/oms-log/index.vue'
const showTabs = ref<boolean>(false)
const goodsDetailsRef = ref()
const stockDetailsRef = ref()
const omsLogRef = ref()
const { loading, total } = commonData()
let form = reactive<NoticeSearchType>(new NoticeSearchType())
const dataList = ref<Array<NoticeListType>>([])
const initMethod = async (data?: NoticeSearchType) => {
  try {
    Object.assign(form, data)
    loading.value = true
    const { code, message, value } = await getList(form)
    if (code != 0) {
      throw new Error(message)
    }
    dataList.value = value.result
    total.value = value.totalCount
    form.pageNum = value.pageNum
    form.pageSize = value.pageSize
    loading.value = false
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
// 双击表格回调事件
const showRecord = (data: NoticeListType) => {
  omsLogRef.value.init(data?.activityCode, '赠品活动', 'page')
  goodsDetailsRef.value.initData(data.id)
  stockDetailsRef.value.initData(data.id)
  showTabs.value = true
}
</script>
<style lang="less" scoped>
.panel-height {
  height: 100%;
}

.shop-config {
  background-color: #fff;
  height: 100%;

  :deep(.arco-tabs-nav) {
    padding: 10px 16px 0px 10px;
  }

  :deep(.arco-tabs-content) {
    padding-left: 16px;
    padding-right: 16px;
  }

  :deep(.arco-tabs-nav-extra) {
    border: 1px solid rgba(112, 112, 112, 0.3);
    border-radius: 50%;
    color: #707070;
    font-size: 11px;
    padding: 2px;
    cursor: pointer;
  }
}
</style>