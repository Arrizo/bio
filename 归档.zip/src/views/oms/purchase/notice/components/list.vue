
<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onReload">
    <template #header-left>
      <a-space :size="10" style="marginBottom:10px;">
        <a-button type="primary" @click="handlerEvent('pushWms')"
          v-permission="['oms:marketing:gift:add']">推送wms</a-button>
        <a-button type="primary" @click="handlerEvent('pushKind')"
          v-permission="['oms:marketing:gift:add']">推送金蝶</a-button>
      </a-space>
    </template>
    <a-table :pagination="false" :data="dataList" hide-expand-button-on-empty :scroll="{ x: 1150, y: 400 }" stripe
      :bordered="{ wrapper: false }" v-db-click="dataList" :db-call-back="getAdjustRecord" :row-selection="rowSelection">
      <template #columns>
        <a-table-column title="采购通知单" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.noticeCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="采购单号" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.purchaseOrderCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="状态" :tooltip="true" :width="120" ellipsis>
          <template #cell="{ record }">
            {{ record.statusName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="入库状态" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ record.inStatusName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="K3状态" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.k3StatusName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="入库仓库" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.virtualWarehouseName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="wms单号" :tooltip="true" :width="300" ellipsis>
          <template #cell="{ record }">
            {{ record.outerCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="采购员" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ `${record.purchaser || '--'}` }}
          </template>
        </a-table-column>
        <a-table-column title="批次号" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.batchNo || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="备注" :tooltip="true" :width="120" ellipsis>
          <template #cell="{ record }">
            {{ record.remark || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="最后入库时间" :tooltip="true" :width="90" ellipsis>
          <template #cell="{ record }">
            {{ record.lastInTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="更新时间" :tooltip="true" :width="90" ellipsis>
          <template #cell="{ record }">
            {{ record.updateTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="180" fixed="right">
          <template #cell="{ record }">
            <a-space :size="10">
              <a-link type="text" @click="handlerEvent('sub', record)"
                v-permission="['oms:marketing:gift:submit']">推送wms</a-link>
              <a-link type="text" @click="handlerEvent('audit', record)"
                v-permission="['oms:marketing:gift:audt']">打印</a-link>
              <a-link type="text" @click="handlerEvent('edit', record)"
                v-permission="['oms:marketing:gift:edit']">取消</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
  <!-- 修改状态 -->
  <oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
  <print-modal ref="printModalRef"></print-modal>
  <!-- <gift-modal ref="giftModalRef" @reload="emits('reload')"></gift-modal> -->
  <!-- <audit ref="auditRef" @reload="emits('reload')"></audit> -->
</template>
<script lang="ts" setup name="gift-list">
import { GiftListType } from '@/types/marketing/gift'
import OmsTable from '@/components/oms-table/index.vue';
import PrintModal from './print-modal.vue'
import { reactive } from 'vue'
// import Audit from './audit.vue'
import OmsWarning from '@/components/oms-warning/index.vue'
import OmsTag from '@/components/oms-tag/index.vue'
import { TableRowSelection } from '@arco-design/web-vue'
import { sendNoticeWms } from '@/api/purchase/notice'
import {
  cancellation,
  productActivitySubmit
} from '@/api/marketing/gift'
import { Message } from '@arco-design/web-vue'
import { ref } from 'vue'
const giftModalRef = ref()
const switchRef = ref()
const auditRef = ref()
const params = ref()
const paramsType = ref()
const emits = defineEmits<{
  (e: "reload", data?: any): void
  (e: "show-record", data: GiftListType): void
}>()
const audittTagType = {
  'WAIT_AUDIT': 'progress',
  'AUDIT_PASS': 'normal',
  'NO_PASS': 'warring',
  'STASH': 'normal',
  'CANCELLATION': 'efficacy',
}
enum AuditStatus {
  "AUDIT_PASS" = '通过',
  "NO_PASS" = '不通过',
  "WAIT_AUDIT" = '待审核',
  "STASH" = '暂存',
  "CANCELLATION" = '已作废',
}
interface PropsType {
  loading: boolean
  total: number
  pageNum: number
  pageSize: number
  dataList: Array<GiftListType>
}
const rowSelection = reactive<TableRowSelection>({
  type: 'checkbox',
  showCheckedAll: true
})
const props = defineProps<PropsType>();
const getAdjustRecord = (data: GiftListType) => {
  emits('show-record', data)
}
const onReload = (data: any) => {
  emits('reload', data)
}
const getActivityTime = (record: GiftListType) => {
  if (['week', 'month'].includes(record.activityTimeDimensionality)) {
    return record?.numberNames ?? [].join(',')
  } else {
    return `${record.presentScheduleTimeAndDayBO?.startTime}-${record.presentScheduleTimeAndDayBO?.endTime}`
  }
}
const handlerEvent = (type: string, record?: GiftListType) => {
  paramsType.value = type
  switch (type) {
    case 'sub':
      params.value = record?.id
      return switchRef.value.open({ title: "提示", content: `此操作将提交选中数据审核, 是否继续？<div style='color:#999999'>提交后不可修改数据</div>` })
    case 'add': return giftModalRef.value.initMethod(0)
    case 'pushWms':
      params.value = record?.id
      return switchRef.value.open({ title: "提示", content: `确定推送采购通知到wms？<div style='color:#999999'>通知wms后仓库将按入库计划执行</div>` })
    case 'pushKind':
      return switchRef.value.open({ title: "提示", content: `确定要把NPNO392002的采购通知单推送到推送金蝶？<div style='color:#999999'>推送到金蝶后，金蝶会生成采购入库单并调整库存。</div>` })
    case 'edit': return giftModalRef.value.initMethod(record?.id)
    case 'copy': return giftModalRef.value.initMethod(record?.id, type)
    default:
      break;
  }
}
const beforeChange = async () => {
  switch (paramsType.value) {
    case 'sub': return handerSub()
    case 'pushWms': return handerPushWms()
    default:
      break;
  }
}
// 提交
const handerSub = async () => {
  try {
    const { code, message, value } = await productActivitySubmit(params.value)
    if (code != 0) {
      throw new Error(message);
    }
    Message.success('操作成功')
    emits('reload')
  } catch (error) {
    Message.error((error as Error).message)
  }

}
// 推送wms
const handerPushWms = async () => {
  try {
    const { code, message, value } = await sendNoticeWms(params.value)
    if (code != 0) {
      throw new Error(message);
    }
    Message.success('操作成功')
    emits('reload')
  } catch (error) {
    Message.error((error as Error).message)
  }
}
</script>