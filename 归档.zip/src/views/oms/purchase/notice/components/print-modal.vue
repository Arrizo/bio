<template>
  <a-modal v-model:visible="showModal" :width="900" title-align="start" :mask-closable="false" title="打印" class="print-main">
    <div id="print-box">
      <div class="title">深圳市金文网络科技有限公司</div>
      <div class="subTitle">送货单</div>
      <div class="info">
        <article class="info-mian">
          <div class="info-mian-item">
            <section class="label">日期：</section>
            <section class="value"> 12312</section>
          </div>
          <div class="info-mian-item">
            <section class="label">收货联系人：</section>
            <section class="value">
              <section>李四 15022988821</section>
              <section>李四 15022988821</section>
            </section>
          </div>
        </article>
        <article class="info-mian">
          <div class="info-mian-item">
            <section class="label">收货联系人：</section>
            <span class="value">NPNO2920181212</span>
          </div>
          <div class="info-mian-item">
            <section class="label">收货联系人：</section>
            <section class="value">深圳市宝安区福水桥头村惠德美工业园D栋1-4《金文科技2C》</section>
          </div>
        </article>
      </div>

      <table border="1">
        <tr>
          <td colspan='3'>
            <span>日期：</span>
            <span>2023/2/16</span>
          </td>
          <td colspan='3'>$100</td>
        </tr>
        <tr>
          <td>商品/物料编码</td>
          <td>品名</td>
          <td>型号/规格</td>
          <td>条形码（69）</td>
          <td>箱数</td>
          <td>发货数量</td>
        </tr>
        <tr v-for="(item,index) in 10" :key="`${index}-print`">
          <td>商品/物料编码</td>
          <td>品名</td>
          <td>型号/规格</td>
          <td>条形码（69）</td>
          <td>箱数</td>
          <td>发货数量</td>
        </tr>
        <tr>
          <td colspan='6' class="footer">
            <section>注意事项：</section>
            <section>1、送货时请务必携带3份此送货单，否则会拒收</section>
            <section>2、原则上，仓库星期天不收货，请送货前预约收货人，沟通好送货时间</section>
          </td>
        </tr>
      </table>
      <div class="info">
        <article class="info-mian chapter">
          <div>送货方：</div>
          <div>送货方签章：</div>
          <div>采购员：</div>
        </article>
        <article class="info-mian chapter">
          <div>仓库收货人：</div>
          <div>收货人日期：</div>
        </article>
      </div>
    </div>
    <template #footer>
      <a-button @click="showModal=false">取消</a-button>
      <a-button type="primary" :loading="loading" v-print="printRef"> 打印</a-button>
    </template>
  </a-modal>

</template>
<script lang="ts" setup name="serial-modal">
  import {
    SerialNumberType,
    NoticeSearchType
  } from '@/types/purchase/notice'
  import omsMultipleSelect from '@/components/oms-multiple-select/index.vue'
  import commonData from '@/views/oms/marketing/commonData/initData'
  import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
  import {
    querySerialNumber
  } from '@/api/purchase/notice'

  import {
    reactive,
    ref,
    onMounted
  } from 'vue'
  import {
    Message
  } from '@arco-design/web-vue'
  const {
    formReset,
    formRef,
    loading,
    showModal
  } = commonData()
  let form = reactive < SerialNumberType > (new SerialNumberType())
  const dataList = ref < Array < NoticeSearchType >> ([])
  const orderId = ref()
  const total = ref(0)
  const printRef = ref({
    id: 'print-box'
  })
  const handlerEvent = () => {}
  const handleSearch = async () => {
    try {
      form.purchaseNoticeOrderId = orderId.value
      loading.value = true
      const {
        code,
        value,
        message
      } = await querySerialNumber(form)
      if (code != 0) {
        throw new Error(message)
      }
      dataList.value = value.result
      form.pageNum = value.pageNum
      form.pageSize = value.pageSize
      total.value = value.totalCount
    } catch (error) {
      Message.error((error as Error).message)
    } finally {
      loading.value = false
    }
  }
  const handleReset = () => {
    formReset()
    handleSearch()
  }
  const print = () => {

  }
  const initData = (id: string) => {
    orderId.value = id
    showModal.value = true
    // handleReset()
  }
  defineExpose({
    initData
  })
</script>
<style lang="less">
.print-main{
   .arco-modal-body{
  height: 600px;
   }
   .arco-modal-footer{
     padding-top: 20px;
   }
}
</style>
<style lang="less" scoped>
  #print-box {
    font-family: SimSun;

    table {
      border-collapse: collapse;
      width: 100%;
      font-size: 12px;

      td {
        text-align: center;
        padding: 4px 0px;
      }
    }

    .info {
      display: flex;
      font-size: 12px;

      .info-mian {
        flex: 1;

        .info-mian-item {
          display: flex;

          margin-bottom: 10px;

          .label {
            font-weight: bold;
            width: 140px;
            text-align: right;
          }

          .value {
            width: 100%;
            word-break: break-all;
          }
        }
      }
    }


    .title {
      font-size: 24px;
      text-align: center;
    }

    .subTitle {
      font-size: 18px;
      text-align: center;
    }
  }

  .footer {
    padding: 4px 10px !important;
    font-weight: bold;

    section {
      line-height: 26px;
      text-align: left;
    }
  }

  .chapter {
    padding: 20px 0px 0px 100px;

    div {
      line-height: 100px;
      font-weight: bold;
    }
  }
</style>