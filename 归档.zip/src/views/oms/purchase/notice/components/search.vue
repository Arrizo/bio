<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-14 15:17:23
 * @LastEditors: chenzechao
 * @LastEditTime: 2023-03-30 22:24:45
 * @FilePath: /oms-admin/src/views/oms/purchase/notice/components/search.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-form :model="form" layout="inline" ref="formRef" :label-col-style="{width:'104px'}">
    <a-form-item field="codeType" hide-label :wrapper-col-style="{width:'313px'}">
      <a-input-group>
        <a-select v-model="form.codeType" :style="{ width: '104px' }">
          <a-option value="notice">通知单号</a-option>
          <a-option value="purchase">采购单号</a-option>
          <a-option value="wms">wms单号</a-option>
        </a-select>
        <a-input v-model.trim="form.code" placeholder="多个用英文逗号隔开" allow-clear :max-length="100"
          @keyup.enter="handleSearch" v-limit-input :style="{ width: '208px' }"></a-input>
      </a-input-group>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择状态" v-model="form.status" :style="{ width: '210px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="NOT_NOTIFIED">未通知</a-option>
        <a-option value="NOTIFIED">已通知</a-option>
        <a-option value="NOTIFICATION_FAILED">通知失败</a-option>
        <a-option value="CANCELLATION">已取消</a-option>
        <a-option value="COMPLETED">已完结</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="inStatus" label="入库状态：">
      <a-select placeholder="请选择状态" v-model="form.inStatus" :style="{ width: '210px' }" allow-clear>
        <a-option value="all">全部入库</a-option>
        <a-option value="NOT_NOTIFIED">未通知</a-option>
        <a-option value="NOTIFIED">已通知</a-option>
        <a-option value="NOTIFICATION_FAILED">通知失败</a-option>
        <a-option value="PART">部分入库</a-option>
        <a-option value="NOT">未入库</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="virtualWarehouseId" label="入库仓库：">
      <oms-multiple-select v-model="form.virtualWarehouseIdList" :maxTagCount="1" value="id" label="virtualWarehouseName"
        :option-list="virtualList"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="batchNo" label="批次号：">
      <a-input v-model.trim="form.batchNo" placeholder="请输入批次号" allow-clear :max-length="20" :style="{ width: '210px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="purchaser" label="采购员：">
      <a-input v-model.trim="form.purchaser" placeholder="请输入采购员" allow-clear :max-length="20" :style="{ width: '210px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="dateType" hide-label :label-col-style="{width:'146px'}" :wrapper-col-style="{width:'500px'}">
      <a-input-group>
        <a-select v-model="form.dateType" :style="{ width: '146px' }">
          <a-option value="lastInTime">最后入库日期</a-option>
          <a-option value="updateTime">更新时间</a-option>
          <a-option value="createTime">通知单生成时间</a-option>
        </a-select>
        <a-range-picker showTime v-model="form.time" @change="onChange" :style="{ width: '350px' }" />
      </a-input-group>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset">
      <a-button>导出</a-button>
    </oms-search-btn>
  </a-form>
</template>
<script lang="ts" setup name="gift-search">

import {
  NoticeSearchType
} from '@/types/purchase/notice'
import omsMultipleSelect from '@/components/oms-multiple-select/index.vue'
import commonData from '@/views/oms/marketing/commonData/initData'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { deepClone } from '@/utils/helper';
import { getActiveVirtual } from '@/api/purchase/notice'
import { reactive, ref, onMounted } from 'vue'
import { Message } from '@arco-design/web-vue'
/**
 * virtualList 虚拟仓库列表
 */
const props = defineProps<{ loading: boolean }>();
const virtualList = ref()
const emits = defineEmits<{
  (e: "on-search", data: NoticeSearchType): void;
}>();
const { formReset, formRef } = commonData()

let form = reactive<NoticeSearchType>(new NoticeSearchType())
const handleReset = () => {
  formReset()
  form.startTime = ''
  form.endTime = ''
  form.virtualWarehouseIdList = []
  handleSearch()
}
const onChange = (value: any) => {
  form.startTime = value?.[0] ?? ''
  form.endTime = value?.[1] ?? ''
}
const handleSearch = () => {
  const newForam = deepClone(form)
  if (form.inStatus === 'all') { newForam.inStatus = '' }
  if (form.status === 'all') { newForam.status = '' }
  emits('on-search', newForam)
}
const activeVirtual = async () => {
  try {
    const { code, value, message } = await getActiveVirtual()
    if (code != 0) {
      throw new Error(message)
    }
    virtualList.value = value
  } catch (error) {
    Message.error((error as Error).message)
  }
}

onMounted(async () => {
  activeVirtual()
  handleSearch()
})
</script>