<template>
  <a-form :model="form" ref="formRef" auto-label-width layout="inline">
    <a-form-item field="code" label="编码：">
      <a-input v-model.trim="form.code" placeholder="请输入编码" allow-clear @keyup.enter="handleSearch"
        v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="skuName" label="名称：">
      <a-input v-model.trim="form.skuName" placeholder="请输入名称" allow-clear @keyup.enter="handleSearch"
        v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="skuName" label="批次号：">
      <a-input v-model.trim="form.skuName" placeholder="请输入批次号" allow-clear @keyup.enter="handleSearch"
        v-limit-input></a-input>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
  <a-table :data="dataList" :pagination="false" hide-expand-button-on-empty :scroll="{ x: 300, y: 550 }" stripe
    :bordered="{ wrapper: false }">
    <template #columns>
      <a-table-column title="序号" :tooltip="true" :width="60" ellipsis fixed="left">
        <template #cell="{ record, rowIndex }">
          {{ rowIndex + 1 }}
        </template>
      </a-table-column>
      <a-table-column title="商品编码" :tooltip="true" :width="100" ellipsis>
        <template #cell="{ record, }">
          {{ record.spuCode || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="规格编码" :tooltip="true" :width="180" ellipsis>
        <template #cell="{ record }">
          {{ record.skuCode || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="规格名称" :tooltip="true" :width="180" ellipsis>
        <template #cell="{ record }">
          {{ record.skuName || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="规格型号" :tooltip="true" :width="100" ellipsis>
        <template #cell="{ record }">
          {{ record.skuModel || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="批次号" :tooltip="true" :width="100" ellipsis>
        <template #cell="{ record }">
          {{ record.quantity || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="生产日期" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.noticeNum || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="过期日期" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.inNum || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="采购入库时间" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.inSubstandardNum || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="库存类型" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.inSubstandardNum || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="入库数量" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.inSubstandardNum || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="单位" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.inSubstandardNum || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="唯一码" :width="100" fixed="right">
        <template #cell="{ record }">
        </template>
      </a-table-column>
    </template>
  </a-table>
</template>
<script lang="ts" setup name="goods-details">
import {
  ProductDetailType,
  NoticeSearchType
} from '@/types/purchase/notice'
import omsMultipleSelect from '@/components/oms-multiple-select/index.vue'
import commonData from '@/views/oms/marketing/commonData/initData'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { queryStockDetail } from '@/api/purchase/notice'

import { reactive, ref, onMounted } from 'vue'
import { Message } from '@arco-design/web-vue'
const { formReset, formRef, loading } = commonData()
let form = reactive<ProductDetailType>(new ProductDetailType())
const dataList = ref<Array<NoticeSearchType>>([])
const orderId = ref()
const handlerEvent = () => { }
const handleSearch = async () => {
  try {
    form.purchaseOrderId = orderId.value
    loading.value = true
    const { code, value, message } = await queryStockDetail(form)
    if (code != 0) {
      throw new Error(message)
    }
    dataList.value = value.result
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
const handleReset = () => {
  formReset()
  handleSearch()
}
const initData = (id: string) => {
  orderId.value = id
  handleReset()
}
defineExpose({
  initData
})
</script>