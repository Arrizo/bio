<template>
  <a-modal v-model:visible="showModal" :width="725  " title-align="start"  :mask-closable="false"
    title="选择商品" class="goods-modal">
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form :model="form" layout="inline" ref="searchRef">
      <a-form-item field="skuCode" label="规格编码：">
        <a-input v-model.trim="form.skuCode" placeholder="spu/sku编码" allow-clear :max-length="20"
          :style="{ width: '200px' }" @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="keyup" label="入库批次号：">
        <a-input v-model.trim="form.batchNo" placeholder="spu/sku名称" allow-clear :max-length="20"
          :style="{ width: '200px' }" @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
    </a-form>
    <!-- </template> -->
    <oms-table :loading="loading" :total="total" :current="form.pageNum" :size="form.pageSize" :simple-pagination="true">
      <a-table :data="dataList" :pagination="false" hide-expand-button-on-empty class="gift-table" :scroll="{ y: 400 }"
        stripe :bordered="{ wrapper: false }">
        <template #columns>
          <a-table-column title="序号" :tooltip="true" :width="60" ellipsis fixed="left">
            <template #cell="{ record, rowIndex }">
              {{ rowIndex + 1 }}
            </template>
          </a-table-column>
          <a-table-column title="唯一码" :tooltip="true" :width="180" ellipsis>
            <template #cell="{ record }">
              {{ record.skuCode || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
    <!-- </oms-panel> -->
  </a-modal>
</template>
<script lang="ts" setup name="serial-modal">
import {
  SerialNumberType,
  NoticeSearchType
} from '@/types/purchase/notice'
import omsMultipleSelect from '@/components/oms-multiple-select/index.vue'
import commonData from '@/views/oms/marketing/commonData/initData'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { querySerialNumber } from '@/api/purchase/notice'

import { reactive, ref, onMounted } from 'vue'
import { Message } from '@arco-design/web-vue'
const { formReset, formRef, loading, showModal } = commonData()
let form = reactive<SerialNumberType>(new SerialNumberType())
const dataList = ref<Array<NoticeSearchType>>([])
const orderId = ref()
const total = ref(0)
const handlerEvent = () => { }
const handleSearch = async () => {
  try {
    form.purchaseNoticeOrderId = orderId.value
    loading.value = true
    const { code, value, message } = await querySerialNumber(form)
    if (code != 0) {
      throw new Error(message)
    }
    dataList.value = value.result
    form.pageNum = value.pageNum
    form.pageSize = value.pageSize
    total.value = value.totalCount
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
const handleReset = () => {
  formReset()
  handleSearch()
}
const initData = (id: string) => {
  orderId.value = id
  handleReset()
}
defineExpose({
  initData
})
</script>