<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-09 17:46:55
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-13 13:48:35
 * @FilePath: \oms\src\views\oms\basicdata\shop\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<!-- 基础资料->店铺管理 -->
<template>
  <div class="panel-height">
    <oms-panel :class="{ 'panel-height': !showTabs }">
      <template #header>
        <search :loading="loading" @on-search="initData"></search>
      </template>
      <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
        @reload="initData" @show-config='showRowDetails'>
      </list>
    </oms-panel>
    <div class="shop-config" v-show="showTabs">
      <a-tabs default-active-key="1">
        <template #extra>
          <icon-close @click="showTabs = false" />
        </template>
        <a-tab-pane key="1" title="店铺配置">
          <store-config ref="storeConfigRef"></store-config>
        </a-tab-pane>
        <a-tab-pane key="2" title="策略配置">
          <policy-config ref="policyConfigRef"></policy-config>
        </a-tab-pane>
        <a-tab-pane key="3" title="操作日志">
          <oms-log ref="operationLogRef"></oms-log>
        </a-tab-pane>
      </a-tabs>
    </div>
  </div>
</template>

<script setup lang="ts" name="basicdata-shop">
import OmsPanel from '@/components/oms-panel/index.vue';
import storeConfig from './components/store-config.vue'
import PolicyConfig from './components/policy-config.vue'
import { StoreSearchForm, StoreSearchFormListItem } from '@/types/basicdata/shop';
import Search from './components/search.vue'
import List from './components/list.vue'
import { getStoreList } from '@/api/basicdata/shop';
import { Message } from '@arco-design/web-vue';
import omsLog from '@/components/oms-log/index.vue'
import { ref, reactive, onMounted } from 'vue'
const loading = ref<boolean>(false)
const showTabs = ref<boolean>(false)
const operationLogRef = ref()
const storeConfigRef = ref()
const policyConfigRef = ref()
const total = ref<number>(0)
const list = ref<StoreSearchFormListItem[]>([]);
let form = reactive<StoreSearchForm>(new StoreSearchForm())
const initData = async (data: StoreSearchForm) => {
  try {
    form = Object.assign(form, data)
    loading.value = true
    const { code, message, value } = await getStoreList(form)
    if (code != 0) {
      return Message.error(message);
    }
    list.value = value.result
    total.value = value.totalCount
    form.pageNum = value.pageNum
    form.pageSize = value.pageSize
    showTabs.value = false
  } finally {
    loading.value = false
  }
}
const showRowDetails = (data: StoreSearchFormListItem) => {
  operationLogRef.value.init(data.storeCode, '店铺管理', 'page')
  storeConfigRef.value.getStoreConfig(data.id)
  policyConfigRef.value.initData(data)
  showTabs.value = true
}
</script>
<style lang="less" scoped>
.panel-height {
  height: 100%;
}

.shop-config {
  background-color: #fff;

  :deep(.arco-tabs-nav) {
    padding: 10px 16px 0px 10px;
  }

  :deep(.arco-tabs-content) {
    padding-left: 16px;
    padding-right: 16px;
  }

  :deep(.arco-tabs-nav-extra) {
    border: 1px solid rgba(112, 112, 112, 0.3);
    border-radius: 50%;
    color: #707070;
    font-size: 11px;
    padding: 2px;
    cursor: pointer;
  }
}
</style>