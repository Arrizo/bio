<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-20 18:28:36
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-23 16:24:44
 * @FilePath: \oms-admin\src\views\oms\basicdata\shop\components\policy-config.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-button type="primary" @click="handlerEvent('add')" style="margin-bottom: 10px;"
    v-permission="['shop:policy:add']">新增策略</a-button>
  <a-table :data="policyTableData" :pagination="false" hide-expand-button-on-empty :scroll="{ y: 450, x: 1400 }" stripe
    :bordered="{ wrapper: false }" >
    <template #columns>
      <a-table-column title="策略类型" ellipsis tooltip :width="80">
        <template #cell="{ record }">
          {{ record.typeName || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="策略名称" ellipsis tooltip :width="80">
        <template #cell="{ record }">
          {{ record.title || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="状态" ellipsis tooltip :width="80">
        <template #cell="{ record }">
          {{ record.status ? '已启用' : '已禁用' }}
        </template>
      </a-table-column>
      <a-table-column title="创建时间" ellipsis tooltip :width="80">
        <template #cell="{ record }">
          {{ record.createTime || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="修改时间" ellipsis tooltip :width="80">
        <template #cell="{ record }">
          {{ record.updateTime || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="操作" ellipsis tooltip :width="30" fixed="right">
        <template #cell="{ record }">
          <a-space :size="12">
            <a-link type="text" @click="handlerEvent('edit', record)" v-permission="['shop:policy:edit']">修改</a-link>
            <a-link type="text" status="danger"  @click="handlerEvent('delete', record)" v-permission="['shop:policy:delete']">删除</a-link>
          </a-space>
        </template>
      </a-table-column>
    </template>
  </a-table>
  <oms-warning ref="omsWarningRef" :on-before-ok="beforeDel"></oms-warning>
  <policy-modal ref="policyModalRef" @reload="initData"></policy-modal>
</template>
<script lang="ts" setup name='policy-config'>
import { reactive, ref } from 'vue'
import omsWarning from '@/components/oms-warning/index.vue'
import { PolicyConfigType, StoreSearchFormListItem, DelPolicyConfigType } from '@/types/basicdata/shop'
import { findStoreRelevance, deleteCategory } from '@/api/basicdata/shop'
import policyModal from './policy-modal.vue'
import { Message } from '@arco-design/web-vue';
const policyTableData = ref<Array<PolicyConfigType>>([])
const omsWarningRef = ref()
const policyModalRef = ref()
const delform = reactive<DelPolicyConfigType>(new DelPolicyConfigType())
const initData = async (data?: StoreSearchFormListItem) => {
  if (data) {
    delform.storeCode = data?.storeCode
    delform.storeId = data?.id
  }
  try {
    const { code, message, value } = await findStoreRelevance(delform?.storeCode ?? '')
    if (code != 0) {
      throw new Error(message)
    }
    policyTableData.value = value
  } catch (error) {
    Message.error((error as Error).message)
  }
}
const handlerEvent = (type: string, record?: PolicyConfigType) => {
  switch (type) {
    case 'delete':
      delform.strategyId = record?.strategyId
      return omsWarningRef.value.open()
    default:
      let params = {
        originalStrategyId: type == 'edit' ? record?.strategyId ?? '' : '',
        storeId: delform.storeId,
        storeCode: delform.storeCode,
        strategyId: record?.strategyId ?? '',
        strategyType: record?.type ?? '',
      }
      return policyModalRef.value.showModal(params)
  }
}
const beforeDel = async () => {
  try {
    const { code, message } = await deleteCategory(delform)
    if (code != 0) {
      throw new Error(message)
    }
    Message.success('删除成功！')
    initData()
    return true
  } catch (error) {
    Message.error((error as Error).message)
    return false
  }
}
defineExpose({
  initData
})
</script>