<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-09 17:46:55
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-13 17:51:25
 * @FilePath: \oms-admin\src\views\oms\basicdata\shop\components\list.vue
-->
<template>
	<oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onShopReload">
		<template #header-left></template>
		<a-table :data="shopList" :pagination="false" hide-expand-button-on-empty :scroll="{ y: 650, x: 1400 }" stripe
			v-db-click="shopList" :db-call-back="dbEvent" :bordered="{ wrapper: false }">
			<template #columns>
				<a-table-column title="店铺编码" fixed="left" :min-width="100" ellipsis tooltip>
					<template #cell="{ record }">
						{{ record.storeCode || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="店铺名称" :min-width="100"  ellipsis tooltip>
					<template #cell="{ record }">
						{{ record.storeName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="店铺类型" ellipsis tooltip :min-width="100">
					<template #cell="{ record }">
						{{ storeTypeStata?.find(item => item.dictionaryValue === record.storeType)?.dictionaryTitle || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="所属公司" ellipsis tooltip :min-width="100">
					<template #cell="{ record }">
						{{ record.companyName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="负责人" ellipsis tooltip :min-width="100">
					<template #cell="{ record }">
						{{ record.owner || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="所属客户" ellipsis tooltip :min-width="100">
					<template #cell="{ record }">
						<a-link v-sensitive="['oms_basicdata_shop', 'customer']">***********</a-link>
						<span v-sensitive-else="['oms_basicdata_shop', 'customer']">***********</span>
					</template>
				</a-table-column>
				<a-table-column title="状态" :width="120" ellipsis tooltip>
					<template #cell="{ record }">
						<a-switch v-model="record.status" @focus="onSwitchForce(record)" v-permission="['shop:role:status']">
							<template #checked>
								启用
							</template>
							<template #unchecked>
								禁用
							</template>
						</a-switch>
					</template>
				</a-table-column>
				<a-table-column title="创建时间" :width="180" ellipsis tooltip>
					<template #cell="{ record }">
						{{ record.createTime || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="修改时间" :width="180" ellipsis tooltip>
					<template #cell="{ record }">
						{{ record.updateTime || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="操作" fixed="right" :width="70" ellipsis>
					<template #cell="{ record }">
						<a-link type="text" v-permission="['shop:role:edit']" @click="edit(record)">编辑</a-link>
					</template>
				</a-table-column>
			</template>
		</a-table>
	</oms-table>
	<oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
	<store-details ref="storeDetailsRefs" :storeTypeStata="storeTypeStata" @reloadTable="onShopReload"></store-details>
</template>
<script setup lang="ts" name="shop-list">
import OmsTable from '@/components/oms-table/index.vue';
import StoreDetails from './store-details.vue'
import OmsWarning from '@/components/oms-warning/index.vue';
import { updateStoreStatus } from '@/api/basicdata/shop';
import { StoreSearchFormListItem, initDataType, StoreSearchForm } from '@/types/basicdata/shop';
import { onMounted, ref, computed } from 'vue';
import { Message } from '@arco-design/web-vue';
import { getDictionaryList } from '@/hooks/useDictionary';
const props = defineProps({
	list: { type: Array, default: () => [] },
	loading: { type: Boolean, default: false },
	total: { type: Number, default: 0 },
	pageNum: { type: Number, default: 1 },
	pageSize: { type: Number, default: 10 },
});
const emits = defineEmits<{
	(e: "reload", data: StoreSearchForm): void,
	(e: 'show-config', data: StoreSearchFormListItem): void
}>();
// 修改转态二次弹窗变量
const switchRef = ref();
const statusId = ref()
const storeDetailsRefs = ref()
const storeTypeStata = ref<Array<initDataType>>()
const edit = (item: StoreSearchFormListItem) => {
	storeDetailsRefs.value.handleShowModal(item.id)
}
const dbEvent = (data: StoreSearchFormListItem) => {
	emits('show-config', data)
}
const beforeChange = async () => {
	try {
		const res = await updateStoreStatus(statusId.value)
		if (res.code != 0) {
			throw new Error(res.message);
		}
		Message.success('更新成功')
		onShopReload({})
	} catch (err) {
		Message.error((err as Error).message);
	}
}
// 开关获取焦点触发二次确认
const onSwitchForce = async (record: StoreSearchFormListItem) => {
	statusId.value = record?.id + ''
	switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}
const onShopReload = (data: StoreSearchForm | any) => {
	emits('reload', data)
}
const getStoreTypeList = async () => {
	try {
		const res = await getDictionaryList('STORE_TYPE')
		storeTypeStata.value = res as Array<initDataType>
	} catch (error) {
		console.error(error)
	}

}
// 返回列表
const shopList = computed(() => {
	return props.list as Array<StoreSearchFormListItem>
})
onMounted(() => {
	getStoreTypeList()
})
</script>