<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-13 10:25:37
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-23 16:25:31
 * @FilePath: \oms-admin\src\views\oms\basicdata\shop\components\policy-modal.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal :mask-closable="false" :title="titleName" width="500px" v-model:visible="visible" titleAlign="start"
    :on-before-ok="onBeforeOk" :ok-loading="loading">
    <a-form :rules="rulesForm" :model="form" ref="formRef">
      <a-form-item field="strategyType" label="策略类型：">
        <a-select v-model="form.strategyType" placeholder="请选择" :disabled="!!form.originalStrategyId" allow-search @change="changeStrate">
          <a-option v-for="(item, index) in strategyList" :key="`${index}-strateg`" :value="item.dictionaryValue">{{
            item.dictionaryTitle }}</a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="strategyId" label="策略名称：">
        <a-select v-model="form.strategyId" placeholder="请选择" allow-search>
          <a-option v-for="(item, index) in storeStrategySelectList" :key="`${index}-type`" :value="item.strategyId">{{
            item.title }}</a-option>
        </a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>
<script lang="ts" setup name="policy-modal">
import { reactive, ref, computed, watch } from 'vue'
import { AddPolicyConfigType, PolicyConfigType } from '@/types/basicdata/shop'
import { Message } from '@arco-design/web-vue';
import { storeStrategySelect, addStoreRelevance, updateStoreRelevance } from '@/api/basicdata/shop'
import { getDictionaryList } from '@/hooks/useDictionary';
const emits = defineEmits<{
  (e: "reload"): void;
}>();
const visible = ref<boolean>(false)
const formRef = ref()
const loading = ref(false)
const strategyList = ref()
const storeStrategySelectList = ref()
const form = reactive<AddPolicyConfigType>(new AddPolicyConfigType())
const showModal = async (data: any) => {
  await getCompanyTypeList()
  Object.assign(form, data)
  if (form.strategyType) {
    await getStoreStrategySelect()
  }
  visible.value = true
  //编辑回显
}
const rulesForm = reactive({
  strategyType: [{
    required: true, message: '请选择策略类型'
  }],
  strategyId: [{
    required: true, message: '请选择策略名称'
  }]
})
const onBeforeOk = async () => {
  const valid = await formRef.value.validate()
  if (valid) { return false }
  try {
    loading.value = true
    let res = null
    if (form.originalStrategyId) {
      res = await updateStoreRelevance(form)
    } else {
      res = await addStoreRelevance(form)
    }
    const { code, message } = res
    if (code != 0) {
      throw new Error(message)
    }
    Message.success('操作成功！')
    emits('reload')
    return true
  } catch (error) {
    Message.error((error as Error).message)
    return false
  } finally {
    loading.value = false
  }


}
const getStoreStrategySelect = async () => {
  try {
    const { code, message, value } = await storeStrategySelect({ storeId: form?.storeId, strategyType: form.strategyType })
    if (code != 0) {
      throw new Error(message)
    }
    storeStrategySelectList.value = value
  } catch (error) {
    Message.error((error as Error).message)
  }


}
const getCompanyTypeList = async () => {
  try {
    const res = await getDictionaryList('STORE_STRATEGY')
    strategyList.value = res
  } catch (error) {
    console.error(error)
  }
}
const changeStrate = () => {
  form.strategyId = ''
  getStoreStrategySelect()
}
watch(() => visible.value, (nV) => {
  if (nV) {

  } else {
    formRef.value.resetFields()
    formRef.value.clearValidate()
  }
})
const titleName = computed(() => form.originalStrategyId ? '编辑策略' : '新增策略')
defineExpose({
  showModal
})
</script>