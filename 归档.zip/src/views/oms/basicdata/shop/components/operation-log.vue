<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-09 20:26:48
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-02-14 19:48:15
 * @FilePath: \oms\src\views\oms\basicdata\shop\components\operation-log.vue
-->
<template>
  <a-table :columns="stata.columns" :scroll="{ y: 300 }" stripe :data="stata.columnsData" :pagination="false"
    sticky-header></a-table>
</template>
<script lang="ts" setup name="store-operation-log">
import { reactive } from 'vue'
import { quaryRangeLog } from '@/api/basicdata/shop'
import { Message } from '@arco-design/web-vue'
import { OperationLogType } from '@/types/basicdata/shop'
import { TableColumnData } from '@arco-design/web-vue'
const stata = reactive<{
  columns: Array<TableColumnData>,
  columnsData: Array<OperationLogType>
}>({
  columnsData: [],
  columns: [
    { title: '操作人', dataIndex: 'operater', width: 200 },
    { title: '操作时间', dataIndex: 'operationTime', width: 200 },
    { title: '操作', dataIndex: 'logType', width: 200 },
    { title: '操作内容', dataIndex: 'msg' }
  ],
})
const getQuaryRangeLog = async (data: any) => {
  try {
    const res = await quaryRangeLog(data.storeCode, '店铺管理')
    if (res.code != 0) {
      throw new Error(res.message)
    }
    stata.columnsData = res.value
  } catch (error) {
    Message.error((error as Error).message)
  }

}
defineExpose({
  getQuaryRangeLog
})
</script>