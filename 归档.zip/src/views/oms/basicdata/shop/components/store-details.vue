<template>
  <a-modal :mask-closable="false" title="编辑" width="800px" v-model:visible="state.show" titleAlign="start" :on-before-ok="onBeforeOk">
    <a-form :model="state.form" auto-label-width ref="formRef" :rules="formRules">
      <section class="shop-title">基本信息</section>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="店铺编码：" field="storeCode">
            <a-input v-model="state.form.storeCode" placeholder="请输入" disabled></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="店铺名称：" field="storeName">
            <a-input v-model="state.form.storeName" disabled placeholder="请输入店铺名称"></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="店铺类型：" field="storeType">
            <a-select v-model="state.form.storeType" disabled placeholder="请选择店铺类型" allow-clear>
              <a-option v-for="(item, index) in storeTypeStata" :key="`${index}-storeType`"
                :value="item.dictionaryValue">{{ item.dictionaryTitle }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="所属公司：" field="companyName">
            <a-select placeholder="请选择" v-model="state.form.companyName" disabled allow-clear>
              <a-option v-for="(item, index) in state.afficoupanyList" :key="`${index}-companyName`"
                :value="item.dictionaryTitle">{{ item.dictionaryTitle }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="负责人：" field="owner">
            <a-select placeholder="请选择" v-model="state.form.owner" allow-search>
              <a-option v-for="(item, index) in state.lstUserList" :key="`${index}-owner`" :value="item.nickname">{{
                item.nickname
              }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="所属客户：" field="customer">
            <a-input v-model.trim="state.form.customer" :max-length="200" v-limit-input allow-clear placeholder="请输入属客户"></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <section class="shop-title">店铺配置</section>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="默认发货仓库：" field="warehouseId">
            <a-select v-model="state.form.warehouseId" placeholder="请选择" allow-search >
              <a-option :value="item.id" v-for="(item, index) in state.lstWarehouseList"
                :key="`${index}-delivererWarehouseId`">{{ item.virtualWarehouseName }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="默认发货人：" field="deliverer">
            <a-input v-model.trim="state.form.deliverer" v-limit-input :max-length="80" allow-clear placeholder="请输入默认发货人"></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="默认发货电话：" field="mobile">
            <a-input v-model="state.form.mobile" allow-clear
              @input="state.form.mobile = $event?.replace(/[^\d]+/g, '')" v-limit-input placeholder="请输入发货电话"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="默认退货仓库：">
            <a-select v-model="state.form.delivererWarehouseId" placeholder="请选择" allow-search allow-clear>
              <a-option :value="item.id" v-for="(item, index) in state.lstWarehouseList"
                :key="`${index}-delivererWarehouseId`">{{ item.virtualWarehouseName }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="价格来源：" field="priceSource">
            <a-select v-model="state.form.priceSource" placeholder="请选择" allow-search >
              <a-option :value="item.dictionaryValue" v-for="(item, index) in state.priceTourceList"
                :key="`${index}-priceSource`">{{ item.dictionaryTitle }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="配货方式：" field="distributionMode">
            <a-select v-model="state.form.distributionMode" placeholder="请选择" allow-search>
              <a-option :value="item.dictionaryValue" v-for="(item, index) in state.destributionMethodList"
                :key="`${index}-distributionMode`">{{ item.dictionaryTitle }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="配货延迟时间：">
            <a-select v-model="state.form.delayTime" placeholder="请选择" allow-search allow-clear>
              <a-option :value="item.dictionaryValue" v-for="(item, index) in state.delayTimeList"
                :key="`${index}-delayTime`">{{ item.dictionaryTitle }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="重新配货延迟：">
            <a-select v-model="state.form.againDelayTime" placeholder="请选择" allow-search allow-clear>
              <a-option :value="item.dictionaryValue" v-for="(item, index) in state.delayTimeList"
                :key="`${index}-time`">{{ item.dictionaryTitle }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>
<script lang="ts" setup name="shop-store-details">
import { onMounted, reactive, ref, computed, watch } from 'vue'
import { StoreDetails, initDataType } from '@/types/basicdata/shop'
import { findStoreDetail, storeInitData, storeInfoSave } from '@/api/basicdata/shop'
import { Message } from '@arco-design/web-vue';
const emits = defineEmits<{
  (e: "reloadTable", data: {}): void,
}>();
class modalState {
  show: boolean = false
  form: StoreDetails = {}
  delayTimeList: Array<initDataType> = []
  destributionMethodList: Array<initDataType> = []
  priceTourceList: Array<initDataType> = []
  afficoupanyList: Array<initDataType> = []
  lstUserList: Array<initDataType> = []
  lstWarehouseList: Array<initDataType> = []
}
const props = defineProps({
  id: { type: Number, default: 0 },
  storeTypeStata: { type: Array, defautl: () => [] }
})
const state = reactive<modalState>(new modalState())
const formRef = ref()
const handleShowModal = async (id: number) => {
  try {
    const res = await findStoreDetail(id)
    if (res.code != 0) {
      throw new Error(res.message)
    }
    state.form = res.value
    state.form.warehouseId = state.form.warehouseId?Number(state.form.warehouseId) : state.form.warehouseId
    state.form.delivererWarehouseId = state.form.delivererWarehouseId?Number(state.form.delivererWarehouseId):state.form.delivererWarehouseId
    state.show = true
  } catch (error) {
    Message.error((error as Error).message)
  }

}
const initData = async () => {
  try {
    const res = await storeInitData()
    state.delayTimeList = res.value.DELAY_TIME
    state.destributionMethodList = res.value.DISTRIBUTION_METHOD
    state.priceTourceList = res.value.PRICE_SOURCE
    state.afficoupanyList = res.value.AFFI_COMPANY
    state.lstUserList = res.value.lstUser
    state.lstWarehouseList = res.value.lstWarehouse
    if (res.code != 0) {
      throw new Error(res.message)
    }
  } catch (error) {
    Message.error((error as Error).message)
  }

}
// 检验规则
const formRules = {
  companyName: [
    { required: true, message: '请选择公司' }
  ],
  storeType: [
    { required: true, message: '请选择店铺类型' }
  ],
  storeCode: [
    { required: true, message: '请输入店铺编码' }
  ],
  storeName: [
    { required: true, message: '请输入店铺名称' }
  ],
  customer: [
    { required: true, message: '请输入所属客户' }
  ],
  owner: [
    { required: true, message: '请选择负责人' }
  ],
  deliverer: [
    { required: true, message: '请选择发货人' }
  ],
  distributionMode: [
    { required: true, message: '请选择配货方式' }
  ],
  priceSource: [
    { required: true, message: '请选择价格来源' }
  ],
  mobile: [
    {
      required: true,validator: (value: any, callback: any) => {
      if (!value || value == ""){
         callback("请输入发货电话");
         return
      }
      return new Promise<void>((resolve) => {
        const mobileReg = /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;
        const phoneReg = /^\d{3}-\d{8}|\d{4}-\d{7}$/;
        if (value.length === 11) {
          if (!mobileReg.test(value)) callback("请输入正确的手机号码或者固话号码");
        } else {
          if (!phoneReg.test(value)) callback("请输入正确的手机号码或者固话号码");
        }
        resolve();
      });
    }
    }
  ],
  warehouseId: [
    { required: true, message: '请选择仓库' }
  ]
}
const storeTypeStata = computed(() => {
  return props.storeTypeStata as Array<{ dictionaryValue: string, dictionaryTitle: string }>
})
// 关闭弹窗前数据检验
const onBeforeOk = async (done: Function) => {
  const valid = await formRef.value.validate()
  if (valid) { return false }
  const res = await storeInfoSave(state.form)
  if (res.code != 0) {
    Message.error(res.message)
    return false
  }
  Message.success('操作成功！')
  emits('reloadTable', {})
  return true
}
watch(() => state.show, (nV) => {
  if (!nV) { formRef.value.clearValidate() }
})
onMounted(() => {
  initData()
})
defineExpose({
  handleShowModal
})
</script>
<style lang="less" scoped>
.shop-title {
  font-size: 13px;
  font-weight: bold;
  margin-bottom: 14px;
}
</style>