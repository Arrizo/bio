<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-09 17:46:55
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-25 14:36:40
 * @FilePath: \oms\src\views\oms\basicdata\shop\components\search.vue
-->
<template>
	<a-form :model="form" layout="inline" ref="formRes">
		<a-form-item field="storeCode" label="店铺编码：">
			<a-input v-model.trim="form.storeCode" placeholder="请输入店铺编码" allow-clear :max-length="50" :style="{ width: '200px' }"
				@keyup.enter="handleSearch" v-limit-input></a-input>
		</a-form-item>
		<a-form-item field="storeName" label="店铺名称：">
			<a-input v-model.trim="form.storeName" placeholder="请输入店铺名称" v-limit-input allow-clear :style="{ width: '200px' }"
				:max-length="200" @keyup.enter="handleSearch"></a-input>
		</a-form-item>
		<a-form-item field="companyCode" label="所属公司：">
			<a-select placeholder="请选择" v-model="form.companyCode" allow-search allow-clear>
				<a-option v-for="(item, index) in companyTypeStata" :key="`${index}-store`" :value="item.dictionaryValue">{{
					item.dictionaryTitle
				}}</a-option>
			</a-select>
		</a-form-item>
		<a-form-item field="customer" label="所属客户：">
			<a-input v-model.trim="form.customer" v-limit-input placeholder="请输入所属客户" allow-clear :style="{ width: '200px' }"
				:max-length="200" @keyup.enter="handleSearch"></a-input>
		</a-form-item>
		<a-form-item field="status" label="状态：">
			<a-select placeholder="请选择"  v-model="form.status" :style="{ width: '200px' }">
				<a-option value="all">全部</a-option>
				<a-option value="true">已启用</a-option>
				<a-option value="false">已禁用</a-option>
			</a-select>
		</a-form-item>
		<oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
	</a-form>
</template>
<script lang="ts" setup name="basicdata-shop-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { deepClone } from '@/utils/helper';
import { reactive, ref, onMounted } from 'vue';
import { StoreSearchForm } from '@/types/basicdata/shop';
import { getDictionaryList } from '@/hooks/useDictionary';
const form = reactive<StoreSearchForm>(new StoreSearchForm())
const companyTypeStata = ref()
const formRes = ref()
const props = defineProps({
	loading: { type: Boolean, default: false }
});
const emits = defineEmits<{
	(e: "on-search", data: StoreSearchForm): void;
}>();
const handleSearch = () => {
	const newForm = deepClone(form)
	if (newForm.status === 'all') {newForm.status =''}
	emits('on-search', newForm)
}
const handleReset = () => {
	formRes.value.resetFields();
	handleSearch();
}
const getCompanyTypeList = async () => {
	try {
		const res = await getDictionaryList('AFFI_COMPANY')
		companyTypeStata.value = res
	} catch (error) {
		console.error(error)
	}

}
onMounted(() => {
	getCompanyTypeList()
	handleSearch();
});
</script>