<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-09 20:22:29
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-02-15 11:18:58
 * @FilePath: \oms\src\views\oms\basicdata\shop\components\store-config.vue
-->
<template>
  <a-form :model="stata.form" layout="horizontal" auto-label-width>
    <a-row :gutter="40">
      <a-col :span="6">
        <a-form-item label="默认发货仓库：">
          <a-input v-model="stata.form.warehouseName" disabled></a-input>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item label="默认发货人：">
          <a-input v-model="stata.form.deliverer" disabled></a-input>
        </a-form-item></a-col>
      <a-col :span="6">
        <a-form-item label="默认发货电话：">
          <a-input v-model="stata.form.mobile" disabled></a-input>
        </a-form-item></a-col>
      <a-col :span="6">
        <a-form-item label="默认退货仓库：">
          <a-input v-model="stata.form.delivererWarehouseName" disabled></a-input>
        </a-form-item></a-col>
    </a-row>
    <a-row :gutter="40">
      <a-col :span="6">
        <a-form-item label="价格来源：">
          <a-input v-model="stata.form.priceSource" disabled></a-input>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item label="配货方式：">
          <a-input v-model="stata.form.distributionMode" disabled></a-input>
        </a-form-item></a-col>
      <a-col :span="6">
        <a-form-item label="配货延迟时间：">
          <a-input v-model="stata.form.delayTime" disabled></a-input>
        </a-form-item></a-col>
      <a-col :span="6">
        <a-form-item label="重新配货延迟：">
          <a-input :model-value="stata.form.againDelayTime" disabled></a-input>
        </a-form-item></a-col>
    </a-row>
  </a-form>
</template>
<script lang="ts" setup name="store-config">
import { onMounted, reactive } from 'vue'
import { StoreDetails, initDataType } from '@/types/basicdata/shop'
import { findStoreDetail, storeInitData } from '@/api/basicdata/shop'
import { Message } from '@arco-design/web-vue';
class stataClass {
  form: StoreDetails = {}
  priceTourceList: Array<initDataType> = []
  delayTimeList: Array<initDataType> = []
  destributionMethodList: Array<initDataType> = []
}
const stata = reactive<stataClass>(new stataClass())
const getStoreConfig = async (id: number) => {
  try {
    let res = await findStoreDetail(id)
    if (res.code != 0) {
      throw new Error(res.message)
    }
    stata.form = res.value
    stata.form.againDelayTime = stata.delayTimeList.find(i => i.dictionaryValue == stata.form.againDelayTime)?.dictionaryTitle
    stata.form.delayTime = stata.delayTimeList.find(i => i.dictionaryValue == stata.form.delayTime)?.dictionaryTitle
    stata.form.distributionMode = stata.destributionMethodList.find(i => i.dictionaryValue == stata.form.distributionMode)?.dictionaryTitle
    stata.form.priceSource = stata.priceTourceList.find(i => i.dictionaryValue == stata.form.priceSource)?.dictionaryTitle
  } catch (error) {
    Message.error((error as Error).message)
  }
}
const initData = async () => {
  const res = await storeInitData()
  if (res.code != 0) {
    return Message.error(res.message)
  }
  stata.delayTimeList = res.value.DELAY_TIME
  stata.destributionMethodList = res.value.DISTRIBUTION_METHOD
  stata.priceTourceList = res.value.PRICE_SOURCE
}
onMounted(() => initData())
defineExpose({
  getStoreConfig
})
</script>