<!-- 基础资料->快递管理->详情列表 -->
<template>
  <oms-table :simplePagination="true" :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize"
    @reload="onReload">
    <template #header-left>
      <a-space :size="14" style="margin-bottom:10px;">
        <a-button v-permission="['oms:basicdata:express:addConfig']" type="primary" status="normal"
          @click="handleAddClick('add', '')"> 新增限发配置
        </a-button>
        <a-button v-permission="['oms:basicdata:express:importConfig']" status="normal"
          @click="handleAddClick('import', '')"> 导入 </a-button>
        <a-button v-permission="['oms:basicdata:express:batchDelConfig']" status="normal"
          @click="handleAddClick('batchDel', '')"> 批量删除 </a-button>
      </a-space>
    </template>
    <template #header-right>
      <a-input allow-clear v-model="form.keyword" :style="{ width: '200px' }" placeholder="输入搜索关键字" @keyup.enter="getInfo">
        <template #suffix>
          <span class="iconfont icon-icon_sousuo sousuoStyle" @click="getInfo"></span>
        </template>
      </a-input>
    </template>

    <a-table :bordered="{ wrapper: false }" stripe ref="tableRef" :data="(list as any)" :pagination="false" row-key="id"
      :row-selection="{
        type: 'checkbox',
        showCheckedAll: true
      }" :scroll="{ x: 1400 }" v-model:selectedKeys="selectedKeys">
      <template #columns>
        <a-table-column title="省" :width="180" data-index="province">
        </a-table-column>
        <a-table-column title="市" :width="180" data-index="city"></a-table-column>
        <a-table-column title="区" :width="180" data-index="area"></a-table-column>
        <a-table-column title="限发原因" ellipsis tooltip :width="180" data-index="limitReasonName"></a-table-column>
        <a-table-column title="创建时间" :width="180" data-index="createTime"></a-table-column>
        <a-table-column title="修改时间" :width="180" data-index="updateTime"></a-table-column>
        <a-table-column title="操作" :width="120" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-space :size="28">
              <a-link v-permission="['oms:basicdata:express:editConfig']" @click="handleAddClick('edit', rowIndex)"
                type="text">编辑</a-link>
              <a-link v-permission="['oms:basicdata:express:delConfig']" status="danger"
                @click="handleAddClick('del', rowIndex)" type="text">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑数据字典项 -->
  <form-details ref="DetailsRef" :expressId="expressId" @reload-details="emits('reload-details')"></form-details>

  <!-- 删除二次确认 -->
  <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>

  <!-- 导入 -->
  <oms-import ref="importRef" uploadUrlName="快递限发导入模板" :uploadUrl="uploadUrl" :importApi="importApi" :paramsObj="importParams"
    @onSuccess="uploadFile">
  </oms-import>
</template>

<script setup lang="ts" name="system-express-list">
import { ref, watch } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import OmsImport from '@/components/oms-import/index.vue'
import FormDetails from './form-details.vue'
import { LimitConfigsReq } from '@/types/basicdata/express';
import { Message } from '@arco-design/web-vue';
import { delLimitConfig, expressLimitUpload } from '@/api/basicdata/express';
const selectedKeys = ref<string[]>([]);

const props = defineProps({
  list: {
    type: Array, default: () => []
  },
  totalCount: {
    type: Number, default: 0
  },
  expressId: {
    type: String, default: ''
  },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  loading: { type: Boolean, default: false },
});
const form = ref<LimitConfigsReq>(new LimitConfigsReq());
const emits = defineEmits<{
  (e: "reload-details", data?: LimitConfigsReq): void
}>();
const uploadUrl = ref(`${import.meta.env.VITE_API_FILE_URL}/bp-auth-service/template/expressManage/%E5%BF%AB%E9%80%92%E9%99%90%E5%8F%91%E5%AF%BC%E5%85%A5%E6%A8%A1%E6%9D%BF.xlsx`)
const DetailsRef = ref();
const warnignRef = ref();
const importRef = ref();
const tableRef = ref();
const importParams = ref<any>({});
const importApi = ref()
// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload-details", form.value)
};

const getInfo = () => {
  emits("reload-details", form.value)
}

// 「新增字典项」按钮点击触发
const handleAddClick = (type: string, index: string) => {
  //批量删除
  if (type === 'batchDel') {
    if (selectedKeys.value.length == 0) return Message.error('请选择需要删除的数据！');
    warnignRef.value.open();
    return;
  }
  if (type === 'del') {
    selectedKeys.value=[];
    selectedKeys.value.push(props.list[index].id);
    warnignRef.value.open();
    return;
  }
  if (type === 'import') {
    importRef.value.visible = true;
    importApi.value = expressLimitUpload;
    let obj = {
      expressId: props.expressId
    }
    importParams.value = obj;
    return;
  }
  DetailsRef.value.handleDetailsShowModal(type, type === 'edit' ? props.list[index] : props.expressId);
};

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delLimitConfig(selectedKeys.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload-details");
    tableRef.value.selectAll(false);
    selectedKeys.value=[]
  } catch (err) {
    Message.error((err as Error).message);
    tableRef.value.selectAll(false);
    return false;
  }
}


//上传文件
const uploadFile = async (data: any) => {
  emits("reload-details");
  // form.value.expressId = props.expressId;
  // // //组装开始上传
  // let formData: FormData = new FormData()
  // formData.append('file', data.file)
  // formData.append('filePath', data.filePath)
  // formData.append('expressId', form.value.expressId)
  // console.log('[ form.value.expressId ] >', form.value.expressId)
  // importRef.value.isUpload = true;
  // //上传
  // try {
  //   const res = await expressLimitUpload(formData);
  //   if (res.code != 0) {
  //     throw new Error(res.message);
  //   }
  //   importRef.value.isUpload = false;
  //   if (res.value) {
  //     let resVal = {
  //       errorData: res.value
  //     }
  //     importRef.value.uploadFileData(resVal);
  //     return
  //   }
  //   Message.success(res.message);
  //   importRef.value.visible = false;
  //   emits("reload-details");
  // } catch (err) {
  //   Message.error((err as Error).message);
  //   importRef.value.visible = false;
  //   return false;
  // }
}

watch(
  () => props.expressId,
  () => {
    if (props.expressId) {
      form.value.expressId = props.expressId;

    }
  }, {
  immediate: true,
  deep: true
}
);

</script>
<style lang="less" scoped>
.sousuoStyle {
  cursor: pointer;
}
</style>