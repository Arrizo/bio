<!-- 基础资料->快递管理->编辑表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="500px" v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" :ok-loading="loading" unmountOnClose>
    <a-form :model="form" ref="formRef" layout="horizontal">
      <a-form-item field="expressCode" label="快递编码：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入快递编码' }]">
        <a-input :maxLength="50" v-limit-input="['#', '']" v-model.trim="form.expressCode" placeholder="请输入"
          @input="form.expressCode = form.expressCode.replace(/[\u4e00-\u9fa5]/g, '')" allowClear />
      </a-form-item>
      <a-form-item field="expressName" label="快递名称：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入快递名称' }]">
        <a-input :maxLength="100" v-limit-input="['#', '']" v-model.trim="form.expressName" placeholder="请输入"
          allowClear />
      </a-form-item>
      <a-form-item field="standardExpress" label="标准快递：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择标准快递' }]">
        <a-select placeholder="请选择" v-model="form.standardExpress">
          <a-option v-for="(item) in standardExpressList" :label="item.dictionaryTitle" :value="item.id + ''"></a-option>
        </a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-express-form">
import { ExpressForm } from '@/types/basicdata/express';
import { reactive, ref } from 'vue';
import { addExpress, editExpress } from '@/api/basicdata/express';
import { Message } from '@arco-design/web-vue';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';

// 快递编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const form = ref<ExpressForm>(new ExpressForm());
const loading = ref<boolean>(false);
let standardExpressList = ref<DictionaryTitleType[]>()
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  loading.value = true;
  try {
    const apiType = editModal.type === 'add' ? addExpress : editExpress;

    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  } finally {
    loading.value = false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: ExpressForm) => {
  editModal.type = type;
  editModal.show = true;
  if (type === 'add') {
    form.value = new ExpressForm();
    //获取标准快递---有效的
    standardExpressList.value = await getDictionaryList('STANDARD_EXPRESS')
  }

  if (type === "edit") {
    //获取标准快递包含禁用的
    standardExpressList.value = await getValidDictionaryList('STANDARD_EXPRESS')
    form.value.expressCode = data.expressCode ?? "";
    form.value.expressName = data.expressName ?? "";
    form.value.standardExpress = data.standardExpress + '' ?? 0;
    form.value.id = data.id;
  }
}

defineExpose({
  handleShowModal
});
</script>