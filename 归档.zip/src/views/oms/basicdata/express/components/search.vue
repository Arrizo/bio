<!-- 基础资料->快递管理->搜索组件 -->
<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="expressCode" label="快递编码：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.expressCode" placeholder="请输入" allow-clear />
    </a-form-item>
    <a-form-item field="expressName" label="快递名称：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.expressName" placeholder="请输入" allow-clear />
    </a-form-item>
    <a-form-item field="standardExpressId" label="标准快递：">
      <a-select placeholder="请选择" v-model="form.standardExpressId" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option v-for="(item) in standardExpressList" :label="item.dictionaryTitle" :value="item.id"></a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="(form.status as string)" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="system-express-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { getDictionaryList } from '@/hooks/useDictionary';
import { ExpressSearchForm } from '@/types/basicdata/express';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false },
});
const formRes = ref();
const emits = defineEmits<{
  (e: "on-search", data: ExpressSearchForm): void;
}>();
let standardExpressList = ref<DictionaryTitleType[]>()
const form = ref<ExpressSearchForm>(new ExpressSearchForm());

const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

onMounted(async () => {
  handleSearch();
  //获取标准快递
  standardExpressList.value = await getDictionaryList('STANDARD_EXPRESS')
});
</script>