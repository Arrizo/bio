<template>
  <div class="express-details">
    <div class="express-details-title">
      <a-tabs :style="{ width: '100%' }">
        <template #extra>
          <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
        </template>
        <a-tab-pane key="2" title="限发配置">
          <details-list @reload-details="getInfo" :totalCount="totalCount" :page-num="form.pageNum" :page-size="form.pageSize" :loading="loading" :list="list"
            :expressId="form.expressId"></details-list>
        </a-tab-pane>
      </a-tabs>
    </div>
  </div>
</template>

<script setup lang="ts" name="system-express-details">
import DetailsList from './details-list.vue';
import { onMounted, ref, watch } from 'vue';
import { LimitConfigsReq, LimitConfigsRes, LimitConfigsResItem } from '@/types/basicdata/express';
import { Message } from '@arco-design/web-vue';
import { deepClone } from '@/utils/helper';
import { limitConfigs } from '@/api/basicdata/express';

const props = defineProps({
  expressId: {
    type: String, default: ''
  },
});
const emits = defineEmits<{
  (e: "close"): void,
}>();
const loading = ref<boolean>(false);
const list = ref<LimitConfigsResItem[]>([]);
const totalCount = ref<number>(0)
const form = ref<LimitConfigsReq>(new LimitConfigsReq());

onMounted(() => {
  form.value.expressId = props.expressId;
});




//关闭详情
const closeDetails = () => {
  emits('close')
}

const getInfo = async (data: LimitConfigsReq = {}) => {
  try {
    form.value = { ...form.value, ...data }
    loading.value = true;
    let params = deepClone(form.value);

    const res = await limitConfigs(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}
watch(
  () => props.expressId,
  () => {
    if (props.expressId) {
      form.value.expressId = props.expressId;
      getInfo(form.value)
    }
  }, {
  immediate: true,
  deep: true
});
</script>

<style lang="less" >
.express-details {
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  .arco-tabs-content {
    padding-left: 16px;
    padding-right: 16px;
  }

  .arco-tabs-nav {
    padding: 0 16px;
  }
}
</style>