<!-- 基础资料->快递管理->编辑表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="500px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose
    :ok-loading="loading">
    <a-form :model="form" ref="formRef" layout="horizontal">
      <a-form-item field="expressArr" label="限发区域：" label-col-flex="110px" required
        :rules="[{ required: true, message: '请选择限发区域' }]">
        <a-cascader :disabled="editModal.type === 'edit'" path-mode ref="cascaderRef"
          :field-names="{ value: 'id', label: 'regionName', children: 'child' }" :max-tag-count="1"
          v-model='form.expressArr' :multiple="true" :allow-clear="true" :options="expressLimitData"
          placeholder="请选择"></a-cascader>
      </a-form-item>
      <a-form-item field="limitReason" label="限发原因：" label-col-flex="110px" required
        :rules="[{ required: true, message: '请选择限发原因' }]">
        <a-select placeholder="请选择" v-model="form.limitReason">
          <a-option v-for="(item) in reasonList" :label="item.dictionaryTitle" :value="item.id"></a-option>
        </a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-express-form-details">
import { AddReasonBo, AddReasonReq, CascaderType, ExpressItem, } from '@/types/basicdata/express';
import { reactive, ref, onMounted } from 'vue';
import { Message } from '@arco-design/web-vue';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { addLimitConfig, getChildList, getChildAddress, updateLimitConfig } from '@/api/basicdata/express';
import { ignorableWatch } from '@vueuse/shared';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';

// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload-details"): void
}>();
const props = defineProps({
  expressId: {
    type: String, default: ''
  },
});

const loading = ref<boolean>(false);
const cascaderRef = ref()
const form = ref<AddReasonReq>(new AddReasonReq());
const reasonList = ref<DictionaryTitleType[]>();
const formRef = ref();
const expressLimitData = ref<CascaderType[]>([]);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  form.value.expressLimitAddressBOS = handleValue(form.value.expressArr)
  try {
    const apiType = editModal.type === 'add' ? addLimitConfig : updateLimitConfig;
    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload-details");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

//处理数据拿到每一级的label值
const handleLabel = (arr: any, brr: any): any[] => {
  for (let i = 0; i < arr.length; i++) {
    const item = arr[i];
    let labelArr = item.label.split(' / ');
    brr[i].province = labelArr[0];
    brr[i].city = labelArr[1];
    brr[i].area = labelArr[2];
  }
  return brr;
}

//处理限发区域数值
const handleValue = (arr: any) => {
  let neArr = [];
  for (let i = 0; i < arr.length; i++) {
    const item = arr[i];
    let obj = new AddReasonBo();
    obj.provinceId = item[0];
    obj.cityId = item[1];
    obj.areaId = item[2];
    neArr.push(obj)
  }
  return handleLabel(cascaderRef.value.selectViewValue, neArr)
}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleDetailsShowModal = async (type: "add" | "edit", data: any) => {
  editModal.type = type;
  editModal.show = true;
  if (type === 'add') {
    form.value = new AddReasonReq();
    //获取限发原因
    reasonList.value = await getDictionaryList('RESTRICTION_REASON')
  }

  form.value.expressId = props.expressId;
  form.value.expressArr = [];
  if (type === 'edit') {
    //获取限发原因
    reasonList.value = await getValidDictionaryList('RESTRICTION_REASON')
    form.value.limitReason = data.limitReason;
    form.value.id = data.id;
    let arr: any = []
    if (data.provinceId) {
      arr.push(data.provinceId)
      if (data.cityId) {
        arr.push(data.cityId)
        if (data.areaId) {
          arr.push(data.areaId)
        }
      }
    }
    form.value.expressArr.push(arr)
  }
}
//获取所有省份
const getProvinceList = async () => {
  try {
    const res = await getChildAddress();

    if (res.code != 0) {
      throw new Error(res.message);
    }
    expressLimitData.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

onMounted(() => {
  getProvinceList();
});

defineExpose({
  handleDetailsShowModal
});
</script>