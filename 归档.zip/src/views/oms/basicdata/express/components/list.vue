<!-- 基础资料->快递管理->列表 -->
<template>
  <oms-table :loading="loading" :total="totalCount" :current="form.pageNum" :size="form.pageSize" @reload="onReload">
    <template #header-left>
      <a-button v-permission="['oms:basicdata:express:add']" type="primary" status="normal"
        @click="handleAddClick('add', {})" style="margin-bottom: 10px;"> 新增快递 </a-button>
    </template>
    <a-table v-db-click="list" :db-call-back="handleDetailsClick" stripe :bordered="{ wrapper: false }"
      :data="(list as any)" :pagination="false" :scroll="{ x: 1400 }">
      <template #columns>
        <a-table-column ellipsis tooltip title="快递编码" data-index="expressCode">
          <template #cell="{ record }">{{ record.expressCode || '--' }}</template>
        </a-table-column>
        <a-table-column :ellipsis="true" :tooltip="true" title="快递名称" data-index="expressName">
          <template #cell="{ record }">{{ record.expressName || '--' }}</template>
        </a-table-column>
        <a-table-column :ellipsis="true" :tooltip="true" title="标准快递" data-index="standardExpressName">
          <template #cell="{ record }">{{ record.standardExpressName || '--' }}</template>
        </a-table-column>
        <a-table-column title="状态" :width="120" data-index="status">
          <template #cell="{ record, rowIndex }">
            <a-switch v-permission="['oms:basicdata:express:status']" v-model="(list as any)[rowIndex].status"
              @focus="onSwitchForce(record, rowIndex)">
              <template #checked>
                启用
              </template>
              <template #unchecked>
                禁用
              </template>
            </a-switch>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" :width="180" data-index="createTime">
          <template #cell="{ record }">{{ record.createTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="修改时间" :width="180" data-index="updateTime">
          <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="操作" :width="80" fixed="right">
          <template #cell="{ record }">
            <a-link v-permission="['oms:basicdata:express:edit']" @click="handleAddClick('edit', record)"
              type="text">编辑</a-link>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 菜单新增/编辑弹窗 -->
  <express-form ref="ExpressFromRef" @reload="emits('reload')"></express-form>

  <!-- 修改状态二次弹框 -->
  <oms-warning ref="switchRef" :on-before-ok="handleStatus"></oms-warning>
</template>

<script setup lang="ts" name="system-express-list">
import { computed, reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import ExpressForm from "./form.vue"
import OmsWarning from '@/components/oms-warning/index.vue';
import { Message } from '@arco-design/web-vue';
import { getStatusUpdate } from '@/api/basicdata/express';
import { ExpressItem, ExpressSearchForm, ExpressStatusForm } from '@/types/basicdata/express';

const props = defineProps({
  list: {
    type: Array, default: () => []
  },
  totalCount: { type: Number, default: 0 },
  loading: { type: Boolean, default: false },
});
const form = ref<ExpressSearchForm>(new ExpressSearchForm());
const emits = defineEmits<{
  (e: "reload", data?: ExpressSearchForm): void,
  (e: "details", data: number): void,
}>();
const switchRef = ref();
const ExpressFromRef = ref();
const statusForm = ref<ExpressStatusForm>(new ExpressStatusForm());

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  // emits("reload", form.value)
  emits('reload', data);
};

// 「新增菜单」按钮点击触发
const handleAddClick = (type: string, record: {}) => {
  ExpressFromRef.value.handleShowModal(type, type === 'edit' ? record : '');
};

//详情
const handleDetailsClick = (data: ExpressItem) => {
  emits('details', data.id)
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: ExpressItem, index: number) => {
  statusForm.value.id = record?.id + '';
  statusForm.value.status = !record?.status;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

const handleStatus = async () => {
  try {
    const res = await getStatusUpdate(statusForm.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 返回列表
const list = computed(() => {
  return props.list as Array<ExpressItem>
})

</script>