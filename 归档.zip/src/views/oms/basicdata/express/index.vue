<!-- 基础资料->快递管理 -->
<template>
  <div>
    <a-row :gutter="10">
      <a-col :span="24">
        <oms-panel>
          <template #header>
            <express-search :loading="loading" @on-search="init"></express-search>
          </template>
          <div>
            <express-list @reload="init" @details="handleDetailsClick" :totalCount="totalCount" :loading="loading"
              :list="list"></express-list>
          </div>
        </oms-panel>
        <!-- 详情 -->
        <express-details v-if="detailsVisible" :expressId="detailsId" @close="closeDetails"></express-details>
      </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts" name="basicdata-express">
import OmsPanel from '@/components/oms-panel/index.vue';
import ExpressSearch from './components/search.vue';
import ExpressList from './components/list.vue';
import ExpressDetails from './components/details.vue';
import { queryList } from '@/api/basicdata/express';
import { ExpressItem, ExpressSearchForm } from '@/types/basicdata/express';
import { Message } from '@arco-design/web-vue';
import { ref } from 'vue';
import { deepClone } from '@/utils/helper';
const form = ref<ExpressSearchForm>(new ExpressSearchForm());
const loading = ref<boolean>(false);
const list = ref<ExpressItem[]>();
const totalCount = ref();
const ExpressDetailsRef = ref();
const detailsVisible = ref<boolean>(false);
const detailsId = ref('')
/**
 * 初始化查询菜单数据
 * @param form
 */

const init = async (data: ExpressSearchForm = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.status = params.status === 'all' ? '' : params.status;
    params.standardExpressId = params.standardExpressId === 'all' ? '' : params.standardExpressId;
    
    const res = await queryList(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
    //关闭详情
    closeDetails();
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}
//详情
const handleDetailsClick = (data: number) => {
  detailsVisible.value = true;
  detailsId.value = data + '';
}
//关闭详情
const closeDetails = () => {
  detailsVisible.value = false;
}
</script>