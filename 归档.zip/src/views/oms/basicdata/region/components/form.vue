<!-- 基础资料->行政区域->编辑表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="props.type === 'add' ? '新增' : '编辑'" width="500px" :visible="props.visible" title-align="start"
    :on-before-ok="onOk" @cancel="handlerClose" unmountOnClose :ok-loading="state.loading">
    <a-form :model="state.form" ref="formRef" layout="horizontal">
      <!-- 上级区域 -->
      <a-form-item field="parentId" label="上级区域：" label-col-flex="100px">
        <a-cascader :options="(state.options as Array<CascaderOption>)" :field-names="fieldNames" placeholder="请选择上级区域"
          check-strictly v-model="state.form.parentId" allow-clear expand-trigger="hover"/>
      </a-form-item>
      <!-- 区域编码 -->
      <a-form-item field="regionCode" label="区域编码：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入区域编码' }]">
        <a-input :maxLength="50" v-model.trim="state.form.regionCode" placeholder="请输入" allowClear
          @input="state.form.regionCode = state.form.regionCode.replace(/[\u4e00-\u9fa5]/g, '')" v-limit-input="['#', '']"/>
      </a-form-item>
      <!-- 区域名称 -->
      <a-form-item field="regionName" label="区域名称：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入区域名称' }]">
        <a-input :maxLength="50" v-model.trim="state.form.regionName" placeholder="请输入" allowClear v-limit-input="['#', '']"/>
      </a-form-item>
      <!-- 区域简称 -->
      <a-form-item field="shortName" label="区域简称：" label-col-flex="100px">
        <a-input :maxLength="50" v-model.trim="state.form.shortName" placeholder="请输入" allowClear v-limit-input="['#', '']"/>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-region-form">
import { reactive, ref, onMounted, watch } from 'vue'
import { CascaderOption, Message } from '@arco-design/web-vue'
import {
  RegionData,
  GetAddressSelectReq,
  GetAddressSelectRes,
  AddOrUpdateRegionReq
} from '@/types/basicdata/region'
import { addOrUpdateRegion, getAddressSelect, getAddressTree } from '@/api/basicdata/region'

const fieldNames = { value: 'id', label: 'regionName' }

const props = defineProps({
  visible: {
    type: Boolean,
    required: true,
    default: false,
  },
  curRow: {
    type: AddOrUpdateRegionReq,
    required: true,
    default: new AddOrUpdateRegionReq()
  },
  type: {
    type: String,
    required: true,
  },
})


class ReactiveCls {
  loading: boolean = false
  options: Array<GetAddressSelectRes> = new Array<GetAddressSelectRes>()
  form: AddOrUpdateRegionReq = new AddOrUpdateRegionReq()
}

//定义emit
const emits = defineEmits(['update:visible', 'reload'])
const state = reactive<ReactiveCls>(new ReactiveCls())
const formRef = ref()


watch(
  () => props.visible,
  async (v) => {
    if(v){
      let options: Array<GetAddressSelectRes> = await fetchData() as Array<GetAddressSelectRes>
      state.options = options
    }
  }
)

watch(
  () => props.curRow,
  (v) => {
    if (v?.id) {
      state.form.id = v.id
      state.form.parentId = v.parentId || ""
      state.form.regionCode = v.regionCode
      state.form.regionName = v.regionName
      state.form.shortName = v.shortName
    }
  }, {
    immediate: true,
    deep: true
  }
)

/** 点击确定按钮时触发 */
const onOk = async () => {
  const check = await formRef.value.validate()
  if (check) {
    return false
  }
  state.loading = true
  try {
    const res = await addOrUpdateRegion(state.form)
    if (res.code != 0) {
      Message.error(res.message)
      state.loading = false
      return false
    }
    Message.success(res.message)
    handlerClose()
    emits("reload")
    state.loading = false
    return true
  } catch (err) {
    Message.error((err as Error).message)
    state.loading = false
    return false
  }
}

/** 点击取消、关闭按钮时触发 */
const handlerClose = () => {
  emits('update:visible', !props.visible)
  formRef.value!.resetFields()
  state.form = new AddOrUpdateRegionReq()
}


/** 获取数据 */
const fetchData = (parentId: number | undefined = undefined) => {
  return new Promise(async (resolve, reject) => {
    try {
      // let data = new GetAddressSelectReq()
      // if (parentId) {
        // data.parentId = parentId
      // }
      // data.level = 3
      const { code, message, value } = await getAddressTree(3)
      if (code != 0) {
        throw new Error(message)
      }

      var list = value.map((item: RegionData) => {
        if (item.level === 3) {
          item.isLeaf = true
        }
        return item
      })
      resolve(list)
    } catch (err) {
      Message.error((err as Error).message)
    }
  })
}

/** 加载更多 */
// const loadMore = async (record: any, done: any) => {
//   try {
//     let list = await fetchData(record.id)
//     done(list)
//   } catch (err) {
//     Message.error((err as Error).message)
//     return false
//   }
// }

</script>