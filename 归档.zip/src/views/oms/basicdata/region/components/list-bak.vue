<!-- 基础资料->行政区域->列表 -->
<template>
  <oms-table :loading="state.loading" :total="0">
    <template #header-left>
      <a-space :size="14">
        <a-button type="primary" status="normal" v-permission="['system:region:add']"
          @click="handleAddClick('add', '')"> 新增区域 </a-button>
        <a-button v-permission="['system:region:batchRemove']" @click="handleAddClick('batchRemove', '')"
          :disabled="!state.selectedKeys.length"> 批量删除 </a-button>
      </a-space>
    </template>
    <!-- 懒加载的table树必须配置row-key! -->
    <a-table :columns="columns" :data="(state.list as any)" :pagination="false" :load-more="loadMore"
      :bordered="{ wrapper: false }" row-key="regionCode" :row-selection="rowSelection" :scroll="{ x: 1400 }"
      v-model:selectedKeys="state.selectedKeys" :bodyCell="true">
      <!-- 重写展开图标 -->
      <template #expand-icon='{ expanded }'>
        <icon-caret-down v-if="expanded" style="font-size: 32;" />
        <icon-caret-right v-else style="font-size: 32;" />
      </template>
      <template #level='{ record }'>
        {{ Level[record.level as any] }}
      </template>
      <template #action='{ record, rowIndex }'>
        <a-space :size="28">
          <a-link type="text" v-permission="['system:region:edit']"
            @click="handleAddClick('edit', rowIndex, record)">编辑</a-link>
          <a-link type="text" v-permission="['system:region:remove']" status="danger"
            @click="handleAddClick('remove', rowIndex, record)">删除</a-link>
        </a-space>
      </template>
    </a-table>
  </oms-table>

  <!-- 菜单新增/编辑弹窗 -->
  <region-form v-model:visible="state.visibleRegionForm" :curRow="state.curRow" @reload="fetchData"></region-form>

  <!-- 修改状态二次弹框 -->
  <oms-warning ref="warningRef" :on-before-ok="handleStatus"></oms-warning>
</template>

<script setup lang="ts" name="system-region-list">
import { reactive, ref, onMounted } from 'vue'
import OmsTable from '@/components/oms-table/index.vue'
import OmsWarning from '@/components/oms-warning/index.vue'
import RegionForm from "./form.vue"
import { Message, TableRowSelection } from '@arco-design/web-vue'
import { getProvinceList, getRegionChild, removeRegion } from '@/api/basicdata/region'
import {
  RegionData,
  GetAddressSelectRes,
  AddOrUpdateRegionReq
} from '@/types/basicdata/region'

enum Level {
  "省" = 1,
  "市",
  "区",
  "街道",
}

const rowSelection: TableRowSelection = reactive({
  type: 'checkbox',
  showCheckedAll: true,
  checkStrictly: false   //是否开启严格选择模式 (default: true)
})

class ReactiveCls {
  curRow: RegionData = new RegionData()
  visibleRegionForm: boolean = false
  loading: boolean = false
  list: Array<RegionData> = new Array<RegionData>()
  selectedKeys: string[] = []
  removeList: string[] = []
  indeterminate: boolean = false
}
const state = reactive<ReactiveCls>(new ReactiveCls())
const warningRef = ref()


/**
 * 初始化查询
 */
const fetchData = async () => {
  try {
    state.loading = true

    const { code, message, value } = await getProvinceList()
    if (code != 0) {
      throw new Error(message)
    }

    state.list = value.map((item: RegionData) => {
      if (item.level === 4) {
        item.isLeaf = true
      }
      return item
    })
  } catch (err) {
    Message.error((err as Error).message)
  } finally {
    state.loading = false
  }
}

// 按钮点击触发
const handleAddClick = (type: string, index: string, record: RegionData | undefined = undefined) => {
  console.log(type, record)
  switch (type) {
    case "add":
    case "edit":
      state.curRow = record as RegionData
      state.visibleRegionForm = true
      break
    case "remove":
      state.removeList = ["" + record?.id]
      warningRef.value.open()
      break
    case "batchRemove":
      state.removeList = [...state.selectedKeys]
      warningRef.value.open()
      break
    default:
      break
  }
}

/**
 * 删除确认回调
 */
const handleStatus = async () => {
  try {
    const res = await removeRegion(state.removeList)
    if (res.code != 0) {
      throw new Error(res.message)
    }
    Message.success(res.message)
    fetchData()
  } catch (err) {
    Message.error((err as Error).message)
  }
}

/** 加载更多 */
const loadMore = async (record: any, done: any) => {
  try {
    const res = await getRegionChild(record.id)
    if (res.code != 0) {
      throw new Error(res.message)
    }

    let list = res.value.map((item: RegionData, index: number) => {
      if (item.level === 4) {
        item.isLeaf = true
      }
      return item
    })
    done(list)
  } catch (err) {
    Message.error((err as Error).message)
    return false
  }
}

const columns = [
  { title: '区域名称', dataIndex: 'regionName', width: "220", fixed:"left" },
  { title: '区域编码', dataIndex: 'regionCode', width: "140" },
  { title: '区域简称', dataIndex: 'shortName', width: "180" },
  { title: '区域级别', dataIndex: 'level', slotName: 'level', width: "120" },
  { title: '创建时间', dataIndex: 'createdTime', width: "180" },
  { title: '修改时间', dataIndex: 'updateTime', width: "180" },
  { title: '操作', dataIndex: 'action', slotName: 'action', fixed: "right", width: "120" },
]

onMounted(() => {
  fetchData()
})

</script>