<!-- 基础资料->行政区域 -->
<template>
  <div>
    <oms-panel>
      <region-list></region-list>
    </oms-panel>
  </div>
</template>

<script setup lang="ts" name="basicdata-region">
import OmsPanel from '@/components/oms-panel/index.vue'
import RegionList from './components/list.vue'
</script>