<!-- 基础资料->仓库管理 -->
<template>
  <div>
    <a-row :gutter="10">
      <a-col :span="24">
        <oms-panel>
          <template #header>
            <search :loading="loading" @on-search="init"></search>
          </template>
          <div>
            <list @reload="init" @details="handleDetailsClick" :totalCount="totalCount" :loading="loading" :list="list">
            </list>
          </div>
        </oms-panel>
        <!-- 详情 -->
        <warehouse-details v-if="detailsVisible" :warehouseId="warehouseId" @close="closeDetails"></warehouse-details>
      </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts" name="basicdata-warehouse">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import { Message } from '@arco-design/web-vue';
import { ref, onMounted } from 'vue';
import WarehouseDetails from './components/details.vue';
import { deepClone } from '@/utils/helper';
import { WarehouseListItem, WarehouseSearchReq } from '@/types/basicdata/warehouse';
import { queryList } from '@/api/basicdata/warehouse';
const form = ref<WarehouseSearchReq>(new WarehouseSearchReq());
const loading = ref<boolean>(false);
const list = ref<WarehouseListItem[]>();
const detailsVisible = ref<boolean>(false);
const totalCount = ref(0)
const warehouseId = ref()
/**
 * 初始化查询菜单数据
 * @param form
 */

const init = async (data: WarehouseSearchReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.status = params.status === 'all' ? '' : params.status;
    params.warehouseType = params.warehouseType === 'all' ? '' : params.warehouseType;
    
    const res = await queryList(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
    //关闭详情
    closeDetails();
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}
//详情
const handleDetailsClick = (data: number) => {
  detailsVisible.value = true;
  warehouseId.value = data;
}
//关闭详情
const closeDetails = () => {
  detailsVisible.value = false;
}
</script>