<!-- 基础资料->仓库管理->列表 -->
<template>
  <oms-table :loading="loading" :total="totalCount" :current="form.pageNum" :size="form.pageSize" @reload="onReload">
    <template #header-left>
      <a-button v-permission="['oms:basicdata:warehouse:add']" type="primary" status="normal"
        @click="handleAddClick('add')" style="margin-bottom: 10px;"> 新增仓库 </a-button>
    </template>
    <a-table  v-db-click="list" :db-call-back="handleDetailsClick" stripe :data="(list as any)" :pagination="false" :scroll="{ x: 1400 }" :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="实体仓编码" ellipsis tooltip  data-index="warehouseCode">
          <template #cell="{ record }">{{ record.warehouseCode || '--' }}</template>
        </a-table-column>
        <a-table-column title="实体仓名称" ellipsis tooltip  data-index="warehouseName">
          <template #cell="{ record }">{{ record.warehouseName || '--' }}</template>
        </a-table-column>
        <a-table-column title="实体仓类型" ellipsis tooltip  data-index="warehouseTypeName">
          <template #cell="{ record }">{{ record.warehouseTypeName || '--' }}</template>
        </a-table-column>
        <a-table-column title="仓库负责人" ellipsis tooltip  data-index="owner">
          <template #cell="{ record }">{{ record.owner || '--' }}</template>
        </a-table-column>
        <a-table-column title="所属公司" ellipsis tooltip  data-index="companyName">
          <template #cell="{ record }">{{ record.companyName || '--' }}</template>
        </a-table-column>
        <a-table-column title="仓储供应商" ellipsis tooltip data-index="supplierName">
          <template #cell="{ record }">{{ record.supplierName || '--' }}</template>
        </a-table-column>
        <a-table-column title="状态" ellipsis tooltip :width="120" data-index="status">
          <template #cell="{ record, rowIndex }">
            <a-switch v-permission="['oms:basicdata:warehouse:status']" v-model="record.status"
              @focus="onSwitchForce(record, rowIndex)">
              <template #checked>
                启用
              </template>
              <template #unchecked>
                禁用
              </template>
            </a-switch>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" ellipsis tooltip :width="180" data-index="createTime">
          <template #cell="{ record }">{{ record.createTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="修改时间" ellipsis tooltip :width="180" data-index="updateTime">
          <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="操作" :width="80" fixed="right">
          <template #cell="{ record }">
            <a-link v-permission="['oms:basicdata:warehouse:edit']" @click="handleAddClick('edit', record)"
              type="text">编辑</a-link>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑弹窗 -->
  <warehouse-form ref="WarehouseFromRef" @reload="emits('reload')"></warehouse-form>

  <!-- 修改状态二次弹框 -->
  <oms-warning ref="switchRef" :on-before-ok="handleStatus"></oms-warning>
</template>

<script setup lang="ts" name="system-warehouse-list">
import { computed, reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import WarehouseForm from "./form.vue"
import { Message } from '@arco-design/web-vue';
import { WarehouseListItem, WarehouseSearchReq, WarehouseStatusForm } from '@/types/basicdata/warehouse';
import { getStatusUpdate } from '@/api/basicdata/warehouse';
import { recordExpression } from '@babel/types';

const props = defineProps({
  list: {
    type: Array, default: () => []
  },
  totalCount: { type: Number, default: 0 },
  loading: { type: Boolean, default: false },
});
const form = ref<WarehouseSearchReq>(new WarehouseSearchReq());
const emits = defineEmits<{
  (e: "reload", data?: WarehouseSearchReq): void,
  (e: "details", data: number): void,
}>();
const WarehouseFromRef = ref();
const statusForm = ref<WarehouseStatusForm>(new WarehouseStatusForm());

const switchRef = ref();
// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};

// 「新增菜单」按钮点击触发
const handleAddClick = (type: string, record?: WarehouseListItem) => {
  WarehouseFromRef.value.handleShowModal(type, type === 'edit' ? record :
    {});
};

//详情
const handleDetailsClick = (data: WarehouseListItem) => {
  emits('details', data.id)
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: WarehouseListItem, index: number) => {
  statusForm.value.id = record?.id + '';
  statusForm.value.status = !record?.status;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

const handleStatus = async () => {
  try {
    const res = await getStatusUpdate(statusForm.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 返回列表
const list = computed(() => {
	return props.list as Array<WarehouseListItem>
})
</script>