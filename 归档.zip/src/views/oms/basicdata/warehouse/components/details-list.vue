<!-- 基础资料->快递管理->详情列表 -->
<template>
  <oms-table :simplePagination="true" :loading="loading">
    <template #header-left>
      <a-button v-permission="['oms:basicdata:warehouse:addConfigure']" type="primary" style="margin-bottom:10px;"
        status="normal" @click="handleAddClick('add', '')"> 新增虚拟仓配置
      </a-button>
    </template>

    <a-table stripe :bordered="{ wrapper: false }" :scroll="{ x: 1400 }" :data="(list as any)" :pagination="false">
      <template #columns>
        <a-table-column title="虚拟仓编码" ellipsis tooltip :width="180" data-index="virtualWarehouseCode"></a-table-column>
        <a-table-column title="虚拟仓名称" ellipsis tooltip :width="180" data-index="virtualWarehouseName"></a-table-column>
        <a-table-column title="虚拟仓类型" ellipsis tooltip :width="180" data-index="virtualWarehouseTypeName"></a-table-column>
        <a-table-column title="状态" :width="180" data-index="status">
          <template #cell="{ record, rowIndex }">
            <a-switch v-permission="['oms:basicdata:warehouse:statusConfigure']" v-model="record.status"
              @focus="onSwitchForce(record, rowIndex)">
              <template #checked>
                启用
              </template>
              <template #unchecked>
                禁用
              </template>
            </a-switch>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" :width="180" data-index="createTime"></a-table-column>
        <a-table-column title="修改时间" :width="180" data-index="updateTime"></a-table-column>
        <a-table-column title="操作" :width="80" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-link v-permission="['oms:basicdata:warehouse:editConfigure']" @click="handleAddClick('edit', record)"
              type="text">编辑</a-link>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑 -->
  <form-details ref="DetailsRef" :warehouseId="warehouseId" @reload-details="emits('reload-details')"></form-details>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleStatusChange"></oms-warning>
</template>

<script setup lang="ts" name="system-warehouse-list">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import FormDetails from './form-details.vue'
import { VirtualWarehouseType, WarehouseStatusForm } from '@/types/basicdata/warehouse';
import { Message } from '@arco-design/web-vue';
import { getEnableVirtualUpdate } from '@/api/basicdata/warehouse';
const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  warehouseId: { type: Number, default: 0 }
});
const emits = defineEmits<{
  (e: "reload-details"): void,
}>();
const statusForm = ref<WarehouseStatusForm>(new WarehouseStatusForm());
const DetailsRef = ref();

const switchRef = ref();
// 「新增」按钮点击触发
const handleAddClick = (type: string, record: any) => {
  DetailsRef.value.handleDetailsShowModal(type, type === 'edit' ? record : '');
};
// 开关获取焦点触发二次确认
const onSwitchForce = async (record: VirtualWarehouseType, index: number) => {
  statusForm.value.id = record?.id + '';
  statusForm.value.status = !record?.status;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}
const handleStatusChange = async () => {
  try {
    const res = await getEnableVirtualUpdate(statusForm.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits('reload-details');
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

</script>