<template>
  <a-form :model="form" layout="horizontal" style="width:100%">
    <a-row>
      <a-col :span="6">
        <a-form-item field="tel" label="联系方式：" label-col-flex="100px">
          <div class="details-box">
            {{ form.tel }}
          </div>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="email" label="电子邮箱：" label-col-flex="130px">
          <div class="details-box">
            {{ form.email }}
          </div>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="area" label="仓库区域：" label-col-flex="130px">
          <div class="details-box">
            {{ form.province ? form.province + '/' : '' }} {{ form.city ? form.city + '/' : '' }} {{ form.area }}
          </div>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="address" label="详细地址：" label-col-flex="130px">
          <a-tooltip :content="form.address">
            <div class="details-box">{{ form.address }}</div>
          </a-tooltip>
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="6">
        <a-form-item field="consignorCode" label="货主编码：" label-col-flex="100px">
          <a-tooltip :content="form.consignorCode">
            <div class="details-box">{{ form.consignorCode }}</div>
          </a-tooltip>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="thirdWarehouseCode" label="第三方仓库编码：" label-col-flex="130px">
          <a-tooltip :content="form.thirdWarehouseCode">
            <div class="details-box">{{ form.thirdWarehouseCode }}</div>
          </a-tooltip>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="value1" label="支持配货：" label-col-flex="130px">
          <div class="details-box">
            {{ form.distribution ? '是' : '否' }}
          </div>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="recommendPackage" label="推荐包材：" label-col-flex="130px">
          <div class="details-box">
            {{ form.recommendPackage ? '是' : '否' }}
          </div>
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="6">
        <a-form-item field="expressName" label="默认快递：" label-col-flex="100px">
          <a-tooltip :content="form.expressName">
            <div class="details-box">{{ form.expressName }}</div>
          </a-tooltip>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="dayOrderMaxAmount" label="当日最大单量：" label-col-flex="130px">
          <div class="details-box">
            {{ form.dayOrderMaxAmount }}
          </div>
        </a-form-item>
      </a-col>
    </a-row>
  </a-form>
</template>
<script setup lang="ts" name="system-warehouse-other-info">
import { WarehouseDetail } from '@/types/basicdata/warehouse';
import { reactive, ref } from 'vue';

const props = defineProps({
  form: {
    type: Object, default: new WarehouseDetail()
  },
});
</script>
<style lang="less" scoped>
.arco-form-item-content {
  .details-box {
    width: 208px;
    height: 32px;
    background-color: #F6F6F6;
    border-radius: 2px;
    font-size: 13px;
    line-height: 32px;
    padding: 0 14px;
    overflow: hidden; // 溢出隐藏
    white-space: nowrap; // 强制一行
    text-overflow: ellipsis; // 文字溢出显示省略号
  }
}
</style>