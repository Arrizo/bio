<!-- 基础资料->仓库管理->虚拟仓编辑表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="500px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose
    :ok-loading="loading">
    <a-form :model="form" ref="formRef" layout="horizontal">
      <a-form-item field="virtualWarehouseCode" label="虚拟仓编码：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入虚拟仓编码' }]">
        <a-input :maxLength="50" v-limit-input="['#', '']" v-model.trim="form.virtualWarehouseCode" placeholder="请输入"
          @input="form.virtualWarehouseCode = form.virtualWarehouseCode.replace(/[\u4e00-\u9fa5]/g, '')" allowClear />
      </a-form-item>
      <a-form-item field="virtualWarehouseName" label="虚拟仓名称：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入虚拟仓名称' }]">
        <a-input :maxLength="60" v-limit-input="['#', '']" v-model.trim="form.virtualWarehouseName" placeholder="请输入"
          allow-clear />
      </a-form-item>
      <a-form-item field="virtualWarehouseType" label="虚拟仓类型：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择虚拟仓类型' }]">
        <a-select placeholder="请选择" v-model="form.virtualWarehouseType">
          <a-option v-for="(item) in virtualWarehouseList" :label="item.dictionaryTitle" :value="item.id"></a-option>
        </a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-warehouse-form-details">

import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { AddVirtualForm, VirtualWarehouseType } from '@/types/basicdata/warehouse';
import { DictionaryType } from '@/types/system/dictionary';
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { addVirtual, updateVirtual } from '@/api/basicdata/warehouse';
const form = ref<AddVirtualForm>(new AddVirtualForm());
let virtualWarehouseList = ref<DictionaryType[]>();
// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});
const props = defineProps({
  warehouseId: { type: Number, default: 0 }
});
const emits = defineEmits<{
  (e: "reload-details"): void,
}>();
const formRef = ref();
const loading = ref<boolean>(false);
/** 点击确定按钮时触发 */
const onOk = async () => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  try {
    loading.value = true;
    const apiType = editModal.type === 'add' ? addVirtual : updateVirtual;

    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload-details");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  } finally {
    loading.value = false;
  }
}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => {


}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleDetailsShowModal = async (type: "add" | "edit", data: VirtualWarehouseType) => {
  editModal.type = type;
  editModal.show = true;
  if (type === 'add') {
    form.value = new AddVirtualForm();
    //获取虚拟仓类型
    virtualWarehouseList.value = await getDictionaryList('VIRTUAL_WAREHOUSE_TYPE');
  } else {
    form.value.id = data.id;
    form.value.virtualWarehouseCode = data.virtualWarehouseCode || '';
    form.value.virtualWarehouseName = data.virtualWarehouseName || '';
    form.value.virtualWarehouseType = data.virtualWarehouseType || '';
    //获取虚拟仓类型
    virtualWarehouseList.value = await getValidDictionaryList('VIRTUAL_WAREHOUSE_TYPE');
  }

  form.value.warehouseId = props.warehouseId;
}

defineExpose({
  handleDetailsShowModal
});
</script>