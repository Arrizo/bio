<!-- 基础资料->仓库管理->搜索组件 -->
<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="warehouseCode" label="实体仓编码：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.warehouseCode" placeholder="请输入" allow-clear />
    </a-form-item>
    <a-form-item field="warehouseName" label="实体仓名称：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model="form.warehouseName" placeholder="请输入" allow-clear />
    </a-form-item>
    <a-form-item field="warehouseType" label="实体仓类型：">
      <a-select placeholder="请选择"  v-model="form.warehouseType" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option v-for="(item) in physicalWarehouseList" :label="item.dictionaryTitle" :value="item.id"></a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="(form.status as string)" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="system-warehouse-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { getDictionaryList } from '@/hooks/useDictionary';
import { WarehouseSearchReq } from '@/types/basicdata/warehouse';
import { DictionaryType } from '@/types/system/dictionary';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false },
  // standardExpressList:{type:Array<DictionaryTitleType>,default:()=>[]}
});
const formRes = ref();
const emits = defineEmits<{
  (e: "on-search", data: WarehouseSearchReq): void;
}>();
let physicalWarehouseList=ref<DictionaryType[]>()
const form = ref<WarehouseSearchReq>(new WarehouseSearchReq());

const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

onMounted(async () => {
  handleSearch();
  //获取实体仓类型
  physicalWarehouseList.value = await getDictionaryList('WAREHOUSE_TYPE')
});
</script>