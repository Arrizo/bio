<!-- 基础资料->仓库管理->新增编辑表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="800px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose
    :ok-loading="loading">
    <a-form :model="form" ref="warehouseFromRef" layout="horizontal">
      <!-- 基本信息 -->
      <p class="form-title" style="margin-top: 0;">基本信息</p>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="warehouseCode" label="实体仓编码：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请输入实体仓编码' }]">
            <a-input :maxLength="50" v-limit-input="['#', '']" v-model.trim="form.warehouseCode" placeholder="请输入" @input="
              form.warehouseCode = form.warehouseCode.replace(/[\u4e00-\u9fa5]/g, '')
            " allowClear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="warehouseName" label="实体仓名称：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请输入实体仓名称' }]">
            <a-input v-limit-input="['#', '']" :maxLength="100" v-model.trim="form.warehouseName" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="warehouseType" label="实体仓类型：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请选择实体仓类型' }]">
            <a-select placeholder="请选择" v-model="form.warehouseType">
              <a-option v-for="item in physicalWarehouseList" :label="item.dictionaryTitle" :value="item.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <a-form-item field="owner" label="仓库负责人：" label-col-flex="130px" :required="isRequried"
            :rules="rulesCheck('input', '仓库负责人')">
            <a-input v-limit-input="['#', '']" v-model.trim="form.owner" :maxLength="50" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <a-form-item field="company" label="所属公司：" label-col-flex="130px" :required="isRequried"
            :rules="rulesCheck('select', '所属公司')">
            <a-select placeholder="请选择" v-model="form.company">
              <a-option v-for="item in companyList" :label="item.dictionaryTitle" :value="item.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <a-form-item field="supplierName" label="仓储供应商：" label-col-flex="130px" :required="isRequried"
            :rules="rulesCheck('input', '仓储供应商')">
            <a-input v-limit-input="['#', '']" :maxLength="100" v-model.trim="form.supplierName" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <!-- 仓库配置 -->
      <p class="form-title" style="margin-top: 20px;">仓库配置</p>
      <a-row :gutter="10">
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <!-- 手机号码、固话号码:/^(0?(13[0-9]|15[012356789]|17[013678]|18[0-9]|14[57])[0-9]{8})|(400|800)([0-9\\-]{7,10})|(([0-9]{4}|[0-9]{3})(-| )?)?([0-9]{7,8})((-| |转)*([0-9]{1,4}))?$/ -->
          <a-form-item field="tel" label="联系方式：" label-col-flex="130px" :rules="rulesPhone">
            <a-input v-model.trim="form.tel" v-limit-input="['#', '']" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <a-form-item field="email" label="电子邮箱：" label-col-flex="130px" :required="isRequried" :rules="emailCheck">
            <a-input v-model.trim="form.email" v-limit-input="['#', '']" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <a-form-item field="expressArr" label="仓库区域：" label-col-flex="130px" :required="isRequried"
            :rules="rulesCheck('cascader', '仓库区域')">
            <a-cascader path-mode ref="cascaderRef" @change="changeArea"
              :field-names="{ value: 'id', label: 'regionName', children: 'child' }" :max-tag-count="1"
              v-model="form.expressArr" check-strictly :allow-clear="true" :options="expressLimitData"
              placeholder="请选择"></a-cascader>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <a-form-item field="address" label="详细地址：" label-col-flex="130px" :required="isRequried"
            :rules="rulesCheck('input', '详细地址')">
            <a-input v-limit-input="['#', '']" :maxLength="300" v-model.trim="form.address" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <a-form-item field="consignorCode" label="货主编码：" label-col-flex="130px" :required="isRequried"
            :rules="rulesCheck('input', '货主编码')">
            <a-input :maxLength="100" v-limit-input="['#', '']" v-model.trim="form.consignorCode" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <!-- 109为委外仓id，若仓库类型=委外仓，此项必填 -->
          <a-form-item field="thirdWarehouseCode" label="第三方仓库编码：" label-col-flex="130px" :required="isRequried"
            :rules="rulesCheck('input', '第三方仓库编码')">
            <a-input :maxLength="100" v-limit-input="['#', '']" v-model.trim="form.thirdWarehouseCode" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="distribution" label="支持配货：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请选择是否支持配货' }]">
            <a-select placeholder="请选择" v-model="form.distribution">
              <a-option label="是" value="true"></a-option>
              <a-option label="否" value="false"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="recommendPackage" label="推荐包材：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请选择推荐包材' }]">
            <a-select placeholder="请选择" v-model="form.recommendPackage">
              <a-option label="是" value="true"></a-option>
              <a-option label="否" value="false"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <!-- 若支持配货=是，此项必填 -->
          <a-form-item field="expressId" label="默认快递：" label-col-flex="130px" :required="distributionVisible"
            :rules="ruleCheck('默认快递')">
            <a-select placeholder="请选择" v-model="form.expressId" allow-search>
              <a-option v-for="item in defaultExpressList" :label="item.expressName" :value="item.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="dayOrderMaxAmount" label="当日最大单量：" label-col-flex="130px">
            <!-- <a-input :max="1000000" v-model.trim="form.dayOrderMaxAmount" v-limit-input="['#', '']" @input="
                      form.dayOrderMaxAmount = form.dayOrderMaxAmount.replace(/^0|[^\d]/g, '')
                    " placeholder="请输入" allow-clear /> -->
            <a-input-number placeholder="请输入" allow-clear v-model="form.dayOrderMaxAmount" :min="0" :max="1000000"
              :precision="0" :formatter="transformNum" :parser="transformNum" />
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-warehouse-form">
import { AddWarehouse, WarehouseListItem } from "@/types/basicdata/warehouse";
import { computed, reactive, ref, watch } from "vue";
import { Message } from "@arco-design/web-vue";
import { getDictionaryList, getValidDictionaryList } from "@/hooks/useDictionary";
import { DictionaryType } from "@/types/system/dictionary";
import {
  addWarehouse,
  getDefaultExpressList,
  updateWarehouse,
  getDetail,
} from "@/api/basicdata/warehouse";
import { getChildAddress } from "@/api/basicdata/express";
import { CascaderType } from "@/types/basicdata/express";

// 菜单编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any;
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});

const emits = defineEmits<{
  (e: "reload"): void;
}>();

const form = ref<AddWarehouse>(new AddWarehouse());
let physicalWarehouseList = ref<DictionaryType[]>();
let companyList = ref<DictionaryType[]>();
let defaultExpressList = ref();
const warehouseFromRef = ref();
const loading = ref<boolean>(false);
const detailLoading = ref<boolean>(false);
const expressLimitData = ref<CascaderType[]>([]);
const cascaderRef = ref();
const isRequried = ref<boolean>(false);
const distributionVisible = ref<boolean>(false);

const changeArea = (val: any) => {
  form.value.provinceId = form.value.expressArr?.[0] ?? null;
  form.value.cityId = form.value.expressArr?.[1] ?? null;
  form.value.areaId = form.value.expressArr?.[2] ?? null;
  //拿取label名
  setTimeout(() => {
    let labelArr = cascaderRef.value.selectViewValue[0].label.split(" / ");
    form.value.province = labelArr?.[0] ?? "";
    form.value.city = labelArr?.[1] ?? "";
    form.value.area = labelArr?.[2] ?? "";
  }, 500);

};

/** 点击确定按钮时触发 */
const onOk = async () => {
  const check = await warehouseFromRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const apiType = editModal.type === "add" ? addWarehouse : updateWarehouse;
    loading.value = true;
    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  } finally {
    loading.value = false;
  }
};

//获取所有省份
const getProvinceList = async () => {
  try {
    const res = await getChildAddress();

    if (res.code != 0) {
      throw new Error(res.message);
    }
    expressLimitData.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
};
/** 点击取消、关闭按钮时触发 */
const onCancel = () => { };

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: WarehouseListItem) => {
  editModal.type = type;
  editModal.show = true;
  if (type === "add") {
    form.value = new AddWarehouse();
    //获取实体仓类型
    physicalWarehouseList.value = await getDictionaryList("WAREHOUSE_TYPE");
    //获取所属公司
    companyList.value = await getDictionaryList("AFFI_COMPANY");
  } else {
    form.value.id = data.id;
    getInfo();
    //获取实体仓类型
    physicalWarehouseList.value = await getValidDictionaryList("WAREHOUSE_TYPE");
    //获取所属公司
    companyList.value = await getValidDictionaryList("AFFI_COMPANY");
  }

  //仓库区域
  getProvinceList();
  //获取默认快递
  getExpressList();
};
//获取其他信息
const getInfo = async () => {
  try {
    detailLoading.value = true;
    const res = await getDetail(form.value.id + "");
    if (res.code != 0) {
      throw new Error(res.message);
    }
    form.value = res.value;
    form.value.distribution = form.value.distribution + "";
    form.value.recommendPackage = form.value.recommendPackage + "";
    let arr: any = [];
    if (form.value.provinceId) {
      arr.push(form.value.provinceId);
      if (form.value.cityId) {
        arr.push(form.value.cityId);
        if (form.value.areaId) {
          arr.push(form.value.areaId);
        }
      }
    }
    form.value.expressArr = arr;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    detailLoading.value = false;
  }
};
//获取默认快递
const getExpressList = async () => {
  try {
    const res = await getDefaultExpressList();

    if (res.code != 0) {
      throw new Error(res.message);
    }
    defaultExpressList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
};
//校验手机号码
const rulesPhone = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (isRequried.value && (!value || value == "")) {
        callback("请输入联系方式");
        return
      }
      if (value) {
        return new Promise<void>((resolve) => {
          const mobileReg = /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;
          const phoneReg = /^\d{3}-\d{8}|\d{4}-\d{7}$/;
          if (value.length === 11) {
            if (!mobileReg.test(value)) callback("请输入正确的手机号码或者固话号码");
          } else {
            if (!phoneReg.test(value)) callback("请输入正确的手机号码或者固话号码");
          }
          resolve();
        });
      }
    },
    required: isRequried.value
  },
]);
//电子邮箱校验
const emailCheck = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (isRequried.value && (!value || value == "")) {
        callback("请输入电子邮箱");
        return
      }
      if (value) {
        return new Promise<void>((resolve) => {
          const regEmail = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
          if (!regEmail.test(value)) callback("请输入正确的电子邮箱");
          resolve();
        });
      }
    },
    required: isRequried.value
  },
]);
//集中处理表单rule验证
const rulesCheck = (type: string, content: string) => {
  if (form.value.warehouseType !== 109) {
    isRequried.value = false;
    return [{ message: `请${type === "input" ? "输入" : "选择"}${content}` }];
  }
  isRequried.value = true;
  return [
    { required: true, message: `请${type === "input" ? "输入" : "选择"}${content}` },
  ];
};
//数字输入框限制只能输入大于等于零的整数
const transformNum = (value: string | number) => {
  let v = null
  switch (typeof value) {
    case 'string':
      v = isNaN(+value) ? 0 : value.replace(/\./g, '')
      break
    case 'number':
      v = isNaN(value) ? 0 : String(value).replace(/\./g, '')
      break
    default:
      v = 0
  }
  return v
}

//集中处理表单rule验证
const ruleCheck = (content: string) => {
  if (form.value.distribution !== "true") {
    distributionVisible.value = false;
    return [{ message: `请选择${content}` }];
  }
  distributionVisible.value = true;
  return [{ required: true, message: `请选择${content}` }];
};

defineExpose({
  handleShowModal,
});
</script>
<style lang="less" scoped>
.form-title {
  color: #3A3A3A;
  font-size: 13px;
  font-weight: bold;
  line-height: 17px;
}
</style>
