<template>
  <div class="warehouse-details">
    <a-tabs :style="{ width: '100%' }" :active-key="tabValue" @change="changeTab">
      <template #extra>
        <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
      </template>
      <a-tab-pane key="info" title="其他信息">
        <other-info :form="detailsData"></other-info>
      </a-tab-pane>
      <a-tab-pane key="config" title="虚拟仓配置">
        <details-list :list="virtualList" :warehouseId="warehouseId" @reload-details="getVirtualData"
          :loading="virtualLoading"></details-list>
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script setup lang="ts" name="system-warehouse-details">
import DetailsList from './details-list.vue';
import OtherInfo from './other-info.vue'
import { onMounted, ref, watch } from 'vue';
import { getDetail, getVirtualList } from '@/api/basicdata/warehouse';
import { Message } from '@arco-design/web-vue';
import { VirtualWarehouseType, WarehouseDetail } from '@/types/basicdata/warehouse';
let show = ref(false);
let warehouseId = ref();
let detailLoading = ref(false);
let virtualLoading = ref(false);
let detailsData = ref<WarehouseDetail>(new WarehouseDetail())
let virtualList = ref<VirtualWarehouseType[]>()
let tabValue = ref('info')
const props = defineProps({
  warehouseId: {
    type: Number, default: NaN
  },
});
const emits = defineEmits<{
  (e: "close"): void,
}>();



//关闭详情
const closeDetails = () => {
  emits('close')
}

const changeTab = (val: any) => {
  tabValue.value = val;
  if (val == 'config') {
    getVirtualData();
  } else {
    getInfo();
  }
}
//获取虚拟仓配置
const getVirtualData = async () => {
  try {
    virtualLoading.value = true;
    const res = await getVirtualList(warehouseId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    virtualList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    virtualLoading.value = false;
  }
}
//获取其他信息
const getInfo = async () => {
  try {
    detailLoading.value = true;
    const res = await getDetail(warehouseId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    detailsData.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    detailLoading.value = false;
  }
}
watch(() => props.warehouseId, () => {
  warehouseId.value = props.warehouseId;
  tabValue.value = 'info';
  getInfo()
}, {
  immediate: true,
  deep: true
});
</script>

<style lang="less">
.warehouse-details {
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  .arco-tabs-content {
    padding-left: 16px;
    padding-right: 16px;
  }

  .arco-tabs-nav {
    padding: 0 16px;
  }
}
</style>