// 合作模式
<template>
  <div>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.cooperationModeList as any)" :pagination="false" :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="合作模式" :width="180" data-index="cooperationModeName"></a-table-column>
        <a-table-column title="发货时效" :width="180" data-index="deliveryTimelinessName"></a-table-column>
        <a-table-column title="售后支持" :width="180" data-index="afterSupportName"></a-table-column>
        <a-table-column title="结算方式" :width="180" data-index="settlementMethodName"></a-table-column>
        <a-table-column title="账期" :width="180" data-index="accountingPeriod"></a-table-column>
      </template>
    </a-table>
  </div>
</template>
<script setup lang="ts" name="system-supplier-finance-info">
import { SupplierFrom } from '@/types/basicdata/supplier';
const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
</script>