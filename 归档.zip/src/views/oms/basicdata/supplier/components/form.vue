<!-- 系统设置-供应商管理-添加/编辑角色表单 -->
<template>
  <a-modal class="supplierFrom" :title="editModal.type === 'add' ? '新增' : '编辑'" width="800px"
    v-model:visible="editModal.show" unmountOnClose :esc-to-close="false" @close="handleCancel" :mask-closable="false" title-align="start">
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-tabs :style="{ width: '100%' }" :active-key="tabValue" @change="changeTab">
        <!-- 基本信息 -->
        <a-tab-pane key="basic-info" title="基本信息">
          <basic-info ref="basicInfoRef" :form="form" :developerList="developerList" :buyerList="buyerList"
            :supplierCategoryList="supplierCategoryList" :supplierAttrList="supplierAttrList"
            :expressLimitData="expressLimitData"
            :registeredCapitalCurrencyList="registeredCapitalCurrencyList"></basic-info>
        </a-tab-pane>
        <!-- 财务信息 -->
        <a-tab-pane key="finance-info" title="财务信息">
          <finance-info :form="form"></finance-info>
        </a-tab-pane>
        <!-- 联系人 -->
        <a-tab-pane key="contacts" title="联系人">
          <contacts :form="form"></contacts>
        </a-tab-pane>
        <!-- 合作模式 -->
        <a-tab-pane key="cooperation-mode" title="合作模式">
          <cooperation-mode :form="form"></cooperation-mode>
        </a-tab-pane>
        <!-- 品牌信息 -->
        <a-tab-pane key="brand-info" title="品牌信息">
          <brand-info :form="form"></brand-info>
        </a-tab-pane>
        <!-- 附件资料 -->
        <a-tab-pane key="annex-data" title="附件资料">
          <annex-data :form="form"></annex-data>
        </a-tab-pane>
      </a-tabs>
    </a-form>
    <template #footer>
      <a-space :size="14">
        <a-button @click="handleCancel">取消</a-button>
        <a-button type="outline" @click="submit(2)">保存</a-button>
        <a-button type="primary" @click="submit(1)">确定</a-button>
      </a-space>
    </template>
  </a-modal>
</template>

<script setup lang="ts" name="system-role-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import BasicInfo from './edit-form/basic-info.vue';
import FinanceInfo from './edit-form/finance-info.vue';
import Contacts from "./edit-form/contacts.vue";
import CooperationMode from './edit-form/cooperation-mode.vue'
import BrandInfo from './edit-form/brand-info.vue';
import AnnexData from './edit-form/annex-data.vue';
import { SupplierFrom, SupplierType } from '@/types/basicdata/supplier';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { addOrUpdate, getDetailInfo } from '@/api/basicdata/supplier';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { CascaderType } from '@/types/basicdata/express';
import { getChildAddress } from '@/api/basicdata/express';

const props = defineProps({
  supplierCategoryList: { type: Array<DictionaryTitleType>, default: () => [] },
  supplierAttrList: { type: Array<DictionaryTitleType>, default: () => [] },
  developerList: { type: Array, default: () => [] },
  buyerList: { type: Array, default: () => [] },
});
const registeredCapitalCurrencyList = ref<DictionaryTitleType[]>();
// 角色编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const basicInfoRef = ref();
const form = ref<SupplierFrom>(new SupplierFrom());
const tabValue = ref('basic-info');
const expressLimitData = ref<CascaderType[]>();

const changeTab = (val: any) => {
  tabValue.value = val;
}
/** 点击确定按钮前触发 */
const submit = async (type: number) => {
  form.value.submitType = type;
  if (!basicInfoRef.value.checkFrom()) {
    return false;
  }
  // 财务信息、联系人、合作模式、品牌信息至少一条数据
  let finance = !!form.value.bankCardList.length;
  let brand = !!form.value.brandList.length;
  let contants = !!form.value.contactsList.length;
  let cooperation = !!form.value.cooperationModeList.length;
  let arr = [finance, brand, contants, cooperation]
  if (arr.includes(false)) {
    Message.error('维护信息不全，请检查；');
    return false;
  }

  try {
    const res = await addOrUpdate(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    handleCancel();
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 关闭弹框
const handleCancel = () => {
  editModal.show = false;
  form.value = new SupplierFrom();
}


//获取所有省份
const getProvinceList = async () => {
  try {
    const res = await getChildAddress();

    if (res.code != 0) {
      throw new Error(res.message);
    }
    expressLimitData.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
};

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", id: number) => {
  editModal.type = type;
  editModal.show = true;
  tabValue.value = 'basic-info';
  getProvinceList();
  if (type === 'add') {
    form.value = new SupplierFrom();
    //注册资本货币
    registeredCapitalCurrencyList.value = await getDictionaryList('REGISTERED_CAPITAL_CURRENCY')
  } else {
    //注册资本货币
    registeredCapitalCurrencyList.value = await getValidDictionaryList('REGISTERED_CAPITAL_CURRENCY')
    try {
      let params = {
        id: id,
        isUpdate: true//编辑回显true，详情true
      };
      const res = await getDetailInfo(params);
      if (res.code != 0) {
        throw new Error(res.message);
      }
      let data = res.value;
      form.value = data;
      form.value.id = id;
      form.value.registeredCapital = Number(res.value.registeredCapital)
    } catch (err) {
      Message.error((err as Error).message);
    }
  }
}

defineExpose({
  handleShowModal
});
</script>
<style lang="less" >
.supplierFrom {
  .arco-modal-body {
    height: 564px;
    padding: 9px 32px 24px 32px !important;
  }
}
</style>