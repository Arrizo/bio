// 品牌信息
<template>
  <div>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.brandList as any)" :pagination="false"
      :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="代理品牌" :width="180" data-index="agentBrand"></a-table-column>
        <a-table-column title="授权级别" :width="180" data-index="authorizeLevelName"></a-table-column>
        <a-table-column title="授权有效期" :width="180">
          <template #cell="{ record }">
            {{  record.startTime }}{{ record.startTime ? '~' + record.endTime : '' }}
          </template>
        </a-table-column>
      </template>
    </a-table>
  </div>
</template>
<script setup lang="ts" name="system-supplier-finance-info">
import { SupplierFrom } from '@/types/basicdata/supplier';
const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
</script>