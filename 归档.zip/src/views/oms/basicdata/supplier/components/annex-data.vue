// 附件资料
<template>
  <div>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.fileList as any)" :pagination="false"
      :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="附件类型" :width="180" data-index="fileTypeName"></a-table-column>
        <a-table-column title="附件" :width="180" data-index="fileName"></a-table-column>
        <a-table-column title="操作" :width="180">
          <template #cell="{ record }">
            <a :href="record.url" class="uploadStyle" target="_blank">下载</a>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </div>
</template>
<script setup lang="ts" name="system-supplier-finance-info">
import { SupplierFrom } from '@/types/basicdata/supplier';
const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
//下载
const handleClick = (url: string) => {
  window.location.href = url;
}
</script>
<style lang="less" scoped>
.uploadStyle{
  cursor: pointer;
  color: rgb(var(--link-6));
  text-decoration: none;
  font-size: 13px;
}
</style>