// 财务信息
<template>
  <div>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.bankCardList as any)" :pagination="false" :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="银行账号" :width="180" data-index="bankCardNo"></a-table-column>
        <a-table-column title="账户名称" :width="180" data-index="accountName"></a-table-column>
        <a-table-column title="开户银行" :width="180" data-index="bankBranchName"></a-table-column>
        <a-table-column title="联行号" :width="180" data-index="interbankNo"></a-table-column>
      </template>
    </a-table>
  </div>
</template>
<script setup lang="ts" name="system-supplier-finance-info">
import { SupplierFrom } from '@/types/basicdata/supplier';

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
</script>