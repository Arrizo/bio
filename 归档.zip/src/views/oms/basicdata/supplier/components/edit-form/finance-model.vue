<!-- 基础资料->供应商管理->财务信息表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="500px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form :model="bankForm" ref="formRef" layout="horizontal">
      <a-form-item field="bankCardNo" label="银行账号：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入银行账号' }]">
        <a-input v-limit-input="['#', '']" @input="bankForm.bankCardNo = bankForm.bankCardNo.replace(/\D/g, '')"
          :maxLength="200" v-model.trim="bankForm.bankCardNo" placeholder="请输入" allow-clear />
      </a-form-item>
      <a-form-item field="accountName" label="账户名称：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入账户名称' }]">
        <a-input v-limit-input="['#', '']" :maxLength="200" v-model.trim="bankForm.accountName" placeholder="请输入"
          allow-clear />
      </a-form-item>
      <a-form-item field="bankBranchName" label="开户银行：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入开户银行' }]">
        <a-input v-limit-input="['#', '']" :maxLength="200" v-model.trim="bankForm.bankBranchName" placeholder="请输入"
          allow-clear />
      <!-- <a-select placeholder="请选择"  allow-clear v-model="form.supplierCategory">
            <a-option v-for="(item) in supplierCategoryList" :label="item.dictionaryTitle"
              :value="item.dictionaryValue"></a-option>
              </a-select> -->
      </a-form-item>
      <a-form-item field="interbankNo" label="联行号：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入联行号' }]">
        <a-input v-limit-input="['#', '']" :maxLength="50"
          @input="bankForm.interbankNo = bankForm.interbankNo.replace(/[\u4e00-\u9fa5]/g, '')"
          v-model.trim="bankForm.interbankNo" placeholder="请输入" allow-clear />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-supplier-finance-model">
import { reactive, ref } from 'vue';
import { BankCardFrom, SupplierFrom } from '@/types/basicdata/supplier';
import { deepClone } from '@/utils/helper';
// 财务信息新增编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any;
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});

const bankForm = ref<BankCardFrom>(new BankCardFrom());
const formRef = ref();
const currentIndex = ref('');
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  if (editModal.type === 'add') {//新增
    props.form.bankCardList.push(bankForm.value);
    return
  }
  //编辑
  props.form.bankCardList.splice(currentIndex.value, 1, bankForm.value)

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: 'add' | 'edit', record: BankCardFrom, index: string) => {
  editModal.show = true;
  editModal.type = type;
  if (type === 'add') {
    bankForm.value = new BankCardFrom();
  } else {
    bankForm.value = deepClone(record);
    currentIndex.value = index;
  }
}


defineExpose({
  handleShowModal
});
</script>