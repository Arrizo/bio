<!-- 基础资料->供应商管理->合作模式表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="500px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form :model="cooperationForm" ref="formRef" layout="horizontal">
      <a-form-item field="cooperationMode" label="合作模式：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择合作模式' }]">
        <a-select placeholder="请选择" v-model="cooperationForm.cooperationMode">
          <a-option v-for="(item) in cooperationModeList" :label="item.dictionaryTitle"
            :value="item.dictionaryValue"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="deliveryTimeliness" label="发货时效：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择发货时效' }]">
        <a-select placeholder="请选择" v-model="cooperationForm.deliveryTimeliness">
          <a-option v-for="(item) in deliveryTimelinessList" :label="item.dictionaryTitle"
            :value="item.dictionaryValue"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="afterSupport" label="售后支持：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择售后支持' }]">
        <a-select placeholder="请选择" v-model="cooperationForm.afterSupport">
          <a-option v-for="(item) in afterSupportList" :label="item.dictionaryTitle"
            :value="item.dictionaryValue"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="settlementMethod" label="结算方式：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择结算方式' }]">
        <a-select placeholder="请选择" v-model="cooperationForm.settlementMethod">
          <a-option v-for="(item) in settlementMethodList" :label="item.dictionaryTitle"
            :value="item.dictionaryValue"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="accountingPeriod" label="账期：" label-col-flex="100px" :rules="rulesPeriod">
        <a-input-number :precision="0" :min="1" v-model="cooperationForm.accountingPeriod" placeholder="请输入"
          allow-clear />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-supplier-cooperation-model">
import { computed, reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { CooperationForm, SupplierFrom } from '@/types/basicdata/supplier';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { deepClone } from '@/utils/helper';
// 财务信息新增编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any;
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});

let afterSupportList = ref<DictionaryTitleType[]>();
let cooperationModeList = ref<DictionaryTitleType[]>();
let deliveryTimelinessList = ref<DictionaryTitleType[]>();
let settlementMethodList = ref<DictionaryTitleType[]>();
const currentIndex = ref('');
const cooperationForm = ref<CooperationForm>(new CooperationForm());
const formRef = ref();
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  cooperationForm.value.cooperationModeName = getName(cooperationModeList.value, cooperationForm.value.cooperationMode) || '';
  cooperationForm.value.afterSupportName = getName(afterSupportList.value, cooperationForm.value.afterSupport) || '';
  cooperationForm.value.deliveryTimelinessName = getName(deliveryTimelinessList.value, cooperationForm.value.deliveryTimeliness) || '';
  cooperationForm.value.settlementMethodName = getName(settlementMethodList.value, cooperationForm.value.settlementMethod) || '';


  //判断是否存在需要添加的合作模式
  let isAdd = props.form.cooperationModeList.some((item: { cooperationMode: any; }) => item.cooperationMode === cooperationForm.value.cooperationMode)
  if (isAdd) {
    Message.error('已存在该合作模式');
    return false;
  }
  // 结算方式为月结时，账期不能大于31
  if (cooperationForm.value.settlementMethod === 'month' && Number(cooperationForm.value.accountingPeriod) > 31) {
    Message.error('账期不能大于31');
    return false;
  }
  if (editModal.type === 'add') {//新增
    props.form.cooperationModeList.push(cooperationForm.value);
    return;
  }

  //编辑
  props.form.cooperationModeList.splice(currentIndex.value, 1, cooperationForm.value)

}

const getName = (arr: DictionaryTitleType[] = [], val: any) => {
  let idx = arr?.findIndex((item) => item.dictionaryValue === val);
  if (idx != -1) {
    return arr?.[idx as number].dictionaryTitle || ''
  }
}

//验证账期
const rulesPeriod = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (cooperationForm.value.settlementMethod === 'month' && (!value || value == "")) {
        callback("请输入账期");
        return
      }
    },
    required: cooperationForm.value.settlementMethod === 'month'
  },
]);

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: 'add' | 'edit', record: CooperationForm, index: string) => {
  editModal.show = true;
  editModal.type = type;

  if (type === 'add') {
    cooperationForm.value = new CooperationForm();
    //售后支持
    afterSupportList.value = await getDictionaryList('AFTER_SUPPORT')
    //合作模式
    cooperationModeList.value = await getDictionaryList('COOPERATION_MODE')
    //发货时效
    deliveryTimelinessList.value = await getDictionaryList('DELIVERY_TIMELINESS')
    //结算方式
    settlementMethodList.value = await getDictionaryList('SETTLEMENT_METHOD')
  } else {
    //售后支持
    afterSupportList.value = await getValidDictionaryList('AFTER_SUPPORT')
    //合作模式
    cooperationModeList.value = await getValidDictionaryList('COOPERATION_MODE')
    //发货时效
    deliveryTimelinessList.value = await getValidDictionaryList('DELIVERY_TIMELINESS')
    //结算方式
    settlementMethodList.value = await getValidDictionaryList('SETTLEMENT_METHOD')
    cooperationForm.value = deepClone(record);
    currentIndex.value = index;
  }
}


defineExpose({
  handleShowModal
});
</script>