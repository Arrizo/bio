<!-- 基础资料->供应商管理->附件表单组件 -->
<template>
  <a-modal :mask-closable="false" title="新增" width="500px" v-model:visible="editModal.show" title-align="start"
    :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form :model="fileForm" ref="formRef" layout="horizontal">
      <a-form-item field="fileType" label="附件类型：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择附件类型' }]">
        <a-select placeholder="请选择" v-model="fileForm.fileType" @change="getFileName">
          <a-option v-for="(item) in fileTypeList" :label="item.dictionaryTitle" :value="item.dictionaryValue"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="url" label="上传文件：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择上传文件' }]">
        <div class="uploader-container">
          <file-uploader ref="uploaderFile" v-model="fileForm.url" module="COMMON_FILE" :size="1024 * 1024 * 10"
            :fileType="2" accept=".xlsx,.xls,.doc,.docx,.pdf,.jpg,.png,.jpeg"></file-uploader>
          <div class="sign">只能上传xlsx/xls/doc/docx/pdf/jpg/png/jpeg格式文件，限制10Mb</div>
        </div>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-supplier-annex-model">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { FileFrom, SupplierFrom } from '@/types/basicdata/supplier';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { DictionaryTitleType } from '@/types/system/dictionary';
import fileUploader from '@/components/file-uploader/index.vue';
// 新增编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any;
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
const fileTypeList = ref<DictionaryTitleType[]>();
const fileForm = ref<FileFrom>(new FileFrom());
const formRef = ref();
const uploaderFile = ref();
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  if (fileForm.value.url) {
    fileForm.value.fileName = uploaderFile.value.fileName;
  }
  props.form.fileList.push(fileForm.value)
}


const getFileName = (val: any) => {
  let idx = fileTypeList.value?.findIndex((item) => item.dictionaryValue === val);
  if (idx != -1) {
    fileForm.value.fileTypeName = fileTypeList.value?.[idx as number].dictionaryTitle || ''
  }
}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: 'add' | 'edit') => {
  editModal.show = true;
  editModal.type = type;
  if (type === 'add') {
    fileForm.value = new FileFrom();
    //附件类型
    fileTypeList.value = await getDictionaryList('FILE_TYPE')
  } else {
    //附件类型
    fileTypeList.value = await getValidDictionaryList('FILE_TYPE')
  }
}


defineExpose({
  handleShowModal
});
</script>
<style lang="less" scoped>
.uploader-container {
  margin-top: 4px;

  .sign {
    font-size: 12px;
    font-weight: 400;
    line-height: 16px;
    color: #999999;
    opacity: 1;
  }
}
</style>