// 附件资料
<template>
  <oms-table>
    <template #header-left>
      <a-button type="primary" style="margin-bottom: 10px;" status="normal" @click="handleClick('add')"> 新增 </a-button>
    </template>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.fileList as any)" :pagination="false"
      :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="附件类型" ellipsis tooltip :width="180" data-index="fileTypeName"></a-table-column>
        <a-table-column title="附件" ellipsis tooltip :width="180" data-index="fileName"></a-table-column>
        <a-table-column title="操作" :width="180">
          <template #cell="{ record, rowIndex }">
            <a-link @click="handleClick('del', rowIndex)" type="text" status="danger">删除</a-link></template>
        </a-table-column>
      </template>
    </a-table>
    <!-- 编辑 -->
    <annex-model ref="annexRef" :form="form"></annex-model>

    <!-- 删除二次确认 -->
    <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>
  </oms-table>
</template>
<script setup lang="ts" name="system-supplier-annex-data">
import { reactive, ref } from 'vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import AnnexModel from './annex-model.vue';
import OmsTable from '@/components/oms-table/index.vue';
import { FileType, SupplierFrom } from '@/types/basicdata/supplier';
const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
const annexRef = ref()
const warnignRef = ref();
const currentIndex = ref();

//操作
const handleClick = (type: "add" | "del", rowIndex?: string) => {
  if (type === 'del') {
    currentIndex.value = rowIndex;
    warnignRef.value.open();
    return
  }
  annexRef.value.handleShowModal(type)
}

const handleDelete = () => {
  props.form.fileList.splice(currentIndex.value, 1);
  return true;
}
</script>