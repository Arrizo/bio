// 联系人
<template>
  <oms-table>
    <template #header-left>
      <a-button type="primary" style="margin-bottom: 10px;" status="normal" @click="handleClick('add')"> 新增 </a-button>
    </template>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.contactsList as any)" :pagination="false"
      :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="联系人" ellipsis tooltip :width="180" data-index="contacts"></a-table-column>
        <a-table-column title="职务" ellipsis tooltip :width="180" data-index="job"></a-table-column>
        <a-table-column title="手机号码" :width="180" data-index="mobile"></a-table-column>
        <a-table-column title="固定电话" ellipsis tooltip :width="180" data-index="fixedPhone"></a-table-column>
        <a-table-column title="电子邮箱" ellipsis tooltip :width="180" data-index="mail"></a-table-column>
        <a-table-column title="操作" :width="120" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-space :size="28">
              <a-link @click="handleClick('edit', record, rowIndex)" type="text">编辑</a-link>
              <a-link @click="handleClick('del', record, rowIndex)" type="text" status="danger">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
    <!-- 编辑 -->
    <contacts-model ref="contactsRef" :form="props.form"></contacts-model>

  <!-- 删除二次确认 -->
  <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>
  </oms-table>
</template>
<script setup lang="ts" name="system-supplier-contacts">
import { reactive, ref } from 'vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import ContactsModel from './contacts-model.vue';
import OmsTable from '@/components/oms-table/index.vue';
import { ContactsType, SupplierFrom } from '@/types/basicdata/supplier';
const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
const contactsRef = ref()
const warnignRef = ref();
const currentIndex = ref();

//操作
const handleClick = (type: "add" | "edit" | "del", record?: ContactsType, rowIndex?: string) => {
  if (type === 'del') {
    currentIndex.value = rowIndex;
    warnignRef.value.open();
    return
  }
  contactsRef.value.handleShowModal(type, type === 'edit' ? record : {}, type === 'edit' ? rowIndex : '')
}

const handleDelete = () => {
  props.form.contactsList.splice(currentIndex.value, 1);
  return true;
}
</script>