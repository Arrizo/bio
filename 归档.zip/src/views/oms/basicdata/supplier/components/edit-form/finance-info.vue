// 财务信息
<template>
  <oms-table>
    <template #header-left>
      <a-button type="primary" style="margin-bottom: 10px;" status="normal" @click="handleClick('add')"> 新增 </a-button>
    </template>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.bankCardList as any)" :pagination="false"
      :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="银行账号" ellipsis tooltip :width="180" data-index="bankCardNo"></a-table-column>
        <a-table-column title="账户名称" ellipsis tooltip :width="180" data-index="accountName"></a-table-column>
        <a-table-column title="开户银行" ellipsis tooltip :width="180" data-index="bankBranchName"></a-table-column>
        <a-table-column title="联行号" ellipsis tooltip :width="180" data-index="interbankNo"></a-table-column>
        <a-table-column title="操作" :width="120" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-space :size="28">
              <a-link @click="handleClick('edit', record, rowIndex)" type="text">编辑</a-link>
              <a-link @click="handleClick('del', record, rowIndex)" type="text" status="danger">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
    <!-- 新增编辑弹框 -->
    <edit-form ref="editFromRef" :form="props.form"></edit-form>

    <!-- 删除二次确认 -->
    <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>
  </oms-table>
</template>
<script setup lang="ts" name="system-supplier-finance-info">
import { reactive, ref, onMounted } from 'vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import OmsTable from '@/components/oms-table/index.vue';
import EditForm from './finance-model.vue'
import { BankCardFrom, BankCardType, SupplierFrom } from '@/types/basicdata/supplier';
const editFromRef = ref()

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
const warnignRef = ref();
const currentIndex = ref();

//操作
const handleClick = (type: "add" | "edit" | "del", record?: BankCardType, rowIndex?: string) => {

  if (type === 'del') {
    currentIndex.value = rowIndex;
    warnignRef.value.open();
    return
  }
  editFromRef.value.handleShowModal(type, type === 'edit' ? record : {}, type === 'edit' ? rowIndex : '')
}

const handleDelete = () => {
  props.form.bankCardList.splice(currentIndex.value, 1);
  return true;
}

</script>