// 品牌信息
<template>
  <oms-table>
    <template #header-left>
      <a-button type="primary" style="margin-bottom: 10px;" status="normal" @click="handleClick('add')"> 新增 </a-button>
    </template>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.brandList as any)" :pagination="false"
      :scroll="{ x: 1400 }">
      <template #columns>
        <a-table-column title="代理品牌" ellipsis tooltip :width="120" data-index="agentBrand"></a-table-column>
        <a-table-column title="授权级别" ellipsis tooltip :width="120" data-index="authorizeLevelName"></a-table-column>
        <a-table-column title="授权有效期" :width="300">
          <template #cell="{ record }">
            {{  record.startTime }}{{ record.startTime ? '~' + record.endTime : '' }}
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="120" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-space :size="28">
              <a-link @click="handleClick('edit', record, rowIndex)" type="text">编辑</a-link>
              <a-link @click="handleClick('del', record, rowIndex)" type="text" status="danger">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
    <!-- 编辑 -->
    <brand-model ref="brandRef" :form="form"></brand-model>

  <!-- 删除二次确认 -->
  <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>
  </oms-table>
</template>
<script setup lang="ts" name="system-supplier-brand-info">
import { reactive, ref } from 'vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import BrandModel from './brand-model.vue';
import OmsTable from '@/components/oms-table/index.vue';
import { BrandType, SupplierFrom } from '@/types/basicdata/supplier';

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});

const brandRef = ref()
const warnignRef = ref();
const currentIndex = ref();

//操作
const handleClick = (type: "add" | "edit" | "del", record?: BrandType, rowIndex?: string) => {
  if (type === 'del') {
    currentIndex.value = rowIndex;
    warnignRef.value.open();
    return
  }
  brandRef.value.handleShowModal(type, type === 'edit' ? record : {}, type === 'edit' ? rowIndex : '')
}

const handleDelete = () => {
  props.form.brandList.splice(currentIndex.value, 1);
  return true;
}
</script>