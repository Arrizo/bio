//基础信息
<template>
  <a-form ref="formRef" class="supplier-basic-info" :model="form" layout="horizontal" style="width:100%">
    <a-row>
      <a-col :span="12">
        <a-form-item field="supplierName" label="供应商名称：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请输入供应商名称' }]">
          <a-input :maxLength="200" style="width:208px;" v-limit-input="['#', '']" v-model.trim="form.supplierName"
            placeholder="请输入" allowClear />
        </a-form-item>
      </a-col>
      <a-col :span="12">
        <a-form-item field="shortName" label="简称：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请输入简称' }]">
          <a-input :maxLength="100" v-limit-input="['#', '']" style="width:208px;" v-model.trim="form.shortName"
            placeholder="请输入" allowClear />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="12">
        <a-form-item field="legalRepresentative" label="法人代表：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请输入法人代表' }]">
          <a-input :maxLength="50" style="width:208px;" v-limit-input="['#', '']" v-model.trim="form.legalRepresentative"
            placeholder="请输入" allowClear />
        </a-form-item>
      </a-col>
      <a-col :span="12">
        <a-form-item field="registeredCapital" label="注册资本(万)：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请输入注册资本' }]">
          <!-- <a-input v-model="form.registeredCapital" :maxLength="50"> -->
          <a-input-group class="supplierInput" style="width:208px;">
            <a-input-number class="supplierInput" v-model="form.registeredCapital" :maxLength="50" :precision="2" :min="0"
              placeholder="请输入"></a-input-number>
            <!-- 人民币 -->
            <a-select placeholder="请选择" style="width: 90px;" v-model="form.registeredCapitalCurrency">
              <a-option v-for="(item) in registeredCapitalCurrencyList" :label="item.dictionaryTitle"
                :value="item.dictionaryValue"></a-option>
            </a-select>
          </a-input-group>

          <!-- </a-input> -->
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="12">
        <a-form-item field="incorporationTime" label="成立日期：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请选择成立日期' }]">
          <a-date-picker style="width:208px;" :disabledDate="(current: any) => !dayjs(current).isBefore(dayjs())"
            v-model="form.incorporationTime" />
        </a-form-item>
      </a-col>
      <a-col :span="12">
        <a-form-item field="socialCreditCode" label="社会信用代码：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请输入社会信用代码' }]">
          <a-input style="width:208px;" :maxLength="50" v-limit-input="['#', '']" v-model.trim="form.socialCreditCode"
            placeholder="请输入" allowClear
            @input="form.socialCreditCode = form.socialCreditCode.replace(/[\u4e00-\u9fa5]/g, '')" />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="12">
        <a-form-item field="regionId" label="公司区域：" label-col-flex="120px">
          <a-cascader style="width:208px;" ref="cascaderRef"
            :field-names="{ value: 'id', label: 'regionName', children: 'child' }" v-model="form.regionId"
            :allow-clear="true" :options="expressLimitData" placeholder="请选择"></a-cascader>
        </a-form-item>
      </a-col>
      <a-col :span="12">
        <a-form-item field="detailAddr" label="详细地址：" label-col-flex="120px">
          <a-input style="width:208px;" v-limit-input="['#', '']" v-model.trim="form.detailAddr" placeholder="请输入"
            allowClear />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="24">
        <a-form-item field="businessScope" label="经营范围：" label-col-flex="120px">
          <a-textarea style="width:94%;" v-limit-input="['#', '']" v-model.trim="form.businessScope"
            placeholder="请输入营业执照经营范围" />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="12">
        <a-form-item field="supplierCategory" label="供应商类别：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请选择供应商类别' }]">
          <a-select style="width:208px;" placeholder="请选择" v-model="form.supplierCategory">
            <a-option v-for="(item) in supplierCategoryList" :label="item.dictionaryTitle"
              :value="item.dictionaryValue"></a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :span="12">
        <a-form-item field="supplierAttr" label="供应商属性：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请选择供应商属性' }]">
          <a-select style="width:208px;" placeholder="请选择" v-model="form.supplierAttr">
            <a-option v-for="(item) in supplierAttrList" :label="item.dictionaryTitle"
              :value="item.dictionaryValue"></a-option>
          </a-select>
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="12">
        <a-form-item field="developerIdList" label="开发人员：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请选择开发人员' }]">
        <!-- <a-select placeholder="请选择" multiple :max-tag-count="2" v-model="form.developerIdList">
            <a-option v-for="(item) in developerList" :label="(item as any).nickname"
              :value="(item as any).id"></a-option>
            </a-select> -->
          <oms-multiple-select style="width:208px;" :maxTagCount="1" v-model="form.developerIdList"
            :option-list="(developerList as any)" value="id" label="nickname"></oms-multiple-select>
        </a-form-item>
      </a-col>

      <a-col :span="12">
        <a-form-item field="buyerIdList" label="采购人员：" label-col-flex="120px">
        <!-- <a-select placeholder="请选择" allow-clear multiple :max-tag-count="2" v-model="form.buyerIdList">
            <a-option v-for="item in buyerList" :label="(item as any).nickname" :value="(item as any).id"></a-option>
            </a-select> -->
          <oms-multiple-select style="width:208px;" :maxTagCount="1" v-model="form.buyerIdList"
            :option-list="(buyerList as any)" value="id" label="nickname"></oms-multiple-select>
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="24">
        <a-form-item field="remark" label="合作说明：" label-col-flex="120px" required
          :rules="[{ required: true, message: '请输入合作说明' }]">
          <a-textarea style="width:94%;" :maxLength="500" v-limit-input="['#', '']" show-word-limit
            v-model.trim="form.remark" placeholder="请描述品牌推荐是否满足、可合作渠道、可合作SKU数量等说明" />
        </a-form-item>
      </a-col>
    </a-row>
  </a-form>
</template>
<script setup lang="ts" name="system-supplier-basic-info">
import dayjs from 'dayjs';
import { SupplierFrom } from '@/types/basicdata/supplier';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { CascaderType } from '@/types/basicdata/express';
import { ref } from 'vue';
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"
const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
  supplierCategoryList: { type: Array<DictionaryTitleType>, default: () => [] },
  supplierAttrList: { type: Array<DictionaryTitleType>, default: () => [] },
  registeredCapitalCurrencyList: { type: Array<DictionaryTitleType>, default: () => [] },
  developerList: { type: Array, default: () => [] },
  buyerList: { type: Array, default: () => [] },
  expressLimitData: { type: Array<CascaderType>, default: () => [] },
});
const formRef = ref();

const checkFrom = async () => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  return true;
}

defineExpose({
  checkFrom
});
</script>
<style lang="less">
.supplier-basic-info {
  .arco-input-disabled {
    background-color: #F6F6F6;
  }

  .arco-input-append {
    background-color: #F6F6F6 !important;
  }

  .arco-input-number-step {
    display: none;
  }

  .arco-input-group>.arco-input-wrapper:not(:last-child),
  .arco-input-group>.arco-input-outer:not(:last-child),
  .arco-input-group>.arco-input-tag:not(:last-child),
  .arco-input-group>.arco-select-view:not(:last-child) {
    border-right: none !important;
  }
}</style>