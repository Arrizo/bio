<!-- 基础资料->供应商管理->品牌表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="500px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form :model="brandForm" ref="formRef" layout="horizontal">
      <a-form-item field="agentBrand" label="代理品牌：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入代理品牌' }]">
        <a-input v-limit-input="['#', '']" :maxLength="50" v-model.trim="brandForm.agentBrand" placeholder="请输入"
          allow-clear />
      </a-form-item>
      <a-form-item field="authorizeLevel" label="授权级别：" label-col-flex="100px">
        <a-select placeholder="请选择" allow-clear v-model="brandForm.authorizeLevel" @change="getLevelName">
          <a-option v-for="(item) in authorizeLevelList" :label="item.dictionaryTitle"
            :value="item.dictionaryValue"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item label="授权有效期：" label-col-flex="100px">
        <a-range-picker v-model="brandTime" @change="onChangeRangeDate" format="YYYY-MM-DD"
          :placeholder="['开始时间', '结束时间']" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-supplier-brand-model">
import { reactive, ref } from 'vue';
import { BrandForm, SupplierFrom } from '@/types/basicdata/supplier';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { deepClone } from '@/utils/helper';
// 新增编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any;
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});

const brandForm = ref<BrandForm>(new BrandForm());
const formRef = ref();
const authorizeLevelList = ref<DictionaryTitleType[]>();
const brandTime = ref();
const currentIndex = ref('');
const onChangeRangeDate = (val: any) => {
  brandForm.value.startTime = val?.[0] ?? '';
  brandForm.value.endTime = val?.[1] ?? '';
}
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
console.log('[ brandForm.authorizeLevel ] >', brandForm.value.authorizeLevel)
  if (editModal.type === 'add') {//新增
    props.form.brandList.push(brandForm.value);
    console.log('[  props.form.brandList ] >', props.form.brandList )
    return
  }
  //编辑
  props.form.brandList.splice(currentIndex.value, 1, brandForm.value)
}

const getLevelName = (val: any) => {
  let idx = authorizeLevelList.value?.findIndex((item) => item.dictionaryValue === val);
  if (idx != -1) {
    brandForm.value.authorizeLevelName = authorizeLevelList.value?.[idx as number].dictionaryTitle || ''
  }else{
    brandForm.value.authorizeLevelName = '';
  }
}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); brandTime.value = []; }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: 'add' | 'edit', record: BrandForm, index: string) => {
  editModal.show = true;
  editModal.type = type;
  brandTime.value = [];
  if (type === 'add') {
    brandForm.value = new BrandForm();
    //授权级别
    authorizeLevelList.value = await getDictionaryList('AUTHORIZE_LEVEL')
  } else {
    //授权级别
    authorizeLevelList.value = await getValidDictionaryList('AUTHORIZE_LEVEL')
    brandForm.value = JSON.parse(JSON.stringify(record));
    if (brandForm.value.startTime) {
      brandTime.value = [brandForm.value.startTime, brandForm.value.endTime]
    }
    currentIndex.value = index;
  }
}


defineExpose({
  handleShowModal
});
</script>