<!-- 基础资料->供应商管理->联系人表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="500px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form :model="contantsForm" ref="formRef" layout="horizontal">
      <a-form-item field="contacts" label="联系人：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入联系人' }]">
        <a-input v-limit-input="['#', '']" :maxLength="50" v-model.trim="contantsForm.contacts" placeholder="请输入"
          allow-clear />
      </a-form-item>
      <a-form-item field="job" label="职务：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入职务' }]">
        <a-input v-limit-input="['#', '']" :maxLength="50" v-model.trim="contantsForm.job" placeholder="请输入"
          allow-clear />
      </a-form-item>
      <a-form-item field="mobile" label="手机号码：" :rules="rulesMobile" label-col-flex="100px" required>
        <a-input v-limit-input="['#', '']" :maxLength="11" v-model.trim="contantsForm.mobile" placeholder="请输入"
          allow-clear />
      </a-form-item>
      <a-form-item field="fixedPhone" label="固定电话：" :rules="rulesPhone" label-col-flex="100px">
        <a-input v-limit-input="['#', '']" v-model.trim="contantsForm.fixedPhone" placeholder="请输入" allow-clear />
      </a-form-item>
      <a-form-item field="mail" label="电子邮箱：" :rules="emailCheck" label-col-flex="100px">
        <a-input v-limit-input="['#', '']" v-model.trim="contantsForm.mail" placeholder="请输入" allow-clear />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-supplier-contacts-model">
import { computed, reactive, ref } from 'vue';
import { ContactsFrom, SupplierFrom } from '@/types/basicdata/supplier';
import { deepClone } from '@/utils/helper';
// 财务信息新增编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any;
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});

const contantsForm = ref<ContactsFrom>(new ContactsFrom());
const formRef = ref();
const currentIndex = ref('');
//校验手机号码
const rulesMobile = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (!value || value == "") {
        callback("请输入手机号码");
        return
      }
      if (value) {
        return new Promise<void>((resolve) => {
          const mobileReg = /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;
          if (value.length !== 11 || !mobileReg.test(value)) callback("请输入正确的手机号码");
          resolve();
        });
      }
    },
    required: true
  },
]);
//校验固定号码
const rulesPhone = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (value) {
        return new Promise<void>((resolve) => {
          const phoneReg = /^\d{3}-\d{8}|\d{4}-\d{7}$/;
          if (!phoneReg.test(value)) callback("请输入正确的固定号码");
          resolve();
        });
      }
    },
  },
]);
//电子邮箱校验
const emailCheck = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (value) {
        return new Promise<void>((resolve) => {
          const regEmail = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
          if (!regEmail.test(value)) callback("请输入正确的电子邮箱");
          resolve();
        });
      }
    },
  },
]);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  if (editModal.type === 'add') {//新增
    props.form.contactsList.push(contantsForm.value);
    return
  }
  //编辑
    props.form.contactsList.splice(currentIndex.value, 1, contantsForm.value)
  
}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: 'add' | 'edit', record: ContactsFrom,index:string) => {
  editModal.show = true;
  editModal.type = type;
  if (type === 'add') {
    contantsForm.value = new ContactsFrom();
  } else {
    contantsForm.value = deepClone(record);
    currentIndex.value=index;
  }
}


defineExpose({
  handleShowModal
});
</script>