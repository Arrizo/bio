// 合作模式
<template>
  <oms-table>
    <template #header-left>
      <a-button type="primary" style="margin-bottom: 10px;" status="normal" @click="handleClick('add')"> 新增 </a-button>
    </template>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.cooperationModeList as any)" :pagination="false"
      :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="合作模式" ellipsis tooltip :width="180" data-index="cooperationModeName"></a-table-column>
        <a-table-column title="发货时效" ellipsis tooltip :width="180" data-index="deliveryTimelinessName"></a-table-column>
        <a-table-column title="售后支持" ellipsis tooltip :width="180" data-index="afterSupportName"></a-table-column>
        <a-table-column title="结算方式" ellipsis tooltip :width="180" data-index="settlementMethodName"></a-table-column>
        <a-table-column title="账期" ellipsis tooltip :width="180" data-index="accountingPeriod"></a-table-column>
        <a-table-column title="操作" :width="120" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-space :size="28">
              <a-link @click="handleClick('edit', record, rowIndex)" type="text">编辑</a-link>
              <a-link @click="handleClick('del', record, rowIndex)" type="text" status="danger">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
    <!-- 编辑 -->
    <cooperation-model ref="cooperationRef" :form="form"></cooperation-model>

  <!-- 删除二次确认 -->
  <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>
  </oms-table>
</template>
<script setup lang="ts" name="system-supplier-cooperation-mode">
import { reactive, ref } from 'vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import CooperationModel from './cooperation-model.vue';
import OmsTable from '@/components/oms-table/index.vue';
import { CooperationType, SupplierFrom } from '@/types/basicdata/supplier';
const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
const cooperationRef = ref()
const warnignRef = ref();
const currentIndex = ref();

//操作
const handleClick = (type: "add" | "edit" | "del", record?: CooperationType, rowIndex?: string) => {

  if (type === 'del') {
    currentIndex.value = rowIndex;
    warnignRef.value.open();
    return
  }
  cooperationRef.value.handleShowModal(type, type === 'edit' ? record : {}, type === 'edit' ? rowIndex : '')
}

const handleDelete = () => {
  props.form.cooperationModeList.splice(currentIndex.value, 1);
  return true;
}
</script>