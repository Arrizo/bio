<!-- 基础资料->供应商管理->列表 -->
<template>
  <div>
    <oms-table :loading="loading" :total="totalCount" :current="form.pageNum" :size="form.pageSize" @reload="onReload">
      <template #header-left>
        <a-button v-permission="['oms:basicdata:supplier:add']" type="primary" status="normal"
          @click="handleAddClick('add')" style="margin-bottom: 10px;"> 新增供应商 </a-button>
      </template>
      <a-table v-db-click="list" :db-call-back="handleDetailsClick" stripe :data="(list as any)" :pagination="false"
        :scroll="{ x: 1400 }" :bordered="{ wrapper: false }">
        <template #columns>
          <a-table-column title="供应商编码" ellipsis tooltip data-index="supplierCode">
          </a-table-column>
          <a-table-column title="供应商名称" ellipsis tooltip data-index="supplierName"></a-table-column>
          <a-table-column title="简称" ellipsis tooltip data-index="shortName"></a-table-column>
          <a-table-column title="供应商类型" data-index="supplierType">
            <template #cell="{ record }">
              {{ supplierTypeObj[record.supplierType] || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="状态" :width="120" data-index="status">
            <template #cell="{ record, rowIndex }">
              <a-switch v-permission="['oms:basicdata:supplier:status']" v-model="(list as any)[rowIndex].status"
                @focus="onSwitchForce(record, rowIndex)">
                <template #checked>
                  启用
                </template>
                <template #unchecked>
                  禁用
                </template>
              </a-switch>
            </template>
          </a-table-column>
          <a-table-column title="审核状态" :width="120" data-index="auditStatus">
            <template #cell="{ record }">
              <oms-tag :type="auditStatusTagObj[record.auditStatus]" v-if="record.auditStatus"
                :content="auditStatusObj[record.auditStatus]"></oms-tag>
            </template>
          </a-table-column>
          <a-table-column title="同步K3状态" :width="120" data-index="k3Status">
            <template #cell="{ record }">
              <oms-tag :type="k3StatusTagObj[record.k3Status]" v-if="record.k3Status"
                :content="k3StatusObj[record.k3Status]"></oms-tag>
            </template>
          </a-table-column>
          <a-table-column title="创建时间" :width="180" data-index="createTime"></a-table-column>
          <a-table-column title="修改时间" :width="180" data-index="updateTime"></a-table-column>
          <a-table-column title="操作" :width="180" fixed="right">
            <template #cell="{ record }">
              <a-space :size="14">
                <a-link v-permission="['oms:basicdata:supplier:submit']" v-if="record.auditStatus === 'STASH'"
                  @click="handleAddClick('submit', record)" type="text">提交</a-link>
                <a-link v-permission="['oms:basicdata:supplier:examine']" v-if="record.auditStatus === 'WAIT_AUDIT'"
                  @click="handleAddClick('examine', record)" type="text">审核</a-link>
                <a-link v-permission="['oms:basicdata:supplier:edit']" v-if="record.auditStatus !== 'WAIT_AUDIT'"
                  @click="handleAddClick('edit', record)" type="text">编辑</a-link>
                <a-link v-permission="['oms:basicdata:supplier:del']" @click="handleAddClick('del', record)" type="text"
                  status="danger">删除</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>

    <!-- 新增/编辑弹窗 -->
    <supplier-form ref="ExpressFromRef" :developerList="developerList" :buyerList="buyerList"
      :supplierCategoryList="supplierTypeList" :supplierAttrList="supplierAttrList"
      @reload="emits('reload')"></supplier-form>

    <!-- 修改状态二次弹框 -->
    <oms-warning ref="switchRef" :on-before-ok="handleStatus"></oms-warning>

    <!-- 删除二次弹框 -->
    <oms-warning ref="warnignRef" :on-before-ok="handleDel"></oms-warning>

    <!-- 提交二次弹框 -->
    <oms-warning ref="submitRef" :on-before-ok="handleSubmit"></oms-warning>

    <!-- 审核 -->
    <examine-modal ref="examineRef" @reload="emits('reload')"></examine-modal>
  </div>
</template>

<script setup lang="ts" name="system-supplier-list">
import { computed, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import SupplierForm from "./form.vue"
import ExamineModal from './examine-modal.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import OmsTag from '@/components/oms-tag/index.vue'
import { Message } from '@arco-design/web-vue';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { SupplierReq, SupplierType } from '@/types/basicdata/supplier';
import { deleteSupplier, onOrDrop, submitSupplier } from '@/api/basicdata/supplier';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';

const props = defineProps({
  list: {
    type: Array, default: () => []
  },
  totalCount: { type: Number, default: 0 },
  loading: { type: Boolean, default: false },
  supplierAttrList: { type: Array<DictionaryTitleType>, default: () => [] },
  developerList: { type: Array, default: () => [] },
  buyerList: { type: Array, default: () => [] },
});
const form = ref<SupplierReq>(new SupplierReq());
const emits = defineEmits<{
  (e: "reload", data?: SupplierReq): void,
  (e: "details", data: SupplierType): void,
}>();
const switchRef = ref();
const ExpressFromRef = ref();
const warnignRef = ref();
const examineRef = ref();
const submitRef = ref();
const currentId = ref();
let supplierTypeList = ref<DictionaryTitleType[]>();//供应商类别
const supplierTypeObj = {
  'formal': '正式供应商',
  'latent': '潜在供应商'
}

/**
   * 审核状态:STASH-草稿，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
   */
const auditStatusObj = {
  'STASH': '暂存',
  'WAIT_AUDIT': '待审核',
  'AUDIT_PASS': '通过',
  'NO_PASS': '不通过',
}

const auditStatusTagObj = {
  'STASH': 'normal',
  'WAIT_AUDIT': 'progress',
  'AUDIT_PASS': 'normal',
  'NO_PASS': 'warring',
}
// UN_PUSH("未推送"),PUSHED("已推送"),PUSH_FAIL("推送失败");
const k3StatusObj = {
  'UN_PUSH': '未同步',
  'PUSHED': '同步成功',
  'PUSH_FAIL': '同步失败',
}

const k3StatusTagObj = {
  'UN_PUSH': 'progress',
  'PUSHED': 'normal',
  'PUSH_FAIL': 'warring',
}

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  // emits("reload", form.value)
  emits('reload', data);
};

// 「新增菜单」按钮点击触发
const handleAddClick = async (type: string, record?: SupplierType) => {
  currentId.value = record?.id;

  switch (type) {
    case 'submit'://提交
      submitRef.value.open({ title: "提示", content: `此操作将提交选中数据审核, 是否继续？<br/>提交后不可修改数据` });
      return
      break;
    case 'examine'://审核
      examineRef.value.handleShowModal(currentId.value);
      return
      break;
    case 'del'://删除
      warnignRef.value.open();
      return
      break;
    case 'add'://新增
      //供应商类别
      supplierTypeList.value = await getDictionaryList('SUPPLIER_CATEGORY')
      ExpressFromRef.value.handleShowModal(type);
      break;
    case 'edit'://编辑
      //供应商类别
      supplierTypeList.value = await getValidDictionaryList('SUPPLIER_CATEGORY')
      ExpressFromRef.value.handleShowModal(type, record?.id);
      break;
    default:
      break;
  }

};

//详情
const handleDetailsClick = (data: SupplierType) => {
  emits('details', data)
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: SupplierType, index: number) => {
  currentId.value = record?.id;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

//删除接口
const handleDel = async () => {
  try {
    const res = await deleteSupplier(currentId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

//提交操作
const handleSubmit = async () => {
  try {
    const res = await submitSupplier(currentId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}
//禁用启用操作
const handleStatus = async () => {
  try {
    const res = await onOrDrop(currentId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}
// 返回列表
const list = computed(() => {
  return props.list as Array<SupplierType>
})

</script>