// 联系人
<template>
  <div>
    <a-table stripe :bordered="{ wrapper: false }" :data="(props.form.contactsList as any)" :pagination="false" :scroll="{ x: 300 }">
      <template #columns>
        <a-table-column title="联系人" :width="180" data-index="contacts"></a-table-column>
        <a-table-column title="职务" :width="180" data-index="job"></a-table-column>
        <a-table-column title="手机号码" :width="180" data-index="mobile"></a-table-column>
        <a-table-column title="固定号码" :width="180" data-index="fixedPhone"></a-table-column>
        <a-table-column title="电子邮箱" :width="180" data-index="mail"></a-table-column>
        <a-table-column title="创建时间" :width="180" data-index="createTime"></a-table-column>
        <a-table-column title="修改时间" :width="180" data-index="updateTime"></a-table-column>
      </template>
    </a-table>
  </div>
</template>
<script setup lang="ts" name="system-supplier-finance-info">
import { SupplierFrom } from '@/types/basicdata/supplier';

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});
</script>