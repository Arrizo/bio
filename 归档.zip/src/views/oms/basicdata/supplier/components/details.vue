<!-- 基础资料->供应商管理->详情 -->
<template>
  <div class="supplier-details">
    <div class="supplier-details-title">
      <a-tabs :style="{ width: '100%' }" :active-key="tabValue" @change="changeTab">
        <template #extra>
          <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
        </template>
        <!-- 基本信息 -->
        <a-tab-pane key="basic-info" title="基本信息">
          <basic-info v-if="tabValue === 'basic-info'" :form="form"></basic-info>
        </a-tab-pane>
        <!-- 财务信息 -->
        <a-tab-pane key="finance-info" title="财务信息">
          <finance-info v-if="tabValue === 'finance-info'" :form="form"></finance-info>
        </a-tab-pane>
        <!-- 联系人 -->
        <a-tab-pane key="contacts" title="联系人">
          <contacts v-if="tabValue === 'contacts'" :form="form"></contacts>
        </a-tab-pane>
        <!-- 合作模式 -->
        <a-tab-pane key="cooperation-mode" title="合作模式">
          <cooperation-mode v-if="tabValue === 'cooperation-mode'" :form="form"></cooperation-mode>
        </a-tab-pane>
        <!-- 品牌信息 -->
        <a-tab-pane key="brand-info" title="品牌信息">
          <brand-info v-if="tabValue === 'brand-info'" :form="form"></brand-info>
        </a-tab-pane>
        <!-- 附件资料 -->
        <a-tab-pane key="annex-data" title="附件资料">
          <annex-data v-if="tabValue === 'annex-data'" :form="form"></annex-data>
        </a-tab-pane>
        <!-- 操作日志 -->
        <a-tab-pane key="operation-log" title="操作日志">
          <oms-log ref="logRef"></oms-log>
        </a-tab-pane>
      </a-tabs>
    </div>
  </div>
</template>

<script setup lang="ts" name="system-supplier-details">
import BasicInfo from './basic-info.vue';
import FinanceInfo from './finance-info.vue';
import Contacts from "./contacts.vue";
import CooperationMode from './cooperation-mode.vue'
import BrandInfo from './brand-info.vue';
import AnnexData from './annex-data.vue';
import OmsLog from '@/components/oms-log/index.vue'
import { ref, watch } from 'vue';
import { Message } from '@arco-design/web-vue';
import { getDetailInfo } from '@/api/basicdata/supplier';
import { SupplierFrom } from '@/types/basicdata/supplier';
import { OperationLogType } from '@/types/basicdata/shop';

const props = defineProps({
  detailsId: {
    type: Number, default: 0
  },
  supplierCode: {
    type: String, default: ''
  }
});
const emits = defineEmits<{
  (e: "close"): void,
}>();
const loading = ref<boolean>(false);
const logRef = ref();

const form = ref<SupplierFrom>(new SupplierFrom());
const tabValue = ref('basic-info');

const changeTab = (val: any) => {
  tabValue.value = val;
  if (tabValue.value ==='operation-log') {
    logRef.value.init(props.supplierCode, '供应商', "page");
  }
}


//关闭详情
const closeDetails = () => {
  emits('close')
}

const getInfo = async (id: number) => {
  try {
    let params = {
      id: id,
      isUpdate: false//编辑回显true，详情true
    };
    const res = await getDetailInfo(params);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    let data = res.value;
    form.value = data;
    form.value.buyerName = data.buyerName??'';
    form.value.detailAddr = data.detailAddr??"";
    form.value.businessScope = data.businessScope??'';
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

watch(
  () => props.detailsId,
  () => {
    if (props.detailsId) {
      tabValue.value = 'basic-info';
      getInfo(props.detailsId);
    }
  }, {
  immediate: true,
  deep: true
}
);
</script>

<style lang="less" >
.supplier-details {
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  .arco-tabs-content {
    padding-left: 16px;
    padding-right: 16px;
  }

  .arco-tabs-nav {
    padding: 0 16px;
  }
}
</style>