<!-- 基础资料->供应商管理->审核表单组件 -->
<template>
  <a-modal :mask-closable="false" title="审核" width="500px" v-model:visible="examineModal.show" title-align="start" :on-before-ok="onOk"
    @cancel="onCancel" unmountOnClose>
    <a-form :model="form" ref="formRef" layout="horizontal">
      <a-form-item field="auditStatus" label="审核结果：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择审核结果' }]">
        <a-select placeholder="请选择" v-model="(form.auditStatus as string)" allow-search>
          <a-option value="true">通过</a-option>
          <a-option value="false">不通过</a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="remark" label="审核备注：" label-col-flex="100px" :rules="emailRemark">
        <a-textarea :maxLength="100" v-limit-input="['#', '']" show-word-limit v-model.trim="form.remark"
          placeholder="请输入" allowClear />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-dictionary-form">
import { DictionaryForm, AddPidType, DictionaryType } from '@/types/system/dictionary';
import { computed, reactive, ref } from 'vue';
import { addDictionary, editDictionary, } from '@/api/system/dictionary';
import { Message } from '@arco-design/web-vue';
import { AuditMappingFrom } from '@/types/product/distribution';
import { auditByIdList } from '@/api/basicdata/supplier';
// 字典编辑表单弹窗
interface ExamineModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const examineModal = reactive<ExamineModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();
//审核备注校验
const emailRemark = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (form.value.auditStatus == 'false' && (!value || value == "")) {
        callback("请选择审核备注");
        return
      }
    },
    required: form.value.auditStatus == 'false'
  },
]);
const form = ref<AuditMappingFrom>(new AuditMappingFrom());
const formRef = ref();
const loading = ref<boolean>(false);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  if (form.value.auditStatus == 'false' && !form.value.remark) {
    Message.error('请输入备注说明');
    return false;
  }
  loading.value = true;
  try {
    const res = await auditByIdList(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  }finally{
    loading.value = false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (data: number) => {
  form.value=new AuditMappingFrom();
  examineModal.show = true;
  form.value.id=data;
}


defineExpose({
  handleShowModal
});
</script>