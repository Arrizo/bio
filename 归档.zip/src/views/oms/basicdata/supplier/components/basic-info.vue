//基础信息
<template>
  <a-form class="supplier-basic-info" :model="form" layout="horizontal" style="width:100%">
    <a-row>
      <a-col :span="6">
        <a-form-item field="legalRepresentative" label="法人代表：" label-col-flex="130px">
          <a-input v-model="form.legalRepresentative" disabled />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="registeredCapital" label="注册资本(万)：" label-col-flex="130px">
          <a-input-number v-model="form.registeredCapital" disabled>
            <template #append>
              {{ form.registeredCapitalCurrencyName }}
            </template>
          </a-input-number>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="incorporationTime" label="成立日期：" label-col-flex="130px">
          <a-input v-model="form.incorporationTime" disabled />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="socialCreditCode" label="社会信用代码：" label-col-flex="130px">
          <a-input v-model="form.socialCreditCode" disabled />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="6">
        <a-form-item field="regionName" label="公司区域：" label-col-flex="130px">
          <a-input v-model="form.regionName" disabled />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="detailAddr" label="详细地址：" label-col-flex="130px">
          <a-tooltip mini :content="form.detailAddr" v-if="form.detailAddr.length > 24">
            <div class="inputDisabled">{{ substringName(form.detailAddr, 23) }}</div>
          </a-tooltip>
          <a-input v-else v-model="form.detailAddr" disabled />
        </a-form-item>
      </a-col>
      <a-col :span="12">
        <a-form-item field="businessScope" label="经营范围：" label-col-flex="130px">
          <a-tooltip mini :content="form.businessScope" v-if="form.businessScope.length > 50">
            <div class="inputDisabled">{{ substringName(form.businessScope, 47) }}</div>
          </a-tooltip>
          <a-input v-else v-model="form.businessScope" disabled />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="6">
        <a-form-item field="supplierCategoryName" label="供应商类别：" label-col-flex="130px">
          <a-input v-model="form.supplierCategoryName" disabled />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="supplierAttrName" label="供应商属性：" label-col-flex="130px">
          <a-input v-model="form.supplierAttrName" disabled />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="developerName" label="开发人员：" label-col-flex="130px">
          <a-tooltip mini :content="form.developerName" v-if="form.developerName.length > 24">
            <div class="inputDisabled">{{ substringName(form.developerName, 23) }}</div>
          </a-tooltip>
          <a-input v-else v-model="form.developerName" disabled />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="buyerName" label="采购人员：" label-col-flex="130px">
          <a-tooltip mini :content="form.buyerName" v-if="form.buyerName.length > 24">
            <div class="inputDisabled">{{ substringName(form.buyerName, 23) }}</div>
          </a-tooltip>
          <a-input v-else v-model="form.buyerName" disabled />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row>
      <a-col :span="12">
        <a-form-item field="remark" label="备注说明：" label-col-flex="130px">
          <a-tooltip mini :content="form.remark" v-if="form.remark.length > 50">
            <div class="inputDisabled">{{ substringName(form.remark, 47) }}</div>
          </a-tooltip>
          <a-input v-else v-model="form.remark" disabled />
        </a-form-item>
      </a-col>
    </a-row>
  </a-form>
</template>
<script setup lang="ts" name="system-warehouse-other-info">
import { SupplierFrom } from '@/types/basicdata/supplier';

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});


//超出几个字省略号
const substringName = (value: string, num: number) => {
  if (!value) return;
  if (value.length > num) {
    return value.slice(0, num) + "...";
  }
  return value;
}
</script>
<style lang="less">
.supplier-basic-info {
  .arco-input-disabled {
    background-color: #F6F6F6;
  }

  .arco-input-append {
    background-color: #F6F6F6 !important;
  }

  .inputDisabled{
    padding: 7px 10px;
    background-color: #F6F6F6;
    width: 100%;
    border-radius: 2px;
  }
}
</style>