<!-- 基础资料->供应商管理->搜索组件 -->
<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="supplierCode" label="供应商编码：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.supplierCode" placeholder="请输入"
        allow-clear />
    </a-form-item>
    <a-form-item field="supplierName" label="供应商名称：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.supplierName" placeholder="请输入"
        allow-clear />
    </a-form-item>
    <a-form-item field="supplierType" label="供应商类型：">
      <a-select placeholder="请选择" v-model="form.supplierType">
        <a-option value="all">全部</a-option>
        <a-option v-for="(item) in supplierCategoryList" :label="item.dictionaryTitle" :value="item.dictionaryValue"></a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="supplierAttr" label="供应商属性：">
      <a-select placeholder="请选择" v-model="form.supplierAttr">
        <a-option value="all">全部</a-option>
        <a-option v-for="(item) in supplierAttrList" :label="item.dictionaryTitle" :value="item.dictionaryValue"></a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="(form.status as string)">
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="k3Status" label="同步K3状态：">
      <a-select placeholder="请选择" v-model="form.k3Status">
        <a-option value="all">全部</a-option>
        <a-option value="UN_PUSH">未同步</a-option>
        <a-option value="PUSHED">同步成功</a-option>
        <a-option value="PUSH_FAIL">同步失败</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="auditStatus" label="审核状态：">
      <a-select placeholder="请选择" v-model="form.auditStatus">
        <a-option value="all">全部</a-option>
        <a-option value="STASH">暂存</a-option>
        <a-option value="WAIT_AUDIT">待审核</a-option>
        <a-option value="AUDIT_PASS">通过</a-option>
        <a-option value="NO_PASS">不通过</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="buyerIdList" label="采购人员：">
      <!-- <a-select placeholder="请选择" multiple v-model="form.buyerIdList" allow-search allow-clear>
        <a-option v-for="item in buyerList" :label="(item as any).nickname" :value="(item as any).id"></a-option>
      </a-select> -->

      <oms-multiple-select :maxTagCount="1" v-model="form.buyerIdList" :option-list="(buyerList as any)" value="id" label="nickname"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="developerIdList" label="开发人员：">
      <!-- <a-select placeholder="请选择" multiple v-model="form.developerIdList" allow-search allow-clear>
        <a-option v-for="(item) in developerList" :label="(item as any).nickname" :value="(item as any).id"></a-option>
      </a-select> -->
      <oms-multiple-select :maxTagCount="1" v-model="form.developerIdList" :option-list="(developerList as any)" value="id" label="nickname"></oms-multiple-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="system-supplier-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"
import { SupplierReq } from '@/types/basicdata/supplier';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false },
  supplierCategoryList: { type: Array<DictionaryTitleType>, default: () => [] },
  supplierAttrList: { type: Array<DictionaryTitleType>, default: () => [] },
  developerList: { type: Array, default: () => [] },
  buyerList: { type: Array, default: () => [] },
});
const formRes = ref();
const emits = defineEmits<{
  (e: "on-search", data: SupplierReq): void;
}>();

const form = ref<SupplierReq>(new SupplierReq());

const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

onMounted(async () => {
  handleSearch();
});
</script>