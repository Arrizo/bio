<!-- 基础资料->供应商管理 -->
<template>
  <div>
    <a-row :gutter="10">
      <a-col :span="24">
        <oms-panel>
          <template #header>
            <supplier-search :developerList="developerList" :buyerList="buyerList"
              :supplierCategoryList="supplierCategoryList" :supplierAttrList="supplierAttrList" :loading="loading"
              @on-search="init"></supplier-search>
          </template>
          <div>
            <supplier-list :developerList="developerList" :buyerList="buyerList" :supplierCategoryList="supplierCategoryList" :supplierAttrList="supplierAttrList"
              @reload="init" @details="handleDetailsClick" :totalCount="totalCount" :loading="loading"
              :list="list"></supplier-list>
          </div>
        </oms-panel>
        <!-- 详情 -->
        <supplier-details v-if="detailsVisible" :detailsId="detailsId" :supplierCode="supplierCode" @close="closeDetails"></supplier-details>
      </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts" name="basicdata-supplier">
import OmsPanel from '@/components/oms-panel/index.vue';
import SupplierSearch from './components/search.vue';
import SupplierList from './components/list.vue';
import SupplierDetails from './components/details.vue';
import { findOpenStatusInnerUserList, queryList } from '@/api/basicdata/supplier';
import { Message } from '@arco-design/web-vue';
import { onMounted, ref } from 'vue';
import { deepClone } from '@/utils/helper';
import { SupplierReq, SupplierType } from '@/types/basicdata/supplier';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { getDictionaryList } from '@/hooks/useDictionary';
const form = ref<SupplierReq>(new SupplierReq());
const loading = ref<boolean>(false);
const list = ref<SupplierType[]>();
const totalCount = ref();
const detailsVisible = ref<boolean>(false);
const detailsId = ref();
const supplierCode=ref();
let supplierCategoryList = ref<DictionaryTitleType[]>()
let supplierAttrList = ref<DictionaryTitleType[]>();
const developerList = ref();
const buyerList = ref();
/**
 * 初始化查询菜单数据
 * @param form
 */

const init = async (data: SupplierReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.k3Status = params.k3Status === 'all' ? '' : params.k3Status;
    params.auditStatus = params.auditStatus === 'all' ? '' : params.auditStatus;
    params.status = params.status === 'all' ? '' : params.status;
    params.supplierAttr = params.supplierAttr === 'all' ? '' : params.supplierAttr;
    params.supplierType = params.supplierType === 'all' ? '' : params.supplierType;
    // params.auditStatus = params.auditStatus === 'all' ? '' : params.auditStatus;
    const res = await queryList(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
    //关闭详情
    closeDetails();
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}
//详情
const handleDetailsClick = (data: SupplierType) => {
  detailsVisible.value = true;
  detailsId.value = data.id;
  supplierCode.value = data.supplierCode;
}
//关闭详情
const closeDetails = () => {
  detailsVisible.value = false;
}

const getPersonList = async () => {
  try {
    const res = await findOpenStatusInnerUserList();
    if (res.code != 0) {
      throw new Error(res.message);
    }
    //开发人员
    developerList.value = res.value;
    //采购人员
    buyerList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

onMounted(async () => {
  //供应商类型
  supplierCategoryList.value = await getDictionaryList('SUPPLIER_TYPE')
  //供应商属性
  supplierAttrList.value = await getDictionaryList('SUPPLIER_ATTR')
  getPersonList();
});
</script>