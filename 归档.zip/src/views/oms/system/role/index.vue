<!-- 系统管理->角色管理 -->
<template>
  <a-row :gutter="10" style="height: 100%;">
    <a-col :span="24" style="height: 100%;">
      <oms-panel style="height: 100%;">
        <template #header>
          <search :loading="loading" @on-search="init"></search>
        </template>
        <div>
          <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
            @reload="init"></list>
        </div>
      </oms-panel>
    </a-col>
  </a-row>
</template>

<script setup lang="ts" name="system-role">
import { ref } from 'vue';
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import { queryRoleList } from '@/api/system/role';
import { Message } from '@arco-design/web-vue';
import { RoleSearchForm, RoleSearchResResultItem } from '@/types/system/role';
import { deepClone } from '@/utils/helper';

const loading = ref<boolean>(false);
const list = ref<RoleSearchResResultItem[]>([]);
const total = ref<number>(0);
const form = ref<RoleSearchForm>(new RoleSearchForm());

/**
 * 初始化查询菜单数据
 * @param data
 */
const init = async (data: RoleSearchForm = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.status = params.status === 'all' ? '' : params.status;

    const res = await queryRoleList(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    setTimeout(() => {
      loading.value = false;
    }, 400);
  }
}
</script>