<!-- 系统设置-角色-添加/编辑角色表单 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="800px" v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" unmountOnClose>
    <a-form ref="formRef" :model="form" layout="horizontal">
      <p style="font-weight:bold">基本信息</p>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="roleName" label="角色名称：" label-col-flex="100px" required
            :rules="[{ required: true, message: '请输入角色名称' }]">
            <a-input v-limit-input @keyup.enter="onOk" v-model="form.roleName" placeholder="请输入" :max-length="50"
              allow-clear show-word-limit />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="remark" label="备注：" label-col-flex="100px">
            <a-input @keyup.enter="onOk" v-model="form.remark" placeholder="请输入" :max-length="200" allow-clear
              show-word-limit />
          </a-form-item>
        </a-col>
      </a-row>
      <p style="font-weight:bold">功能授权</p>
      <a-row style="max-height: 400px;overflow: auto;">
        <a-col :span="12">
          <a-tree ref="treeRef" blockNode :data="((menuList) as any)" :fieldNames="{
            key: 'id',
            title: 'menuName',
            icon: ''
          }" checkable :default-expand-all="false" :check-strictly="false" only-check-leaf default-expand-checked
            v-model:checked-keys="form.menuIdList" @check="onTreeCheck"></a-tree>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-role-form">
import { reactive, ref } from 'vue';
import { submitRoleForm } from '@/api/system/role';
import { Message } from '@arco-design/web-vue';
import { queryMenu } from '@/api/system/menu';
import { RoleForm } from '@/types/system/role';
import { MenuListItem } from '@/types/system/menu';
import { getRoleDetail } from '@/api/system/role';

// 角色编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const treeRef = ref();
const form = ref<RoleForm>(new RoleForm());
const menuLoading = ref<boolean>(false);
const menuList = ref<MenuListItem[]>([]);

const onTreeCheck = (keys: any[], data: any) => {
  console.log('[ keys ]-66', keys);
  console.log('[ data ]-66', data);
}

const queryMenuList = async () => {
  try {
    menuLoading.value = true;
    const res = await queryMenu({
      menuName: "",
      type: ""
    });

    if (res.code != 0) {
      throw new Error(res.message);
    }
    menuList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    menuLoading.value = false;
  }
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  const halfSelect = treeRef.value.getHalfCheckedNodes();
  for (let i = 0; i < halfSelect.length; i++) {
    form.value.menuIdList?.push(halfSelect[i].id)
  }

  try {
    const res = await submitRoleForm(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: string) => {
  editModal.type = type;
  editModal.show = true;

  if (type === 'add') {
    form.value = new RoleForm();
  }

  if (type === "edit") {
    try {
      const res = await getRoleDetail(data);
      if (res.code != 0) {
        Message.error(res.message);
        return;
      }
      form.value = res.value;
    } catch (err) {
      Message.error((err as Error).message);
    }
  }

  queryMenuList();
}

defineExpose({
  handleShowModal
});
</script>