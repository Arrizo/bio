<!-- 系统设置-角色管理-功能授权 -->
<template>
  <a-modal :mask-closable="false" title="功能授权" width="600px" v-model:visible="theModal.show" title-align="start" unmountOnClose
    :on-before-ok="onOk">
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-row style="max-height: 600px;overflow: auto;">
        <a-col :span="12">
          <a-spin dot v-if="menuLoading" />
          <a-tree v-else :blockNode="true" :data="((menuList) as any)" :fieldNames="{
            key: 'id',
            title: 'menuName',
            icon: ''
          }" :checkable="true" v-model:checked-keys="form.menuIdList"></a-tree>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-role-function-auth">
import { reactive, ref } from 'vue';
import { queryMenu } from '@/api/system/menu';
import { MenuListItem } from '@/types/system/menu';
import { Message } from '@arco-design/web-vue';
import { RoleFunctionAuthForm } from '@/types/system/role';
import { batchRoleMenu } from "@/api/system/role"

const emits = defineEmits<{
  (e: "on-add"): void,
  (e: "reload"): void,
}>();

interface TheModal {
  show: boolean;
  data?: any
}
const theModal = reactive<TheModal>({
  show: false,
  data: null
});
const formRef = ref();
const menuLoading = ref<boolean>(false);
const menuList = ref<MenuListItem[]>([]);
const form = ref<RoleFunctionAuthForm>(new RoleFunctionAuthForm());

const queryMenuList = async () => {
  try {
    menuLoading.value = true;
    const res = await queryMenu({
      menuName: "",
      type: ""
    });

    if (res.code != 0) {
      throw new Error(res.message);
    }
    menuList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    menuLoading.value = false;
  }
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  if (form.value.menuIdList?.length === 0) {
    Message.error("请选择菜单");
    return false;
  }

  try {
    const res = await batchRoleMenu(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

const handleShowModal = async (roleIds: number[]) => {
  theModal.show = true;
  form.value.roleIdList = roleIds;
  form.value.menuIdList = [];
  queryMenuList();
}

defineExpose({
  handleShowModal
});
</script>