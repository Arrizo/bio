<!-- 系统管理->角色管理->搜索组件 -->
<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="roleName" label="角色名称：">
      <a-input v-limit-input @keyup.enter="handleSearch(false)" v-model.trim="form.roleName" allow-clear placeholder="请输入" />
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="(form.status as string)" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="system-menu-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { RoleSearchForm } from '@/types/system/role';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: "on-search", data: RoleSearchForm): void;
}>();

const formRes = ref();
const form = ref<RoleSearchForm>(new RoleSearchForm());

// 搜索
const handleSearch = (isReset: boolean = false) => {
  emits("on-search", !isReset ? {
    roleName: form.value.roleName,
    status: form.value.status,
    pageNum: 1
  } : new RoleSearchForm())
};

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch(true);
}

onMounted(() => {
  handleSearch();
});
</script>