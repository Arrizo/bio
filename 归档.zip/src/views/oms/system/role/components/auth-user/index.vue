<!-- 系统设置-角色管理-授权用户 -->
<template>
  <a-modal :mask-closable="false" title="授权用户" width="800px" :footer="false" v-model:visible="theModal.show" title-align="start" unmountOnClose>
    <a-form ref="formRef" :model="searchForm" layout="horizontal">
      <a-row :gutter="10">
        <a-col :span="10">
          <a-form-item field="username" label="用户账户：" label-col-flex="80px">
            <a-input v-limit-input @keyup.enter="handleSearch" v-model="searchForm.username" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="10">
          <a-form-item field="nickname" label="用户名称：" label-col-flex="80px">
            <a-input v-limit-input @keyup.enter="handleSearch" v-model="searchForm.nickname" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="4">
          <a-button type="primary" status="normal" @click="handleSearch({ ...searchForm, pageNum: 1 })">
            <template #icon>
              <icon-search />
            </template>
            查询
          </a-button>
        </a-col>
      </a-row>
    </a-form>

    <oms-table :loading="loading" :total="total" :current="searchForm.pageNum" :size="searchForm.pageSize"
      @reload="handleSearch" :simple-pagination="true">
      <template #header-left></template>
      <a-table :data="(list as any)" stripe :pagination="false" hide-expand-button-on-empty row-key="id"
        :virtual-list-props="{ height: 400 }" :scroll="{ y: 400 }">
        <template #columns>
          <a-table-column title="用户账号" data-index="username"></a-table-column>
          <a-table-column title="用户名称" data-index="nickname"></a-table-column>
          <a-table-column title="所属组织" data-index="orgName"></a-table-column>
        </template>
      </a-table>
    </oms-table>
  </a-modal>
</template>

<script setup lang="ts" name="role-auth-user">
import { reactive, ref } from 'vue';
import { RoleUserResResultItem, RoleUserSearch } from '@/types/system/role';
import OmsTable from '@/components/oms-table/index.vue';
import { getRoleUserPage } from "@/api/system/role";
import { Message } from '@arco-design/web-vue';

const searchForm = ref<RoleUserSearch>(new RoleUserSearch());
const loading = ref<boolean>(false);
const total = ref<number>(0);
const list = ref<RoleUserResResultItem[]>([]);

// 授权用户弹窗
interface TheModal {
  show: boolean;
  data?: any
}
const theModal = reactive<TheModal>({
  show: false,
  data: null
});

const handleSearch = async (form?: RoleUserSearch) => {
  if (form) {
    searchForm.value.pageNum = form.pageNum;
    searchForm.value.pageSize = form.pageSize;
  }
  try {
    const res = await getRoleUserPage(searchForm.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

const handleShowModal = async (roleId: number) => {
  theModal.show = true;
  searchForm.value.roleId = roleId;
  handleSearch();
}

defineExpose({
  handleShowModal
});
</script>