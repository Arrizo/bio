<!-- 系统管理->角色管理->列表 -->
<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onTableReload">
    <template #header-left>
      <a-space :size="14" style="margin-bottom: 10px;">
        <a-button v-permission="['system:role:add']" type="primary" status="normal" @click="handleAddClick"
          style="width:80px"> 新增角色
        </a-button>
        <a-button v-permission="['system:role:function']" @click="handleAuthClick" :disabled="selectList.length === 0"
          style="width:80px">
          功能授权 </a-button>
      </a-space>
    </template>

    <a-table ref="tableRef" stripe row-key="id" :data="(list as any)" :pagination="false" hide-expand-button-on-empty
      :row-selection="{
        type: 'checkbox',
        showCheckedAll: true,
        onlyCurrent: false,
      }" @selection-change="onSelectionChange" :bordered="{ wrapper: false }" :scroll="{ x: 1400 }">
      <template #columns>
        <a-table-column title="角色名称" ellipsis tooltip>
          <template #cell="{ record }">
            {{ record.roleName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="授权用户">
          <template #cell="{ record }">
            <a-link type="text" v-if="record.userNum" @click="onUserNumClick(record)">
              {{ record.userNum }}
            </a-link>
            <span v-else>--</span>
          </template>
        </a-table-column>
        <a-table-column title="备注" ellipsis tooltip>
          <template #cell="{ record }">
            {{ record.remark || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="状态" :width="120">
          <template #cell="{ record, rowIndex }">
            <div v-permission="['system:role:status']">
              <a-switch v-model="(list as any)[rowIndex].status" @focus="onSwitchForce(record, rowIndex)">
                <template #checked>
                  启用
                </template>
                <template #unchecked>
                  禁用
                </template>
              </a-switch>
            </div>
            <div v-permission-else="['system:role:status']">{{ record.status ? '启用' : '禁用' }}</div>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" :width="180">
          <template #cell="{ record }"> {{ record.createTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="修改时间" :width="180">
          <template #cell="{ record }"> {{ record.updateTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="操作" :width="180" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link v-permission="['system:role:edit']" @click="handleActoin('edit', record)" type="text">编辑</a-link>
              <a-link v-permission="['system:role:params']" @click="handleActoin('auth', record)"
                type="text">字段授权</a-link>
              <a-link v-permission="['system:role:del']" @click="handleActoin('del', record)" type="text"
                status="danger">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 角色新增/编辑弹窗 -->
  <role-form ref="roleFormRef" @reload="emits('reload')"></role-form>

  <!-- 授权用户弹窗 -->
  <auth-user ref="authUserRef"></auth-user>

  <!-- 删除二次确认 -->
  <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleDropRole"></oms-warning>

  <!-- 功能授权 -->
  <function-auth ref="functionAuthRef" @reload="onAuthReload"></function-auth>

  <!-- 字段授权 -->
  <params-auth ref="paramsAuthRef"></params-auth>
</template>

<script setup lang="ts" name="system-menu-list">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import { RoleSearchForm, RoleSearchResResultItem } from '@/types/system/role';
import roleForm from "./role-form.vue";
import authUser from "./auth-user/index.vue";
import functionAuth from './function-auth.vue';
import paramsAuth from './params-auth.vue';
import { delRole, onOrDropRole } from "@/api/system/role";
import { Message } from '@arco-design/web-vue';

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  total: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "on-add"): void,
  (e: "reload", data?: RoleSearchForm): void,
}>();

const roleFormRef = ref();
const tableRef = ref();
const authUserRef = ref();
const warnignRef = ref();
const switchRef = ref();
const functionAuthRef = ref();
const paramsAuthRef = ref();
const selectList = ref<number[]>([]);
const delId = ref<number>(NaN);
const statusData = reactive({
  id: NaN,
  index: NaN
});

// 「新增角色」按钮点击触发
const handleAddClick = () => {
  roleFormRef.value.handleShowModal("add");
};

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: RoleSearchResResultItem, index: number) => {
  statusData.id = record?.id;
  statusData.index = index;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

// 角色启用/禁用
const handleDropRole = async () => {
  try {
    const res = await onOrDropRole(statusData.id);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits('reload');
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 授权用户
const onUserNumClick = (record: RoleSearchResResultItem) => {
  authUserRef.value.handleShowModal(record.id);
}

// 功能授权
const handleAuthClick = () => {
  functionAuthRef.value.handleShowModal(selectList.value);
}

// 功能授权完成触发
const onAuthReload = () => {
  emits('reload');
  tableRef.value.selectAll(false);
  tableRef.value.select(selectList.value, false);
  selectList.value = [];
}

// 表格选框触发
const onSelectionChange = (key: any[]) => {
  selectList.value = key;
}

// 表格分页触发
const onTableReload = (data: { pageNum: number; pageSize: number }) => {
  emits('reload', data);
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "edit" | "del" | "auth", data?: RoleSearchResResultItem) => {
  if (type === "edit") {
    roleFormRef.value.handleShowModal("edit", data?.id);
    return;
  }

  if (type === 'del') {
    delId.value = data?.id || NaN;
    warnignRef.value.open();
    return;
  }

  if (type === 'auth') {
    paramsAuthRef.value.handleShowModal(data?.id);
    return;
  }
};

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delRole(delId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}
</script>