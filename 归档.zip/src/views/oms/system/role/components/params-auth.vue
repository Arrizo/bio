<!-- 系统设置-角色管理-字段授权 -->
<template>
  <a-modal :mask-closable="false" title="字段授权" width="800px" v-model:visible="theModal.show" title-align="start" unmountOnClose
    :on-before-ok="onOk">
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-row :gutter="20" style="max-height: 800px;overflow: auto;" class="params-auth-row">
        <a-col :span="12">
          <div class="left-panel">
            <div class="header">
              选择页面
            </div>

            <a-spin dot v-if="menuLoading" />
            <a-tree v-else :blockNode="true" :data="((menuList) as any)" :fieldNames="{
              key: 'id',
              title: 'menuName',
              icon: ''
            }" @select="getPerm">
              <template #switcher-icon='{ expanded }'>
                <icon-caret-right v-if="expanded" style="font-size: 16;" />
                <icon-caret-down v-else style="font-size: 16;" />
              </template>
          </a-tree>
          </div>
        </a-col>
        <a-col :span="12">
          <div class="right-panel">
            <a-table :data="paramsList" :loading="authLoading" :pagination="false">
              <template #columns>
                <a-table-column title="字段" align="center" data-index="dataTitleName"></a-table-column>
                <a-table-column title="类型" align="center">
                  <template #cell="{ record, index }">
                    <a-radio-group @change="onRadioChange(record)" v-model="record.type">
                      <a-radio :value="1">敏感</a-radio>
                      <a-radio :value="2">监控</a-radio>
                    </a-radio-group>
                  </template>
                </a-table-column>
              </template>
            </a-table>
          </div>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-role-params-auth">
import { reactive, ref } from 'vue';
import { MenuListItem } from '@/types/system/menu';
import { Message } from '@arco-design/web-vue';
import { RoleAuthParamsRes, RoleParamsForm } from '@/types/system/role';
import { getRoleMenuSelect, getRoleDataPermissions,saveRoleDataPermissions } from "@/api/system/role"

const emits = defineEmits<{
  (e: "on-add"): void,
  (e: "reload"): void,
}>();

interface TheModal {
  show: boolean;
  data?: any
}
const theModal = reactive<TheModal>({
  show: false,
  data: null
});
const formRef = ref();
const menuLoading = ref<boolean>(false);
const authLoading = ref<boolean>(false);
const menuList = ref<MenuListItem[]>([]);
const form = ref<RoleParamsForm>(new RoleParamsForm());
const paramsList = ref<RoleAuthParamsRes[]>([]);

const queryMenuList = async () => {
  try {
    menuLoading.value = true;
    const res = await getRoleMenuSelect({ roleId: form.value.roleId });

    if (res.code != 0) {
      throw new Error(res.message);
    }
    menuList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    menuLoading.value = false;
  }
}

/** 点击获取对应的字段权限 */
const getPerm = async (selectedKeys: Array<any>, data: any) => {
  try {
    authLoading.value = true;
    const res = await getRoleDataPermissions({
      roleId: form.value.roleId,
      perms: data.node?.perms
    });
    if (res.code != 0) {
      throw new Error(res.message);
    }
    paramsList.value = res.value;
    for (let i = 0; i < paramsList.value.length; i++) {
      paramsList.value[i].type = paramsList.value[i].type || '';
    }
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    authLoading.value = false;
  }
}

/** 单选框改变触发 */
const onRadioChange = (data: RoleAuthParamsRes) => {
  const { perms, dictionaryValue, type } = data;

  // 首次直接添加
  if (form.value.list.length === 0) {
    form.value.list.push({ perms, dictionaryValue, type });
    return;
  }

  // 其余均需要判断是否已经选择相同字段权限，做对应的更新或者追加操作
  for (let i = 0; i < form.value.list.length; i++) {
    if (dictionaryValue === form.value.list[i].dictionaryValue && perms === form.value.list[i].perms) {
      form.value.list[i].type = type;
      break;
    } else {
      form.value.list.push({ perms, dictionaryValue, type });
      break;
    }
  }
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  try {
    const res = await saveRoleDataPermissions(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

const handleShowModal = async (id: number) => {
  theModal.show = true;
  form.value.roleId = id;
  queryMenuList();
}

defineExpose({
  handleShowModal
});
</script>
<style lang="less" scoped>
.params-auth-row {

  .left-panel {
    border: 1px solid #e5e6f5;
    border-radius: 6px;
    height: 600px;
    overflow-y: auto;

    .header {
      height: 40px;
      line-height: 40px;
      border-bottom: 1px solid #e5e6f5;
      background-color: #f2f3f5;
      color: #3c3c3c;
      text-align: center;
      font-size: 13px;
      font-weight: bold;
    }
  }
}
</style>