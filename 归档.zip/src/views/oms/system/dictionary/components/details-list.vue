<!-- 系统管理->数据字典->详情列表 -->
<template>
  <oms-table :simplePagination="true" :loading="loading" :total="totalCount" :current="form.pageNum" :size="form.pageSize"
    @reload="onReload">
    <template #header-left>
      <a-button style="margin-bottom:10px;" v-permission="['oms:system:dictionary:addItem']" type="primary" status="normal"
        @click="handleAddClick('add', {})"> 新增字典项 </a-button>
    </template>

    <a-table stripe :bordered="{ wrapper: false }" :scroll="{ x: 1400 }" :data="(list as any)" :pagination="false">
      <template #columns>
        <a-table-column title="字典项编码" ellipsis tooltip :width="180" data-index="dictionaryValue"></a-table-column>
        <a-table-column title="字典项名称" ellipsis tooltip :width="180" data-index="dictionaryTitle"></a-table-column>
        <a-table-column title="排序" :width="180" data-index="sort"></a-table-column>
        <a-table-column title="备注" ellipsis tooltip :width="180" data-index="remark"></a-table-column>
        <a-table-column title="上级字典项" ellipsis tooltip :width="180" data-index="subDictionaryValue"></a-table-column>
        <a-table-column title="状态" :width="120" data-index="status">
          <template #cell="{ record, rowIndex }">
            <a-switch v-permission="['oms:system:dictionary:statusItem']" v-model="record.status"
              @focus="onSwitchForce(record, rowIndex)">
              <template #checked>
                启用
              </template>
              <template #unchecked>
                禁用
              </template>
            </a-switch>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" :width="180" data-index="createTime"></a-table-column>
        <a-table-column title="修改时间" :width="180" data-index="updateTime"></a-table-column>
        <a-table-column title="操作" :width="80" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-link v-permission="['oms:system:dictionary:editItem']" @click="handleAddClick('edit', record)"
              type="text">编辑</a-link>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑数据字典项 -->
  <form-details @reload-details="emits('reload-details')" :dictionaryName="dictionaryName" :dictionaryTypeId="dictionaryTypeId"
    ref="DetailsRef"></form-details>
  <!-- 修改状态二次弹框 -->
  <oms-warning ref="switchRef" :on-before-ok="handleStatus"></oms-warning>
</template>

<script setup lang="ts" name="system-dictionary-list">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import FormDetails from './form-details.vue'
import OmsWarning from '@/components/oms-warning/index.vue';
import { Message } from '@arco-design/web-vue';
import { getTitleStatusUpdate } from '@/api/system/dictionary';
import { DictionaryListItem, DictionarySearchListForm } from '@/types/system/dictionary';

const props = defineProps({
  list: {
    type: Array, default: () => []
  },
  totalCount: {
    type: Number, default: 0
  },
  dictionaryTypeId: {
    type: String, default: ''
  },
  dictionaryName: {
    type: String, default: ''
  },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  loading: { type: Boolean, default: false },
});
const form = ref<DictionarySearchListForm>(new DictionarySearchListForm());
const emits = defineEmits<{
  (e: "reload-details", data?: DictionarySearchListForm): void
}>();

const DetailsRef = ref();
const switchRef = ref();
const currentId = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload-details", form.value)
};

// 「新增字典项」按钮点击触发
const handleAddClick = (type: string, record: DictionarySearchListForm) => {

  DetailsRef.value.handleDetailsShowModal(type, type === 'edit' ? record : {});
};

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: DictionaryListItem, index: number) => {
  currentId.value = record?.id + '';
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

const handleStatus = async () => {
  try {
    const res = await getTitleStatusUpdate(currentId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload-details");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

</script>