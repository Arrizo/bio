<!-- 系统设置->数据字典->编辑表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="500px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form :model="form" ref="formRef" layout="horizontal">
      <a-form-item field="dictionaryType" label="字典编码：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入字典编码' }]">
        <a-input :maxLength="50" :disabled="editModal.type === 'edit'" v-limit-input="['#', '']"
          v-model.trim="form.dictionaryType"
          @input="form.dictionaryType = form.dictionaryType.replace(/[\u4e00-\u9fa5]/g, '')" placeholder="请输入" allowClear />
      </a-form-item>
      <a-form-item field="dictionaryName" label="字典名称：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入字典名称' }]">
        <a-input :maxLength="50" v-limit-input="['#', '']" v-model.trim="form.dictionaryName" placeholder="请输入"
          allowClear />
      </a-form-item>
      <a-form-item field="dictionaryCategory" label="字典分类：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请选择字典分类' }]">
        <a-select placeholder="请选择" v-model="form.dictionaryCategory" allow-search>
          <a-option v-for="(item) in typeList" :label="item.dictionaryTitle" :value="item.dictionaryValue"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="remark" label="备注：" label-col-flex="100px">
        <a-textarea :maxLength="200" v-limit-input="['#', '']" show-word-limit v-model.trim="form.remark"
          placeholder="请输入" />
      </a-form-item>
      <a-form-item field="subDictionaryType" label="上级字典：" label-col-flex="100px">
        <a-select allow-search allow-clear placeholder="请选择" :disabled="editModal.type === 'edit'"
          v-model="form.subDictionaryType">
          <a-option v-for="item in pidValue" :label="item.dictionaryName" :value="item.dictionaryType"></a-option>
        </a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-dictionary-form">
import { DictionaryForm, AddPidType, DictionaryType } from '@/types/system/dictionary';
import { reactive, ref } from 'vue';
import { addDictionary, editDictionary, getNameList, queryType } from '@/api/system/dictionary';
import { Message } from '@arco-design/web-vue';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const form = ref<DictionaryForm>(new DictionaryForm());
const typeList = ref<DictionaryType[]>();
const formRef = ref();
const loading = ref<boolean>(false);
const pidValue = ref<AddPidType[]>([]);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  loading.value = true;
  try {
    const apiType = editModal.type === 'add' ? addDictionary : editDictionary;

    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: DictionaryForm) => {
  editModal.type = type;
  editModal.show = true;
  if (type === 'add') {
    form.value = new DictionaryForm();
    //获取字典分类
    typeList.value = await getDictionaryList('DICTIONARY_CATEGORY');
  }
  getPidList();
  if (type === "edit") {
    //获取字典分类
    typeList.value = await getValidDictionaryList('DICTIONARY_CATEGORY');
    form.value.dictionaryCategory = data.dictionaryCategoryCode;
    form.value.dictionaryName = data.dictionaryName;
    form.value.dictionaryType = data.dictionaryType;
    form.value.remark = data.remark;
    form.value.subDictionaryType = data.subDictionaryType || "";
    form.value.id = data.id;
  }
}

//获取上级字典
const getPidList = async () => {
  const res = await getNameList();
  if (res.code != 0) {
    Message.error(res.message);
    return false;
  }
  pidValue.value = res.value
}


defineExpose({
  handleShowModal
});
</script>