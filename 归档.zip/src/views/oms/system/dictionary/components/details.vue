<template>
  <div class="dictionary-details">
    <a-tabs :style="{ width: '100%' }">
      <template #extra>
        <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
      </template>
      <a-tab-pane key="2" title="字典项配置">
        <details-list @reload-details="getInfo" :dictionaryName="dictionaryData.dictionaryName" :dictionaryTypeId="dictionaryData.id + ''" :totalCount="totalCount"
          :loading="loading" :list="list"></details-list>
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script setup lang="ts" name="system-dictionary-details">
import DetailsList from './details-list.vue';
import { onMounted, ref, watch } from 'vue';
import { queryList } from '@/api/system/dictionary';
import { DictionaryListItem, DictionaryPropsForm, DictionarySearchListForm } from '@/types/system/dictionary';
import { Message } from '@arco-design/web-vue';
import { deepClone } from '@/utils/helper';
let show = ref(false);
let loading = ref(false);
let totalCount = ref();
let list = ref<DictionaryListItem[]>()
let dictionaryTypeId = ref();//字典ID，用来查询上级字典

const props = defineProps({
  dictionaryData: {
    type: Object, default: new DictionaryPropsForm()
  },
});
const emits = defineEmits<{
  (e: "close"): void,
}>();


onMounted(() => {
  dictionaryTypeId.value = props.dictionaryData.id + '';
  form.value.dictionaryType = props.dictionaryData.dictionaryType;
});


//关闭详情
const closeDetails = () => {
  emits('close')
}
const form = ref<DictionarySearchListForm>(new DictionarySearchListForm());

const getInfo = async (data: DictionarySearchListForm = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);

    const res = await queryList(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}


watch(
  () => props.dictionaryData.id,
  () => {
    if (props.dictionaryData.id) {
      dictionaryTypeId.value = props.dictionaryData.id + '';
      form.value.dictionaryType = props.dictionaryData.dictionaryType;
      getInfo(form.value);
    }
  }, {
  immediate: true,
  deep: true
}
);

</script>

<style lang="less">
.dictionary-details {
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  .arco-tabs-content {
    padding-left: 16px;
    padding-right: 16px;
  }

  .arco-tabs-nav {
    padding: 0 16px;
  }
}
</style>