<!-- 系统管理->菜单管理->列表 -->
<template>
  <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
    <template #header-left>
      <a-button style="margin-bottom: 10px;" v-permission="['oms:system:dictionary:add']" type="primary" status="normal"
        @click="handleAddClick('add', '')"> 新增字典 </a-button>
    </template>

    <a-table v-db-click="list" :db-call-back="handleDetailsClick" stripe :scroll="{ x: 1400 }" :data="(list as any)"
      :pagination="false" :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="字典编码" ellipsis tooltip data-index="dictionaryType">
          <template #cell="{ record }">{{ record.dictionaryType || '--' }}</template>
        </a-table-column>
        <a-table-column title="字典名称" ellipsis tooltip data-index="dictionaryName">
          <template #cell="{ record }">{{ record.dictionaryName || '--' }}</template>
        </a-table-column>
        <a-table-column title="字典分类" ellipsis tooltip data-index="dictionaryCategory">
          <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
        </a-table-column>
        <a-table-column title="备注" ellipsis tooltip data-index="remark">
          <template #cell="{ record }">{{ record.remark || '--' }}</template>
        </a-table-column>
        <a-table-column title="上级字典" ellipsis tooltip data-index="subDictionaryType">
          <template #cell="{ record }">{{ record.subDictionaryType || '--' }}</template>
        </a-table-column>
        <a-table-column title="状态" :width="120" data-index="status">
          <template #cell="{ record, rowIndex }">
            <a-switch v-permission="['oms:system:dictionary:status']" v-model="record.status"
              @focus="onSwitchForce(record, rowIndex)">
              <template #checked>
                启用
              </template>
              <template #unchecked>
                禁用
              </template>
            </a-switch>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" :width="180" data-index="createTime">
          <template #cell="{ record }">{{ record.createTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="修改时间" :width="180" data-index="updateTime">
          <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="操作" :width="80" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-link v-permission="['oms:system:dictionary:edit']" @click="handleAddClick('edit', rowIndex)"
              type="text">编辑</a-link>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 菜单新增/编辑弹窗 -->
  <dictionary-form-vue ref="DictionaryFromRef" @reload="emits('reload')"></dictionary-form-vue>

  <!-- 修改状态二次弹框 -->
  <oms-warning ref="switchRef" :on-before-ok="handleStatus"></oms-warning>
</template>

<script setup lang="ts" name="system-dictionary-list">
import { computed, reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import DictionaryFormVue from "./form.vue"
import { Message } from '@arco-design/web-vue';
import { getStatusUpdate } from '@/api/system/dictionary';
import { DictionaryItem, DictionaryPropsForm, DictionarySearchForm } from '@/types/system/dictionary';
const form = ref<DictionarySearchForm>(new DictionarySearchForm());

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload", data?: DictionarySearchForm): void,
  (e: "details", data: DictionaryItem): void,
}>();
const switchRef = ref();
const DictionaryFromRef = ref();
const currentId = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};

// 「新增菜单」按钮点击触发
const handleAddClick = (type: string, index: string) => {
  DictionaryFromRef.value.handleShowModal(type, type === 'edit' ? props.list[index] : '');
};

//详情
const handleDetailsClick = (data: DictionaryItem) => {
  emits('details', data)
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: DictionaryItem, index: number) => {
  currentId.value = record?.id + '';
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

const handleStatus = async () => {
  try {
    const res = await getStatusUpdate(currentId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 返回列表
const list = computed(() => {
  return props.list as Array<DictionaryItem>
})
</script>