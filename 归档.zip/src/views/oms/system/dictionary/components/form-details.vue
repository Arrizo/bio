<!-- 系统设置->数据字典->数据字典项编辑表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增字典项' : '编辑字典项'" width="500px" v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form :model="form" ref="formRef" layout="horizontal">
      <a-form-item field="dictionaryName" label="字典编码：" label-col-flex="100px">
        <a-input :disabled="true" :maxLength="50" v-limit-input="['#', '']" v-model.trim="form.dictionaryName"
          placeholder="请输入" allowClear />
      </a-form-item>
      <a-form-item field="dictionaryValue" label="字典项编码：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入字典项编码' }]">
        <a-input :disabled="editModal.type === 'edit'" :maxLength="50" v-limit-input="['#', '']"
          v-model.trim="form.dictionaryValue"
          @input="form.dictionaryValue = form.dictionaryValue.replace(/[\u4e00-\u9fa5]/g, '')" placeholder="请输入"
          allowClear />
      </a-form-item>
      <a-form-item field="dictionaryTitle" label="字典项名称：" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入字典项名称' }]">
        <a-input :maxLength="100" v-model.trim="form.dictionaryTitle" placeholder="请输入" allowClear />
      </a-form-item>
      <a-form-item field="sort" label="排序：" label-col-flex="100px">
        <a-input-number v-model="form.sort" :min="0" :max="9999" :precision="0" :formatter="transformNum"
          :parser="transformNum" />
        <!-- <a-input v-model.trim="form.sort" v-limit-input="['#', '']"  @input="form.sort=form.sort.replace(/^0|\D/g, '')" placeholder="请输入" allowClear /> -->
      </a-form-item>
      <a-form-item field="remark" label="备注：" label-col-flex="100px">
        <a-textarea :maxLength="200" v-limit-input="['#', '']" show-word-limit v-model.trim="form.remark"
          placeholder="请输入" />
      </a-form-item>
      <a-form-item field="pid" label="上级字典项：" label-col-flex="100px">
        <a-select placeholder="请选择" allow-clear :disabled="editModal.type === 'edit'" v-model="form.pid" allow-search>
          <a-option v-for="item in pidValue" :label="item.dictionaryTitle" :value="item.id"></a-option>
        </a-select>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-dictionary-form-details">
import { DictionaryTitleForm, PidType } from '@/types/system/dictionary';
import { addDictionaryTitle, editDictionaryTitle, getPidList } from '@/api/system/dictionary';
import { reactive, ref, onMounted } from 'vue';
import { Message } from '@arco-design/web-vue';
import { deepClone } from '@/utils/helper';
const props = defineProps({
  dictionaryTypeId: {
    type: String, default: ''
  },
  dictionaryName: {
    type: String, default: ''
  },
});
// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload-details"): void
}>();

const pidValue = ref<PidType[]>([]);
const form = ref<DictionaryTitleForm>(new DictionaryTitleForm());
const formRef = ref();
const loading = ref<boolean>(false);
/** 点击确定按钮时触发 */
const onOk = async (done: Function) => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const apiType = editModal.type === 'add' ? addDictionaryTitle : editDictionaryTitle;

    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload-details");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

//通过字典ID获取上级数据字典的标签列表
const pidList = async () => {
  const res = await getPidList(props.dictionaryTypeId);
  if (res.code != 0) {
    Message.error(res.message);
    return false;
  }
  pidValue.value = res.value
  return true;
}
//数字输入框限制只能输入大于等于零的整数
const transformNum = (value: string | number) => {
  let v = null
  switch (typeof value) {
    case 'string':
      v = isNaN(+value) ? 0 : value.replace(/\./g, '')
      break
    case 'number':
      v = isNaN(value) ? 0 : String(value).replace(/\./g, '')
      break
    default:
      v = 0
  }
  return v
}
/** 点击取消、关闭按钮时触发 */
const onCancel = () => { Object.assign(form.value, reactive<DictionaryTitleForm>(new DictionaryTitleForm())); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleDetailsShowModal = (type: "add" | "edit", data: DictionaryTitleForm) => {
  editModal.type = type;
  editModal.show = true;
  if (type === 'add') {
    form.value = new DictionaryTitleForm();
  }
  if (type === "edit") {
    form.value.dictionaryValue = data.dictionaryValue;
    form.value.dictionaryTitle = data.dictionaryTitle;
    form.value.sort = data.sort;
    form.value.remark = data.remark;
    form.value.pid = data.pid || "";
    form.value.id = data.id;
  }
  form.value.dictionaryTypeId = props.dictionaryTypeId;
  form.value.dictionaryName = props.dictionaryName;
  pidList();
}
defineExpose({
  handleDetailsShowModal
});
</script>