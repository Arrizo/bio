<!-- 系统管理->菜单管理->列表 -->
<template>
  <oms-table :loading="loading">
    <template #header-left>
      <a-button v-permission="['system:menu:add']" type="primary" status="normal" @click="handleAddClick" style="margin-bottom: 10px;"> 新增菜单
      </a-button>
    </template>

    <a-table :data="(list as any)" :pagination="false" hide-expand-button-on-empty row-key="id" :bordered="{ wrapper: false }">
      <!-- 重写展开图标 -->
      <template #expand-icon='{ expanded }'>
        <icon-caret-down v-if="expanded" style="font-size: 32;" />
        <icon-caret-right v-else style="font-size: 32;" />
      </template>
      <template #columns>
        <a-table-column title="菜单名称" data-index="menuName">
          <template #cell="{ record }">
						{{ record.menuName || '--' }}
					</template>
        </a-table-column>
        <a-table-column title="菜单类型" :width="100">
          <template #cell="{ record }">
            {{ TypeObj[record.type] || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="排序" :width="80" data-index="sort">
          <template #cell="{ record }">
						{{ record.sort || '--' }}
					</template>
        </a-table-column>
        <a-table-column title="权限标识" data-index="perms">
          <template #cell="{ record }">
						{{ record.perms || '--' }}
					</template>
        </a-table-column>
        <a-table-column title="URL" data-index="url">
          <template #cell="{ record }">
						{{ record.url || '--' }}
					</template>
        </a-table-column>
        <a-table-column title="图标" :width="80">
          <template #cell="{ record }">
            <i :class="['iconfont', `icon-${record.icon}`]"></i>
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="100" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link v-permission="['system:menu:edit']" @click="handleActoin('edit', record)" type="text">编辑</a-link>
              <a-link v-permission="['system:menu:del']" @click="handleActoin('del', record)" type="text"
                status="danger">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 菜单新增/编辑弹窗 -->
  <menu-form ref="MenuFormRef" @reload="emits('reload')"></menu-form>

  <!-- 删除二次确认 -->
  <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>
</template>

<script setup lang="ts" name="system-menu-list">
import { ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import MenuForm from "./form.vue";
import { MenuForm as MenuFormType } from '@/types/system/menu';
import { delMenu } from '@/api/system/menu';
import { Message } from '@arco-design/web-vue';

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

enum TypeObj {
  MENU = "目录",
  PAGE = "页面",
  BUTTON = "按钮",
}
const MenuFormRef = ref();
const warnignRef = ref();
const delId = ref<number>(NaN);

// 「新增菜单」按钮点击触发
const handleAddClick = () => {
  MenuFormRef.value.handleShowModal("add");
};

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "edit" | "del", data?: MenuFormType) => {
  if (type === "edit") {
    MenuFormRef.value.handleShowModal("edit", data);
    return;
  }

  if (type === 'del') {
    delId.value = data?.id || NaN;
    warnignRef.value.open();
    return;
  }
};

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delMenu(delId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}
</script>