<!-- 系统管理->菜单管理->搜索组件 -->
<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="menuName" label="菜单名称：">
      <a-input v-limit-input v-model.trim="form.menuName" @keyup.enter="handleSearch" allow-clear placeholder="请输入" />
    </a-form-item>
    <a-form-item field="type" label="菜单类型：">
      <a-select placeholder="请选择" v-model="form.type" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="MENU">目录</a-option>
        <a-option value="PAGE">页面</a-option>
        <a-option value="BUTTON">按钮</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="system-menu-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { MenuSearchForm } from '@/types/system/menu';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: "on-search", data: MenuSearchForm): void;
}>();

const formRes = ref();
const form = ref<MenuSearchForm>(new MenuSearchForm());

// 搜索
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

onMounted(() => {
  handleSearch();
});
</script>