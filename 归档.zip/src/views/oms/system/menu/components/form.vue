<!-- 系统设置->菜单管理->编辑表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="800px"
    v-model:visible="editModal.show" title-align="start" cancel="onCancel" unmountOnClose>
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="pid" label="上级菜单：" label-col-flex="100px">
            <a-cascader check-strictly :field-names="{ value: 'id', label: 'menuName' }" :options="last_list"
              v-model="form.pid" placeholder="请选择" allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="type" label="菜单类型：" :rules="[{ required: true, message: '请选择菜单类型' }]" label-col-flex="100px"
            required>
            <a-select placeholder="请选择" v-model="form.type">
              <a-option value="MENU">目录</a-option>
              <a-option value="PAGE">页面</a-option>
              <a-option value="BUTTON">按钮</a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="menuName" label="菜单名称：" label-col-flex="100px" required
            :rules="[{ required: true, message: '请输入菜单名称' }]">
            <a-input v-limit-input v-model="form.menuName" placeholder="请输入" :max-length="20" allow-clear
              show-word-limit />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="sort" label="排序：" label-col-flex="100px" v-if="form.type !== 'BUTTON'">
            <a-input-number v-model="form.sort" placeholder="请输入" />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="icon" label="图标样式：" label-col-flex="100px" v-if="form.type !== 'BUTTON'">
            <icon-select v-model="form.icon"></icon-select>
            <a-link style="margin-top:32px;color:#3E6CFE;margin-left:4px;font-weight: 500;" v-if="form.icon"
              @click="form.icon = ''">清空</a-link>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="url" label="URL：" label-col-flex="100px" v-if="form.type !== 'BUTTON'">
            <a-input v-limit-input v-model="form.url" placeholder="请输入" />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="perms" label="权限标识：" label-col-flex="100px">
            <a-input v-limit-input v-model="form.perms" placeholder="请输入" />
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
    <template #footer>
      <a-button @click="onCancel">取消</a-button>
      <a-button type="primary" status="normal" @click="onOk(false)">确定</a-button>
      <a-button type="primary" status="normal" v-if="editModal.type === 'add'" @click="onOk(true)">确定并添加下一个</a-button>
    </template>
  </a-modal>
</template>

<script setup lang="ts" name="system-menu-form">
import { MenuForm, MenuListItem } from '@/types/system/menu';
import { reactive, ref } from 'vue';
import { addMenu, editMenu } from '@/api/system/menu';
import { Message } from '@arco-design/web-vue';
import { queryMenu } from '@/api/system/menu';
import { deepClone } from '@/utils/helper';
import iconSelect from './icon-select.vue';

// 菜单编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const form = ref<MenuForm>(new MenuForm());
const last_list = ref<MenuListItem[]>([]);

const init = async () => {
  try {
    const res = await queryMenu({
      menuName: "",
      type: ""
    });

    if (res.code != 0) {
      throw new Error(res.message);
    }
    last_list.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

/** 点击确定按钮前触发 */
const onOk = async (isNext = false) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const apiType = editModal.type === 'add' ? addMenu : editMenu;

    delete form.value.children;
    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    if (!isNext) {
      onCancel();
    }
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => {
  editModal.show = false;
  emits("reload");
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = (type: "add" | "edit", data: MenuForm) => {
  editModal.type = type;
  editModal.show = true;

  if (type === "edit") {
    form.value = deepClone(data);

    // 一些需要特殊处理
    form.value.menuId = data.id;
    form.value.pid === 0 && (form.value.pid = '');
    form.value.sort = data.sort ?? undefined;
    form.value.icon = data.icon ?? '';
    form.value.url = data.url ?? '';
    form.value.perms = data.perms ?? '';
  }

  if (type === 'add') {
    form.value = new MenuForm();
  }

  init();
}

defineExpose({
  handleShowModal
});
</script>