<template>
  <div class="icon-select">
    <div v-if="modelValue" class="icon-preview" @click="showModal = true">
      <i :class="['iconfont', `icon-${icon}`]"></i>
    </div>
    <a-button v-else @click="showModal = true">选择图标</a-button>

    <a-modal :mask-closable="false" title="选择图标" width="800px" v-model:visible="showModal" title-align="start" :on-before-ok="onOk"
      unmountOnClose @cancel="icon = ''">
      <div class="icon-area">
        <div :class="['icon-item', { active: icon === v }]" v-for="v in list" :key="`icon-${v}`" @click="onSelect(v)">
          <i :class="['iconfont', `icon-${v}`]"></i>
        </div>
      </div>
    </a-modal>
  </div>
</template>

<script setup lang="ts" name="icon-select">
import { Message } from '@arco-design/web-vue';
import { ref, watch } from 'vue';

const props = defineProps({
  modelValue: { type: String, default: "" }
});

const emits = defineEmits<{
  (e: "update:modelValue", data: string): void
}>();

const list: string[] = [
  "a-huaban3",
  "a-huaban2",
  "icon_home_nomal",
  "icon_wuliuzx_nomal",
  "icon_kefuzx_nomal",
  "icon_xitonggl_nomal",
  "icon_yingxiaogl_nomal",
  "icon_dingdanzx_nomal",
  "icon_jichuzl_nomal",
  "icon_celuegl_nomal",
];
const showModal = ref<boolean>(false);
const icon = ref<string>(props.modelValue);

const onSelect = (v: string) => {
  icon.value = v;
}

const onOk = () => {
  if (!icon.value) {
    Message.error("请选择图标");
    return false;
  }
  emits("update:modelValue", icon.value);
  return true
}

watch(() => props.modelValue, (v) => {
  icon.value = props.modelValue;
});
</script>

<style lang="less">
.icon-select {
  .icon-preview {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    width: 49px;
    height: 49px;
    background: rgba(255, 255, 255, 0.39);
    border: 1px solid #EDEDED;
    opacity: 1;
    border-radius: 2px;
    cursor: pointer;

    .iconfont {
      font-size: 20px;
    }

    &::after {
      width: 100%;
      content: "更换";
      background: rgba(0, 0, 0, 0.69);
      opacity: 0.5;
      border-radius: 0px 0px 2px 2px;
      font-size: 12px;
      font-weight: 400;
      line-height: 16px;
      text-align: center;
      color: #FFFFFF;
    }
  }
}

.icon-area {
  display: inline-flex;
  flex-direction: row-reverse;
  flex-wrap: wrap;
  justify-content: flex-end;

  .icon-item {
    display: flex;
    justify-content: center;
    align-items: center;
    color: #5a5a5a;
    width: 40px;
    height: 40px;
    border-radius: 4px;
    border: 1px solid #ececec;
    margin-bottom: 10px;
    margin-right: 10px;
    cursor: pointer;

    .iconfont {
      font-size: 24px;
    }

    &:hover {
      border: 1px solid #3e6cfe;

      .iconfont {
        color: #3e6cfe;
      }
    }
  }

  .active {
    border: 1px solid #3e6cfe;

    .iconfont {
      color: #3e6cfe;
    }
  }
}
</style>