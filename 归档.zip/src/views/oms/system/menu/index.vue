<!-- 系统管理->菜单管理 -->
<template>
  <a-row :gutter="10" style="height: 100%;">
    <a-col :span="24" style="height: 100%;">
      <oms-panel style="height: 100%;">
        <template #header>
          <search :loading="loading" @on-search="init"></search>
        </template>
        <div>
          <list :loading="loading" :list="list" @reload="init"></list>
        </div>
      </oms-panel>
    </a-col>
  </a-row>
</template>

<script setup lang="ts" name="system-menu">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import { queryMenu } from '@/api/system/menu';
import { MenuListItem, MenuSearchForm } from '@/types/system/menu';
import { Message } from '@arco-design/web-vue';
import { ref } from 'vue';

const loading = ref<boolean>(false);
const list = ref<MenuListItem[]>([]);
const form = ref<MenuSearchForm>(new MenuSearchForm());

/**
 * 初始化查询菜单数据
 * @param data
 */
const init = async (data: MenuSearchForm = form.value) => {
  try {
    form.value = data;

    loading.value = true;
    const res = await queryMenu({
      menuName: form.value.menuName,
      type: form.value.type === 'all' ? '' : form.value.type
    });

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}
</script>