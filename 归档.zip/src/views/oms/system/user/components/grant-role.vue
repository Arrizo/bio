<template>
  <a-modal unmountOnClose title="角色授权" width="828px" :mask-closable="false" title-align="start" class="system-user-grant-model"
    v-model:visible="visible" :on-before-ok="handleConfirm" @cancel="handleClose">

    <div class="grant-inner">
      <div class="grant-inner-box box-left">
        <div class="header">
          <a-checkbox :indeterminate="leftSelect.length >= 1 && leftSelect.length < leftData.length"
            v-model="leftSelectAll" @change="onLeftSelectAll">未选</a-checkbox>
          <p class="num-tip">{{ leftSelect.length }}/{{ leftData.length }}</p>
        </div>
        <div class="content">
          <a-input-search v-model="leftInp" placeholder="请输入" @input="onLeftSelectChange"></a-input-search>
          <a-empty v-if="leftData.length === 0" />

          <template v-else>
            <a-checkbox-group v-model="leftSelect" @change="onLeftSelectChange">
              <div class="trans-data-item" v-for="v in leftData">
                <a-checkbox :value="v.value">{{ v.label }}</a-checkbox>
              </div>
            </a-checkbox-group>
          </template>
        </div>
      </div>
      <div class="grant-inner-arrow-box">
        <div :class="['arrow-item', { 'arrow-disabled': transferData.length === 0 }]" @click="handleTrans('right')">
          <icon-right />
        </div>
        <div :class="['arrow-item', { 'arrow-disabled': rightTransferData.length === 0 }]" @click="handleTrans('left')">
          <icon-left />
        </div>
      </div>
      <div class="grant-inner-box box-right">
        <div class="header">
          <a-checkbox :indeterminate="rightSelect.length >= 1 && rightSelect.length < rightData.length"
            v-model="rightSelectAll" @change="onRightSelectAll">已选</a-checkbox>
          <p class="num-tip">{{ rightSelect.length }}/{{ rightData.length }}</p>
        </div>
        <div class="content">
          <a-input-search v-model="rightInp" placeholder="请输入" @input="onRightSelectChange"></a-input-search>
          <a-empty v-if="rightData.length === 0" />

          <template v-else>
            <a-checkbox-group v-model="rightSelect" @change="onRightSelectChange">
              <div class="trans-data-item" v-for="v in rightData">
                <a-checkbox :value="v.value">{{ v.label }}</a-checkbox>
              </div>
            </a-checkbox-group>
          </template>
        </div>
      </div>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="grant-role">
import { ref, computed } from 'vue';
import { Message } from '@arco-design/web-vue';
import {
  roleAuth,
  getRoleList,
  getUserRoleList,
  RoleAuthParameterType,
} from '@/api/system/role';

// 弹窗相关
const visible = ref(false);
const leftInp = ref('');
const leftSelect = ref<any[]>([]);
const leftSelectAll = ref(false);
const rightInp = ref('');
const rightSelect = ref<any[]>([]);
const rightSelectAll = ref(false);

const leftData = computed(() => {
  return transferData.value.filter((v) => {
    return v.label.includes(leftInp.value);
  });
});

const rightData = computed(() => {
  return rightTransferData.value.filter((v) => {
    return v.label.includes(rightInp.value);
  });
});

const onLeftSelectAll = () => {
  leftSelect.value = [];
  if (leftSelectAll.value) {
    for (let i = 0; i < leftData.value.length; i++) {
      leftSelect.value.push(leftData.value[i].value);
    }
  }
}

const onRightSelectAll = () => {
  rightSelect.value = [];
  if (rightSelectAll.value) {
    for (let i = 0; i < rightData.value.length; i++) {
      rightSelect.value.push(rightData.value[i].value);
    }
  }
}

const onLeftSelectChange = () => {
  leftSelectAll.value = leftInp.value
    ? false
    : leftSelect.value.length === transferData.value.length;
}

const onRightSelectChange = () => {
  rightSelectAll.value = rightInp.value
    ? false
    : rightSelect.value.length === rightTransferData.value.length;
}

const handleTrans = (type: "left" | "right") => {
  if (type === 'right') {
    for (let i = 0; i < leftSelect.value.length; i++) {
      for (let j = 0; j < transferData.value.length; j++) {
        if (leftSelect.value[i] === transferData.value[j].value) {
          rightTransferData.value.push(transferData.value[j]);
          transferData.value.splice(j, 1);
        }
      }
    }
    leftSelect.value = [];
    leftSelectAll.value = false;
  }

  if (type === 'left') {
    for (let i = 0; i < rightSelect.value.length; i++) {
      for (let j = 0; j < rightTransferData.value.length; j++) {
        if (rightSelect.value[i] === rightTransferData.value[j].value) {
          transferData.value.push(rightTransferData.value[j]);
          rightTransferData.value.splice(j, 1);
        }
      }
    }
    rightSelect.value = [];
    rightSelectAll.value = false;
  }
}

const handleConfirm = async () => {
  try {
    selectRoleIdList.value = [];
    for (let i = 0; i < rightData.value.length; i++) {
      selectRoleIdList.value.push(rightData.value[i].value);
    }
    if (isBatchGrant() && selectRoleIdList.value.length < 1) {
      Message.warning('请选择角色');
      return false;
    }
    let parameter: RoleAuthParameterType = {
      id: modelOptions.value.userId,
      lstRoleId: selectRoleIdList.value
    }
    let response = await roleAuth(parameter);
    if (response?.success) {
      Message.success('角色授权保存成功');
      return true;
    } else {
      Message.warning(response?.message || '角色授权保存失败');
      return false;
    }
  } catch (e) {
    console.error(e);
    Message.warning('设置角色授权失败');
    return false;
  }
}
const handleClose = () => {
  visible.value = false;
}

// 穿梭框相关
class TransferItem {
  value: string = '';
  label: string = '';
  disabled: boolean = false;
}
const transferData = ref<TransferItem[]>([]);
const rightTransferData = ref<TransferItem[]>([]);
const selectRoleIdList = ref<string[]>([]);

// 查询角色列表
class RoleSelectItem {
  id: string = '';
  roleName: string = '';
  disabled: boolean = false;
}
const roleList = ref<RoleSelectItem[]>([]);
const queryRoleList = async () => {
  try {
    let response = await getRoleList();
    if (response?.success) {
      roleList.value = response?.value ?? [];
      transferData.value = roleList.value.map(role => {
        return {
          value: role.id,
          label: role.roleName,
          disabled: false
        }
      })
    } else {
      Message.warning(response?.message || '查询角色列表失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询角色列表失败");
  }
}

// 查询用户已经被授予的角色
const queryUserRoleList = async (userId: string) => {
  try {
    let response = await getUserRoleList(userId);
    if (response?.success) {
      return response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询用户已经被授予的角色失败');
      return [];
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询用户已经被授予的角色失败");
    return [];
  }
}

// 弹窗可选配置项
class OpenOptions {
  // 切换的用户ID
  userId: string[] = [];
}
const modelOptions = ref(new OpenOptions());
const isBatchGrant = () => {
  return Array.isArray(modelOptions.value.userId) && modelOptions.value?.userId?.length > 1;
}
const open = async (options: OpenOptions) => {
  try {
    transferData.value = [];
    leftInp.value = "";
    leftSelect.value = [];
    leftSelectAll.value = false;
    rightTransferData.value = [];
    rightInp.value = "";
    rightSelect.value = [];
    rightSelectAll.value = false;
    await queryRoleList();
    if (Array.isArray(options?.userId) && options?.userId?.length === 1) {
      let selectRoleList: Pick<RoleSelectItem, 'id' | 'roleName'>[] = await queryUserRoleList(options.userId[0]);
      selectRoleIdList.value = selectRoleList.map(item => item.id);
    } else {
      selectRoleIdList.value = [];
    }
    for (let i = 0; i < selectRoleIdList.value.length; i++) {
      for (let j = 0; j < transferData.value.length; j++) {
        if (selectRoleIdList.value[i] === transferData.value[j].value) {
          rightTransferData.value.push(transferData.value[j]);
          transferData.value.splice(j, 1);
        }
      }
    }
    modelOptions.value = options;
    visible.value = true;
  } catch (e) {
    console.error(e);
  }
}
defineExpose({
  open
})

</script>

<style lang="less">
@import './grant-madel.less';
</style>