<!-- 系统设置->用户管理->组织表单 -->
<template>
  <a-modal :mask-closable="false" :title="`${editModal.type === 'add' ? '新增' : '编辑'}组织`" width="800px" v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form :model="form" layout="horizontal" ref="formRef">
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="orgCode" label="组织编码：" label-col-flex="100px" required
            :rules="[{ required: true, message: '请输入组织编码' }]">
            <a-input v-limit-input :max-length="50" allow-clear show-word-limit v-model.trim="form.orgCode"
              @input="form.orgCode = form.orgCode.replace(/[\u4e00-\u9fa5]/g, '')" placeholder="请输入" />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="orgName" label="组织名称：" label-col-flex="100px" required
            :rules="[{ required: true, message: '请输入组织名称' }]">
            <a-input v-limit-input :max-length="100" allow-clear show-word-limit v-model.trim="form.orgName"
              placeholder="请输入" />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="parentId" label="上级组织：" label-col-flex="100px">
            <a-cascader v-model="form.parentId" :options="treeData" expand-child :style="{ width: '320px' }"
              :field-names="{ value: 'id', label: 'orgName' }" placeholder="请选择" check-strictly />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="sort" label="排序：" label-col-flex="100px">
            <a-input-number v-model="(form.sort as number)" placeholder="请输入" />
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-user-organization-form">
import { OrganizationForm } from '@/types/system/user';
import { addOrg, updateOrg, getOrgTree } from '@/api/system/user';
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { deepClone } from '@/utils/helper';
import { fromPairs } from 'lodash';

// 菜单编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});
const emits = defineEmits<{
  (e: "reload"): void
}>();

const treeData = ref();
const formRef = ref();
const form = ref<OrganizationForm>(new OrganizationForm());

const init = async () => {
  try {
    const res = await getOrgTree();
    if (res.code != 0) {
      throw new Error(res.message);
    }

    treeData.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

/** 点击确定按钮时触发 */
const onOk = async () => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  try {
    const api = editModal.type === 'add' ? addOrg : updateOrg;
    const res = await api(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = (type: "add" | "edit", data: OrganizationForm) => {
  editModal.type = type;
  editModal.show = true;
  editModal.data = data;

  if (type === 'add') {
    form.value = new OrganizationForm();
    form.value.parentId = data.id;
  } else {
    form.value = deepClone(data);
    form.value.sort = form.value.sort ? 0 : form.value.sort;
  }
  init();
}
defineExpose({
  handleShowModal
});
</script>