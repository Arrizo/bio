<template>
  <a-modal
    unmountOnClose
    :mask-closable="false"
    title-align="start"
    v-model:visible="visible"
    @ok="handleConfirm"
    :width="440"
    @cancel="handleClose">
    <template #title>{{ modelOptions.title }}</template>
    <div>{{ modelOptions.content }}</div>
  </a-modal>
</template>

<script setup lang="ts" name="system-user-toggle">
import { ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { toggleUserStatus, batchToggleUserStatus } from '@/api/system/user';

const visible = ref(false);
const emits = defineEmits(['reload', 'clearSelection']);
const handleConfirm = async()  => {
  try {
    let response = null;
    if (modelOptions.value.type === 'batch') {
      response = await batchToggleUserStatus(modelOptions.value.userId as string[], modelOptions.value.status);
    } else {
      response = await toggleUserStatus(modelOptions.value.userId as string);
    }
    if (response?.success) {
      Message.success('切换用户状态成功');
      visible.value = false;
      emits('reload');
      if (modelOptions.value.type === 'batch') {
        emits('clearSelection');
      }
    } else {
      Message.warning(response?.message ?? '切换用户状态失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning('切换用户状态失败');
  }
}
const handleClose = () => {
  visible.value = false;
}

// 弹窗可选配置项
class OpenOptions {
  // 批量切换/单个切换
  type: 'batch' | 'single' = 'single';
  // 切换状态为 启用：true，禁用：fasle
  status: boolean = false;
  // 弹窗标题
  title: string = '';
  // 弹窗内容
  content: string = '';
  // 切换的用户ID
  userId: string | string[] = '';
}
const modelOptions = ref(new OpenOptions());
const open = (options: OpenOptions) => {
  modelOptions.value = options;
  visible.value = true;
}
defineExpose({
  open
})

</script>