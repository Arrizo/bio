<!-- 系统设置-用户管理-用户表单 -->
<template>
  <a-modal
    width="800px"
    :mask-closable="false"
    title-align="start"
    v-model:visible="editModal.show"
    :on-before-ok="onOk" unmountOnClose
    :title="editModal.type === 'add' ? '新增用户' : '编辑用户'">
    <!-- 表单内容 -->
    <a-form ref="formRef" :model="form" :rules="formRules" layout="horizontal">
      <!-- 用户信息表单-基本信息 -->
      <p style="font-weight:bold">基本信息</p>
      <a-row :gutter="10">
        <!-- 用户类型 -->
        <a-col :span="12">
          <a-form-item required field="type" label="用户类型：" label-col-flex="100px">
            <a-select v-model="form.type" :style="{ width: '320px' }" placeholder="请选择" allow-clear>
              <a-option v-for="v in initParams?.USER_TYPE" :value="v.dictionaryValue" :label="v.dictionaryTitle"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <!-- 用户账号 -->
        <a-col :span="12">
          <a-form-item field="userName" label="用户账号：" label-col-flex="100px">
            <a-input v-limit-input @keyup.enter="onOk" v-model.trim="form.userName" placeholder="请输入" :max-length="50" allow-clear
              show-word-limit @input="form.userName = form.userName?.replace(/[\u4e00-\u9fa5]+/g, '')"/>
          </a-form-item>
        </a-col>
        <!-- 用户姓名 -->
        <a-col :span="12">
          <a-form-item field="nickname" label="用户姓名：" label-col-flex="100px" required
            :rules="[{ required: true, message: '请输入用户姓名' }]">
            <a-input v-limit-input @keyup.enter="onOk" v-model.trim="form.nickname" placeholder="请输入" :max-length="100" allow-clear
              show-word-limit />
          </a-form-item>
        </a-col>
        <!-- 所属组织 -->
        <a-col :span="12">
          <a-form-item field="orgId" label="所属组织：" label-col-flex="100px">
            <a-cascader v-model="form.orgId" :options="treeData" expand-child :style="{ maxWidth: '320px' }"
              :field-names="{ value: 'id', label: 'orgName' }" placeholder="请选择"
              check-strictly allow-clear/>
          </a-form-item>
        </a-col>
        <!-- 岗位名称 -->
        <a-col :span="12">
          <a-form-item field="jobCode" label="岗位名称：" label-col-flex="100px">
            <a-select v-model="form.jobCode" :style="{ width: '320px' }" placeholder="请选择">
              <a-option v-for="v in initParams?.JOB_TYPE" :value="v.dictionaryValue" :label="v.dictionaryTitle"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <!-- 手机号码 -->
        <a-col :span="12">
          <a-form-item field="mobile" label="手机号码：" label-col-flex="100px">
            <a-input v-limit-input @keyup.enter="onOk" v-model.trim="form.mobile" placeholder="请输入" :max-length="11" allow-clear
              show-word-limit />
          </a-form-item>
        </a-col>
      </a-row>
      <!-- 用户信息表单-权限设置 -->
      <p style="font-weight:bold">权限设置</p>
      <a-row :gutter="10">
        <!-- 角色授权 -->
        <a-col :span="12">
          <a-form-item field="lstRoleId" label="角色授权：" label-col-flex="100px">
            <!-- <a-select multiple v-model="form.lstRoleId" :style="{ width: '320px' }" placeholder="请选择" allow-clear :max-tag-count="1">
              <a-option v-for="v in initParams?.lstRole" :value="v.id" :label="v.roleName"></a-option>
            </a-select> -->
            <oms-multiple-select v-model="form.lstRoleId" :option-list="initParams?.lstRole" value="id" label="roleName"></oms-multiple-select>
          </a-form-item>
        </a-col>
        <!-- 店铺授权 -->
        <a-col :span="12">
          <a-form-item field="lstStoreId" label="店铺授权：" label-col-flex="100px">
            <!-- <a-select multiple v-model="form.lstStoreId" :style="{ width: '320px' }" placeholder="请选择" allow-clear :max-tag-count="1">
              <a-option v-for="v in initParams?.lstStore" :value="v.id" :label="v.storeName"></a-option>
            </a-select> -->
            <oms-multiple-select v-model="form.lstStoreId" :style="{ width: '320px' }" :option-list="initParams?.lstStore" value="id" label="storeName" :max-tag-count="1"></oms-multiple-select>
          </a-form-item>
        </a-col>
        <!-- 仓库授权 -->
        <a-col :span="12">
          <a-form-item field="lstWarehouseId" label="仓库授权：" label-col-flex="100px">
            <!-- <a-select multiple v-model="form.lstWarehouseId" :style="{ width: '320px' }" placeholder="请选择" allow-clear :max-tag-count="1">
              <a-option v-for="v in initParams?.lstWarehouse" :value="v.id" :label="v.warehouseName"></a-option>
            </a-select> -->
            <oms-multiple-select v-model="form.lstWarehouseId" :style="{ width: '320px' }" :option-list="initParams?.lstWarehouse" value="id" label="warehouseName" :max-tag-count="1"></oms-multiple-select>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-user-form">
import { reactive, ref } from 'vue'
import { Message } from '@arco-design/web-vue'
import { UserForm } from '@/types/system/user'
import { addUser, editUser, getOrgTree, initData, userDetail } from '@/api/system/user'
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"
import { Mobile, Phone } from '@/utils/regex';

interface EditModal {
  show: boolean
  type: "add" | "edit"
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
})

const emits = defineEmits<{
  (e: "reload"): void
}>()

const formRef = ref()
const treeData = ref()
const initParams = ref()
const form = ref<UserForm>(new UserForm())
const formRules = {
  // 用户类型
  type: [
    { required: true, message: '请输入用户类型' }
  ],
  // 用户账号
  userName: [
    { required: true, message: '请输入用户账号' }
  ],
  mobile: [
    {
      validator: (value: any, callback: any) => {
        return new Promise((resolve) => {
          if (!value) {
            return resolve(true);
          }
          if (value.length > 0) {
            if (!Mobile.test(value)) callback("请输入正确的手机号码或者固话号码");
          } else {
            if (!Phone.test(value)) callback("请输入正确的手机号码或者固话号码");
          }
          resolve(true);
        });
      }
    }
  ]
}

const init = async () => {
  try {
    const res = await getOrgTree()
    const initRes = await initData()
    if (res.code != 0 || initRes.code != 0) {
      throw new Error(res.message)
    }

    treeData.value = res.value
    initParams.value = initRes.value
  } catch (err) {
    Message.error((err as Error).message)
  }
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate()
  if (check) {
    return false
  }
  try {
    const api = editModal.type === 'add' ? addUser : editUser
    const res = await api(form.value)

    if (res.code != 0) {
      Message.error(res.message)
      return false
    }
    Message.success(res.message)
    emits("reload")
    return true
  } catch (err) {
    Message.error((err as Error).message)
    return false
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: any) => {
  editModal.type = type
  editModal.show = true
  editModal.data = data

  if (type === 'edit') {
    try {
      const res = await userDetail(data.id)
      if (res.code != 0) {
        Message.error(res.message)
        return
      }

      form.value = res.value
    } catch (err) {
      Message.error((err as Error).message)
    }
  } else {
    form.value = new UserForm();
  }

  init()
}

defineExpose({
  handleShowModal
})
</script>