<template>
  <a-modal
    unmountOnClose
    title="仓库授权"
    title-align="start"
    :mask-closable="false"
    class="system-user-grant-model"
    v-model:visible="visible"
    :on-before-ok="handleConfirm"
    @cancel="handleClose">
    <a-transfer
      :data="transferData"
      :title="['未选', '已选']"
      v-model="selectStoreIdList"
      show-search/>
  </a-modal>
</template>

<script setup lang="ts" name="grant-store">
import { ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import {
  storeAuth,
  getStoreList,
  getUserStoreList,
  StoreAuthParameterType
} from '@/api/system/role';

// 弹窗相关
const visible = ref(false);
const handleConfirm = async()  => {
  try {
    if (isBatchGrant() && selectStoreIdList.value.length < 1) {
      Message.warning('请选择仓库');
      return false;
    }
    let parameter: StoreAuthParameterType = {
      id: modelOptions.value.userId,
      lstWarehouseId: selectStoreIdList.value
    }
    let response = await storeAuth(parameter);
    if (response?.success) {
      Message.success('仓库授权保存成功');
      return true;
    } else {
      Message.warning(response?.message || '仓库授权保存失败');
      return false;
    }
  } catch (e) {
    console.error(e);
    Message.warning('设置仓库授权失败');
    return false;
  }
}
const handleClose = () => {
  visible.value = false;
}

// 穿梭框相关
class TransferItem {
  value: string = '';
  label: string = '';
  disabled: boolean = false;
}
const transferData = ref<TransferItem[]>([]);
const selectStoreIdList = ref<string[]>([]);

// 查询仓库列表
class StoreSelectItem {
  id: string = '';
  warehouseName: string = '';
  disabled: boolean = false;
}
const storeList = ref<StoreSelectItem[]>([]);
const queryStoreList = async() => {
  try {
    let response = await getStoreList();
    if (response?.success) {
      storeList.value = response?.value ?? [];
      transferData.value = storeList.value.map(store => {
        return {
          value: store.id,
          label: store.warehouseName,
          disabled: false
        }
      })
    } else {
      Message.warning(response?.message || '查询仓库列表失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询仓库列表失败");
  }
}

// 查询用户已经被授权的仓库
const queryUserStoreList = async(userId: string) => {
  try {
    let response = await getUserStoreList(userId);
    if (response?.success) {
      return response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询用户已经被授权的仓库失败');
      return [];
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询用户已经被授权的仓库失败");
    return [];
  }
}

// 弹窗可选配置项
class OpenOptions {
  // 切换的用户ID
  userId: string[] = [];
}
const modelOptions = ref(new OpenOptions());
const isBatchGrant = () => {
  return Array.isArray(modelOptions.value.userId) && modelOptions.value?.userId?.length > 1;
}
const open = async (options: OpenOptions) => {
  try {
    await queryStoreList();
    if (Array.isArray(options?.userId) && options?.userId?.length === 1) {
      let selectStoreList: Pick<StoreSelectItem, 'id' | 'warehouseName'>[] = await queryUserStoreList(options.userId[0]);
      selectStoreIdList.value = selectStoreList.map(item => item.id);
    } else {
      selectStoreIdList.value = [];
    }
    modelOptions.value = options;
    visible.value = true;
  } catch (e) {
    console.error(e);
  }
}
defineExpose({
  open
})

</script>

<style lang="less">
@import './grant-madel.less';
</style>