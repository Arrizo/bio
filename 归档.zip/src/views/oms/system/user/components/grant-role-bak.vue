<template>
  <a-modal
    unmountOnClose
    title="角色授权"
    :mask-closable="false"
    title-align="start"
    class="system-user-grant-model"
    v-model:visible="visible"
    :on-before-ok="handleConfirm"
    @cancel="handleClose">
    <a-transfer
      :data="transferData"
      :title="['未选', '已选']"
      v-model="selectRoleIdList"
      show-search/>
  </a-modal>
</template>

<script setup lang="ts" name="grant-role">
import { ref, computed } from 'vue';
import { Message } from '@arco-design/web-vue';
import {
  roleAuth,
  getRoleList,
  getUserRoleList,
  RoleAuthParameterType,
} from '@/api/system/role';

// 弹窗相关
const visible = ref(false);
const handleConfirm = async()  => {
  try {
    if (isBatchGrant() && selectRoleIdList.value.length < 1) {
      Message.warning('请选择角色');
      return false;
    }
    let parameter: RoleAuthParameterType = {
      id: modelOptions.value.userId,
      lstRoleId: selectRoleIdList.value
    }
    let response = await roleAuth(parameter);
    if (response?.success) {
      Message.success('角色授权保存成功');
      return true;
    } else {
      Message.warning(response?.message || '角色授权保存失败');
      return false;
    }
  } catch (e) {
    console.error(e);
    Message.warning('设置角色授权失败');
    return false;
  }
}
const handleClose = () => {
  visible.value = false;
}

// 穿梭框相关
class TransferItem {
  value: string = '';
  label: string = '';
  disabled: boolean = false;
}
const transferData = ref<TransferItem[]>([]);
const selectRoleIdList = ref<string[]>([]);

// 查询角色列表
class RoleSelectItem {
  id: string = '';
  roleName: string = '';
  disabled: boolean = false;
}
const roleList = ref<RoleSelectItem[]>([]);
const queryRoleList = async() => {
  try {
    let response = await getRoleList();
    if (response?.success) {
      roleList.value = response?.value ?? [];
      transferData.value = roleList.value.map(role => {
        return {
          value: role.id,
          label: role.roleName,
          disabled: false
        }
      })
    } else {
      Message.warning(response?.message || '查询角色列表失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询角色列表失败");
  }
}

// 查询用户已经被授予的角色
const queryUserRoleList = async(userId: string) => {
  try {
    let response = await getUserRoleList(userId);
    if (response?.success) {
      return response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询用户已经被授予的角色失败');
      return [];
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询用户已经被授予的角色失败");
    return [];
  }
}

// 弹窗可选配置项
class OpenOptions {
  // 切换的用户ID
  userId: string[] = [];
}
const modelOptions = ref(new OpenOptions());
const isBatchGrant = () => {
  return Array.isArray(modelOptions.value.userId) && modelOptions.value?.userId?.length > 1;
}
const open = async (options: OpenOptions) => {
  try {
    await queryRoleList();
    if (Array.isArray(options?.userId) && options?.userId?.length === 1) {
      let selectRoleList: Pick<RoleSelectItem, 'id' | 'roleName'>[] = await queryUserRoleList(options.userId[0]);
      selectRoleIdList.value = selectRoleList.map(item => item.id);
    } else {
      selectRoleIdList.value = [];
    }
    modelOptions.value = options;
    visible.value = true;
  } catch (e) {
    console.error(e);
  }
}
defineExpose({
  open
})

</script>

<style lang="less">
@import './grant-madel.less';
</style>