<!-- 系统管理->用户管理->搜索组件 -->
<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="username" label="用户账号：" label-col-flex="90px">
      <a-input v-limit-input v-model.trim="form.username" placeholder="请输入" @keyup.enter="handleSearch" :max-length="50"
        @input="form.username = form.username?.replace(/[\u4e00-\u9fa5]+/g, '')" allow-clear/>
    </a-form-item>
    <a-form-item field="nickname" label="用户姓名：" label-col-flex="90px">
      <a-input v-limit-input v-model.trim="form.nickname" placeholder="请输入" @keyup.enter="handleSearch" allow-clear :max-length="100"/>
    </a-form-item>
    <a-form-item field="status" label="状态：" label-col-flex="90px">
      <a-select placeholder="请选择" v-model="(form.status as string)" allow-clear @keyup.enter="handleSearch">
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>

    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="system-user-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { UserSearchForm } from '@/types/system/user';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: "on-search", data: UserSearchForm): void;
}>();

const formRes = ref();
const form = ref<UserSearchForm>(new UserSearchForm());

// 搜索
const handleSearch = () => emits("on-search", {
  nickname: form.value.nickname,
  username: form.value.username,
  status: form.value.status
});

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

onMounted(() => {
  handleSearch();
});
</script>