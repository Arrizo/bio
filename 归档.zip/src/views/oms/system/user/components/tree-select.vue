<!-- 系统管理->用户管理->左侧树状选择组件 -->
<template>
  <div class="tree-select-box-user">
    <div style="padding:10px 10px 16px 10px">
      <a-input-search placeholder="输入搜索关键字" allow-clear v-model="searchValue">
      </a-input-search>
    </div>

    <a-scrollbar style="height:96%;overflow:scroll;padding: 0 10px 0 10px;">
      <a-spin dot v-if="loading" />
      <a-tree blockNode v-else :data="treeData" :fieldNames="{
        title: 'orgName',
        key: 'id'
      }" @select="onSelect" style="height:740px;">
        <template #switcher-icon="{ isLeaf }">
          <icon-caret-right v-if="isLeaf" style="font-size: 16;" />
          <icon-caret-down v-else style="font-size: 16;" />
        </template>
        <template #title="nodeData">
          <template v-if="index = getMatchIndex(nodeData?.orgName), index < 0"><span>{{ nodeData?.orgName
          }}</span></template>
          <template v-else>
            {{ nodeData?.orgName?.substr(0, index) }}
            <span style="color: var(--color-primary-light-4);">
              {{ nodeData?.orgName?.substr(index, searchValue.length) }}
            </span>{{ nodeData.orgCode === 'all' ? nodeData.orgName : nodeData.orgCode + '-' + nodeData.orgName }}
          </template>
        </template>
        <template #extra="nodeData">
          <a-dropdown trigger="click" @select="handleActionClick($event, nodeData)"
            @popup-visible-change="popupVisibleChange">
            <div style="position: absolute; right: 8px; font-size: 14px; color: #3A3A3A;" class="icon-box"
              @click="onDropClick">
              <IconMore />
            </div>
            <template #content>
              <a-doption value="add" style="width:88px">
                <template #icon>
                  <i class="iconfont icon-tianjia" style="color:#999999"></i>
                </template>
                添加
              </a-doption>
              <a-doption value="edit" v-if="nodeData.id != 1">
                <template #icon>
                  <i class="iconfont icon-bianji" style="color:#999999"></i>
                </template>
                编辑
              </a-doption>
              <a-doption value="delete" v-if="nodeData.id != 1">
                <template #icon>
                  <i class="iconfont icon-shanchu" style="color:#999999"></i>
                </template>
                删除
              </a-doption>
            </template>
          </a-dropdown>
        </template>
      </a-tree>
    </a-scrollbar>
  </div>

  <!-- 添加/编辑组织表单 -->
  <organization-form ref="organizationFormRef" @reload="init"></organization-form>

  <!-- 删除二次确认 -->
  <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>
</template>

<script setup lang="ts" name="system-user-tree">
import { getOrgTree, delOrg } from '@/api/system/user';
import { Message } from '@arco-design/web-vue';
import { computed, onMounted, ref } from 'vue';
import organizationForm from './organization-form.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import { getClass } from '@/utils/helper';

const searchValue = ref<string>("");
const warnignRef = ref();
const originTreeData = ref();
const organizationFormRef = ref();
const loading = ref<boolean>(false);
const delId = ref<number>(NaN);

const emits = defineEmits<{
  (e: "change", data: object): void
}>();

const onSelect = (selectedKeys: (number | string)[]) => {
  emits('change', { orgId: selectedKeys[0] as number });
}

const treeData = computed(() => {
  if (!searchValue.value) return originTreeData.value;
  return searchData(searchValue.value);
})

function searchData(keyword: string) {
  const loop = (data: any) => {
    const result: any[] = [];
    data.forEach((item: any) => {
      if (item.orgName.toLowerCase().indexOf(keyword.toLowerCase()) > -1) {
        result.push({ ...item });
      } else if (item.children) {
        const filterData = loop(item.children);
        if (filterData.length) {
          result.push({
            ...item,
            children: filterData
          })
        }
      }
    })
    return result;
  }
  return loop(originTreeData.value);
}
function getMatchIndex(title: any) {
  if (!searchValue.value) return -1;
  return title.toLowerCase().indexOf(searchValue.value.toLowerCase());
}

// 「新增/编辑组织」按钮点击触发
const handleActionClick = (type: any, e: any) => {
  if (type !== 'delete') {
    organizationFormRef.value.handleShowModal(type, e);
    return;
  }

  delId.value = e?.id || NaN;
  warnignRef.value.open();
  return;
};

const init = async () => {
  try {
    loading.value = true;

    const res = await getOrgTree();
    if (res.code != 0) {
      throw new Error(res.message);
    }

    originTreeData.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delOrg(delId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    init();
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

const onDropClick = (e: any) => {
  const el = e.target.parentElement.parentElement;
  if (el.getAttribute("class").indexOf("arco-tree-node") !== -1) {
    el.setAttribute("class", "arco-tree-node arco-tree-node-is-leaf pin-hover")
  }
}

const popupVisibleChange = (status: boolean) => {
  if (!status) {
    const els = getClass("pin-hover");
    for (let i = 0; i < els.length; i++) {
      els[i].setAttribute("class", "arco-tree-node arco-tree-node-is-leaf")
    }
  }
}

onMounted(() => {
  init();
});
</script>

<style lang="less">
.tree-select-box-user {
  overflow: hidden;
  height: 100%;

  .arco-tree-node-title {
    padding-left: 0;
    margin-left: -10px;
  }
  .arco-tree-node-switcher-expanded{
    left: -6px;
  }

  .arco-scrollbar {
    height: calc(100% - 56px);
  }

  .arco-tree-node-title-text {
    width: 140px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .arco-tree-node:hover,
  .arco-tree-node-title:hover {
    background: #fafafa !important;
  }

  .arco-tree-node-selected {
    background: #f8f8f8;

    .arco-tree-node-title-text {
      color: #3A3A3A;
    }
  }

  .arco-tree {
    .pin-hover {
      background-color: #fafafa !important;

      &:hover {
        background-color: #fafafa !important;
      }
    }

    .arco-tree-node {
      .icon-box {
        opacity: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 20px;
        height: 20px;
        border-radius: 2px;

        &:hover {
          background-color: #e5e5e5;
        }
      }

      &:hover {
        .icon-box {
          opacity: 1;
        }
      }
    }
  }
}
</style>