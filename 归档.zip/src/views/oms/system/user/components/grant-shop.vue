<template>
  <a-modal
    unmountOnClose
    title="店铺授权"
    title-align="start"
    :mask-closable="false"
    class="system-user-grant-model"
    v-model:visible="visible"
    :on-before-ok="handleConfirm"
    @cancel="handleClose">
    <a-transfer
      :data="transferData"
      :title="['未选', '已选']"
      v-model="selectShopIdList"
      show-search/>
  </a-modal>
</template>

<script setup lang="ts" name="grant-shop">
import { ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import {
  shopAuth,
  getShopList,
  getUserShopList,
  ShopAuthParameterType
} from '@/api/system/role';

// 弹窗相关
const visible = ref(false);
const handleConfirm = async()  => {
  try {
    if (isBatchGrant() && selectShopIdList.value.length < 1) {
      Message.warning('请选择店铺');
      return false;
    }
    let parameter: ShopAuthParameterType = {
      id: modelOptions.value.userId,
      lstStoreId: selectShopIdList.value
    }
    let response = await shopAuth(parameter);
    if (response?.success) {
      Message.success('店铺授权保存成功');
      return true;
    } else {
      Message.warning(response?.message || '店铺授权保存失败');
      return false;
    }
  } catch (e) {
    console.error(e);
    Message.warning('设置店铺授权失败');
    return false;
  }
}
const handleClose = () => {
  visible.value = false;
}

// 穿梭框相关
class TransferItem {
  value: string = '';
  label: string = '';
  disabled: boolean = false;
}
const transferData = ref<TransferItem[]>([]);
const selectShopIdList = ref<string[]>([]);

// 查询店铺列表
class ShopSelectItem {
  id: string = '';
  storeCode: string = '';
  storeName: string = '';
  disabled: boolean = false;
}
const shopList = ref<ShopSelectItem[]>([]);
const queryShopList = async() => {
  try {
    let response = await getShopList();
    if (response?.success) {
      shopList.value = response?.value ?? [];
      transferData.value = shopList.value.map(shop => {
        return {
          value: shop.id,
          storeCode: shop.storeCode,
          label: shop.storeName,
          disabled: false
        }
      })
    } else {
      Message.warning(response?.message || '查询店铺列表失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询店铺列表失败");
  }
}

// 查询用户已经被授权的店铺
const queryUserShopList = async(userId: string) => {
  try {
    let response = await getUserShopList(userId);
    if (response?.success) {
      return response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询用户已经被授权的店铺失败');
      return [];
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询用户已经被授权的店铺失败");
    return [];
  }
}

// 弹窗可选配置项
class OpenOptions {
  // 切换的用户ID
  userId: string[] = [];
}
const modelOptions = ref(new OpenOptions());
const isBatchGrant = () => {
  return Array.isArray(modelOptions.value.userId) && modelOptions.value?.userId?.length > 1;
}
const open = async (options: OpenOptions) => {
  try {
    await queryShopList();
    if (Array.isArray(options?.userId) && options?.userId?.length === 1) {
      let selectShopList: Pick<ShopSelectItem, 'id' | 'storeName'>[] = await queryUserShopList(options.userId[0]);
      selectShopIdList.value = selectShopList.map(item => item.id);
    } else {
      selectShopIdList.value = [];
    }
    modelOptions.value = options;
    visible.value = true;
  } catch (e) {
    console.error(e);
  }
}
defineExpose({
  open
})

</script>

<style lang="less">
@import './grant-madel.less';
</style>