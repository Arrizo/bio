<!-- 系统管理->用户管理->列表 -->
<template>
  <oms-table :total="total" :current="pageNum" :size="pageSize" @reload="init">
    <!-- 表格操作按钮组 -->
    <template #header-left>
      <a-space :size="14" style="margin-bottom: 10px;">
        <a-button type="primary" status="normal" @click="handleAddClick" v-permission="['oms:system:user:add']"
          style="width:80px"> 新增用户 </a-button>
        <a-dropdown @select="handleCommand">
          <a-button :disabled="selectedKeys.length <= 0">
            批量操作
            <icon-down />
          </a-button>
          <template #content>
            <a-doption value="enable" v-permission="['oms:system:user:enable']">启用</a-doption>
            <a-doption value="disable" v-permission="['oms:system:user:disable']">禁用</a-doption>
            <a-doption value="delete-batch" style="color:red" v-permission="['oms:system:user:delete']">删除</a-doption>
            <a-doption value="grant-role-batch" v-permission="['oms:system:user:grant:role']">角色授权</a-doption>
            <a-doption value="grant-shop-batch" v-permission="['oms:system:user:grant:shop']">店铺授权</a-doption>
            <a-doption value="grant-store-batch" v-permission="['oms:system:user:grant:store']">仓库授权</a-doption>
          </template>
        </a-dropdown>
      </a-space>
    </template>
    <!-- 表格数据 -->
    <a-table stripe row-key="id" :data="(list as any)" :pagination="false" :row-selection="{
      type: 'checkbox',
      showCheckedAll: true
    }" :scroll="{ x: 1400, y: 900 }" :bordered="{ wrapper: false }" v-model:selectedKeys="selectedKeys">
      <template #columns>
        <a-table-column title="用户账号">
          <template #cell="{ record }">
            {{ record.username || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="用户姓名" data-index="nickname"></a-table-column>
        <a-table-column title="用户类型" data-index="typeName">
          <template #cell="{ record }">
            {{ record.typeName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="所属组织" data-index="orgName">
          <template #cell="{ record }">
            {{ record.orgName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="岗位名称" data-index="jobName">
          <template #cell="{ record }">
            {{ record.jobName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="手机号码">
          <!-- TODO: 加密这块还没调试，放下一版本开发 -->
          <template #cell="{ record }">
          <!-- <a-link v-sensitive="['oms_system_user', 'mobile']">***********</a-link>
                <span v-sensitive-else="['oms_system_user', 'mobile']">***********</span> -->
            <span>***********</span>
          </template>
        </a-table-column>
        <a-table-column title="状态" :width="120">
          <template #cell="{ record, rowIndex }">
            <div v-permission="['oms:system:user:enable', 'oms:system:user:disable']">
              <a-switch v-model="(list as any)[rowIndex].status" @focus="onSwitchForce(record, rowIndex)">
                <template #checked>
                  启用
                </template>
                <template #unchecked>
                  禁用
                </template>
              </a-switch>
            </div>
            <div v-permission-else="['oms:system:user:enable', 'oms:system:user:disable']">{{ (list as
              any)[rowIndex].status ? '启用' : '禁用' }}</div>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" :width="180" data-index="createTime"></a-table-column>
        <a-table-column title="修改时间" :width="180" data-index="updateTime"></a-table-column>
        <a-table-column title="操作" :width="100" align="left" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link @click="handleActoin('edit', record)" v-permission="['oms:system:user:edit']">编辑</a-link>
              <a-dropdown @select="(command: CommandType) => handleCommand(command, record)">
                <a-link @click="handleActoin('auth', record)">更多</a-link>
                <template #content>
                  <a-doption value="grant-role-single" v-permission="['oms:system:user:grant:role']">角色授权</a-doption>
                  <a-doption value="grant-shop-single" v-permission="['oms:system:user:grant:shop']">店铺授权</a-doption>
                  <a-doption value="grant-store-single" v-permission="['oms:system:user:grant:store']">仓库授权</a-doption>
                  <a-doption value="reset-password" v-permission="['oms:system:user:resetpassword']">重置密码</a-doption>
                  <a-doption value="delete-single" style="color:red"
                    v-permission="['oms:system:user:delete']">删除</a-doption>
                </template>
              </a-dropdown>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
  <!-- 用户新增/编辑弹窗 -->
  <user-form ref="UserFormRef" @reload="emits('reload')"></user-form>
  <!-- 启用/禁用弹窗 -->
  <user-toggle ref="UserToggleRef" @reload="emits('reload')" @clearSelection="selectedKeys = []"></user-toggle>
  <!-- 角色授权 -->
  <grant-role ref="GrantRoleRef"></grant-role>
  <!-- 店铺授权 -->
  <grant-shop ref="GrantShopRef"></grant-shop>
  <!-- 仓库授权 -->
  <grant-store ref="GrantStoreRef"></grant-store>
  <!-- 删除弹窗 -->
  <oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
</template>

<script setup lang="ts" name="system-user-list">
import { ref, h } from 'vue';
import UserForm from "./user-form.vue";
import omsWarning from '@/components/oms-warning/index.vue'
import GrantRole from './grant-role.vue';
import GrantShop from './grant-shop.vue';
import GrantStore from './grant-store.vue';
import UserToggle from './user-toggle.vue';
import { Message } from '@arco-design/web-vue';
import { Modal, Button } from '@arco-design/web-vue';
import OmsTable from '@/components/oms-table/index.vue';
import { deleteUser, resetPassword } from '@/api/system/user';
import { UserSearchForm, UserSearchListItem } from '@/types/system/user';
import { IconExclamationCircleFill } from '@arco-design/web-vue/es/icon';

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  total: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "on-add"): void,
  (e: "reload", data?: UserSearchForm): void,
}>();

const loading = ref(false);
const UserFormRef = ref();
const GrantRoleRef = ref();
const GrantShopRef = ref();
const GrantStoreRef = ref();
const UserToggleRef = ref();
const switchRef = ref();
const deleteIds = ref()
const selectedKeys = ref<string[]>([]);

const init = ({ pageNum, pageSize }: { pageNum: number, pageSize: number }) => {
  loading.value = true;
  emits('reload', { pageNum, pageSize });
  setTimeout(() => {
    loading.value = false;
  }, 800);
};

type CommandType = string | number | Record<string, any> | undefined;
function handleCommand(command: CommandType): void
function handleCommand(command: CommandType, record: UserSearchListItem): void
function handleCommand(command?: CommandType, record?: UserSearchListItem): void {
  switch (command) {
    // 批量启用
    case 'enable':
      UserToggleRef.value.open({
        type: 'batch',
        status: true,
        userId: selectedKeys.value,
        title: "提示",
        content: `确定将状态更改为已启用？`
      });
      break;
    // 批量禁用
    case 'disable':
      UserToggleRef.value.open({
        type: 'batch',
        status: false,
        userId: selectedKeys.value,
        title: "提示",
        content: `确定将状态更改为已禁用？`
      });
      break;
    // 批量删除用户
    case 'delete-batch':
      handleDeleteUser(selectedKeys.value);
      break;
    // 删除单个用户
    case 'delete-single':
      handleDeleteUser([`${record?.id}`]);
      break;
    // 重置默认密码
    case 'reset-password':
      handleResetPassword(`${record?.id}`);
      break;
    // 单个用户角色授权
    case 'grant-role-single':
      handleGrantRole([`${record?.id}`]);
      break;
    // 多个用户角色授权
    case 'grant-role-batch':
      handleGrantRole(selectedKeys.value);
      break;
    // 单个店铺授权
    case 'grant-shop-single':
      handleGrantShop([`${record?.id}`]);
      break;
    // 多个店铺授权
    case 'grant-shop-batch':
      handleGrantShop(selectedKeys.value);
      break;
    // 单个仓库授权
    case 'grant-store-single':
      handleGrantStore([`${record?.id}`]);
      break;
    // 多个仓库授权
    case 'grant-store-batch':
      handleGrantStore(selectedKeys.value);
      break;
  }
}
const beforeChange = async () => {
  try {
    let response = await deleteUser(deleteIds.value);
    if (response?.success) {
      Message.success('删除用户成功');
      emits('reload');
    } else {
      Message.warning(response?.message || '删除用户失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning('删除用户失败');
  }
}
// 删除用户
const handleDeleteUser = (userIdList: string[]) => {
  deleteIds.value = userIdList.map(Number)
  switchRef.value.open()
}

// 重置用户密码为默认密码
const handleResetPassword = (userId: string) => {
  const ModalContent = {
    setup() {
      return () => h('div', { style: { display: 'flex' } }, [
        h('div', { style: { 'margin-right': '10px' } }, [
          h(IconExclamationCircleFill, { style: { color: 'rgb(245, 154, 35)', fontSize: '30px' } })
        ]),
        h('div', {}, [
          h('div', { style: 'margin-bottom: 10px;' }, '此操作将重置用户密码为pflm123456, 是否继续？'),
          h('div', {}, '重置密码后需重新登录'),
        ]),
      ])
    },
  }
  Modal.open({
    title: '提示',
    titleAlign: 'start',
    content: () => h(ModalContent),
    onOk: async () => {
      try {
        let response = await resetPassword(userId);
        if (response?.success) {
          Message.success('重置用户密码成功');
          emits('reload');
        } else {
          Message.warning(response?.message || '重置用户密码失败');
        }
      } catch (e) {
        console.error(e);
        Message.warning('重置用户密码失败');
      }
    }
  });
}

// 角色授权
const handleGrantRole = (userId: string[]) => {
  GrantRoleRef.value.open({
    userId: userId
  });
}

// 店铺授权
const handleGrantShop = (userId: string[]) => {
  GrantShopRef.value.open({
    userId: userId
  });
}

// 仓库授权
const handleGrantStore = (userId: string[]) => {
  GrantStoreRef.value.open({
    userId: userId
  });
}


// 「新增用户」按钮点击触发
const handleAddClick = () => {
  UserFormRef.value.handleShowModal("add");
};

const onSwitchForce = async (record: UserSearchListItem, index: number) => {
  UserToggleRef.value.open({
    type: 'single',
    status: !record.status,
    userId: record.id,
    title: "提示",
    content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？`
  });
}

const handleActoin = async (type: "edit" | "del" | "auth", data?: UserSearchListItem) => {
  if (type === 'edit') {
    UserFormRef.value.handleShowModal("edit", data);
  }
}

</script>