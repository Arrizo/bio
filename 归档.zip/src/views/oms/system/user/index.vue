<!-- 系统管理->菜单管理 -->
<template>
    <a-row :gutter="10" style="flex-wrap: nowrap;height: 100%;">
      <a-col flex="234px" style="height: 100%;width: 234px;">
        <oms-panel style="height: 100%;" class="left-tree">
          <tree-select @change="init"></tree-select>
        </oms-panel>
      </a-col>
      <a-col flex="auto" style="overflow: auto;height: 100%;">
        <oms-panel style="height: 100%;margin-bottom: 0;">
          <template #header>
            <search :loading="loading" @on-search="init"></search>
          </template>
          <div>
            <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
              @reload="init"></list>
          </div>
        </oms-panel>
      </a-col>
    </a-row>
</template>

<script setup lang="ts" name="system-user">
import OmsPanel from '@/components/oms-panel/index.vue';
import TreeSelect from './components/tree-select.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import { ref } from 'vue';
import { UserSearchForm, UserSearchListItem } from '@/types/system/user';
import { deepClone } from '@/utils/helper';
import { getUserPage } from '@/api/system/user';
import { Message } from '@arco-design/web-vue';

const loading = ref<boolean>(false);
const list = ref<UserSearchListItem[]>([]);
const total = ref<number>(0);
const form = ref<UserSearchForm>(new UserSearchForm());

/**
 * 初始化查询用户数据
 * @param data
 */
const init = async (data: UserSearchForm = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    form.value.orgId = form.value.orgId == 1 ? '' : form.value.orgId;
    params.status = params.status === 'all' ? '' : params.status;

    const res = await getUserPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    setTimeout(() => {
      loading.value = false;
    }, 400);
  }
}
</script>
<style lang="less" scoped>
:deep(.left-tree){
  .content{
    height: 100% !important;
    padding: 0;
  }
  .content-inner {
      padding: 0;
    }
}
</style>