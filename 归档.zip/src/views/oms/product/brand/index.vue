<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-22 16:32:18
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-10 14:07:30
 * @FilePath: \oms-admin\src\views\oms\product\brand\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <oms-panel style="height: 100%;">
    <template #header>
      <search :loading="loading" @on-search="initMethod"></search>
    </template>
    <list :loading="loading" :total="total" :brand-list="brandListData" :page-num="form.pageNum"
      :page-size="form.pageSize" @reload="initMethod"></list>
  </oms-panel>
</template>
<script lang="ts" setup name="goods-brand">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search/index.vue'
import List from './components/list/index.vue'
import commoMethod from './commo-method/index'
const { loading, total, form, brandListData, initMethod } = commoMethod()
</script>