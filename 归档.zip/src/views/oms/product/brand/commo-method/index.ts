import initData from "../initData";
import { GoodsBrandSearchType, GoodsBrandListType } from '@/types/goods/brand'
import { queryBrandList } from '@/api/goods/brand'
import { Message } from '@arco-design/web-vue';
import { ref } from 'vue'

export default function () {
  let { loading, form, total } = initData()
  // 初始化表格数据类型
  const brandListData = ref<Array<GoodsBrandListType>>([])
  const initMethod = async (data?: GoodsBrandSearchType) => {
    try {
      form = Object.assign(form, data)
      loading.value = true
      const { code, value, message } = await queryBrandList(form)
      if (code != 0) {
        throw new Error(message)
      }
      brandListData.value = value.result
      total.value = value.totalCount;
      form.pageNum = value.pageNum;
      form.pageSize = value.pageSize;
    } catch (error) {
      Message.error((error as Error).message);
    } finally {
      loading.value = false
    }

  }
  return {
    loading,
    total,
    form,
    brandListData,
    initMethod
  }
}