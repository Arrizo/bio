/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-22 16:32:18
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-29 11:11:51
 * @FilePath: \oms-admin\src\views\oms\product\brand\components\brand-modal\brand-modal-methods\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import { ref, computed, reactive, watch } from 'vue'
import { GoodsBrandListType } from '@/types/goods/brand'
import { findBrandDetail, productBrandAdd } from '@/api/goods/brand'
import { Message } from '@arco-design/web-vue'
export default function (emits: Function) {
  const brandFormRef = ref()
  let brandForm = reactive<GoodsBrandListType>(new GoodsBrandListType())
  const showBrandModal = ref<boolean>(false)
  const titleName = computed(() => {
    return `${brandForm.id ? '编辑' : '新增'}品牌`
  })
  const formRules = reactive({
    chineseName: [
      { required: true, message: '请输入品牌名称' }
    ],
  })
  const queryBrandDetails = async (id?: string) => {
    showBrandModal.value = true
    try {
      if (id) {
        const { code, value, message } = await findBrandDetail(id)
        if (code != 0) {
          throw new Error(message)
        }
        Object.assign(brandForm, value)
      }
    } catch (error) {
      Message.error((error as Error).message)
    }
  }
  // 关闭弹窗前数据检验
  const onBeforeOk = async (done: Function) => {
    const valid = await brandFormRef.value.validate()
    if (valid) { return false }
    if (brandForm.englishName) {
      if (brandForm.englishName.length < 2) {
        Message.error('品牌英文名长度需要在2~20字符之间')
        return false
      }
      if (/^[^a-zA-Z]/.test(brandForm.englishName)) {
        Message.error('英文名称首字符必须是字母')
        return false
      }
    }
    const res = await productBrandAdd(brandForm)
    if (res.code != 0) {
      Message.error(res.message)
      return false
    }
    Message.success('操作成功！')
    emits('reloadTable', {})
    return true
  }
  watch(() => showBrandModal.value, (nV) => {
    if (!nV) {
      brandFormRef.value.clearValidate()
      brandFormRef.value.resetFields()
      brandForm.id = ''
    }
  })
  return {
    showBrandModal,
    titleName,
    brandFormRef,
    brandForm,
    formRules,
    queryBrandDetails,
    onBeforeOk,
    // showWatch
  }
}