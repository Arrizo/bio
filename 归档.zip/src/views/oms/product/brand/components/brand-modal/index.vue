<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 16:52:06
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-27 14:17:37
 * @FilePath: \oms-admin\src\views\oms\basicdata\goods-brand\components\brand-modal\index.vue
-->
<template>
  <a-modal :width="800" :title="titleName" v-model:visible="showBrandModal" title-align="start" :on-before-ok="onBeforeOk"
    :mask-closable="false">
    <a-form :model="brandForm" auto-label-width ref="brandFormRef" :rules="formRules">
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="品牌编码：" field="code">
            <a-input v-model="brandForm.code" allow-clear disabled placeholder="系统自动生成"
              :class="{ 'disabled-input': !brandForm.id }"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="品牌名称：" field="chineseName">
            <a-input v-model.trim="brandForm.chineseName" allow-clear placeholder="请输入品牌名称" :max-length="20"></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="英文名称：" field="englishName">
            <a-input v-model.trim="brandForm.englishName" allow-clear placeholder="请输入英文名称"
              @input="brandForm.englishName = $event.replace(/[^\w(?!\-)]/g, '')" :max-length="20"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="品牌方：" field="client">
            <a-input v-model.trim="brandForm.client" allow-clear placeholder="请输入品牌方名称"></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="24">
          <a-form-item label="品牌logo：" field="logo" :label-col-style="{ lineHeight: '16px' }">
            <section class="upload-wrap">
              <span class="title">建议尺寸800*800px，每张不超过1M，支持格式jpg/png/gif</span>
              <image-uploader v-model="brandForm.logo" :limit="1" :size="1024 * 1024 * 1"></image-uploader>
            </section>
          </a-form-item>
        </a-col>
        <a-col :span="24">
          <a-form-item label="备注：" field="remark">
            <a-textarea v-model.trim="brandForm.remark" placeholder="请输入（限200个字）" show-word-limit
              :max-length="200"></a-textarea>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>
<script setup lang="ts" name="brand-modal">
import brandModalMethods from './brand-modal-methods'
import { GoodsBrandSearchType } from '@/types/goods/brand'
import ImageUploader from '@/components/image-uploader/index.vue'
const emits = defineEmits<{
  (e: "reloadTable", data?: GoodsBrandSearchType): void
}>()
const { showBrandModal, titleName, brandFormRef, brandForm, formRules, queryBrandDetails, onBeforeOk } = brandModalMethods(emits)

defineExpose({
  queryBrandDetails
})
</script>
<style lang="less" scoped>
.upload-wrap {
  display: flex;
  flex-direction: column;

  // margin-top: 8px;
  .title {
    color: #B1B1B1;
    font-size: 12px;
    margin-bottom: 5px;
  }
}

:deep(.disabled-input .arco-input[disabled]) {
  color: #B1B1B1 !important;
  -webkit-text-fill-color: #B1B1B1 !important;
}</style>