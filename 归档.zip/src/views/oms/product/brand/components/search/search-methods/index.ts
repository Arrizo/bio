import initData from '../../../initData'
import { ref,onMounted } from 'vue'
import { deepClone } from '@/utils/helper';
export default function (emits:Function) {
  const { form } = initData()
  const searchRef = ref()
  const handleReset = () => {
    searchRef.value.resetFields();
    handleSearch();
  }
  const handleSearch = () => {
    const newForm = deepClone(form)
    if (newForm.status === 'all') {newForm.status =''}
    emits('on-search', newForm)
  }
  onMounted(() => {
    handleSearch()
  })
  return {
    form,
    searchRef,
    handleReset,
    handleSearch
  }
}