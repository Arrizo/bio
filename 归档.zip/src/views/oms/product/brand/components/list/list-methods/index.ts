/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 10:46:56
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-10 11:17:28
 * @FilePath: \oms-admin\src\views\oms\basicdata\goods-brand\components\list\list-methods\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import { GoodsBrandSearchType, GoodsBrandListType } from '@/types/goods/brand'
import { Message } from '@arco-design/web-vue';
import { ref } from 'vue'
import { brandStatusUpdate } from '@/api/goods/brand'

export default function (emits: Function) {
  // 勾选状态id
  const statusId = ref()
  // 修改状态ref
  const switchRef = ref()
  // 日志ref
  const logRefs = ref()
  // 新增或编辑品牌ref
  const brandModalRef = ref()
  const onBrandReload = (data?: GoodsBrandSearchType) => {
    emits('reload', data)
  }
  // 新增仓库
  const handleAdd = (record?: GoodsBrandListType) => {
    brandModalRef.value.queryBrandDetails(record?.id ?? '')
  }
  // 显示日志
  const openLog = (record: GoodsBrandListType) => {
    logRefs.value.init(record.code,'商品品牌')
  }
  // 修改状态事件
  const onSwitchForce = (record: any) => {
    statusId.value = record?.id + ''
    switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
  }
  const beforeChange = async () => {
    try {
      const res = await brandStatusUpdate(statusId.value)
      if (res.code != 0) {
        throw new Error(res.message);
      }
      Message.success('更新成功')
      onBrandReload()
    } catch (err) {
      Message.error((err as Error).message);
    }
  }
  return {
    onBrandReload,
    handleAdd,
    switchRef,
    logRefs,
    openLog,
    onSwitchForce,
    beforeChange,
    brandModalRef
  }
}