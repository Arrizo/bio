<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 10:46:56
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-08 16:30:45
 * @FilePath: \oms-admin\src\views\oms\basicdata\goods-brand\components\list\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
	<oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onBrandReload">
		<template #header-left>
			<a-button type="primary" status="normal" @click="handleAdd()" style="margin-bottom:10px" v-permission="['oms:product:brand:add']">新增</a-button>
		</template>
		<a-table :data="brandList" :pagination="false" hide-expand-button-on-empty :scroll="{ y: 650, x: 1400 }" stripe
			:bordered="{ wrapper: false }">
			<template #columns>
				<a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
					<template #cell="{ rowIndex }">
						{{ rowIndex+ 1 }}
					</template>
				</a-table-column>
				<a-table-column title="品牌名称（中文）" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.chineseName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="英文名称" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.englishName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="品牌编码" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.code || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="备注" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.remark || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="状态" :tooltip="true" :width="120" ellipsis>

					<template #cell="{ record }">
						<span v-permission="['oms:product:brand:statusUpdata']">
						<a-switch v-model="record.status" @focus="onSwitchForce(record)">
							<template #checked>
								启用
							</template>
							<template #unchecked>
								禁用
							</template>
						</a-switch>
					</span>
					</template>
				</a-table-column>
				<a-table-column title="更新时间" :tooltip="true" :width="180" ellipsis>
					<template #cell="{ record }">
						{{ record.updateTime || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="操作" :tooltip="true" :width="120" ellipsis fixed="right">
					<template #cell="{ record }">
						<a-space :size="10">
							<a-link type="text" @click="handleAdd(record)" v-permission="['oms:product:brand:edit']">编辑</a-link>
							<a-link type="text" @click="openLog(record)">日志</a-link>
						</a-space>
					</template>
				</a-table-column>
			</template>
		</a-table>
	</oms-table>
	<oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
	<brand-modal ref="brandModalRef" @reloadTable="emits('reload')"></brand-modal>
	<oms-log ref="logRefs"></oms-log>
</template>
<script lang="ts" setup name="brand-list">
import OmsTable from '@/components/oms-table/index.vue';
import listMethods from './list-methods'
import OmsWarning from '@/components/oms-warning/index.vue';
import omsLog from '@/components/oms-log/index.vue'
import BrandModal from '../brand-modal/index.vue';
import { GoodsBrandListType, GoodsBrandSearchType } from '@/types/goods/brand'
const emits = defineEmits<{
	(e: "reload", data?: GoodsBrandSearchType): void
}>()
interface PropsType {
	loading: boolean
	total: number
	pageNum: number
	pageSize: number
	brandList: Array<GoodsBrandListType>
}
const {
	onBrandReload,
	handleAdd,
	switchRef,
	onSwitchForce,
	beforeChange,
	openLog,
	logRefs,
	brandModalRef,
} = listMethods(emits)
const props = defineProps<PropsType>();
</script>