/**
 * 声明该模块所有的数据变量
 */
import { ref, reactive } from 'vue'
import { GoodsBrandSearchType } from '@/types/goods/brand'
import { TableColumnData } from '@arco-design/web-vue'
export default function () {
  // 查询参数
  let form = reactive<GoodsBrandSearchType>(new GoodsBrandSearchType())
  const loading = ref<boolean>(false)
  const total = ref<number>(0)
  const initTableColumns = (list: Array<TableColumnData>) => {
    return ref<Array<TableColumnData>>(list)
  }
  // 通过泛型指定数据类型
  const initTableData = <T>(data: T) => {
    return ref<Array<T>>([])
  }

  return {
    form,
    loading,
    total,
    initTableData,
    initTableColumns
  }
}