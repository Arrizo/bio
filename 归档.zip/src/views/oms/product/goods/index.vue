<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-21 14:04:07
 * @ Modified by: Sam
 * @ Modified time: 2023-03-15 08:29:53
 * @ Description: 商品档案
 -->
<template>
  <div style="height: 100%;">
    <a-row :gutter="10" style="flex-wrap: nowrap;height: 100%;">
      <a-col flex="234px" style="height: 100%;width: 234px;">
        <oms-panel style="height: 100%;" class="left-tree">
          <category-tree ref="categoryTreeRef" @change="init"></category-tree>
        </oms-panel>
      </a-col>

      <a-col flex="auto" style="overflow: auto;height: 100%;">
        <oms-panel allow-drop :style="rowData ? `` : `height:100%`">
          <template #header>
            <search :loading="loading" @on-search="init" :select-list="selectList" @on-export="openExport"></search>
          </template>
          <list ref="listRef" :loading="loading" :list="list" :total="total" :page-num="searchForm.pageNum"
            :page-size="searchForm.pageSize" @reload="init" @on-db-click="onDbClick"></list>
        </oms-panel>

        <!-- 行详情 -->
        <div style="margin-top:10px" v-if="rowData">
          <row-detail ref="rowDetialRef" @close="onDetailClose"></row-detail>
        </div>
      </a-col>
    </a-row>

    <!-- 导出 -->
    <export-modal ref="exportRef"></export-modal>
  </div>
</template>

<script setup lang="ts" name="product-goods">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import categoryTree from './components/category-tree.vue';
import rowDetail from './components/row-detail.vue';
import exportModal from './components/export-modal.vue';
import List from './components/list.vue';
import { Message } from '@arco-design/web-vue';
import { computed, nextTick, ref } from 'vue';
import { getList } from '@/api/product/goods';
import { GoodsSearchForm, GoodsListItem } from '@/types/product/goods';

const loading = ref<boolean>(false);
const list = ref<GoodsListItem[]>([]);
const rowData = ref();
const rowDetialRef = ref();
const categoryTreeRef = ref();
const total = ref<number>(0);
const exportRef = ref();
const listRef = ref();
const selectList = computed(() => {
  return listRef.value ? listRef.value.selectList : []
});
const searchForm = ref<GoodsSearchForm>(new GoodsSearchForm());

const init = async (data: any, isReset: boolean = false) => {
  if (isReset) {
    categoryTreeRef.value.popupVisibleChange(false);
  }
  try {
    searchForm.value = { ...searchForm.value, ...data };

    loading.value = true;
    const res = await getList(searchForm.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    setTimeout(() => {
      loading.value = false;
    }, 400);
  }
}

/** 双击触发展示详情 */
const onDbClick = (data: GoodsListItem) => {
  rowData.value = data;
  nextTick(() => {
    rowDetialRef.value.init(data.id, data);
  });
}

const openExport = (spuIds: number[]) => {
  exportRef.value.open(searchForm.value, spuIds);
}

/** 行详情关闭 */
const onDetailClose = () => {
  rowData.value = null;
}
</script>

<style lang="less" scoped>
:deep(.left-tree) {
  .content {
    height: 100% !important;
    padding: 0;

    .content-inner {
      padding: 0;
    }
  }
}
</style>