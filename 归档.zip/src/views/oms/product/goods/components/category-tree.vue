<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-22 08:53:30
 * @ Modified by: Sam
 * @ Modified time: 2023-03-29 08:51:14
 * @ Description: 商品分类树选择
 -->
<template>
  <div class="tree-select-box">
    <div style="padding:10px 10px 16px 10px">
      <a-input-search placeholder="输入搜索关键字" allow-clear v-model="searchValue">
      </a-input-search>
    </div>

    <a-scrollbar style="height:96%;overflow: auto;padding: 0 10px 0 10px;">
      <a-spin dot v-if="loading" />
      <a-tree blockNode v-else :data="treeData" :fieldNames="{
        title: 'title',
        key: 'id'
      }" @select="onSelect" style="height:740px">
        <template #switcher-icon="{ isLeaf }">
          <icon-caret-right v-if="isLeaf" style="font-size: 16;" />
          <icon-caret-down v-else style="font-size: 16;" />
        </template>
        <template #title="nodeData">
          <template v-if="index = getMatchIndex(nodeData?.title), index < 0">{{ nodeData?.title }}</template>
          <span v-else>
            {{ nodeData?.title?.substr(0, index) }}
            <span style="color: var(--color-primary-light-4);">
              {{ nodeData?.title?.substr(index, searchValue.length) }}
            </span>{{ nodeData?.title?.substr(index + searchValue.length) }}
          </span>
        </template>
      </a-tree>
    </a-scrollbar>
  </div>
</template>

<script setup lang="ts" name="product-category-tree">
import { getList } from '@/api/product/category';
import { getClass } from '@/utils/helper';
import { Message } from '@arco-design/web-vue';
import { computed, onMounted, ref } from 'vue';

const emits = defineEmits<{
  (e: "change", data: object): void
}>();
const searchValue = ref<string>("");

const onSelect = (selectedKeys: (number | string)[]) => {
  emits('change', { categoryId: selectedKeys[0] as number });
}
function getMatchIndex(title: any) {
  if (!searchValue.value) return -1;
  return title.toLowerCase().indexOf(searchValue.value.toLowerCase());
}

const loading = ref<boolean>(false);
const originTreeData = ref();
const treeData = computed(() => {
  if (!searchValue.value) return originTreeData.value;
  return searchData(searchValue.value);
});

const init = async () => {
  try {
    loading.value = true;

    // @ts-ignore
    const res = await getList({ status: true, title: "" });
    if (res.code != 0) {
      throw new Error(res.message);
    }

    originTreeData.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

const popupVisibleChange = (status: boolean) => {
  if (!status) {
    const els = getClass("arco-tree-node-selected");
    for (let i = 0; i < els.length; i++) {
      els[i].setAttribute("class", "arco-tree-node arco-tree-node-is-leaf")
    }
  }
}

function searchData(keyword: string) {
  const loop = (data: any) => {
    const result: any[] = [];
    data.forEach((item: any) => {
      if (item.title.toLowerCase().indexOf(keyword.toLowerCase()) > -1) {
        result.push({ ...item });
      } else if (item.children) {
        const filterData = loop(item.children);
        if (filterData.length) {
          result.push({
            ...item,
            children: filterData
          })
        }
      }
    })
    return result;
  }
  return loop(originTreeData.value);
}

onMounted(() => {
  init()
});

defineExpose({
  popupVisibleChange
});
</script>


<style lang="less">
.tree-select-box {
  overflow: hidden;
  height: 100%;

  .arco-scrollbar {
    height: calc(100% - 56px);
  }

  .arco-tree-node-title-text {
    width: 140px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .arco-tree-node:hover,
  .arco-tree-node-title:hover {
    background: #fafafa !important;
  }

  .arco-tree-node-selected {
    background: #f8f8f8;

    .arco-tree-node-title-text {
      color: #3A3A3A;
    }
  }
}
</style>