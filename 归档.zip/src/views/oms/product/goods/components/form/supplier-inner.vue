<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-06 11:00:06
 * @ Modified by: Sam
 * @ Modified time: 2023-03-15 08:27:05
 * @ Description: 供应商
 -->

<template>
  <oms-table :loading="loading">
    <template #header-left>
      <a-button v-if="!isDetail" type="primary" status="normal" style="margin-bottom: 10px;"
        @click="onAddClick">添加供应商</a-button>
    </template>
    <template #header-right>
      <a-input-search v-model="searchVal" placeholder="供应商编码/名称" style="margin-bottom: 10px;" />
    </template>

    <a-table :data="(searchList as any)" stripe scrollbar :pagination="false" :bordered="{ wrapper: false }"
      :scroll="{ x: 1000, y: 500 }">
      <template #columns>
        <a-table-column title="序号" :width="40">
          <template #cell="{ rowIndex }">
            {{ rowIndex + 1 }}
          </template>
        </a-table-column>
        <a-table-column title="供应商编码" :width="170">
          <template #cell="{ record }">
            {{ record.supplierCode }}
          </template>
        </a-table-column>
        <a-table-column title="供应商名称" :width="170">
          <template #cell="{ record }">
            {{ record.supplierName }}
          </template>
        </a-table-column>
        <a-table-column title="默认" :width="80">
          <template #cell="{ record }">
            <a-checkbox :disabled="isDetail" v-model="record.defaultSupplier" @change="onCkbChange(record)"></a-checkbox>
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="60" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link v-if="!record.defaultSupplier && !isDetail" status="danger" @click="handleDel(record)">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 添加供应商 -->
  <add-supplier ref="addSupplierRef" @on-add="onSupplierAdd"></add-supplier>
</template>

<script setup lang="ts" name="supplier-inner">
import { computed, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { SupplierItem } from '@/types/product/goods';
import addSupplier from './add-supplier.vue';

const props = defineProps({
  isDetail: { type: Boolean, dafault: false },
  skuId: { type: Number, default: NaN }
});

const loading = ref(false);
const list = ref<SupplierItem[]>([]);
const addSupplierRef = ref();
const searchVal = ref("");

const onCkbChange = (value: any) => {
  for (let i = 0; i < list.value.length; i++) {
    if (list.value[i].id !== value.id) {
      list.value[i].defaultSupplier = false;
    }
  }
}

/** 自定义查询筛选 */
const searchList = computed(() => {
  if (!searchVal.value) return list.value;

  return list.value.filter((v, i) => {
    if (v.supplierCode?.includes(searchVal.value) || v.supplierName?.includes(searchVal.value)) {
      return list.value[i]
    }
  });
});

const onAddClick = () => {
  addSupplierRef.value.open(props.skuId);
}

const handleDel = (record: any) => {
  for (let i = 0; i < list.value.length; i++) {
    if (list.value[i].id === record.id) {
      list.value.splice(i, 1);
      break;
    }
  }
}

/**
 * 选择供应商回调触发
 * selectList 已选择的数据
 */
const onSupplierAdd = (selectList: SupplierItem[]) => {
  function isExist(id: number) {
    for (let j = 0; j < list.value.length; j++) {
      if (id === list.value[j].id) {
        return true;
      }
    }
  }

  for (let i = 0; i < selectList.length; i++) {
    if (!isExist(selectList[i].id as number)) {
      list.value.push({ ...selectList[i], ...{ isDel: true } });
    }
  }
}

defineExpose({
  list
});
</script>