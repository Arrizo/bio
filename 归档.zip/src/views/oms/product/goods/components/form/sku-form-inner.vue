<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-02 16:31:59
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 08:26:50
 * @ Description: sku 表单
 -->
<template>
  <a-form ref="formRef" :model="form" layout="horizontal">
    <a-row :gutter="6">
      <a-col :span="8">
        <a-form-item label="规格编码：" label-col-flex="100px">
          <a-input v-limit-input disabled v-model="form.specsCode" />
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="specsModel" label="规格型号：" label-col-flex="100px">
          <a-input :disabled="isDetail" v-limit-input v-model="form.specsModel" placeholder="请输入" allow-clear
            :max-length="50" show-word-limit />
          <a-link v-if="!isDetail" style="width: 40px;" @click="onAttrClick">设置</a-link>
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="barCode" label="商品条码：" label-col-flex="100px">
          <a-input :disabled="isDetail" v-limit-input v-model="form.barCode" placeholder="请输入" allow-clear />
        </a-form-item>
      </a-col>
    </a-row>
    <a-form-item field="specsTitle" label="规格名称：" label-col-flex="100px"
      :rules="[{ required: true, message: '请输入规格名称' }]">
      <a-tooltip :content="form.specsTitle" mini v-if="form.specsTitle.length > 60">
        <a-input :disabled="isDetail" v-limit-input v-model="form.specsTitle" placeholder="请输入" allow-clear
          show-word-limit :max-length="200" />
      </a-tooltip>
      <a-input v-else :disabled="isDetail" v-limit-input v-model="form.specsTitle" placeholder="请输入" allow-clear
        show-word-limit :max-length="200" />
    </a-form-item>
    <a-form-item field="pictures" label="sku图片：" label-col-flex="100px">
      <div>
        <p style="font-size: 12px;color: #B1B1B1;margin:0;line-height: 32px;">
          最多上传5张图片，建议尺寸800*800px，每张不超过1M，支持格式jpg/png/gif，可拖动调整图片顺序。第一张为主图</p>
        <image-uploader :disabled="isDetail" v-model="form.pictures" :limit="5" :size="1 * 1024 * 1024" module="PRODUCT_COMPRESSED_FILE"></image-uploader>
      </div>
    </a-form-item>
    <a-row :gutter="6">
      <a-col :span="8">
        <a-form-item field="suggestRetailPrice" label="建议零售价：" label-col-flex="100px">
          <a-input-number @blur="limitNum('suggestRetailPrice')" :min="0" :max="99999" hide-button :disabled="isDetail"
            v-limit-input v-model="form.suggestRetailPrice" allow-clear placeholder="请输入" />
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="focusPurchasePrice" label="集采入仓价：" label-col-flex="100px">
          <a-input-number @blur="limitNum('focusPurchasePrice')" :min="0" :max="99999" hide-button :disabled="isDetail"
            v-limit-input v-model="form.focusPurchasePrice" allow-clear placeholder="请输入" />
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="dispatchPurchasePrice" label="代发采购价：" label-col-flex="100px">
          <a-input-number @blur="limitNum('dispatchPurchasePrice')" :min="0" :max="99999" hide-button :disabled="isDetail"
            v-limit-input v-model="form.dispatchPurchasePrice" allow-clear placeholder="请输入" />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row :gutter="6">
      <a-col :span="8">
        <a-form-item field="tagPrice" label="吊牌价/面值：" label-col-flex="100px">
          <a-input-number @blur="limitNum('tagPrice')" :min="0" :max="99999" hide-button :disabled="isDetail"
            v-limit-input v-model="form.tagPrice" allow-clear placeholder="请输入" />
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="logisticsInsured" label="物流保价：" label-col-flex="100px">
          <a-input-number @blur="limitNum('logisticsInsured')" :min="0" :max="99999" hide-button :disabled="isDetail"
            v-limit-input v-model="form.logisticsInsured" allow-clear placeholder="留空表示不需保价" />
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="shippingBoxGauge" label="发货箱规：" label-col-flex="100px">
          <a-input-number :precision="0" :disabled="isDetail" :min="1" :max="99" v-limit-input
            v-model="form.shippingBoxGauge" allow-clear placeholder="留空表示不启用箱规" />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row :gutter="6">
      <a-col :span="8">
        <a-form-item label="长宽高(cm)：" label-col-flex="100px">
          <a-space :size="8">
            <a-input-number :min="0" :max="999" :disabled="isDetail" hide-button @blur="handleVolume('length')"
              v-limit-input v-model="form.length" style="width: 50px;" placeholder="长" />
            <a-input-number :min="0" :max="999" :disabled="isDetail" hide-button @blur="handleVolume('width')"
              v-limit-input v-model="form.width" style="width: 50px;" placeholder="宽" />
            <a-input-number :min="0" :max="999" :disabled="isDetail" hide-button @blur="handleVolume('height')"
              v-limit-input v-model="form.height" style="width: 50px;" placeholder="高" />
            <a-input-number :min="0" :max="999999999" @blur="limitNum('volume')" :disabled="isDetail" hide-button
              v-limit-input v-model="form.volume as number" style="width: 80px;" placeholder="体积" />
          </a-space>
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="grossWeight" label="毛重(g)：" label-col-flex="100px">
          <a-input-number @blur="limitNum('grossWeight')" hide-button :min="0" :max="99999" :disabled="isDetail"
            v-limit-input v-model="form.grossWeight" placeholder="请输入" allow-clear />
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="suttle" label="净重(g)：" label-col-flex="100px">
          <a-input-number @blur="limitNum('suttle')" hide-button :min="0" :max="99999" :disabled="isDetail" v-limit-input
            v-model="form.suttle" placeholder="请输入" allow-clear />
        </a-form-item>
      </a-col>
    </a-row>
    <a-row :gutter="6">
      <a-col :span="8">
        <a-form-item field="cartonPackagingCode" label="包装纸箱：" label-col-flex="100px">
          <a-select :disabled="isDetail" placeholder="请选择" v-model="form.cartonPackagingCode" @change="onPackingChange"
            allow-clear allow-search>
            <a-option v-for="v in initInfo?.skuOverview" :label="v.title" :value="v.code"></a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="cartonPackagingModel" label="纸箱规格：" label-col-flex="100px">
          <a-input :disabled="isDetail" v-limit-input v-model="form.cartonPackagingModel" allow-clear show-word-limit
            :max-length="200" placeholder="请输入" />
        </a-form-item>
      </a-col>
      <a-col :span="8">
        <a-form-item field="developerId" label="开发人员：" label-col-flex="100px">
          <a-select :disabled="isDetail" placeholder="请选择" v-model="form.developerId" allow-clear allow-search>
            <a-option v-for="v in initInfo?.userList" :label="v.nickname" :value="v.id"></a-option>
          </a-select>
        </a-form-item>
      </a-col>
    </a-row>
    <a-form-item field="remark" label="备注：" label-col-flex="100px">
      <a-textarea :disabled="isDetail" v-limit-input v-model="form.remark" placeholder="请输入" show-word-limit
        :max-length="200" />
    </a-form-item>
    <a-form-item field="attachment" label="上传附件：" label-col-flex="100px">
      <file-uploader :disabled="isDetail" v-model="form.attachment" download module="PRODUCT_COMPRESSED_FILE"
        file-type="3" :size="50 * 1024 * 1024"></file-uploader>
    </a-form-item>
  </a-form>

  <!-- 商品属性 -->
  <attr-modal ref="attrModalRef" @ok="onAttrOk"></attr-modal>
</template>

<script setup lang="ts" name="product-goods-sku-form-inner">
import { ref } from 'vue';
import { SpecForm } from '@/types/product/goods';
import imageUploader from '@/components/image-uploader/index.vue';
import fileUploader from '@/components/file-uploader/index.vue';
import { initSku } from '@/api/product/goods';
import { Message } from '@arco-design/web-vue';
import attrModal from './attr-modal.vue';

const formRef = ref();
const attrModalRef = ref();
const form = ref<SpecForm>(new SpecForm());
/** 是否查看详情模式 */
const isDetail = ref(false);
/** 初始的下拉数据 */
const initInfo = ref();

const init = async (type: "add" | "edit" | "detail", data: any) => {
  isDetail.value = type === 'detail';

  if (type === 'add') {
    form.value = new SpecForm();
    /** 这时候 data 是商品 spu 的 ID */
    form.value.productId = data;
  }

  try {
    /** 初始化商品下拉信息 */
    const res = await initSku();

    if (res.code != 0) {
      Message.error(res.message);
    }
    initInfo.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

const limitNum = (param: string) => {
  form.value[param] = Number(Number(form.value[param]).toFixed(4))
}

const onPackingChange = (v: any) => {
  for (let i = 0; i < initInfo.value.skuOverview.length; i++) {
    if (v === initInfo.value.skuOverview[i].code) {
      form.value.cartonPackagingModel = initInfo.value.skuOverview[i].model;
      form.value.cartonPackagingSkuId = initInfo.value.skuOverview[i].id;
    }
  }
}

const handleVolume = (param: string) => {
  form.value[param] = Number(Number(form.value[param]).toFixed(4))
  const { height, width, length } = form.value;
  if (!height || !width || !length) return;
  form.value.volume = Number(Number(Number(height) * Number(width) * Number(length)).toFixed(2));
}

/** 规格属性设置，弹出商品属性弹框，然后一波骚操作自动回填规格 */
const onAttrClick = () => {
  attrModalRef.value.open();
}
const onAttrOk = (str: string) => {
  form.value.specsModel = str;
}

defineExpose({
  init,
  form
});
</script>