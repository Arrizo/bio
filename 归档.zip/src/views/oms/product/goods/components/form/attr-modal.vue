<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-06 16:30:31
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 08:30:38
 * @ Description: 商品属性
 -->

<template>
  <a-modal class="attr-modal" title="设置规格型号" width="1000px" v-model:visible="modal.show" title-align="start"
    :on-before-ok="onOk" unmountOnClose :esc-to-close="false" :mask-closable="false">
    <div class="attr-modal-ckb">
      <a-checkbox v-model="isAuto">自动组装规格型号</a-checkbox>
      <p class="tip-text">勾选后自动将所选商品属性组装成商品规格，并填充到商品【规格型号】中</p>
    </div>
    <div class="transfer-area">
      <p class="tip-text">请从下面列表中选择商品适用的属性，添加到右侧列表中</p>
      <a-transfer v-model:model-value="target" :title="['待选属性', '已选属性']" :data="(attrList as any)" :show-select-all="true"
        one-way>
        <template #target="{ data }">
          <div class="right-area">
            <div v-for="v in data" class="custom-item">
              <!-- 可拖动标题 -->
              <div class="label">
                <icon-drag-dot-vertical />
                <a-tooltip :content="v.label">
                  <p class="label-text">{{ v.label }}：</p>
                </a-tooltip>
              </div>
              <!-- 文本输入 -->
              <template v-if="dataObj[v.value].type === 'text'">
                <a-input v-limit-input v-model="dataObj[v.value].val" style="width: 200px;" placeholder="请输入"
                  show-word-limit :max-length="200"></a-input>
              </template>
              <!-- 下拉选择 -->
              <template v-if="dataObj[v.value].type === 'dataDictionary'">
                <a-select v-model="dataObj[v.value].val" style="width: 200px;" placeholder="请选择">
                  <a-option v-for="i in dataObj[v.value].content" :value="i" :label="i"></a-option>
                </a-select>
              </template>
              <!-- 删除 -->
              <icon-delete @click="onTargetDel(v)" />
            </div>
          </div>
        </template>
      </a-transfer>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="product-goods-attr-modal">
import { getSpecsAttr } from '@/api/product/goods';
import { Message } from '@arco-design/web-vue';
import { nextTick, reactive, ref, toRaw, watch } from 'vue';
import Sortable from 'sortablejs';
import { deepClone } from '@/utils/helper';

const emits = defineEmits<{
  (e: "ok", data: string): void
}>();

const modal = reactive({ show: false });
/** 属性列表 */
const attrList = ref<any[]>([]);
/** 已选的，在右侧的那一堆数据 */
const target = ref();
/** 属性ID对应的映射数据 */
const dataObj = ref({});
/** 是否勾选了自动组装（不知道意义何在） */
const isAuto = ref<boolean>(true);

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  if (!isAuto.value) {
    return true;
  }

  // 对选择的属性挨个判断，不能为空，然后拼接字符串，最后梭哈给表单
  let str = "";
  for (let i = 0; i < target.value.length; i++) {
    const { val, attrName } = dataObj.value[target.value[i]];

    if (!val) {
      Message.error(`${attrName}不能为空`);
      return false;
    }
    str += `${val}`;
  }
  if (str.length > 50) {
    Message.error("规格型号最长为 50 个字符");
    return false;
  }
  emits("ok", str);
  return true;
}

/** 初始化一些必要的数据 */
const init = async () => {
  try {
    const res = await getSpecsAttr();
    if (res.code != 0) {
      throw new Error(res.message);
    }
    const arr = res.value;

    attrList.value = [];
    for (let i = 0; i < arr.length; i++) {
      const { id, attrName, content, type } = arr[i];
      // 组装左侧数据
      attrList.value.push({ value: id, label: attrName });
      // 组装映射数据
      dataObj.value[String(id)] = { content, attrName, type, val: "" }
    }
  } catch (err) {
    Message.error((err as Error).message);
  }
}

/** 初始化排序 */
const initSortable = () => {
  var el = document.getElementsByClassName('right-area')[0] as HTMLElement;
  Sortable.create(el, {
    group: "name",
    handle: ".arco-icon-drag-dot-vertical",
    draggable: ".custom-item",
    sort: true,
    animation: 150,
    easing: "cubic-bezier(1, 0, 0, 1)",
    onEnd: (evt: { newIndex: any; oldIndex: any }) => {
      const oldArr = toRaw(deepClone(target.value));
      oldArr.splice(evt.newIndex, 0, oldArr.splice(evt.oldIndex, 1)[0]);
      const newArr = oldArr.slice(0);
      nextTick(() => {
        target.value = deepClone(newArr);
      });
    },
  });
}

/** 右侧数据删除触发，需要手动删 (doge) */
const onTargetDel = (v: { label: string, value: any }) => {
  for (let i = 0; i < target.value.length; i++) {
    if (target.value[i] === v.value) {
      target.value.splice(i, 1);
      break;
    }
  }
  nextTick(() => {
    initSortable();
  });
}

// 打开弹窗
const open = async () => {
  modal.show = true;
  target.value = [];
  isAuto.value = false;
  init();
}

watch(() => target.value, () => {
  nextTick(() => {
    initSortable();
  });
});

defineExpose({
  open
});
</script>

<style lang="less">
.attr-modal {

  // UI 说要滚动条要常规显示...一直显示...
  .arco-scrollbar.arco-scrollbar-type-embed .arco-scrollbar-thumb {
    opacity: 1;
  }

  // （不理解）不要全部删除功能，说是原型和 UI 上都没有，（然鹅 UI 上是选择占比...）
  .arco-transfer-view-header-clear-btn {
    display: none;
  }

  .attr-modal-ckb {
    display: flex;
    margin-top: -10px;
    margin-bottom: 10px;

    .tip-text {
      color: #B1B1B1;
      margin-left: 20px;
      font-size: 12px;
    }
  }

  .transfer-area {
    padding: 0 40px;
    margin-bottom: 20px;

    .tip-text {
      font-size: 13px;
      color: #3A3A3A;
      line-height: 1.2;
    }

    .arco-transfer-view {
      width: 364px;
      height: 400px;
      border: 1px solid #EFEFEF;

      .arco-transfer-view-header {
        background: rgba(248, 248, 248, 1);
        font-size: 12px;
        color: #3A3A3A;
        height: 37px;

        .arco-transfer-view-header-count {
          color: #3A3A3A;
          font-size: 12px;
        }
      }
    }

    .arco-transfer-operations {
      padding: 0 30px;

      .arco-btn-secondary {
        background-color: rgba(238, 242, 255, 1);
        color: #3E6CFE;
        border: 1px solid rgba(238, 242, 255, 1);
      }

      .arco-btn {
        min-width: 34px;
        width: 34px;
        height: 34px;
        border-radius: 50%;
      }
    }
  }

  .custom-item {
    padding: 0 20px;
    display: flex;
    align-items: center;
    background-color: #fff;

    .label {
      display: flex;
      align-items: center;
      justify-content: flex-end;

      .label-text {
        width: 70px;
        text-align: right;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        -o-text-overflow: ellipsis;
      }

      .arco-icon-drag-dot-vertical {
        color: #C9C9C9;
        margin-right: 10px;
        font-size: 18px;
        cursor: move;
      }
    }

    .arco-icon-delete {
      color: #CECECE;
      margin-left: 10px;
      font-size: 18px;
      cursor: pointer;
    }
  }
}
</style>