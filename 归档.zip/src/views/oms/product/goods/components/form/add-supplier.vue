<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-06 15:22:35
 * @ Modified by: Sam
 * @ Modified time: 2023-03-15 09:07:41
 * @ Description: 添加供应商
 -->

<template>
  <a-modal title="选择供应商" width="600px" v-model:visible="modal.show" title-align="start" :on-before-ok="onOk"
    unmountOnClose :esc-to-close="false" :mask-closable="false">
    <a-form ref="formRes" layout="inline" :model="form">
      <a-form-item field="keyWord" label="供应商：" label-col-flex="60px">
        <a-input v-limit-input v-model="form.keyWord" placeholder="供应商编码/名称" allow-clear></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="init" @clear="handleReset"></oms-search-btn>
    </a-form>

    <a-table :data="(list as any)" :pagination="false" row-key="id" :bordered="{ wrapper: false }" :row-selection="{
      type: 'checkbox',
      showCheckedAll: true,
      onlyCurrent: false,
    }" @selection-change="onSelectionChange" :scroll="{ y: 400 }">
      <template #columns>
        <a-table-column title="序号" :width="60">
          <template #cell="{ rowIndex }">
            {{ rowIndex + 1 }}
          </template>
        </a-table-column>
        <a-table-column title="供应商编码" :width="180">
          <template #cell="{ record }">
            {{ record.supplierCode }}
          </template>
        </a-table-column>
        <a-table-column title="供应商名称" :width="180">
          <template #cell="{ record }">
            {{ record.supplierName }}
          </template>
        </a-table-column>
      </template>
    </a-table>
  </a-modal>
</template>

<script setup lang="ts" name="add-supplier">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { getSupplierList } from '@/api/product/goods';
import { SupplierItem } from '@/types/product/goods';
import { Message } from '@arco-design/web-vue';
import { reactive, ref } from 'vue';

const modal = reactive({
  show: false
});
const emits = defineEmits<{
  (e: "on-add", data: SupplierItem[]): void
}>();

const loading = ref(false);
const form = ref({ keyWord: "" });
const skuId = ref();
const formRes = ref();
const selectList = ref<SupplierItem[]>([]);
const list = ref<SupplierItem[]>([]);

// 表格选框触发
const onSelectionChange = (key: any[]) => {
  selectList.value = key;
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  if (selectList.value.length === 0) {
    Message.error("请选择供应商");
    return false;
  }
  let arr = [];
  for (let i = 0; i < selectList.value.length; i++) {
    for (let j = 0; j < list.value.length; j++) {
      if (selectList.value[i] === list.value[j].id) {
        arr.push(list.value[j]);
      }
    }
  }

  emits("on-add", arr);
}

const open = async (specId: number) => {
  form.value.keyWord = "";
  skuId.value = specId;
  modal.show = true;
  init();
}

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  init();
}

const init = async () => {
  try {
    loading.value = true;
    const res = await getSupplierList(form.value.keyWord, skuId.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }

    list.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  } finally {
    loading.value = false;
  }
}

defineExpose({
  open
});
</script>