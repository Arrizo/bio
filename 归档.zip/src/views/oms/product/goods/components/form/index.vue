<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-21 14:28:36
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 14:28:39
 * @ Description: 商品新增/编辑组件
 -->
<template>
  <a-modal :title="`${editModal.type === 'add' ? '新增' : '编辑'}`" width="1100px" v-model:visible="editModal.show"
    title-align="start" unmountOnClose :esc-to-close="false" :mask-closable="false">
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-row :gutter="6">
        <a-col :span="8">
          <a-form-item label="商品编码：" label-col-flex="100px">
            <a-input v-limit-input disabled v-model="form.productCode" />
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item field="productType" label="类型：" label-col-flex="100px"
            :rules="[{ required: true, message: '选择类型' }]">
            <a-select placeholder="请选择" v-model="form.productType" allow-clear>
              <a-option value="PHYSICAL" label="实物商品"></a-option>
              <a-option value="PACKAGING" label="包装材料"></a-option>
              <a-option value="ACCESSORY" label="辅料耗材"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item field="barCode" label="商品条码：" label-col-flex="100px">
            <a-input v-limit-input v-model="form.barCode" placeholder="请输入" allow-clear show-word-limit
              :max-length="20" />
          </a-form-item>
        </a-col>
      </a-row>
      <a-form-item field="productTitle" label="商品名称：" label-col-flex="100px"
        :rules="[{ required: true, message: '请输入商品名称' }]">
        <a-tooltip mini :content="form.productTitle" v-if="form.productTitle.length > 60">
          <a-input v-limit-input v-model="form.productTitle" placeholder="请输入" allow-clear show-word-limit
            :max-length="500" />
        </a-tooltip>
        <a-input v-else v-limit-input v-model="form.productTitle" placeholder="请输入" allow-clear show-word-limit
          :max-length="500" />
      </a-form-item>
      <a-form-item field="shortTitle" label="商品简称：" label-col-flex="100px">
        <a-tooltip mini :content="form.shortTitle" v-if="form.shortTitle.length > 60">
          <a-input v-limit-input v-model="form.shortTitle" placeholder="请输入" allow-clear show-word-limit
            :max-length="500" />
        </a-tooltip>
        <a-input v-else v-limit-input v-model="form.shortTitle" placeholder="请输入" allow-clear show-word-limit
          :max-length="500" />
      </a-form-item>
      <a-form-item field="englishTitle" label="英文名称：" label-col-flex="100px">
        <a-tooltip mini :content="form.englishTitle" v-if="form.englishTitle.length > 60">
          <a-input v-limit-input v-model="form.englishTitle" placeholder="请输入" allow-clear show-word-limit
            :max-length="500" />
        </a-tooltip>
        <a-input v-else v-limit-input v-model="form.englishTitle" placeholder="请输入" allow-clear show-word-limit
          :max-length="500" />
      </a-form-item>
      <a-form-item field="pictures" label="商品主图：" label-col-flex="100px">
        <div>
          <p style="font-size: 12px;color: #B1B1B1;margin:0;line-height: 32px;">
            最多上传5张图片，建议尺寸800*800px，每张不超过1M，支持格式jpg/png/gif，可拖动调整图片顺序。第一张为主图</p>
          <image-uploader v-model="form.pictures" :limit="5" :size="1 * 1024 * 1024"
            module="PRODUCT_COMPRESSED_FILE"></image-uploader>
        </div>
      </a-form-item>
      <a-row :gutter="6">
        <a-col :span="8">
          <a-form-item field="brandId" label="商品品牌：" label-col-flex="100px"
            :rules="[{ required: true, message: '请选择商品品牌' }]">
            <a-select placeholder="请选择" v-model="form.brandId" allow-clear allow-search>
              <a-option v-for="v in initInfo?.brandTitles" :label="v.name" :value="v.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item field="categoryId" label="商品分类：" label-col-flex="100px"
            :rules="[{ required: true, message: '请选择商品分类' }]">
            <a-cascader check-strictly :field-names="{ value: 'id', label: 'title' }" :options="categoryList"
              v-model="form.categoryId" placeholder="请选择" allow-clear @change="onCategoryChange" />
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item field="jdCategoryId" label="京东分类：" label-col-flex="100px">
            <a-select placeholder="请选择" v-model="form.jdCategoryId" allow-clear allow-search>
              <a-option v-for="v in initInfo?.jdCategory" :label="v.dictionaryTitle" :value="v.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="6">
        <a-col :span="8">
          <a-form-item field="unitId" label="单位：" label-col-flex="100px">
            <a-select placeholder="请选择" v-model="form.unitId" allow-clear allow-search>
              <a-option v-for="v in initInfo?.unitTitles" :label="v.name" :value="v.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item field="defaultTaxRateId" label="默认税率：" label-col-flex="100px">
            <a-select placeholder="请选择" v-model="form.defaultTaxRateId" allow-clear allow-search>
              <a-option v-for="v in initInfo?.defaultTaxRate" :label="v.dictionaryTitle" :value="v.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item field="effectiveDay" label="有效期(天)：" label-col-flex="100px">
            <a-input-number :precision="0" :min="1" :max="99999" v-limit-input v-model="form.effectiveDay"
              placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="6">
        <a-col :span="8">
          <a-form-item label="长宽高(cm)：" label-col-flex="100px">
            <a-space :size="8">
              <a-input-number :min="0" :max="999" @blur="handleVolume('length')" v-limit-input
                v-model="form.length" style="width: 50px;" placeholder="长" />
              <a-input-number :min="0" :max="999" @blur="handleVolume('width')" v-limit-input
                v-model="form.width" style="width: 50px;" placeholder="宽" />
              <a-input-number :min="0" :max="999" @blur="handleVolume('height')" v-limit-input
                v-model="form.height" style="width: 50px;" placeholder="高" />
              <a-input-number :min="0" :max="999999999" v-limit-input v-model="form.volume as number"
                style="width: 80px;" placeholder="体积" @blur="limitNum('volume')" />
            </a-space>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item field="grossWeight" label="毛重(g)：" label-col-flex="100px">
            <a-input-number :min="0" :max="99999" @blur="limitNum('grossWeight')" :precision="4" v-limit-input
              v-model="form.grossWeight" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item field="suttle" label="净重(g)：" label-col-flex="100px">
            <a-input-number :min="0" :max="99999" @blur="limitNum('suttle')" :precision="4" v-limit-input
              v-model="form.suttle" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-form-item field="remark" label="备注：" label-col-flex="100px">
        <a-textarea v-limit-input v-model="form.remark" placeholder="请输入" show-word-limit :max-length="200" />
      </a-form-item>
      <a-form-item field="menuName" label="设置：" label-col-flex="100px">
        <a-space :size="46">
          <a-checkbox v-model="form.dispatch">一件代发</a-checkbox>
          <a-checkbox v-model="form.uniqueCode">启用唯一码管理</a-checkbox>
          <a-checkbox v-model="form.effectiveBatch">启用有效期批次管理</a-checkbox>
        </a-space>
      </a-form-item>
      <a-form-item field="attachment" label="上传附件：" label-col-flex="100px">
        <file-uploader v-model="form.attachment" accept=".zip,.rar,.7z" download module="PRODUCT_COMPRESSED_FILE"
          file-type="3" :size="50 * 1024 * 1024"></file-uploader>
      </a-form-item>
    </a-form>
    <template #footer>
      <a-button @click="editModal.show = false">取消</a-button>
      <a-button type="outline" @click="onSubmit()">提交</a-button>
      <a-button type="primary" status="normal" v-if="editModal.type === 'add'" @click="onSubmit(true)">提交并新增sku</a-button>
    </template>
  </a-modal>

  <!-- sku 编辑-->
  <sku-form ref="skuFormRef"></sku-form>
</template>

<script setup lang="ts" name="product-goods-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import imageUploader from '@/components/image-uploader/index.vue';
import fileUploader from '@/components/file-uploader/index.vue';
import skuForm from './sku-form.vue';
import { GoodsForm } from '@/types/product/goods';
import { initSpu, addProduct, updateProduct, getProductDetail } from '@/api/product/goods';
import { getList } from '@/api/product/category';
import { CategoryListItem } from '@/types/product/category';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const skuFormRef = ref();
const loading = ref<boolean>(false);
const detailLoading = ref<boolean>(false);
const categoryList = ref<CategoryListItem[]>([]);
const initInfo = ref<{
  brandTitles: any[],
  jdCategory: any[],
  unitTitles: any[],
  defaultTaxRate: any[]
}>();
const form = ref<GoodsForm>(new GoodsForm());
const productId = ref();

/** 确定按钮回调 */
const onSubmit = async (isNext: boolean = false) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    loading.value = true;
    const api = editModal.type === 'add' ? addProduct : updateProduct;
    /** 需要特殊处理 */
    form.value.picture = form.value?.pictures;

    const res = await api(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    editModal.show = false;

    setTimeout(() => {
      isNext && skuFormRef.value.handleShowModal("add", productId.value || res.value, form.value);
    }, 200);
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  } finally {
    loading.value = false;
  }
}

const limitNum = (param: string) => {
  form.value[param] = Number(Number(form.value[param]).toFixed(4))
}

const handleVolume = (param: string) => {
  form.value[param] = Number(Number(form.value[param]).toFixed(4))
  const { height, width, length } = form.value;
  if (!height || !width || !length) return;
  form.value.volume = Number(Number(Number(height) * Number(width) * Number(length)).toFixed(2));
}

const onCategoryChange = (id: any) => {
  let isHas = false;
  function hasChild(arr: any): boolean {
    for (let i = 0; i < arr.length; i++) {
      if (arr[i]?.children && arr[i].children.length !== 0) {
        isHas = hasChild(arr[i]?.children);
      }
      if (arr[i].id === id && !!arr[i].children && arr[i].children.length !== 0) {
        isHas = true;
        break;
      }
    }

    return isHas;
  }

  if (hasChild(categoryList.value)) {
    Message.error("只能选择末级分类");
    // @ts-ignore
    form.value.categoryId = '';
    return;
  }
}

/** 初始化商品下拉信息 */
const init = async () => {
  try {
    const res = await initSpu();
    const categoryRes = await getList({ status: "", title: "" });

    if (res.code != 0 || categoryRes.code != 0) {
      throw new Error(res.message || categoryRes.message);
    }
    initInfo.value = res.value;
    categoryList.value = categoryRes.value
  } catch (err) {
    Message.error((err as Error).message);
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: any) => {
  editModal.type = type;
  editModal.show = true;
  productId.value = data;
  init();

  if (type === 'add') {
    form.value = new GoodsForm();
  }

  if (type === "edit") {
    try {
      detailLoading.value = true;
      const res = await getProductDetail(productId.value);
      if (res.code != 0) {
        throw new Error(res.message);
      }
      form.value = res.value;
      form.value.pictures = form.value.picture && [...form.value.picture]
    } catch (err) {
      Message.error((err as Error).message);
    } finally {
      detailLoading.value = false;
    }
  }
}

defineExpose({
  handleShowModal
});
</script>