<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-25 08:59:12
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 08:24:46
 * @ Description: SKU 表单
 -->

<template>
  <a-modal :title="`${editModal.type === 'add' ? '新增' : editModal.type === 'detail' ? '查看' : '编辑'}sku`" width="1100px"
    v-model:visible="editModal.show" title-align="start" unmountOnClose :esc-to-close="false" :mask-closable="false"
    class="sku-form">
    <a-tabs :style="{ width: '100%' }" v-model:active-key="currentTab">
      <a-tab-pane key="info" title="基本信息">
        <sku-form-inner ref="skuInnerFormRef"></sku-form-inner>
      </a-tab-pane>
      <a-tab-pane key="supplier" title="供应商">
        <supplier-inner ref="supplierInnerRef" :is-detail="isDetail" :sku-id="editModal.data"></supplier-inner>
      </a-tab-pane>
    </a-tabs>
    <template #footer>
      <a-button @click="editModal.show = false">取消</a-button>
      <template v-if="!isDetail">
        <a-button type="outline" @click="onSubmit(true)">暂存</a-button>
        <a-button type="primary" status="normal" @click="onSubmit(false)">提交</a-button>
      </template>
    </template>
  </a-modal>
</template>

<script setup lang="ts" name="product-goods-sku-form">
import { reactive, nextTick, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import skuFormInner from './sku-form-inner.vue';
import supplierInner from './supplier-inner.vue';
import { addSpecs, updateSpecs, getSpecsDetail, getProductDetail } from '@/api/product/goods';

interface EditModal {
  show: boolean;
  type: "add" | "edit" | "detail";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const currentTab = ref("info");
const skuInnerFormRef = ref();
const isDetail = ref(false);
const supplierInnerRef = ref();
const submitLoading = ref<boolean>(false);

// SKU 表单统一提交
const onSubmit = async (isTemp: boolean = false) => {
  submitLoading.value = true;
  try {
    const form = await skuInnerFormRef.value.form;
    /** 需要特殊处理 */
    form.picture = form.pictures;
    const supplierList = await supplierInnerRef.value.list;
    // if (supplierList.length === 0) {
    //   throw new Error("请选择供应商");
    // }
    // 又说不强制了...
    // const isSelect = supplierList.filter((v: any) => v.defaultSupplier);
    // if (supplierList.length !== 0 && isSelect.length === 0) {
    //   throw new Error("请选择一个默认供应商");
    // }
    for (let i = 0; i < supplierList.length; i++) {
      supplierList[i].supplierId = supplierList[i].id;
    }

    const api = editModal.type === "add" ? addSpecs : updateSpecs;
    form.operateType = isTemp ? 2 : 1;
    form.suppliers = supplierList;
    const res = await api(form);
    if (res.code != 0) {
      throw new Error(res.message);
    }

    editModal.show = false;
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    submitLoading.value = false;
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 * @param data id
 * @param form 需要继承的字段
 */
const handleShowModal = async (type: "add" | "edit" | "detail", data: any, form: any) => {
  isDetail.value = type === 'detail';

  editModal.type = type;
  editModal.show = true;
  editModal.data = data;
  currentTab.value = "info";

  if (editModal.type === 'add') {
    nextTick(async () => {
      try {
        const res = await getProductDetail(data);
        if (res.code != 0) {
          throw new Error(res.message);
        }
        skuInnerFormRef.value.form.length = res.value.length;
        skuInnerFormRef.value.form.width = res.value.width;
        skuInnerFormRef.value.form.height = res.value.height;
        skuInnerFormRef.value.form.volume = res.value.volume;
        skuInnerFormRef.value.form.grossWeight = res.value.grossWeight;
        skuInnerFormRef.value.form.suttle = res.value.suttle;
        skuInnerFormRef.value.form.barCode = res.value.barCode;
      } catch (err) {
        Message.error((err as Error).message);
      }
    });
  }

  if (['edit', 'detail'].includes(type)) {
    try {
      const res = await getSpecsDetail(data);
      if (res.code != 0) {
        throw new Error(res.message);
      }

      skuInnerFormRef.value.form = res.value;
      skuInnerFormRef.value.form.pictures = res.value.picture;
      supplierInnerRef.value.list = res.value.suppliers;
    } catch (err) {
      Message.error((err as Error).message);
    }
  }

  nextTick(() => {
    skuInnerFormRef.value.init(type, data);
  });
}

defineExpose({
  handleShowModal
});
</script>

<style lang="less">
.sku-form {
  .arco-modal-body {
    padding: 10px 32px;
    height: 700px;
  }
}
</style>