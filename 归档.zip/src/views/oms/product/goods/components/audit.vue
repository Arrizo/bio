<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-03 14:55:20
 * @ Modified by: Sam
 * @ Modified time: 2023-03-28 14:00:22
 * @ Description: 商品审核
 -->

<template>
  <a-modal title="审核商品" width="1200px" v-model:visible="modal.show" title-align="start" unmountOnClose
    :esc-to-close="false" :mask-closable="false" :footer="false" @close="onClose">
    <a-form ref="searchFormRef" :model="searchForm" layout="inline">
      <a-form-item field="code" label="编码：">
        <a-input v-limit-input allow-clear v-model="searchForm.code" placeholder="spu/sku编码/条码" />
      </a-form-item>
      <a-form-item field="name" label="名称：">
        <a-input v-limit-input allow-clear v-model="searchForm.name" placeholder="spu/sku名称/品牌" />
      </a-form-item>
      <oms-search-btn :loading="loading" @search="search(true)" @clear="handleReset"></oms-search-btn>
    </a-form>

    <div style="margin-bottom: 8px;">
      <a-button type="primary" status="normal" @click="handleActoin('batch')"
        :disabled="selectList.length === 0">批量审核</a-button>
    </div>
    <oms-table :loading="loading" :total="total" :current="searchForm.pageNum" :size="searchForm.pageSize"
      @reload="onReload">
      <a-table :data="(list as any)" :pagination="false" hide-expand-button-on-empty row-key="id" stripe scrollbar
        :bordered="{ wrapper: false }" :scroll="{ x: 1400, y: 500 }" :row-selection="{
          type: 'checkbox',
          showCheckedAll: true,
          onlyCurrent: false,
        }" @selection-change="onSelectionChange">
        <template #columns>
          <a-table-column title="规格名称" :width="200">
            <template #cell="{ record }">
              <div class="goods-info">
                <a-image width="44" height="44" :src="record.mainPicture">
                  <template #error>
                    <div class="empty-picture">
                      <i class="iconfont icon-shangpinzhanweitu"></i>
                    </div>
                  </template>
                </a-image>
                <a-tooltip :content="record.specsTitle">
                  <span>{{ record.specsTitle }}</span>
                </a-tooltip>
              </div>
            </template>
          </a-table-column>
          <a-table-column title="规格编码" :width="140">
            <template #cell="{ record }"> {{ record.specsCode || '--' }} </template>
          </a-table-column>
          <a-table-column title="规格型号" :width="140">
            <template #cell="{ record }"> {{ record.specsModel || '--' }} </template>
          </a-table-column>
          <a-table-column title="条码" :width="140">
            <template #cell="{ record }"> {{ record.barCode || '--' }} </template>
          </a-table-column>
          <a-table-column title="吊牌价/面值（元）" :width="200" align="right" cell-class="paddingR40">
            <template #cell="{ record }"> {{ record.tagPrice || '--' }} </template>
          </a-table-column>
          <a-table-column title="代发采购价" :width="140" align="right" cell-class="paddingR40">
            <template #cell="{ record }"> {{ record.tagPrice || '--' }} </template>
          </a-table-column>
          <a-table-column title="集采入仓价" :width="140" align="right" cell-class="paddingR40">
            <template #cell="{ record }"> {{ record.tagPrice || '--' }} </template>
          </a-table-column>
          <a-table-column title="箱规">
            <template #cell="{ record }"> {{ record.shippingBoxGauge || '--' }} </template>
          </a-table-column>
          <a-table-column title="操作" :width="110">
            <template #cell="{ record }">
              <a-space :size="14">
                <a-link @click="handleActoin('detail', record)" type="text">查看</a-link>
                <a-link @click="handleActoin('audit', record)" type="text">审核</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </a-modal>

  <!-- sku 编辑-->
  <sku-form ref="skuFormRef"></sku-form>

  <!-- 审核弹框 -->
  <audit-modal ref="auditModalRef" @reload="search(true)"></audit-modal>
</template>

<script setup lang="ts" name="product-goods-audit">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { AuditSkuListItem, AuditSkuSearchForm } from '@/types/product/goods';
import { getUnAudit } from "@/api/product/goods";
import skuForm from './form/sku-form.vue';
import auditModal from "./audit-modal.vue";

const modal = reactive({
  show: false
});

const searchFormRef = ref();
const skuFormRef = ref();
const auditModalRef = ref();
const searchForm = ref<AuditSkuSearchForm>(new AuditSkuSearchForm());
const list = ref<AuditSkuListItem[]>([]);
const total = ref<number>(0);
const selectList = ref<number[]>([]);
const loading = ref<boolean>(false);

const emits = defineEmits<{
  (e: "close"): void
}>();

// 表格选框触发
const onSelectionChange = (key: any[]) => {
  selectList.value = key;
}

// 重置搜索条件
const handleReset = () => {
  searchFormRef.value.resetFields();
  search(true);
}

const onReload = (data: {
  pageNum: number;
  pageSize: number;
}) => {
  searchForm.value.pageNum = data.pageNum;
  searchForm.value.pageSize = data.pageSize;
  search();
}

const onClose = () => {
  emits("close");
}

const search = async (isReload = false) => {
  try {
    loading.value = true;
    if (isReload) {
      searchForm.value.pageNum = 1;
    }
    const res = await getUnAudit(searchForm.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "audit" | "detail" | "batch", data?: any) => {
  if (type === 'detail') {
    skuFormRef.value.handleShowModal("detail", data.id);
  }
  if (type === 'audit') {
    auditModalRef.value.open([data.id]);
  }
  if (type === "batch") {
    auditModalRef.value.open(selectList.value);
  }
};

const open = async () => {
  modal.show = true;
  search(true)
}

defineExpose({
  open
});
</script>