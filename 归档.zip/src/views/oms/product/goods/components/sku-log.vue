<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-20 10:30:24
 * @ Modified by: Sam
 * @ Modified time: 2023-03-09 09:06:45
 * @ Description: 商品档案日志
 -->

<template>
  <a-modal title="日志" width="800px" v-model:visible="logModal.show" title-align="start" unmountOnClose
    :esc-to-close="false" :mask-closable="false">
    <oms-table :loading="loading">
      <a-table :data="(list as any)" :pagination="false" hide-expand-button-on-empty row-key="id"
        :bordered="{ wrapper: false }">
        <template #columns>
          <a-table-column title="操作时间" :width="180" data-index="operationTime"></a-table-column>
          <a-table-column title="操作人" :width="80" data-index="operater"></a-table-column>
          <a-table-column title="操作" :width="80" data-index="logType"></a-table-column>
          <a-table-column title="内容" data-index="msg"></a-table-column>
        </template>
      </a-table>
    </oms-table>
    <template #footer>
      <a-space :size="14">
        <a-button @click="handleCancel">关闭</a-button>
      </a-space>
    </template>
  </a-modal>
</template>

<script setup lang="ts" name="product-unit-log">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { Message } from '@arco-design/web-vue';
import { quaryRangeLog } from '@/api/basicdata/shop';

interface LogModal {
  show: boolean
  data?: any
}
const logModal = reactive<LogModal>({
  show: false,
  data: null
});

const list = ref<{
  businessCode: string;
  businessType: string;
  logType: string;
  msg: string;
  operater: string;
  operationTime: string
}[]>([]);
const loading = ref(false);

const open = async (data: string) => {
  logModal.show = true;
  try {
    loading.value = true;
    const res = await quaryRangeLog(data, "商品规格档案");
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  } finally {
    loading.value = false;
  }
}

const handleCancel = () => {
  logModal.show = false;
}

defineExpose({
  open
});
</script>