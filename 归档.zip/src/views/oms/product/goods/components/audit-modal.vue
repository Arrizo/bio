<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-04 09:41:14
 * @ Modified by: Sam
 * @ Modified time: 2023-03-20 13:38:12
 * @ Description: 审核弹框
 -->
<template>
  <a-modal title="审核商品" width="600px" v-model:visible="modal.show" title-align="start" :on-before-ok="onOk" unmountOnClose
    :esc-to-close="false" :mask-closable="false">
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-form-item field="k3PushStatus" label="审核结果：" label-col-flex="100px">
        <a-select placeholder="请选择" v-model="form.auditStatus as string">
          <a-option value="true">通过</a-option>
          <a-option value="false">不通过</a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="remark" label="备注说明：" label-col-flex="100px"
        :rules="[{ required: form.auditStatus === 'false', message: '请输入备注说明' }]">
        <a-textarea v-limit-input placeholder="请输入" v-model="form.remark" show-word-limit :max-length="200"></a-textarea>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="product-goods-audit-modal">
import { batchAudit } from '@/api/product/goods';
import { BatchAuditForm } from '@/types/product/goods';
import { Message } from '@arco-design/web-vue';
import { reactive, ref } from 'vue';

const modal = reactive({
  show: false
});
const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const form = ref<BatchAuditForm>(new BatchAuditForm())

const open = async (ids: number[]) => {
  form.value = new BatchAuditForm();
  form.value.skuId = ids;
  modal.show = true;
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const res = await batchAudit({
      auditStatus: form.value.auditStatus === "true",
      remark: form.value.remark,
      skuId: form.value.skuId,
    });
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

defineExpose({
  open
});
</script>