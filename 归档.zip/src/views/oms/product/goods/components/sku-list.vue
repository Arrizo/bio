<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-23 13:52:51
 * @ Modified by: Sam
 * @ Modified time: 2023-03-28 13:57:53
 * @ Description: 规格列表
 -->

<template>
  <div class="prouct-goods-sku-list">
    <oms-table :loading="loading">
      <template #header-left>
        <a-button type="primary" status="normal" style="margin-bottom: 10px;" @click="handleActoin('add')"
          v-permission="['oms:product:goods:addsku']">新增sku</a-button>
      </template>

      <a-table :data="(list as any)" stripe :pagination="false" :bordered="{ wrapper: false }" :scroll="{ x: 1400 }" size="small">
        <template #columns>
          <a-table-column title="规格名称" :width="200">
            <template #cell="{ record }">
              <div class="goods-info">
                <a-image width="44" height="44" :src="record.mainPicture">
                  <template #error>
                    <div class="empty-picture">
                      <i class="iconfont icon-shangpinzhanweitu"></i>
                    </div>
                  </template>
                </a-image>
                <a-tooltip :content="record.specsTitle">
                  <span>{{ record.specsTitle }}</span>
                </a-tooltip>
              </div>
            </template>
          </a-table-column>
          <a-table-column title="规格编码" :width="140">
            <template #cell="{ record }"> {{ record.specsCode || '--' }} </template>
          </a-table-column>
          <a-table-column title="规格型号" :width="140">
            <template #cell="{ record }"> {{ record.specsModel || '--' }} </template>
          </a-table-column>
          <a-table-column title="条码" :width="140">
            <template #cell="{ record }"> {{ record.barCode || '--' }} </template>
          </a-table-column>
          <a-table-column title="吊牌价/面值（元）" :width="200" align="right" cell-class="paddingR40">
            <template #cell="{ record }"> {{ record.tagPrice || '--' }} </template>
          </a-table-column>
          <a-table-column title="推送k3状态" :width="140">
            <template #cell="{ record }">
              <oms-tag v-if="record.k3Status" :type="K3StatusTagObj[record.k3Status]"
                :content="K3Status[record.k3Status]"></oms-tag>
              <span v-else>--</span>
            </template>
          </a-table-column>
          <a-table-column title="同步wms状态" :width="140">
            <template #cell="{ record }">
              <oms-tag v-if="record.syncWmsStatus" :type="SyncWmsStatusTagObj[record.syncWmsStatus]"
                :content="SyncWmsStatus[record.syncWmsStatus]"></oms-tag>
              <span v-else>--</span>
            </template>
          </a-table-column>
          <a-table-column title="审核状态" :width="140">
            <template #cell="{ record }">
              <oms-tag v-if="record.auditStatus" :type="auditStatusTagObj[record.auditStatus]"
                :content="AuditStatusList[record.auditStatus]"></oms-tag>
              <span v-else>--</span>
            </template>
          </a-table-column>
          <a-table-column title="状态" :width="140">
            <template #cell="{ record, rowIndex }">
              <div v-permission="['oms:product:goods:skustatus']">
                <a-switch v-model="(list as any)[rowIndex].status" @focus="onSwitchForce(record, rowIndex)">
                  <template #checked>
                    启用
                  </template>
                  <template #unchecked>
                    禁用
                  </template>
                </a-switch>
              </div>
              <div v-permission-else="['oms:product:goods:skustatus']">{{ record.status ? '启用' : '禁用' }}</div>
            </template>
          </a-table-column>
          <a-table-column title="箱规" :width="140">
            <template #cell="{ record }"> {{ record.shippingBoxGauge || '--' }} </template>
          </a-table-column>
          <a-table-column title="操作" :width="100" fixed="right">
            <template #cell="{ record }">
              <a-space :size="14">
                <a-link v-permission="['oms:product:goods:editsku']" v-if="record.auditStatus !== 'WAIT_AUDIT'"
                  @click="handleActoin('edit', record)" type="text">编辑</a-link>
                <a-link v-permission="['oms:product:goods:log']" @click="handleActoin('log', record)"
                  type="text">日志</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </div>

  <!-- sku 编辑-->
  <sku-form ref="skuFormRef" @reload="onSkuReload"></sku-form>

  <!-- sku 日志 -->
  <oms-log ref="logRef"></oms-log>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleUpdateStatus"></oms-warning>
</template>

<script setup lang="ts" name="prouct-goods-sku-list">
import { PropType, reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { GoodsListItem, SpecsListItem } from '@/types/product/goods';
import omsTag from "@/components/oms-tag/index.vue";
import skuForm from './form/sku-form.vue';
import OmsLog from '@/components/oms-log/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import { K3Status, SyncWmsStatus, AuditStatusList } from "@/types/product/goods";
import { updateSkuStatus } from "@/api/product/goods";
import { Message } from '@arco-design/web-vue';

const props = defineProps({
  list: { type: Array as PropType<SpecsListItem[]>, default: () => [] },
  loading: { type: Boolean, default: false },
  pid: { type: Number, default: NaN },
  rawData: { type: Object as PropType<GoodsListItem>, default: () => { } }
});
const emits = defineEmits<{
  (e: "reload"): void
}>();

const switchRef = ref();
const skuFormRef = ref();
const logRef = ref();
const statusData = reactive({
  id: NaN,
  index: NaN
});

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: any, index: number) => {
  statusData.id = record?.id;
  statusData.index = index;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

const onSkuReload = () => {
  emits("reload");
}

// 修改状态
const handleUpdateStatus = async () => {
  try {
    const res = await updateSkuStatus(statusData.id, !props.list[statusData.index]?.status);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "add" | "edit" | "log", data?: any) => {
  if (type === "add") {
    skuFormRef.value.handleShowModal("add", props.pid, props.rawData);
  }
  if (type === "edit") {
    skuFormRef.value.handleShowModal("edit", data.id);
    return;
  }
  if (type === "log") {
    logRef.value.init(data.logCode, "商品规格档案");
    return;
  }
};

const K3StatusTagObj = {
  'PUSHED': 'progress',
  'PART_SUCCESS': 'progress',
  'UN_PUSH': 'normal',
  'PUSH_FAIL': 'warring',
  'PUSHING': 'normal',
}

const auditStatusTagObj = {
  'AUDIT_PASS': 'progress',
  'NO_PASS': 'warring',
  'STASH': 'normal',
  'WAIT_AUDIT': 'progress',
}

const SyncWmsStatusTagObj = {
  'PART_SUCCESS': 'progress',
  'SYNCHRONIZED': 'progress',
  'NO_SYNC': 'normal',
  'SYNC_FAIL': 'warring',
  'SYNCHRONIZING': 'normal',
}

</script>

<style lang="less" scoped>
.prouct-goods-sku-list {
  padding-top: 20px;
}

.spec-info {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  flex-direction: row;

  span {
    padding-left: 10px;
    word-break: break-all;
    text-overflow: ellipsis;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .empty-picture {
    width: 44px;
    height: 44px;
    background-color: #fff;
    border: 1px solid #EDEDED;
    border-radius: 2px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: row;

    .icon-shangpinzhanweitu {
      color: #EDEDED;
    }
  }
}
</style>