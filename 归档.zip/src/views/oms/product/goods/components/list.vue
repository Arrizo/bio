<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-21 14:07:05
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-27 20:05:15
 * @ Description: 商品档案列表
 -->
<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="emits('reload', $event)">
    <template #header-left>
      <a-space style="margin-bottom: 10px;">
        <a-button v-permission="['oms:product:goods:add']" type="primary" status="normal" @click="handleAddClick"> 新增
        </a-button>
        <a-button v-permission="['oms:product:goods:audit']" type="outline" @click="handleActoin('audit')"> 审核 </a-button>
        <a-button :loading="importLoading" v-permission="['oms:product:goods:import']" @click="handleActoin('import')"> 导入
        </a-button>
        <!-- 挪到搜索那去了 -->
        <!-- <a-button v-permission="['oms:product:goods:export']" :disabled="selectList.length === 0"
          @click="handleActoin('output')"> 导出 </a-button> -->
        <!-- 后端说先不做，跟产品确认了 -->
        <!-- <a-button :disabled="selectList.length === 0"> 批量推送 </a-button> -->
      </a-space>
    </template>

    <a-table v-db-click="list" :db-call-back="handleDbClick" :data="(list as any)" :pagination="false"
      hide-expand-button-on-empty row-key="id" stripe :bordered="{ wrapper: false }" :row-selection="{
        type: 'checkbox',
        showCheckedAll: true,
        onlyCurrent: false,
      }" @selection-change="onSelectionChange" :scroll="{ x: 1400 }" size="small">
      <!-- 重写展开图标 -->
      <template #expand-icon='{ expanded }'>
        <icon-caret-down v-if="expanded" style="font-size: 32;" />
        <icon-caret-right v-else style="font-size: 32;" />
      </template>
      <template #columns>
        <a-table-column title="商品名称" :width="200" tooltip>
          <template #cell="{ record }">
            <div class="goods-info">
              <a-image width="44" height="44" :src="record.mainPicture">
                <template #error>
                  <div class="empty-picture">
                    <i class="iconfont icon-shangpinzhanweitu"></i>
                  </div>
                </template>
              </a-image>
              <a-tooltip :content="record.productTitle">
                <span>{{ record.productTitle }}</span>
              </a-tooltip>
            </div>
          </template>
        </a-table-column>
        <a-table-column title="spu编码" >
          <template #cell="{ record }"> {{ record.productCode || '--' }} </template>
        </a-table-column>
        <a-table-column title="品牌" >
          <template #cell="{ record }"> {{ record.brandName || '--' }} </template>
        </a-table-column>
        <a-table-column title="条码" >
          <template #cell="{ record }"> {{ record.barCode || '--' }} </template>
        </a-table-column>
        <a-table-column title="推送k3状态" >
          <template #cell="{ record }">
            <oms-tag v-if="record.k3Status" :type="K3StatusTagObj[record.k3Status]" :content="K3Status[record.k3Status]"></oms-tag>
            <span v-else>--</span>
          </template>
        </a-table-column>
        <a-table-column title="同步wms状态" >
          <template #cell="{ record }">
            <oms-tag v-if="record.syncWmsStatus" :type="SyncWmsStatusTagObj[record.syncWmsStatus]"
              :content="SyncWmsStatus[record.syncWmsStatus]"></oms-tag>
              <span v-else>--</span>
          </template>
        </a-table-column>
        <a-table-column title="状态" :width="120">
          <template #cell="{ record, rowIndex }">
            <div v-permission="['oms:product:goods:status']">
              <a-switch v-model="(list as any)[rowIndex].status" @focus="onSwitchForce(record, rowIndex)">
                <template #checked>
                  启用
                </template>
                <template #unchecked>
                  禁用
                </template>
              </a-switch>
            </div>
            <div v-permission-else="['oms:product:goods:status']">{{ record.status ? '启用' : '禁用' }}</div>
          </template>
        </a-table-column>
        <a-table-column title="更新时间" data-index="updateTime" :width="180">
          <template #cell="{ record }"> {{ record.updateTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="操作" :width="60" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link v-permission="['oms:product:goods:edit']" @click="handleActoin('edit', record)"
                type="text">编辑</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑弹窗 -->
  <goods-form ref="goodsFormRef" @reload="emits('reload')"></goods-form>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleUpdateStatus"></oms-warning>

  <!-- 导入 -->
  <oms-import ref="importRef" :uploadSize="10" uploadType="link" uploadUrlName="导入模板" :templateUrl="uploadUrl"
    :importApi="uploadGoods"></oms-import>

  <!-- 审核 -->
  <audit ref="auditRef" @close="handleDbClick(dbClickData)"></audit>
</template>

<script setup lang="ts" name="product-goods-list">
import { PropType, reactive, ref } from 'vue';
import { GoodsListItem, K3Status, SyncWmsStatus } from "@/types/product/goods";
import { uploadGoods, updateSpuStatus, downTemplate } from "@/api/product/goods";
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import goodsForm from "./form/index.vue";
import OmsImport from '@/components/oms-import/index.vue';
import { Message } from '@arco-design/web-vue';
import omsTag from "@/components/oms-tag/index.vue";
import audit from './audit.vue';

const props = defineProps({
  list: { type: Array as PropType<GoodsListItem[]>, default: () => [] },
  loading: { type: Boolean, default: false },
  total: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload", data?: any): void,
  (e: "on-db-click", data: any): void,
}>();

const goodsFormRef = ref();
const switchRef = ref();
const auditRef = ref();
const importRef = ref();
const uploadUrl = ref();
const dbClickData = ref();
const importLoading = ref(false);
const statusData = reactive({
  id: NaN,
  index: NaN
});

const selectList = ref<number[]>([]);

// 「新增」按钮点击触发
const handleAddClick = () => {
  goodsFormRef.value.handleShowModal("add");
};

// 表格选框触发
const onSelectionChange = (key: any[]) => {
  selectList.value = key;
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: any, index: number) => {
  statusData.id = record?.id;
  statusData.index = index;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "audit" | "edit" | "del" | "import", data?: any) => {
  if (type === "edit") {
    goodsFormRef.value.handleShowModal("edit", data.id);
    return;
  }
  if (type === "audit") {
    auditRef.value.open();
    return;
  }
  if (type === 'import') {
    try {
      importLoading.value = true;
      const res = await downTemplate();
      if (res.code != 0) {
        Message.error(res.message);
      }
      importRef.value.visible = true;
      uploadUrl.value = res.value;
    } catch (err) {
      Message.error((err as Error).message);
    } finally {
      importLoading.value = false;
    }
  }
};

/** 行双击触发 */
const handleDbClick = (data: any) => {
  dbClickData.value = data;
  emits("on-db-click", dbClickData.value)
}

// 修改状态
const handleUpdateStatus = async () => {
  try {
    const res = await updateSpuStatus(statusData.id, !props.list[statusData.index]?.status);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

const K3StatusTagObj = {
  'PUSHED': 'progress',
  'PART_SUCCESS': 'progress',
  'UN_PUSH': 'normal',
  'PUSH_FAIL': 'warring',
  'PUSHING': 'normal',
}

const SyncWmsStatusTagObj = {
  'PART_SUCCESS': 'progress',
  'SYNCHRONIZED': 'progress',
  'NO_SYNC': 'normal',
  'SYNC_FAIL': 'warring',
  'SYNCHRONIZING': 'normal',
}

defineExpose({
  selectList
});
</script>
<style lang="less" scope>
.goods-info {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  flex-direction: row;

  span {
    padding-left: 10px;
    word-break: break-all;
    text-overflow: ellipsis;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }

  .empty-picture {
    width: 44px;
    height: 44px;
    background-color: #fff;
    border: 1px solid #EDEDED;
    border-radius: 2px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: row;

    .icon-shangpinzhanweitu {
      color: #EDEDED;
    }
  }
}
</style>