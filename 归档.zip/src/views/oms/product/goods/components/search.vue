<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-21 14:07:03
 * @ Modified by: Sam
 * @ Modified time: 2023-03-15 09:51:03
 * @ Description: 商品档案-搜索
 -->
<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="code" label="编码：">
      <a-input v-limit-input v-model="form.code" @keyup.enter="handleSearch" placeholder="SPU/SKU编码/条码" allow-clear />
    </a-form-item>
    <a-form-item field="title" label="名称：">
      <a-input v-limit-input v-model="form.title" @keyup.enter="handleSearch" placeholder="SPU/SKU名称/品牌" allow-clear />
    </a-form-item>
    <a-form-item field="k3PushStatus" label="推送k3状态：">
      <a-select allow-clear placeholder="请选择" v-model="form.k3PushStatus">
        <a-option :value="K3PushStatus.All">全部</a-option>
        <a-option :value="K3PushStatus.UnPush">未推送</a-option>
        <a-option :value="K3PushStatus.Pushing">推送中</a-option>
        <a-option :value="K3PushStatus.PartSuccess">部分成功</a-option>
        <a-option :value="K3PushStatus.Pushed">已推送</a-option>
        <a-option :value="K3PushStatus.PushFail">推送失败</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="wmsSyncStatus" label="同步wms状态：" label-col-flex="120px">
      <a-select allow-clear placeholder="请选择" v-model="form.wmsSyncStatus">
        <a-option :value="WmsSyncStatus.All">全部</a-option>
        <a-option :value="WmsSyncStatus.NoSync">未同步</a-option>
        <a-option :value="WmsSyncStatus.Synchronizing">同步中</a-option>
        <a-option :value="WmsSyncStatus.PartSuccess">部分成功</a-option>
        <a-option :value="WmsSyncStatus.Synchronized">已同步</a-option>
        <a-option :value="WmsSyncStatus.SyncFail">同步失败</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="dispatch" label="是否代发：">
      <a-select allow-clear placeholder="请选择" v-model="form.dispatch">
        <a-option value="all">全部</a-option>
        <a-option value="true">是</a-option>
        <a-option value="false">否</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="auditStatus" label="审核状态：">
      <a-select allow-clear placeholder="请选择" v-model="form.auditStatus">
        <a-option :value="AuditStatus.All">全部</a-option>
        <a-option :value="AuditStatus.Stash">暂存</a-option>
        <a-option :value="AuditStatus.WaitAudit">待审核</a-option>
        <a-option :value="AuditStatus.AuditPass">通过</a-option>
        <a-option :value="AuditStatus.NoPass">不通过</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="status" label="禁用状态：">
      <a-select allow-clear placeholder="请选择" v-model="form.status">
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset">
      <a-button v-permission="['oms:product:goods:export']" :disabled="selectList.length === 0"
        @click="emits('on-export', props.selectList)"> 导出 </a-button>
    </oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="product-goods-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { GoodsSearchForm, K3PushStatus, WmsSyncStatus, AuditStatus } from '@/types/product/goods';
import { deepClone } from '@/utils/helper';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false },
  selectList: { type: Array, default: () => [] }
});

const emits = defineEmits<{
  (e: "on-search", data: any, isReset: boolean): void;
  (e: "on-export", data: any): void;
}>();

const formRes = ref();
const form = ref<GoodsSearchForm>(new GoodsSearchForm());

// 搜索
const handleSearch = (isReset: boolean = false) => {
  const data = deepClone(form.value);
  data.k3PushStatus = form.value.k3PushStatus === 'all' ? '' : form.value.k3PushStatus;
  data.wmsSyncStatus = form.value.wmsSyncStatus === 'all' ? '' : form.value.wmsSyncStatus;
  data.auditStatus = form.value.auditStatus === 'all' ? '' : form.value.auditStatus;
  data.status = form.value.status === 'all' ? '' : form.value.status;
  data.dispatch = form.value.dispatch === 'all' ? '' : form.value.dispatch;
  emits("on-search", data, isReset);
};

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch(true);
}

onMounted(() => {
  handleSearch();
});
</script>