<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-23 13:52:51
 * @ Modified by: Sam
 * @ Modified time: 2023-03-10 11:01:55
 * @ Description: 操作日志
 -->

<template>
  <div class="prouct-goods-log">
    <oms-log ref="logRef"></oms-log>
  </div>
</template>

<script setup lang="ts" name="prouct-goods-log">
import OmsLog from '@/components/oms-log/index.vue';
import { ref } from 'vue';

const list = ref<{
  businessCode: string;
  businessType: string;
  logType: string;
  msg: string;
  operater: string;
  operationTime: string
}[]>([]);
const logRef = ref();

const init = async (logCode: any) => {
  logRef.value.init(logCode, "商品档案", "page");
}

defineExpose({
  init
});
</script>

<style lang="less" scoped>
.prouct-goods-log {
  padding-top: 20px;
}
</style>