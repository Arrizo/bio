<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-23 10:21:26
 * @ Modified by: Sam
 * @ Modified time: 2023-03-14 13:41:30
 * @ Description: 行详情
 -->

<template>
  <div class="product-goods-row-detail">
    <a-tabs :style="{ width: '100%' }" @tab-click="onTabClick" v-model:active-key="currentTab">
      <template #extra>
        <span class="iconfont icon-guanbianniu close-btn" @click="closeDetails"></span>
      </template>
      <a-tab-pane key="sku-info" title="规格信息">
        <sku-list :pid="pid" :loading="loading" :list="list" @reload="init(pid, rawData)" :raw-data="rawData"></sku-list>
      </a-tab-pane>
      <a-tab-pane key="log" title="日志" v-permission="['oms:product:goods:log']">
        <log ref="logRef"></log>
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script setup lang="ts" name="product-goods-row-detail">
import skuList from "./sku-list.vue";
import log from "./spu-log.vue";
import { getSpecs } from "@/api/product/goods";
import { Message } from "@arco-design/web-vue";
import { ref } from "vue";
import { SpecsListItem } from "@/types/product/goods";

const emits = defineEmits<{
  (e: "close"): void,
}>();

const loading = ref<boolean>(false);
const list = ref<SpecsListItem[]>([]);
const pid = ref<number>(NaN);
const rawData = ref();
const logRef = ref();
const currentTab = ref("sku-info");

const init = async (productId: number, data?: any) => {
  currentTab.value = "sku-info";
  pid.value = productId;
  rawData.value = data;
  try {
    loading.value = true;
    const res = await getSpecs(pid.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value

  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

const onTabClick = (key: string | number) => {
  if (key === 'sku-info') {
    return init(pid.value);
  }
  logRef.value.init(rawData.value.logCode);
}

const closeDetails = () => {
  emits("close")
}

defineExpose({
  init
});
</script>

<style lang="less" scope>
.product-goods-row-detail {
  background-color: #fff;
  padding-bottom: 16px;

  .close-btn {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  .arco-tabs-content {
    padding: 0 16px;
  }

  .arco-tabs-nav {
    padding-right: 16px;
  }
}
</style>