<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-07 11:00:34
 * @ Modified by: Sam
 * @ Modified time: 2023-03-09 13:50:22
 * @ Description: 商品档案导出
 -->

<template>
  <a-modal title="导出" width="500px" v-model:visible="modal.show" title-align="start" :on-before-ok="onOk" unmountOnClose
    :esc-to-close="false" :mask-closable="false">
    <p>确定导出商品档案？</p>
    <a-form ref="formRef" :model="form" layout="inline">
      <a-form-item field="fileName" label="导出文件名：" :rules="[{ required: true, message: '请输入文件名' }]">
        <a-input v-model="form.fileName" placeholder="请输入" v-limit-input allow-clear></a-input>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="export-modal">
import { Message } from '@arco-design/web-vue';
import { reactive, ref } from 'vue';
import { outputGoods } from "@/api/product/goods"
import { GoodsSearchForm } from '@/types/product/goods';
import { deepClone } from '@/utils/helper';

const modal = reactive({
  show: false
});

var d = new Date();
const searchForm = ref<GoodsSearchForm>(new GoodsSearchForm());
const form = ref({ fileName: '' });
const formRef = ref();

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const res = await outputGoods({ ...searchForm.value, ...form.value });
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(`导出任务已提交到下载中心，请到下载中心查看进度并下载导出文件。`);
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

const open = async (data: GoodsSearchForm, spuIds: number[]) => {
  modal.show = true;
  form.value.fileName = `商品档案导出${d.getFullYear()}${d.getMonth() + 1 > 10 ? d.getMonth() + 1 : `0${d.getMonth() + 1}`}${d.getDate() > 10 ? d.getDate() : `0${d.getDate()}`}`;
  searchForm.value = deepClone({ ...data, spuIds });
}

defineExpose({
  open
});
</script>
