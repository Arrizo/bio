<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 16:19:35
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-07 10:00:01
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\audit\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal :width="500" title="提示" v-model:visible="showOrLoading" title-align="start" :on-before-ok="onBeforeOk"
    :mask-closable="false" :ok-loading="loading">
    <section class="main">
      <div class="main-icon">
        <icon-exclamation-circle-fill class="icon-red" />
        <span> 确定把采购调价记录状态调整为{{auditForm.auditStatus?'上线':'下线'}}  ？ </span>
      </div>
      <div class="mian-content">调整后会影响采购业务，请谨慎操作。</div>
    </section>
    <a-form :model="auditForm" auto-label-width ref="searchRef">
      <a-form-item label="备注：" field="remark">
        <a-textarea v-model.trim="auditForm.remark" show-word-limit placeholder="请输入 （限200个字）"
          :max-length="200"></a-textarea>
      </a-form-item>
    </a-form>
  </a-modal>
</template>
<script lang="ts" setup name="purchase-import">
import auditMethod from '../audit/audit-method'
const emits = defineEmits<{
	(e: "reload", data?: any): void
}>()
const {
  showOrLoading,
  showModal,
  onBeforeOk,
  searchRef,
  auditForm,
  loading,
} = auditMethod(emits)
defineExpose({
  showModal
})
</script>
<style lang="less" scoped>
.main {
  font-size: 13px;
  color: #3A3A3A;

  .main-icon {
    display: flex;
    align-items: center;

    .icon-red {
      font-size: 25px;
      color: #FF3E3E;
      margin-right: 10px;
    }
  }
  .mian-content{
    font-size: 12px;
    color: #999999;
    margin: 3px 0px 20px 35px;
  }
}
</style>