<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-23 14:17:29
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-13 17:07:18
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\search\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-form :model="form" layout="inline" ref="searchRef" >
    <a-form-item field="code" label="编码：">
      <a-input v-model.trim="form.code" placeholder="spu/sku编码" allow-clear :max-length="20" :style="{ width: '200px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="name" label="名称：">
      <a-input v-model.trim="form.name" placeholder="spu/sku名称" allow-clear :max-length="20" :style="{ width: '200px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="supplier" label="供应商：">
      <a-input v-model.trim="form.supplier" placeholder="供应商编码/名称" allow-clear :max-length="20" :style="{ width: '200px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="organization" label="组织：">
      <a-input v-model.trim="form.organization" placeholder="采购组织名称" allow-clear :max-length="20" :style="{ width: '200px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="auditStatus" label="审核状态：">
      <a-select placeholder="请选择" v-model="form.auditStatus" :style="{ width: '200px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="WAIT_AUDIT">待审核</a-option>
        <a-option value="AUDIT_PASS">通过</a-option>
        <a-option value="NO_PASS">不通过</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="form.status" :style="{ width: '200px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="time" label="更新时间：" class="time">
      <a-range-picker showTime v-model="form.time" @change="onChange" />
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>
<script lang="ts" setup name="purchese-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import searchMethods from './search-method/index'
import { PurchaseSeachType } from '@/types/product/purchase'
const props = defineProps<{ loading: boolean }>();
const emits = defineEmits<{
  (e: "on-search", data: PurchaseSeachType): void;
}>();
let {
  form,
  handleSearch,
  handleReset,
  searchRef,
  onChange
} = searchMethods(emits)
</script>
<style lang="less" scoped>
.time{
  :deep(.arco-form-item-wrapper-col){
    width: 400px;
  }
}
</style>