/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-23 15:21:29
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-02 19:57:16
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\search\search-method\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import initData from "../../../commo-method/initData";
import { deepClone } from '@/utils/helper';
import { onMounted } from 'vue'
export default function (emits: Function) {
  let { form, searchRef, formReset } = initData()
  const handleSearch = () => {
    const newForm = deepClone(form)
    if (newForm.status === 'all') { newForm.status = '' }
    if (newForm.auditStatus === 'all') { newForm.auditStatus = '' }
    emits('on-search', newForm)
  }
  const handleReset = () => {
    formReset()
    form.startTime=''
    form.endTime=''
    handleSearch();
  }
  const onChange=(value:any)=>{
    form.startTime=value?.[0]??''
    form.endTime=value?.[1]??''
  }
  onMounted(()=>{
    handleSearch()
  })
  return {
    form,
    handleSearch,
    searchRef,
    handleReset,
    onChange
  }
}