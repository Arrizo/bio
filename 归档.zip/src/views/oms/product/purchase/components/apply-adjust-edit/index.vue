<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 17:36:32
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-13 17:09:08
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\apply-adjust\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal v-model:visible="showOrLoading" :width="1300" title-align="start" :on-before-ok="onBeforeEditOk"
    :mask-closable="false" title="采购调价申请" ok-text="提交" :ok-loading="loading">
    <a-form :model="applyForm" ref="searchRef" auto-label-width :rules="formRules">
      <a-row :gutter="20">
        <a-col :span="6">
          <a-form-item field="skuCode" label="规格编码：">
            <a-input v-model="applyForm.skuCode" placeholder="请输入规格编码" allow-clear disabled :style="{ width: '240px' }"
              v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="skuName" label="规格名称：">
            <a-input v-model="applyForm.skuName" placeholder="请输入规格名称" allow-clear disabled :style="{ width: '240px' }"
              v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="skuType" label="规格型号：">
            <a-input v-model="applyForm.skuType" placeholder="请输入规格型号" allow-clear disabled :style="{ width: '240px' }"
              v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="spuCode" label="商品编码：">
            <a-input v-model="applyForm.spuCode" placeholder="请输入商品编码" allow-clear disabled :style="{ width: '240px' }"
              v-limit-input></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="20">
        <a-col :span="6">
          <a-form-item field="supplierName" label="供应商：">
            <a-input v-model="applyForm.supplierName" placeholder="请输入供应商" allow-clear disabled
              :style="{ width: '240px' }" v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="organization" label="采购组织：">
            <a-input v-model="applyForm.organization" placeholder="请输入采购组织" allow-clear disabled
              :style="{ width: '240px' }" v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="remark" label="备注：">
            <a-input v-model="applyForm.priceRemark" placeholder="请输入备注" allow-clear disabled :style="{ width: '584px' }"
              v-limit-input></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="20">
        <a-col :span="6">
          <a-form-item field="storeCode" label="店铺：">
            <a-select v-model="applyForm.storeCode" allow-search allow-clear placeholder="请选择"
              :style="{ width: '240px' }">
              <a-option :label="item.storeName" :value="item.storeCode" v-for="(item, index) in shopList"
                :key="`${index}-storeCode`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="cause" label="调价原因：">
            <a-select v-model="applyForm.cause" allow-search allow-clear placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item, index) in causeList"
                :key="`${index}-cause`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="startTime" label="生效日期：">
            <a-date-picker showTime v-model="applyForm.startTime" :style="{ width: '240px' }"/>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="endTime" label="失效日期：">
            <a-date-picker showTime v-model="applyForm.endTime" :style="{ width: '240px' }"/>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="20">
        <a-col :span="6">
          <a-form-item field="type" label="调价类型：">
            <a-select v-model="applyForm.type" allow-clear allow-search placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue"
                v-for="(item, index) in adjustPriceType" :key="`${index}-type`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="maxNum" label="阶梯数量：">
            <a-input v-model.number="applyForm.minNum"  allow-clear placeholder="请输入" @input="formatInput($event,'minNum',0)"></a-input>
            ~
            <a-input v-model.number="applyForm.maxNum" allow-clear placeholder="请输入" @input="formatInput($event,'maxNum',0)"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="price" label="采购价：">
            <a-input v-model.trim="applyForm.price" allow-clear placeholder="请输入" @input="formatInput($event,'price')"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="unit" label="单位：">
            <a-select v-model="applyForm.unit" allow-clear allow-search placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item, index) in unitList"
                :key="`${index}-unit`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="20">
        <a-col :span="6">
          <a-form-item field="minPrice" label="价格下限：">
            <a-input v-model.trim="applyForm.minPrice" allow-clear placeholder="请输入" @input="formatInput($event,'minPrice')"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="maxPrice" label="价格上限：">
            <a-input v-model.trim="applyForm.maxPrice" allow-clear placeholder="请输入" @input="formatInput($event,'maxPrice')"> </a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="discount" label="折扣：">
            <a-select v-model="applyForm.discount" allow-search allow-clear placeholder="请输入">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue"
                v-for="(item, index) in discoutTypeList" :key="`${index}-cause`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="tag" label="标识：">
            <a-input v-model.trim="applyForm.tag" allow-clear placeholder="请输入"></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="20">
        <a-col :span="24">
          <a-form-item field="remark" label="采购备注：">
            <a-textarea :maxLength="200" v-limit-input show-word-limit v-model.trim="applyForm.remark" placeholder="请输入"
             />
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>
<script lang="ts" setup name="purchase-goods">

import applyAdjustMethod from '../apply-adjust/apply-adjust-method'
const emits = defineEmits<{
  (e: "reload", data: any): void;
}>();
const {
  formatInput,
  showOrLoading,
  loading,
  searchRef,
  showModal,
  applyForm,
  shopList,
  causeList,
  unitList,
  adjustPriceType,
  onBeforeEditOk,
  formRules,
  discoutTypeList
} = applyAdjustMethod(emits)
defineExpose({
  showModal
})
</script>