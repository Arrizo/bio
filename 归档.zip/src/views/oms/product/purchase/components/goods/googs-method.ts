/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-27 18:22:47
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-29 10:00:13
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\goods\googs-method.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import initData from "../../commo-method/initData"
import { reactive, ref, watch } from 'vue'
import { queryProductAndSpecList } from '@/api/product/purchase'
import { Message, TableData } from "@arco-design/web-vue"
import { goodsTableDataType } from '@/types/product/purchase'
import commoMethod from '../../commo-method/index'
export default function (emits: Function, props: any) {
  let { initTableData, loading, formReset, searchRef } = initData()
  const { showModal, rowSelection, showOrLoading } = commoMethod()
  class goodsFormClass {
    code: string = ''
    name: string = ''
    pageNum: number = 1
    pageSize: number = 10
  }
  const total = ref(0)
  // 表格数据
  const goodsTableData = initTableData<goodsTableDataType>()
  // 选中的数据
  const selectGoodsTableData = ref<goodsTableDataType | {}>()
  // 表格选中的key值
  const selectedkeys = ref()
  let goodsForm = reactive<goodsFormClass>(new goodsFormClass())
  let searchForm = reactive<goodsFormClass>(new goodsFormClass())
  const handleSearch = async (data?: any) => {
    try {
      loading.value = true
      const { code, message, value } = await queryProductAndSpecList(searchForm)
      if (code != 0) {
        throw new Error(message)
      }
      goodsTableData.value = value.result
      goodsForm.pageNum = value.pageNum
      goodsForm.pageSize = value.pageSize
      total.value = value.totalCount
      selectionChange(selectedkeys.value)
    } catch (error) {
      Message.error((error as Error).message)
    } finally {
      loading.value = false
    }
  }
  const realodGoods = (data: any) => {
    searchForm = Object.assign(searchForm, data)
    handleSearch()
  }
  const handleReset = (data?: any) => {
    goodsForm.pageNum = 1
    goodsForm.pageSize = 10
    !data && formReset()
    searchForm = Object.assign(searchForm, goodsForm)
    handleSearch()
  }
  const onBeforeOk = () => {
    if (!selectGoodsTableData.value) {
      Message.error('请选择商品')
      return false
    }
    emits('on-select', selectGoodsTableData.value)
    return true
  }
  watch(() => showOrLoading.value, (nV) => {
    if (nV) {
      selectedkeys.value = props.specsCode ? [props.specsCode] : []
      // handleSearch()
    } else {
      formReset()
      goodsTableData.value = []
      selectGoodsTableData.value = ''
      goodsForm.pageNum = 1
      goodsForm.pageSize = 10
      total.value = 0
    }
  })
  const selectionChange = (rowKeys: Array<string | number>) => {
    selectGoodsTableData.value = goodsTableData.value.find(i => i.specsCode == rowKeys[0]) ?? ''
  }
  const rowClick = (row: TableData) => {
    selectedkeys.value = [row.specsCode]
    selectGoodsTableData.value = goodsTableData.value.find(i => i.specsCode == row.specsCode) ?? ''
  }
  return {
    realodGoods,
    total,
    rowClick,
    loading,
    formReset,
    handleSearch,
    handleReset,
    goodsForm,
    goodsTableData,
    searchRef,
    onBeforeOk,
    selectionChange,
    showOrLoading,
    showModal,
    rowSelection,
    selectedkeys
  }
}