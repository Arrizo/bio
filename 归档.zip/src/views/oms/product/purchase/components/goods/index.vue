<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 15:02:33
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-29 09:56:26
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\goods\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal v-model:visible="showOrLoading" :width="800" title-align="start" :on-before-ok="onBeforeOk"
    :mask-closable="false" title="选择商品" class="goods-modal">
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form :model="goodsForm" layout="inline" ref="searchRef">
      <a-form-item field="code" label="编码：">
        <a-input v-model.trim="goodsForm.code" placeholder="spu/sku编码" allow-clear :max-length="20"
          :style="{ width: '200px' }" @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="name" label="名称：">
        <a-input v-model.trim="goodsForm.name" placeholder="spu/sku名称" allow-clear :max-length="20"
          :style="{ width: '200px' }" @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleReset('search')" @clear="handleReset"></oms-search-btn>
    </a-form>
    <!-- </template> -->
    <oms-table :loading="loading" :total="total" :current="goodsForm.pageNum" :size="goodsForm.pageSize"
      @reload="realodGoods" :simple-pagination="true">
      <a-table v-model:selected-keys="selectedkeys" :data="goodsTableData" :pagination="false"
        @selection-change="selectionChange" hide-expand-button-on-empty class="gift-table" :scroll="{ y: 400 }" stripe
        row-key="specsCode" :bordered="{ wrapper: false }" :row-selection="rowSelection" @row-click="rowClick">
        <template #columns>
          <a-table-column title="商品编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.specsCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.specsTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格型号" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.specsModel || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
    <!-- </oms-panel> -->
  </a-modal>
</template>
<script lang="ts" setup name="purchase-goods">
import OmsTable from '@/components/oms-table/index.vue';
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import gooodsMethod from './googs-method'
import { goodsTableDataType } from '@/types/product/purchase'
interface PropsType {
  specsCode: string
}
const props = defineProps<PropsType>();
const emits = defineEmits<{
  (e: "on-select", data: goodsTableDataType): void;
}>();
const {
  realodGoods,
  total,
  rowClick,
  selectedkeys,
  goodsForm,
  loading,
  goodsTableData,
  handleSearch,
  searchRef,
  handleReset,
  onBeforeOk,
  selectionChange,
  showModal,
  showOrLoading,
  rowSelection
} = gooodsMethod(emits, props)

defineExpose({
  showModal
})
</script>
<style lang="less">
.goods-modal {
  .arco-modal-body {
    height: 588px;
  }

  .gift-table {
    .arco-table-tr-empty .arco-table-td {
      height: 370px;
    }
  }
}
</style>
