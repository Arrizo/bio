/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-01 11:09:22
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-17 17:05:10
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\apply-adjust\apply-adjust-method.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import initData from "../../commo-method/initData"
import { PurchaseListType, AdjustPriceRecordAddBO } from '@/types/product/purchase'
import { queryAdjustPriceDetail, queryAdjustRecordPriceDetail, adjustPriceRecordAdd, adjustPriceRecordEdit } from '@/api/product/purchase'
import addPurchaseMethod from '../addPurchase/add-purchase-method/index'
import { ref, reactive, watch } from 'vue'
import { Message, TableRowSelection } from "@arco-design/web-vue"
import commoMethod from '../../commo-method'
export default function (emits: Function) {
  const { getCompanyTypeList, formaNumber } = commoMethod()
  const { showOrLoading, loading, searchRef, formReset } = initData()
  const { shopList, queryShopList, causeList, unitList, taxRateList } = addPurchaseMethod(emits)
  const applyForm = ref<PurchaseListType>(new PurchaseListType())
  const applyTableData = ref<Array<AdjustPriceRecordAddBO>>([])
  const adjustPriceType = ref()
  const selectedKeys = ref<Array<number>>([])
  const auditRef = ref()
  const discoutTypeList = ref()
  const showModal = async (id: number, type?: string) => {
    applyForm.value.id = id
    applyForm.value.relationId = id
    showOrLoading.value = true
    getApplyDetails(id, type)
  }
  // 查询详情
  const getApplyDetails = async (id: any, type?: string) => {
    let res = null
    // 采购编辑详情
    if (type) {
      res = await queryAdjustPriceDetail(id)
    } else {
      // 采购记录编辑详情
      res = await queryAdjustRecordPriceDetail(id)
    }
    const { code, message, value } = res
    if (code != 0) { return Message.error(message) }
    Object.assign(applyForm.value, value)
    return value
  }
  // 处理删除跟添加
  const handler = (type: string) => {
    if (type == 'add') {
      if (applyTableData.value.length >= 50) {
        return Message.error('调价申请最多50行')
      }
      const AdjustPriceObject = new AdjustPriceRecordAddBO()
      AdjustPriceObject.rowKey = Date.now()
      applyTableData.value.push(AdjustPriceObject)
    } else {
      applyTableData.value = applyTableData.value.filter(i => !selectedKeys.value.includes(i?.rowKey))
    }
  }
  // 校验规则字段
  const formRules = reactive({
    skuCode: [{ required: true, message: '请输入规格编码' }],
    supplierName: [{ required: true, message: '请输入供应商' }],
    startTime: [{ required: true, message: '请选择时间' }],
    endTime: [{ required: true, message: '请选择时间' }],
    unit: [{ required: true, message: '请选择单位' }],
    price: [{ required: true, message: '请输入采购价' }],
  })
  const rowSelection = reactive<TableRowSelection>({
    type: 'checkbox',
    showCheckedAll: true,
    fixed: true
  })
  // 采购调价申请编辑
  const onBeforeEditOk = async () => {
    const valid = await searchRef.value.validate()
    if (valid) { return false }
    //要不全都填,要不都不填
    if (applyForm.value.minNum || applyForm.value.maxNum) {
      if (!applyForm.value.minNum) {
        Message.error(`请填写最小值`)
        return false
      }
      if (!applyForm.value.maxNum) {
        Message.error(`请填写最大值`)
        return false
      }
      if (Number(applyForm.value.minNum) >= Number(applyForm.value.maxNum)) {
        Message.error(`最大值大于最小值`)
        return false
      }
    }
    //要不全都填,要不都不填
    if (applyForm.value.maxPrice || applyForm.value.minPrice) {
      if (!applyForm.value.maxPrice) {
        Message.error(`请填写价格上限`)
        return false
      }
      if (!applyForm.value.minPrice) {
        Message.error(`请填写价格下限`)
        return false
      }
      if (Number(applyForm.value.minPrice) >= Number(applyForm.value.maxPrice)) {
        Message.error(`价格上限大于价格下限`)
        return false
      }
    }
    if (new Date(applyForm.value.startTime).getTime() > new Date(applyForm.value.endTime).getTime()) {
      Message.error('生效时间不能晚于失效时间')
      return false
    }
    try {
      loading.value = true
      const { code, message } = await adjustPriceRecordEdit(applyForm.value)
      if (code != 0) {
        throw new Error(message)
      }
      Message.success('操作成功！')
      showOrLoading.value = false
      emits('reload')
    } catch (error) {
      Message.error((error as Error).message)
      return false
    } finally {
      loading.value = false
    }
  }
  const onBeforeOk = async () => {
    const valid = await searchRef.value.validate()
    if (valid) { return false }
    if(!applyTableData.value.length){
      Message.error('请添加申请调价记录')
      return false
    }
    for (let i = 0; i < applyTableData.value.length; i++) {
      let rowData = applyTableData.value[i]
      if (!rowData.price) {
        Message.error(`请输入第${i + 1}行含税采购价`)
        return false
      }
      //要不全都填,要不都不填
      if (rowData.minNum || rowData.maxNum) {
        if (!rowData.minNum) {
          Message.error(`请填写第${i + 1}行最小值`)
          return false
        }
        if (!rowData.maxNum) {
          Message.error(`请填写第${i + 1}行最大值`)
          return false
        }
        if (Number(rowData.minNum) >= Number(rowData.maxNum)) {
          Message.error(`第${i + 1}行最大值大于最小值`)
          return false
        }
      }
      //要不全都填,要不都不填
      if (rowData.maxPrice || rowData.minPrice) {
        if (!rowData.maxPrice) {
          Message.error(`请填写第${i + 1}行价格上限`)
          return false
        }
        if (!rowData.minPrice) {
          Message.error(`请填写第${i + 1}行价格下限`)
          return false
        }
        if (Number(rowData.minPrice) >= Number(rowData.maxPrice)) {
          Message.error(`第${i + 1}行价格上限大于价格下限`)
          return false
        }
      }
      if (!rowData.taxRate) {
        Message.error(`请选择第${i + 1}行税率`)
        return false
      }
      if (!rowData.unit) {
        Message.error(`请选择第${i + 1}行单位`)
        return false
      }
      if (rowData.discount) {
        if (Number(rowData.discount) >= 100 || Number(rowData.discount) <= 0) {
          Message.error('折扣范围0~100之间')
          return false
        }
      }
      // 超过一行做阶梯数量校验
      // let nextRowData = applyTableData.value[i + 1]
      // if (nextRowData) {
      //   if (Number(nextRowData.minNum) <= Number(rowData.maxNum)) {
      //     Message.error(`第${i + 1}行跟第${i + 2}行阶梯存在重叠`)
      //     return false
      //   }
      // }
      applyTableData.value[i].storeCode = applyForm.value.storeCode
      applyTableData.value[i].cause = applyForm.value.cause
      applyTableData.value[i].startTime = applyForm.value.startTime
      applyTableData.value[i].endTime = applyForm.value.endTime
      applyTableData.value[i].id = applyForm.value.id
      applyTableData.value[i].relationId = applyForm.value.relationId
    }
    try {
      loading.value = true
      const { code, message } = await adjustPriceRecordAdd(applyTableData.value)
      if (code != 0) {
        throw new Error(message)
      }
      Message.success('操作成功！')
      showOrLoading.value = false
      emits('reload')
      return true
    } catch (error) {
      Message.error((error as Error).message)
      return false
    } finally {
      loading.value = false
    }
  }
  // 表格输入限制问题
  const formatTableInput = ($event: any, type: string, record: AdjustPriceRecordAddBO, num?: number) => {
    record[type] = formaNumber($event, num)
  }
  const formatInput = ($event: any, type: string, num?: number) => {
    applyForm.value[type] = formaNumber($event, num)
  }
  watch(() => showOrLoading.value, async (nV) => {
    if (nV) {
      handler('add')
      queryShopList()
      causeList.value = await getCompanyTypeList('CAUSE')
      unitList.value = await getCompanyTypeList('UNIT')
      adjustPriceType.value = await getCompanyTypeList('ADJUST_PRICE_TYPE')
      taxRateList.value = await getCompanyTypeList('TAX_RATE')
      discoutTypeList.value = await getCompanyTypeList('DISCOUNT')
    } else {
      formReset()
      applyTableData.value = []
    }
  })
  return {
    onBeforeEditOk,
    taxRateList,
    formatInput,
    formRules,
    rowSelection,
    shopList,
    showOrLoading,
    loading,
    searchRef,
    formReset,
    showModal,
    applyForm,
    causeList,
    unitList,
    applyTableData,
    handler,
    selectedKeys,
    adjustPriceType,
    onBeforeOk,
    getApplyDetails,
    auditRef,
    formatTableInput,
    discoutTypeList
  }
}