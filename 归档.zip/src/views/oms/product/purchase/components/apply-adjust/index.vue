<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 17:36:32
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-29 10:41:01
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\apply-adjust\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal v-model:visible="showOrLoading" :width="1200" title-align="start" :on-before-ok="onBeforeOk"
    :mask-closable="false" title="申请调价" ok-text="提交" :ok-loading="loading" class="goods-modal">
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form :model="applyForm" ref="searchRef" auto-label-width :rules="formRules">
      <a-row :gutter="20">
        <a-col :span="6">
          <a-form-item field="skuCode" label="规格编码：">
            <a-input v-model="applyForm.skuCode"  allow-clear disabled
              :style="{ width: '220px' }" v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="skuName" label="规格名称：">
            <a-input v-model="applyForm.skuName" allow-clear disabled
              :style="{ width: '220px' }" v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="skuType" label="规格型号：">
            <a-input v-model="applyForm.skuType" allow-clear disabled
              :style="{ width: '220px' }" v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="spuCode" label="商品编码：">
            <a-input v-model="applyForm.spuCode" allow-clear disabled
              :style="{ width: '220px' }"  v-limit-input></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="20">
        <a-col :span="6">
          <a-form-item field="supplierName" label="供应商：">
            <a-input v-model="applyForm.supplierName" allow-clear disabled
              :style="{ width: '220px' }"  v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="organization" label="采购组织：">
            <a-input v-model="applyForm.organization" allow-clear disabled
              :style="{ width: '220px' }"  v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="remark" label="备注：">
            <a-input v-model="applyForm.remark" allow-clear disabled
              :style="{ width: '584px' }"  v-limit-input></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="20">
        <a-col :span="6">
          <a-form-item field="storeCode" label="店铺：">
            <a-select v-model="applyForm.storeCode" allow-search allow-clear placeholder="请选择" :style="{ width: '220px' }">
              <a-option :label="item.storeName" :value="item.storeCode" v-for="(item,index) in shopList" :key="`${index}-storeCode`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="cause" label="调价原因：">
            <a-select v-model="applyForm.cause" allow-search allow-clear placeholder="请选择" :style="{ width: '220px' }">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item,index) in causeList" :key="`${index}-cause`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="startTime" label="生效日期：">
            <a-date-picker showTime v-model="applyForm.startTime" style="width: 220px;"/>
          </a-form-item>
        </a-col>
        <a-col :span="6">
          <a-form-item field="endTime" label="失效日期：">
              <a-date-picker showTime v-model="applyForm.endTime" style="width: 220px;"/>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
    <a-space :size="20" style="margin-bottom: 10px;">
      <a-button @click="handler('add')" type="primary">添加行</a-button>
      <a-button @click="handler('del')" :disabled="!selectedKeys.length"  type="outline">删除行</a-button>
    </a-space>
    <a-table :data="applyTableData" :pagination="false" hide-expand-button-on-empty :scroll="{ x: 100,y:400 }" stripe
    class="gift-table"
      :bordered="{ wrapper: false }" :row-selection="rowSelection" row-key="rowKey" v-model:selected-keys="selectedKeys">
      <template #columns>
        <a-table-column title="调价类型"  :width="150" ellipsis>
          <template #cell="{ record }">
            <a-select v-model="record.type" allow-clear allow-search placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item,index) in adjustPriceType" :key="`${index}-type`"></a-option>
            </a-select>
          </template>
        </a-table-column>
        <a-table-column title="从"  :width="150" ellipsis>
          <template #cell="{ record }">
            <a-input v-model.trim="record.minNum" allow-clear placeholder="请输入" @input="formatTableInput($event,'minNum',record,0)"></a-input>
          </template>
        </a-table-column>
        <a-table-column title="到"  :width="150" ellipsis>
          <template #cell="{ record }">
            <a-input v-model.trim="record.maxNum" allow-clear placeholder="请输入" @input="formatTableInput($event,'maxNum',record,0)"></a-input>
          </template>
        </a-table-column>
        <a-table-column title="单位"  :width="150" ellipsis>
          <template #title>
            <span style="color:#f53f3f">*</span> 单位
          </template>
          <template #cell="{ record }">
            <a-select v-model.trim="record.unit" allow-search placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item,index) in unitList" :key="`${index}-unit`"></a-option>
            </a-select>
          </template>
        </a-table-column>
        <a-table-column  :width="150" ellipsis>
          <template #title>
            <span style="color:#f53f3f">*</span> 含税采购价(元)
          </template>
          <template #cell="{ record }">
            <a-input v-model.trim="record.price" allow-clear placeholder="请输入含税采购价" @input="formatTableInput($event,'price',record)"></a-input>
          </template>
        </a-table-column>
        <a-table-column title=""  :width="150" ellipsis>
          <template #title>
            <span style="color:#f53f3f">*</span> 税率%
          </template>
          <template #cell="{ record }">
            <a-select v-model.trim="record.taxRate" allow-search placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item,index) in taxRateList" :key="`${index}-cause`"></a-option>
            </a-select>
          </template>
        </a-table-column>
        <a-table-column title="价格上限"  :width="150" ellipsis>
          <template #cell="{ record }">
            <a-input v-model.trim="record.maxPrice" allow-clear placeholder="请输入价格上限" @input="formatTableInput($event,'maxPrice',record)"></a-input>
          </template>
        </a-table-column>
        <a-table-column title="价格下限"  :width="150" ellipsis>
          <template #cell="{ record }">
            <a-input v-model.trim="record.minPrice" allow-clear placeholder="请输入价格下限" @input="formatTableInput($event,'minPrice',record)"></a-input>
          </template>
        </a-table-column>
        <a-table-column title="折扣%"  :width="150" ellipsis>
          <template #cell="{ record }">
            <a-input v-model.trim="record.discount" allow-clear placeholder="请输入折扣" @input="formatTableInput($event,'discount',record)"></a-input>
          </template>
        </a-table-column>
        <a-table-column title="标识"  :width="150" ellipsis>
          <template #cell="{ record }">
            <a-input v-model.trim="record.tag" allow-clear placeholder="请输入标识" ></a-input>
          </template>
        </a-table-column>
        <a-table-column title="备注说明"  :width="200" ellipsis>
          <template #cell="{ record }">
            <a-input v-model.trim="record.remark" allow-clear placeholder="请输入备注" ></a-input>
          </template>
        </a-table-column>
      </template>
    </a-table>
    <!-- </a-spin> -->
    <!-- </oms-panel> -->
  </a-modal>
  <audit ref="auditRef"></audit>
</template>
<script lang="ts" setup name="purchase-goods">
import Audit from '../audit/index.vue'
import applyAdjustMethod from './apply-adjust-method'
const emits = defineEmits<{
  (e: "on-search", data: any): void;
}>();
const {
  formatTableInput,
  showOrLoading,
  loading,
  searchRef,
  showModal,
  applyForm,
  shopList,
  causeList,
  handler,
  applyTableData,
  rowSelection,
  unitList,
  adjustPriceType,
  onBeforeOk,
  selectedKeys,
  formRules,
  auditRef,
  taxRateList
} = applyAdjustMethod(emits)
defineExpose({
  showModal
})
</script>
<style lang="less">
.goods-modal {
  .arco-modal-body {
    height: 688px;
  }

  .gift-table {
    .arco-table-tr-empty .arco-table-td {
      height: 370px;
    }
  }
}
</style>