import initData from '../../commo-method/initData';
import { ref, reactive } from 'vue'
import { AdjustPriceRecordAddBO, AdjustRecordSearch } from '@/types/product/purchase'
import { queryRecordList } from '@/api/product/purchase'
import { Message } from "@arco-design/web-vue";
import { deepClone } from '@/utils/helper';
import commoMethod from '../../commo-method/index'
export default function () {
  const { formaNumber } = commoMethod()
  const { loading, searchRef, formReset } = initData()
  const serchRecordForm = reactive<AdjustRecordSearch>(new AdjustRecordSearch())
  const recordTableData = ref<Array<AdjustPriceRecordAddBO>>([])
  const logRef = ref()
  const auditRecordRef = ref()
  const editStatusRef = ref()
  const applyAdjustEditRef = ref()
  const initDataInfo = async (id: string) => {
    serchRecordForm.relationId = id
    handleReset()
  }
  const auditStatusList = reactive<Array<{ value: number | string, title: string }>>(
    [
      {
        value: 'all',
        title: '全部'
      },
      {
        value: 1,
        title: '待审核'
      },
      {
        value: 2,
        title: '审核不通过'
      },
      {
        value: 3,
        title: '待确认'
      },
      {
        value: 4,
        title: '确认不通过'
      },
      {
        value: 5,
        title: '上线'
      },
      {
        value: 6,
        title: '下线'
      },
    ]
  )
  const handleReset = () => {
    serchRecordForm.minPrice = ''
    serchRecordForm.endTime = ''
    serchRecordForm.startTime=''
    serchRecordForm.endTime=''
    formReset()
    handleSearch()
  }
  const handleSearch = async () => {
    let form = deepClone(serchRecordForm)
    if (serchRecordForm.auditStatus == 'all') {
      form.auditStatus = ''
    }
    try {
      loading.value = true
      const { code, value, message } = await queryRecordList(form)
      if (code != 0) {
        throw new Error(message)
      }
      recordTableData.value = value.result
    } catch (error) {
      Message.error((error as Error).message)
    } finally {
      loading.value = false
    }
  }
  const inputFormat = ($event: any, type: string,) => {
    serchRecordForm[type] = formaNumber($event)
  }
  // 事件统一处理
  const handlerEvent = (type: string = '', record?: AdjustPriceRecordAddBO) => {
    switch (type) {
      case 'edit': return applyAdjustEditRef.value.showModal(record?.id);
      case 'log': return logRef.value.init(record?.code, '采购调价记录','modal','调价日志');
      case 'audit':
        return auditRecordRef.value.showModal({
          titleName: '审核采购调价申请',
          lableName: '审核结果',
          auditNode: '申请调价',
          lstId: [record?.id],
          adjustType: true
        })
      case 'confirm':
        return auditRecordRef.value.showModal({
          titleName: '确认采购调价申请',
          lableName: '确认结果',
          auditNode: '申请调价',
          lstId: [record?.id],
          adjustType: true
        })
      case 'goDown':
        return editStatusRef.value.showModal({
          auditNode: '调价记录',
          id: record?.id,
          auditStatus: false,
          modalType: true
        })
      case 'online':
        return editStatusRef.value.showModal({
          auditNode: '调价记录',
          id: record?.id,
          auditStatus: true,
          modalType: true
        })
      default:
        break;
    }
  }
  const onChange=(value:any)=>{
    serchRecordForm.startTime=value?.[0]??''
    serchRecordForm.endTime=value?.[1]??''
  }
  return {
    onChange,
    inputFormat,
    editStatusRef,
    auditRecordRef,
    logRef,
    handlerEvent,
    handleReset,
    initDataInfo,
    loading,
    searchRef,
    formReset,
    serchRecordForm,
    recordTableData,
    auditStatusList,
    handleSearch,
    applyAdjustEditRef
  }
}