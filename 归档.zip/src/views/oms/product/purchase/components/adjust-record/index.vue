<template>
  <!-- <oms-panel>
    <template #header> -->
  <a-form :model="serchRecordForm" ref="searchRef" auto-label-width layout="inline">
    <a-form-item field="time" label="日期：">
      <a-range-picker showTime v-model="serchRecordForm.time" @change="onChange" />
    </a-form-item>
    <a-form-item field="maxPrice" label="采购价：">
      <a-input v-model.trim="serchRecordForm.minPrice" placeholder="最小值" allow-clear :style="{ width: '120px' }"
        @keyup.enter="handleSearch" v-limit-input @input="inputFormat($event, 'minPrice')"></a-input>
      <span class="separator">-</span>
      <a-input v-model.trim="serchRecordForm.maxPrice" placeholder="最大值" allow-clear :style="{ width: '120px' }"
        @keyup.enter="handleSearch" v-limit-input @input="inputFormat($event, 'maxPrice')"></a-input>
    </a-form-item>
    <a-form-item field="auditStatus" label="状态：">
      <a-select v-model="serchRecordForm.auditStatus" placeholder="请选择" :style="{ width: '200px' }">
        <a-option v-for="(item, index) in auditStatusList" :key="`${index}-status`" :value="item.value">{{
          item.title }}</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
  <!-- </template> -->
  <a-table :data="recordTableData" :pagination="false" hide-expand-button-on-empty :scroll="{ x: 300, y: 550 }" stripe
    :bordered="{ wrapper: false }">
    <template #columns>
      <a-table-column title="序号" :tooltip="true" :width="60" ellipsis fixed="left">
        <template #cell="{ record, rowIndex }">
          {{ rowIndex + 1 }}
        </template>
      </a-table-column>
      <a-table-column title="调价类型" :tooltip="true" :width="100" ellipsis>
        <template #cell="{ record, }">
          {{ record.typeName || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="生效日期" :tooltip="true" :width="180" ellipsis>
        <template #cell="{ record }">
          {{ record.startTime || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="失效日期" :tooltip="true" :width="180" ellipsis>
        <template #cell="{ record }">
          {{ record.endTime || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="从" :tooltip="true" :width="100" ellipsis>
        <template #cell="{ record }">
          {{ record.minNum || '0' }}
        </template>
      </a-table-column>
      <a-table-column title="到" :tooltip="true" :width="100" ellipsis>
        <template #cell="{ record }">
          {{ record.maxNum || '0' }}
        </template>
      </a-table-column>
      <a-table-column title="采购价(元)" align="right" cell-class="paddingR40" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.price || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="税率%" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.taxRateName || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="折扣%" :tooltip="true" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.discount || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="价格下限(元)" :tooltip="true" align="right" cell-class="paddingR40" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.minPrice || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="价格上限(元)" :tooltip="true" align="right" cell-class="paddingR40" :width="150" ellipsis>
        <template #cell="{ record }">
          {{ record.maxPrice || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="店铺" :tooltip="true" :width="200" ellipsis>
        <template #cell="{ record }">
          {{ record.storeName || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="调价原因" :tooltip="true" :width="200" ellipsis>
        <template #cell="{ record }">
          {{ record.causeName || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="备注说明" :tooltip="true" :width="200" ellipsis>
        <template #cell="{ record }">
          {{ record.remark || '--' }}
        </template>
      </a-table-column>
      <a-table-column title="状态" :tooltip="true" :width="200" ellipsis>
        <template #cell="{ record }">
          <oms-tag :type="audittTagType[record.auditStatus]" :content="directions[record.auditStatus]"></oms-tag>
        </template>
      </a-table-column>
      <a-table-column title="操作" :width="100" fixed="right">
        <template #cell="{ record }">
          <a-space :size="14">
            <a-link type="text" @click="handlerEvent('goDown', record)" v-if="record.auditStatus == 5"
              v-permission="['oms:product:purchase:goDown']">下线</a-link>
            <a-link type="text" @click="handlerEvent('online', record)" v-if="record.auditStatus == 6"
              v-permission="['oms:product:purchase:online']">上线</a-link>
            <a-link type="text" @click="handlerEvent('edit', record)" v-if="[2, 4].includes(record.auditStatus)"
              v-permission="['oms:product:purchase:edit']">编辑</a-link>
            <a-link type="text" @click="handlerEvent('confirm', record)" v-if="record.auditStatus == 3"
              v-permission="['oms:product:purchase:confirm']">确认</a-link>
            <a-link type="text" @click="handlerEvent('audit', record)" v-if="record.auditStatus == 1"
              v-permission="['oms:product:purchase:recordAudit']">审核</a-link>
            <a-link type="text" @click="handlerEvent('log', record)"
              v-permission="['oms:product:purchase:recordLog']">日志</a-link>
          </a-space>
        </template>
      </a-table-column>
    </template>
  </a-table>
  <!-- </oms-panel> -->
  <audit ref="auditRecordRef" @reload="handleSearch"></audit>
  <omg-log ref="logRef"></omg-log>
  <edit-status ref="editStatusRef" @reload="handleSearch"></edit-status>
  <apply-adjust-edit ref="applyAdjustEditRef" @reload="handleSearch"></apply-adjust-edit>
</template>
<script lang="ts" setup name="purchase-goods">
import Audit from '../audit/index.vue'
import OmsTag from '@/components/oms-tag/index.vue'
import OmsPanel from '@/components/oms-panel/index.vue'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import adjustRecordMethod from './adjust-record-method'
import editStatus from '../editStatus/index.vue'
import applyAdjustEdit from '../apply-adjust-edit/index.vue'
import omgLog from '@/components/oms-log/index.vue'
const audittTagType = {
  '1': 'progress',
  '3': 'progress',
  '5': 'normal',
  '6': 'efficacy',
  '2': 'warring',
  '4': 'warring',
}
let directions = {
  1: '待审核',
  2: '审核不通过',
  3: '待确认',
  4: '确认不通过',
  5: '上线',
  6: '下线'
}
const {
  onChange,
  inputFormat,
  applyAdjustEditRef,
  editStatusRef,
  auditRecordRef,
  initDataInfo,
  handleReset,
  loading,
  serchRecordForm,
  searchRef,
  recordTableData,
  auditStatusList,
  handleSearch,
  handlerEvent,
  logRef,
} = adjustRecordMethod()
defineExpose({
  initDataInfo
})
</script>
<style lang="less" scoped>
.separator {
  display: inline-block;
  padding: 0px 4px;
  color: #b1b1b1;
  ;
}
</style>