<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 16:19:35
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-25 14:47:01
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\audit\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal :width="500" :title="auditInfo?.titleName" v-model:visible="showOrLoading" title-align="start"
    :on-before-ok="onBeforeOk" :mask-closable="false" :ok-loading="loading">
    <template v-if="auditInfo?.content">
      <div v-html="auditInfo?.content" class="title"></div>
    </template>
    <a-form :model="auditForm" auto-label-width ref="searchRef" :rules="formRules">
      <a-form-item :label="`${auditInfo?.lableName}：`" field="auditStatus">
        <a-select v-model="auditForm.auditStatus" placeholder="请选择">
          <a-option :value="1">通过</a-option>
          <a-option :value="0">不通过</a-option>
        </a-select>
      </a-form-item>
      <a-form-item label="备注：" field="remark" :rules="[{ required: auditForm.auditStatus == 0, message: '请输入' }]">
        <a-textarea v-model.trim="auditForm.remark" show-word-limit :placeholder="placeholder"
          :max-length="200"></a-textarea>
      </a-form-item>
    </a-form>
  </a-modal>
</template>
<script lang="ts" setup name="purchase-import">
import auditMethod from './audit-method'
const emits = defineEmits<{
  (e: "reload", data?: any): void
}>()
const {
  placeholder,
  showOrLoading,
  showModal,
  onBeforeOk,
  searchRef,
  auditForm,
  formRules,
  loading,
  auditInfo
} = auditMethod(emits)
defineExpose({
  showModal
})
</script>
<style lang="less" scoped>
.title {
  color: #3A3A3A;
  font-size: 13px;
  margin-bottom: 20px;
}
</style>