/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-13 09:20:06
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-25 14:47:23
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\audit\audit-method.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import initData from "../../commo-method/initData"
import { reactive, computed, ref, watch } from 'vue'
import { PurchaseAuditType, AuditTypeClass } from "@/types/product/purchase";
import { deepClone } from "@/utils/helper";
import { adjustPriceAudit, adjustPriceRecordOnOrOff, auditMapping } from '@/api/product/purchase'
import { Message } from '@arco-design/web-vue'
export default function (emits: Function) {
  // 导入统一数据
  const { showOrLoading, searchRef, formReset, loading } = initData()
  const auditForm = reactive<PurchaseAuditType>(new PurchaseAuditType())
  const auditInfo = ref<AuditTypeClass>(new AuditTypeClass())
  // 审核弹窗的参数
  const showModal = (params: any) => {
    auditForm.lstId = params.lstId
    auditForm.id = params.id
    auditForm.auditNode = params.auditNode
    auditInfo.value = params
    showOrLoading.value = true
    // 上下线弹窗转态直接赋值
    if (auditInfo.value.modalType) {
      auditForm.auditStatus = params.auditStatus
    }
  }
  const formRules = reactive({
    auditStatus: [
      { required: true, message: '请选择' }
    ],
    remark: [
      { required: true, message: '请输入' }
    ]
  })
  const onBeforeOk = async () => {
    const valid = await searchRef.value.validate()
    let form = deepClone(auditForm)
    form.auditStatus = Boolean(auditForm.auditStatus)
    if (valid) { return false }
        // 不通过时候，备注必填
        // if (!form.auditStatus && !auditForm.remark) {
        //   Message.error('请输入备注')
        //   return false
        // }
    try {
      loading.value = true
      let res = null

      if (auditInfo.value.modalType) {
        // 上下线接口
        res = await adjustPriceRecordOnOrOff(form)
      } else if (auditInfo.value.adjustType) {
        // 审核接口
        res = await auditMapping(form)
      } else {
        // 调价审核
        res = await adjustPriceAudit(form)
      }
      if (res.code != 0) {
        throw new Error(res.message)
      }
      Message.success('操作成功！')
      emits('reload')
      return true
    } catch (error) {
      Message.error((error as Error).message)
      return false
    } finally {
      loading.value = false
    }
  }
  watch(() => showOrLoading.value, (nV) => {
    if (nV) {

    } else {
      formReset()
      auditForm.remark=''
    }
  })
  const placeholder = computed(() => {
    return '限200个字，如不通过则必填'
  })
  return {
    placeholder,
    showOrLoading,
    showModal,
    onBeforeOk,
    searchRef,
    formReset,
    auditForm,
    formRules,
    loading,
    auditInfo
  }
}