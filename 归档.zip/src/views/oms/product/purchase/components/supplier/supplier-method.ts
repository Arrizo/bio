/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-13 09:20:06
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-28 20:23:57
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\supplier\supplier-method.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import initData from "../../commo-method/initData"
import { ref, watch } from 'vue'
import { querySupplierList } from '@/api/product/purchase'
import { Message,TableData } from "@arco-design/web-vue"
import commoMethod from '../../commo-method/index'
import { SupplierTableDataType } from '@/types/product/purchase'
export default function (emits: Function, props: any) {
  const { showModal, rowSelection, showOrLoading } = commoMethod()
  let { initTableData, loading } = initData()
  const supplierTableData = initTableData<SupplierTableDataType>()
  const keyWord = ref<string>('')
  const selectedkeys = ref()
  // 选中的数据
  const selectSupplierTableData = ref<SupplierTableDataType | {}>()
  const handleSearch = async () => {
    try {
      loading.value = true
      const { code, message, value } = await querySupplierList(keyWord.value,props.skuCode??'')
      if (code != 0) {
        throw new Error(message)
      }
      supplierTableData.value = value
      selectionChange(selectedkeys.value)
    } catch (error) {
      Message.error((error as Error).message)
    } finally {
      loading.value = false
    }
  }
  const onBeforeOk = () => {
    if (!selectSupplierTableData.value) {
      Message.error('请选择供应商')
      return false
    }
    emits('on-select', selectSupplierTableData.value)
    return true
  }
  const handleReset = () => {
    keyWord.value = ''
    handleSearch()
  }
  const selectionChange = (rowKeys: Array<string | number>) => {
    selectSupplierTableData.value = supplierTableData.value.find(i => i.supplierCode == rowKeys[0]) ?? ''
  }
  // 单击表格行选中
  const rowClick=(row:TableData)=>{
    selectedkeys.value=[row.supplierCode]
    selectSupplierTableData.value = supplierTableData.value.find(i => i.supplierCode == row.supplierCode) ?? ''
  }
  watch(() => showOrLoading.value, (nV) => {
    if (nV) {
      selectedkeys.value = props.supplierCode ? [props.supplierCode] : []
    } else {
      // 关闭弹窗,表格数据初始化
      keyWord.value = ''
      supplierTableData.value = []
      selectSupplierTableData.value=''
    }
  })
  return {
    rowClick,
    selectionChange,
    onBeforeOk,
    selectedkeys,
    showModal,
    showOrLoading,
    rowSelection,
    loading,
    handleReset,
    handleSearch,
    keyWord,
    supplierTableData
  }
}