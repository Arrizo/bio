<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 15:39:23
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-29 09:05:44
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\supplier\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal v-model:visible="showOrLoading" :width="800" title-align="start" :on-before-ok="onBeforeOk"
    :mask-closable="false" title="选择供应商" class="goods-modal">
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form layout="inline" :model="{}">
      <a-form-item field="code" label="供应商：">
        <a-input v-model.trim="keyWord" placeholder="供应商编码/名称" allow-clear :max-length="20" :style="{ width: '200px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
    </a-form>
    <!-- </template> -->
    <a-spin :loading="loading">
      <a-table @selection-change="selectionChange" :data="supplierTableData" v-model:selected-keys="selectedkeys"
        class="gift-table" :pagination="false" hide-expand-button-on-empty :scroll="{ y: 450 }" stripe
        :bordered="{ wrapper: false }" :show-page-size="false" :show-jumper="false" row-key="supplierCode"
        :row-selection="rowSelection" @row-click="rowClick">
        <template #columns>
          <a-table-column title="供应商编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.supplierCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="供应商名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.supplierName || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </a-spin>
    <!-- </oms-panel> -->
  </a-modal>
</template>
<script lang="ts" setup name="purchase-goods">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import supplierMethod from './supplier-method'
import { SupplierTableDataType } from '@/types/product/purchase'
interface PropsType {
  supplierCode: string
  skuCode: string
}
const props = defineProps<PropsType>();
const emits = defineEmits<{
  (e: "on-select", data: SupplierTableDataType): void;
}>();
const {
  rowClick,
  showModal,
  selectedkeys,
  loading,
  handleSearch,
  handleReset,
  onBeforeOk,
  selectionChange,
  showOrLoading,
  rowSelection,
  keyWord,
  supplierTableData
} = supplierMethod(emits, props)
defineExpose({
  showModal
})
</script>
<style lang="less">
.goods-modal {
  .arco-modal-body {
    height: 588px;
  }

  .gift-table {
    .arco-table-tr-empty .arco-table-td {
      height: 370px;
    }
  }
}
</style>