<template>
  <a-modal v-model:visible="showOrLoading" :width="1200" title-align="start" :mask-closable="false" :title="titleName"
  class="goods-modal"
  hideCancel>
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form :model="form" layout="inline" ref="searchRef">
      <a-form-item field="code" label="编码：">
        <a-input v-model.trim="form.code" placeholder="spu/sku编码" allow-clear :style="{ width: '160px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="skuName" label="名称：">
        <a-input v-model.trim="form.skuName" placeholder="请输入规格名称" allow-clear :style="{ width: '160px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="supplier" label="供应商：">
        <a-input v-model.trim="form.supplier" placeholder="请输入供应商" allow-clear :style="{ width: '160px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="organization" label="组织：">
        <a-input v-model.trim="form.organization" placeholder="请输入采购组织" allow-clear :style="{ width: '160px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
    </a-form>
    <!-- </template> -->
    <a-space :size="20">
      <section class="confirm">
        <a-button @click="handlerAudit(true)" type="primary" :disabled="!selectedKeys.length">
          {{ adjustType == 'adjustAudit' ? '批量审核' : '批量确认' }}
        </a-button>
        <template v-if="adjustType == 'adjustConfirm'">
          <icon-exclamation-circle-fill class="icon-red" />
          <span>采购价目调价经审核、确认通过后将自动上线，即确认通过=已上线</span>
        </template>
      </section>
    </a-space>
    <!-- <a-spin :loading="loading"> -->
    <a-table :data="tableData" :pagination="false" hide-expand-button-on-empty :scroll="{ x: 300, y: 400 }" stripe
    class="gift-table"
      :bordered="{ wrapper: false }" :row-selection="rowSelection" row-key="id" v-model:selected-keys="selectedKeys">
      <template #columns>
        <a-table-column title="商品编码" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格编码" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.skuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格名称" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.skuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格型号" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.skuType || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="调价类型" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.typeName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="从" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ record.minNum || '0' }}
          </template>
        </a-table-column>
        <a-table-column title="到" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ record.maxNum || '0' }}
          </template>
        </a-table-column>
        <a-table-column title="采购价(元)" align="right" cell-class="paddingR40" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.price || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="折扣%" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.discount || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="生效日期" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.startTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="失效日期" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.endTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="价格下限(元)" align="right" cell-class="paddingR40" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.minPrice || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="价格上限(元)" align="right" cell-class="paddingR40" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.maxPrice || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="店铺" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.storeName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="调价原因" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.cause || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="供应商" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.supplierName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="采购组织" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.organizationName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="备注说明" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.remark || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="70" fixed="right">
          <template #cell="{ record }">
            <a-space :size="28">
              <a-link type="text" @click="handlerAudit(false, record)">{{ adjustType == 'adjustAudit' ? '审核' : '确认'
              }}</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
    <!-- </a-spin> -->
    <!-- </oms-panel> -->
    <template #footer>
      <a-button @click="showOrLoading=false">关闭</a-button>
    </template>
  </a-modal>
  <audit ref="auditRef" @reload="handleSearch"></audit>
</template>
<script lang="ts" setup name="purchase-goods">
import Audit from '../audit/index.vue'
import OmsPanel from '@/components/oms-panel/index.vue'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import commoMethod from '../../commo-method/index'
import adjustAuditMethod from './adjust-audit-method'
const emits = defineEmits<{
  (e: "on-search", data: any): void;
}>();
const {
  adjustType,
  titleName,
  showOrLoading,
  searchRef,
  loading,
  showModal,
  form,
  handleSearch,
  tableData,
  handleReset,
  rowSelection,
  selectedKeys,
  auditRef,
  handlerAudit
} = adjustAuditMethod(emits)
const { } = commoMethod()
defineExpose({
  showModal
})
</script>
<style lang="less" scoped>
.confirm {
  margin-bottom: 10px;
  display: flex;
  align-items: center;

  .icon-red {
    font-size: 20px;
    color: #FF3E3E;
    margin: 0px 5px;
  }

  span {
    font-size: 12px;
    color: #999999;
  }
}
</style>
<style lang="less">
.goods-modal {
  .arco-modal-body {
    height: 588px;
  }

  .gift-table {
    .arco-table-tr-empty .arco-table-td {
      height: 370px;
    }
  }
}
</style>