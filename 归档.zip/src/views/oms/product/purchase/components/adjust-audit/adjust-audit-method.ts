import initData from "../../commo-method/initData"
import { PriceRecordAuditPageClass, AdjustPriceRecordAddBO } from '@/types/product/purchase'
import { reactive, ref, computed, watch } from 'vue'
import { findAdjustPriceRecordAuditPage } from '@/api/product/purchase'
import { Message, TableRowSelection } from "@arco-design/web-vue";
export default function (emits: Function) {
  const { showOrLoading, loading, searchRef, formReset } = initData()
  const form = reactive<PriceRecordAuditPageClass>(new PriceRecordAuditPageClass())
  const tableData = ref<Array<AdjustPriceRecordAddBO>>([])
  const selectedKeys = ref<Array<number>>([])
  const adjustType = ref()
  const auditRef = ref()
  const rowSelection = reactive<TableRowSelection>({
    type: 'checkbox',
    showCheckedAll: true,
    fixed: true
  })
  const showModal = async (type: string) => {
    showOrLoading.value = true
    adjustType.value = type
  }
  const handleSearch = async () => {
    try {
      loading.value = true
      form.auditStatus = adjustType.value == 'adjustAudit' ? 1 : 3
      const { code, value, message } = await findAdjustPriceRecordAuditPage(form)
      if (code != 0) {
        throw new Error(message)
      }
      tableData.value = value.result
      selectedKeys.value = []
    } catch (error) {
      Message.error((error as Error).message)
    } finally {
      loading.value = false
    }
  }
  const handleReset = () => {
    formReset()
    handleSearch()
    selectedKeys.value = []
  }
  const handlerAudit = (type: boolean, record?: AdjustPriceRecordAddBO) => {
    let params = {}
    if (adjustType.value == 'adjustAudit') {
      params = {
        titleName: type ? '批量审核' : '审核',
        lableName: '审核结果',
        content: type ? `确定审核已选中的<span style='color:#FF3E3E'>${selectedKeys.value.length}</span>条采购调价申请？` : '',
        auditNode: '采购调价审核',
        lstId: record ? [record.id] : selectedKeys.value,
        adjustType:true
      }
    } else {
      params = {
        titleName: type ? '批量确认' : '确认',
        lableName: '确认结果',
        content: type ? `确定确认已选中的<span style='color:#FF3E3E'>${selectedKeys.value.length}</span>条采购调价申请？` : '',
        auditNode: '采购调价确认',
        lstId: record ? [record.id] : selectedKeys.value,
        adjustType:true
      }
    }
    auditRef.value.showModal(params)
  }
  const titleName = computed(() => {
    switch (adjustType.value) {
      case 'adjustAudit': return '采购调价审核'
      case 'adjustConfirm': return '采购调价确认'
      default: return ''
    }
  })
  watch(() => showOrLoading.value, (nV) => {
    if (nV) {
      handleSearch()
    } else {
      formReset()
      selectedKeys.value = []
    }
  })
  return {
    adjustType,
    titleName,
    handlerAudit,
    handleReset,
    form,
    showOrLoading,
    loading,
    searchRef,
    showModal,
    handleSearch,
    tableData,
    rowSelection,
    selectedKeys,
    auditRef
  }

}