/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-23 16:28:18
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-29 10:22:45
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\list\list-methods\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import { reactive, ref,computed } from 'vue'
import { TableRowSelection } from "@arco-design/web-vue"
import { PurchaseSeachType, PurchaseListType } from '@/types/product/purchase'
import { adjustPriceStatus,importAdjustPrice } from '@/api/product/purchase'
import { Message } from '@arco-design/web-vue';
export default function (emits: Function) {
  // 审核状态值枚举
  enum AuditStatus {
    "AUDIT_PASS" = '通过',
    "NO_PASS" = '不通过',
    "WAIT_AUDIT" = '待审核',
  }
  const selectedKeys = ref<Array<string>>([])
  // 勾选状态id
  const purchaseId = ref()
  // 修改状态ref
  const switchRef = ref()
  // 日志ref
  const logRefs = ref()
  // 新增调价
  const addPurchaseRef = ref()
  // 导入ref
  const importRef = ref()
  // 审核ref
  const auditRef = ref()
  // 调价审核ref
  const adjustAuditRef = ref()
  // 申请调价ref
  const applyAdjustRef = ref()
  // 模板下载路径
  const uploadUrl = ref(`${import.meta.env.VITE_API_FILE_URL}/bp-auth-service/template/adjustPriceManage/%E9%87%87%E8%B4%AD%E4%BB%B7%E7%9B%AE%E5%AF%BC%E5%85%A5%E6%A8%A1%E6%9D%BF.xlsx?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20230308%2F%2Fs3%2Faws4_request&X-Amz-Date=20230308T070107Z&X-Amz-Expires=432000&X-Amz-SignedHeaders=host&X-Amz-Signature=be3a07ef950ba3905bc9eda94ca301c5077456801a1d9a5b51957f87778d5ef8`);
  const rowSelection = reactive<TableRowSelection>({
    type: 'checkbox',
    showCheckedAll: true
  })
  const onPurchaseReload = (data?:any) => {
    emits('reload', data)
  }
  // 修改状态事件
  const onSwitchForce = (record: PurchaseListType) => {
    purchaseId.value = record?.id
    switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
  }
  const beforeChange = async () => {
    try {
      const res = await adjustPriceStatus(purchaseId.value)
      if (res.code != 0) {
        throw new Error(res.message);
      }
      Message.success('更新成功')
      onPurchaseReload()
    } catch (err) {
      Message.error((err as Error).message);
    }
  }
  /**
   * 事件统一处理，根据不同参数调用不同模块
   */
  const handler = (type: string, record?: PurchaseListType) => {
    switch (type) {
      case 'add': return addPurchaseRef.value.showAddPurchse()
      case 'import': return  importRef.value.visible = true;
      case 'adjustAudit': return adjustAuditRef.value.showModal('adjustAudit')
      case 'adjustConfirm': return adjustAuditRef.value.showModal('adjustConfirm')
      case 'applyAdjust': return applyAdjustRef.value.showModal(record?.id??"",'listEdit')
      case 'audit':
        return auditRef.value.showModal({
          titleName:'审核采购价目',
          lableName:'审核结果',
          auditNode: '审核采购价目',
          lstId: selectedKeys.value,
        })
    }
  }
  const getAdjustRecord = (data: PurchaseListType) => {
    emits('show-record', data)
  }
  const audittTagType = {
    'WAIT_AUDIT': 'progress',
    'AUDIT_PASS': 'normal',
    'NO_PASS': 'warring',
  }
  return {
    audittTagType,
    importAdjustPrice,
    uploadUrl,
    getAdjustRecord,
    selectedKeys,
    onPurchaseReload,
    rowSelection,
    switchRef,
    onSwitchForce,
    beforeChange,
    logRefs,
    handler,
    addPurchaseRef,
    AuditStatus,
    importRef,
    auditRef,
    adjustAuditRef,
    applyAdjustRef
  }
}