
<template>
	<oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onPurchaseReload"
		class="purchase-list">
		<template #header-left>
			<a-space :size="10" style="marginBottom:10px;">
				<a-button type="primary" @click="handler('add')" v-permission="['oms:product:purchase:add']">新增</a-button>
				<a-button @click="handler('import')" type="outline" v-permission="['oms:product:purchase:import']">导入</a-button>
				<a-button @click="handler('audit')" :disabled="!selectedKeys.length"
					v-permission="['oms:product:purchase:audit']">审核</a-button>
				<a-button @click="handler('adjustAudit')" v-permission="['oms:product:purchase:adjustAudit']">调价审核</a-button>
				<a-button @click="handler('adjustConfirm')" v-permission="['oms:product:purchase:adjustConfirm']">调价确认</a-button>
			</a-space>
		</template>
		<a-table :pagination="false" :row-selection="rowSelection" hide-expand-button-on-empty v-db-click="purchaseList"
			:db-call-back="getAdjustRecord" :data="purchaseList" :scroll="{ x: 1150, y: 515 }" stripe
			:bordered="{ wrapper: false }" row-key="id" v-model:selected-keys="selectedKeys">
			<template #columns>
				<a-table-column title="商品编码" :tooltip="true" :width="150" ellipsis>
					<template #cell="{ record }">
						{{ record.spuCode || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="规格编码" :tooltip="true" :width="150" ellipsis>
					<template #cell="{ record }">
						{{ record.skuCode || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="规格名称" :tooltip="true" :width="200" ellipsis>
					<template #cell="{ record }">
						{{ record.skuName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="规格型号" :tooltip="true" :width="150" ellipsis>
					<template #cell="{ record }">
						{{ record.skuType || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="单位" :tooltip="true" :width="100" ellipsis>
					<template #cell="{ record }">
						{{ record.unitName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="含税单价(元)" align='right' cell-class="paddingR40" :tooltip="true" :width="150" ellipsis>
					<template #cell="{ record }">
						{{ record.price || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="税率%" :tooltip="true" :width="100" ellipsis>
					<template #cell="{ record }">
						{{ record.taxRateName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="供应商" :tooltip="true" :width="200" ellipsis>
					<template #cell="{ record }">
						{{ record.supplierName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="采购组织" :tooltip="true" :width="150" ellipsis>
					<template #cell="{ record }">
						{{ record.organizationName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="审核状态" :tooltip="true" :width="120" ellipsis>
					<template #cell="{ record }">
						<oms-tag :type="audittTagType[record.auditStatus]" :content="AuditStatus[record.auditStatus]"></oms-tag>
					</template>
				</a-table-column>
				<a-table-column title="状态" :tooltip="true" :width="120" ellipsis>
					<template #cell="{ record }">
						<a-switch v-model="record.status" @focus="onSwitchForce(record)"
							v-permission="['oms:product:purchase:status']">
							<template #checked>
								启用
							</template>
							<template #unchecked>
								禁用
							</template>
						</a-switch>
					</template>
				</a-table-column>
				<a-table-column title="更新时间" :tooltip="true" :width="180" ellipsis>
					<template #cell="{ record }">
						{{ record.updateTime || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="操作" :width="90" fixed="right">
					<template #cell="{ record }">
						<a-space :size="14">
							<a-link type="text" @click="handler('applyAdjust', record)" v-if="record.auditStatus == 'AUDIT_PASS'"
								v-permission="['oms:product:purchase:applyAdjust']">申请调价</a-link>
						</a-space>
					</template>
				</a-table-column>
			</template>
		</a-table>
	</oms-table>
	<!-- 修改状态 -->
	<oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
	<!-- 添加调价 -->
	<add-purchase ref="addPurchaseRef" @reload-table="onPurchaseReload"></add-purchase>
	<!-- 审核 -->
	<audit ref="auditRef" @reload="onPurchaseReload"></audit>
	<!-- 调价审核 -->
	<adjust-audit ref="adjustAuditRef"></adjust-audit>
	<!-- 申请调价 -->
	<apply-adjust ref="applyAdjustRef"></apply-adjust>
	<oms-import ref="importRef" :uploadSize="10" uploadUrlName="导入" :uploadUrl="uploadUrl" :importApi="importAdjustPrice"
		@on-success="onPurchaseReload"></oms-import>
</template>
<script lang="ts" setup name="purchase-list">
import OmsImport from '@/components/oms-import/index.vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsTag from '@/components/oms-tag/index.vue'
import listMethods from './list-methods'
import OmsWarning from '@/components/oms-warning/index.vue';
import AddPurchase from '../addPurchase/index.vue'
import Audit from '../audit/index.vue'
import AdjustAudit from '../adjust-audit/index.vue'
import ApplyAdjust from '../apply-adjust/index.vue'
import { watch } from 'vue'
import { PurchaseListType, PurchaseSeachType } from '@/types/product/purchase'
const emits = defineEmits<{
	(e: "reload", data?: PurchaseSeachType): void
	(e: "show-record", data: PurchaseListType): void
}>()
interface PropsType {
	loading: boolean
	total: number
	pageNum: number
	pageSize: number
	purchaseList: Array<PurchaseListType>
}
const props = defineProps<PropsType>();
watch(() => props.purchaseList, (nV) => {
	selectedKeys.value = []
})
const {
	audittTagType,
	importAdjustPrice,
	uploadUrl,
	rowSelection,
	onPurchaseReload,
	switchRef,
	onSwitchForce,
	beforeChange,
	AuditStatus,
	handler,
	addPurchaseRef,
	importRef,
	auditRef,
	adjustAuditRef,
	applyAdjustRef,
	selectedKeys,
	getAdjustRecord
} = listMethods(emits)

</script>