<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 14:02:47
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-25 14:41:35
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\addPurchase\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->


<template>
  <a-modal v-model:visible="showOrLoading" :width="900" title="新增" title-align="start" :mask-closable="false"
    :on-before-ok="onBeforeOk" :ok-loading="loading" ok-text="提交">
    <a-form :model="addPurchaseForm" :rules="formRules" auto-label-width ref="searchRef">
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="规格编码：" field="skuCode">
            <a-input v-model="addPurchaseForm.skuCode" @click="handleAdd('goods')" readonly placeholder="请选择"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="商品编码：" field="spuCode">
            <a-input v-model="addPurchaseForm.spuCode" allow-clear disabled ></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="规格名称：" field="specsTitle">
            <a-input v-model="addPurchaseForm.specsTitle" allow-clear disabled></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="规格型号：" field="specsModel">
            <a-input v-model="addPurchaseForm.specsModel" allow-clear disabled></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="供应商：" field="supplierName">
            <a-input v-model="addPurchaseForm.supplierName" @click="handleAdd('supplier')" readonly placeholder="请选择"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="采购组织：" field="organization">
            <a-select v-model="addPurchaseForm.organization" placeholder="请选择" allow-search>
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item,index) in organizationList" :key="`${index}-organization`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="价格下限：" field="adjustPriceRecordAddBO.minPrice">
            <a-input v-model.trim="addPurchaseForm.adjustPriceRecordAddBO.minPrice" allow-clear placeholder="请输入" @input="formaInput($event,'minPrice')"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="价格上限：" field="adjustPriceRecordAddBO.maxPrice">
            <a-input v-model.trim="addPurchaseForm.adjustPriceRecordAddBO.maxPrice" allow-clear placeholder="请输入" @input="formaInput($event,'maxPrice')"></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="采购价：" field="adjustPriceRecordAddBO.price">
            <a-input v-model.trim="addPurchaseForm.adjustPriceRecordAddBO.price" allow-clear @input="formaInput($event,'price')" placeholder="请输入"></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="折扣：" field="adjustPriceRecordAddBO.discount">
            <a-input v-model.trim="addPurchaseForm.adjustPriceRecordAddBO.discount" allow-clear @input="formaInput($event,'discount','scope')" placeholder="请输入"></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="税率：" field="adjustPriceRecordAddBO.taxRate">
            <a-select v-model="addPurchaseForm.adjustPriceRecordAddBO.taxRate" allow-search placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item,index) in taxRateList" :key="`${index}-taxRate`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="单位：" field="adjustPriceRecordAddBO.unit">
            <a-select v-model="addPurchaseForm.adjustPriceRecordAddBO.unit" allow-search placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item,index) in unitList" :key="`${index}-unit`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="生效时间：" field="adjustPriceRecordAddBO.startTime">
            <a-date-picker showTime v-model="addPurchaseForm.adjustPriceRecordAddBO.startTime"  style="width: 334px;"/>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="失效时间：" field="adjustPriceRecordAddBO.endTime">
            <a-date-picker showTime v-model="addPurchaseForm.adjustPriceRecordAddBO.endTime"  style="width: 334px;"/>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="店铺：" field="adjustPriceRecordAddBO.storeCode">
            <a-select v-model="addPurchaseForm.adjustPriceRecordAddBO.storeCode" allow-search allow-clear placeholder="请选择">
              <a-option :label="item.storeName" :value="item.storeCode" v-for="(item,index) in shopList" :key="`${index}-storeCode`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="调价原因：" field="adjustPriceRecordAddBO.cause">
            <a-select v-model="addPurchaseForm.adjustPriceRecordAddBO.cause" allow-search allow-clear placeholder="请选择">
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item,index) in causeList" :key="`${index}-cause`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="24">
          <a-form-item label="备注：" field="remark">
            <a-textarea v-model.trim="addPurchaseForm.remark" :max-length="200" show-word-limit
              placeholder="请输入（限200个字）"></a-textarea>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
  <goods ref="goodsRef" :specs-code="addPurchaseForm.skuCode" @on-select="onGoodsSelect"></goods>
  <supplier ref="supplierRef" @on-select="onSupplierSelect" :skuCode="addPurchaseForm.skuCode" :supplier-code="addPurchaseForm.supplierCode"></supplier>
</template>
<script lang="ts" setup name="add-purchase">
import addPurchaseMethod from "./add-purchase-method/index"
import goods from '../goods/index.vue'
import supplier from '../supplier/index.vue'
const emits = defineEmits<{
  (e: "reloadTable", data?: any): void
}>()
const {
  formaInput,
  shopList,
  causeList,
  taxRateList,
  discoutTypeList,
  organizationList,
  unitList,
  showOrLoading,
  loading,
  searchRef,
  formRules,
  addPurchaseForm,
  showAddPurchse,
  onBeforeOk,
  goodsRef,
  supplierRef,
  handleAdd,
  onGoodsSelect,
  onSupplierSelect
} = addPurchaseMethod(emits)

defineExpose({
  showAddPurchse
})
</script>
