/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 14:09:07
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-20 18:13:57
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\addPurchase\add-purchase-method\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */

import initData from "../../../commo-method/initData"
import { reactive, ref, watch } from 'vue'
import { Message } from '@arco-design/web-vue'
import { AddjustPriceType } from '@/types/product/purchase'
import { goodsTableDataType, SupplierTableDataType } from '@/types/product/purchase'
import commoMethod from "../../../commo-method"
import { getShopList } from '@/api/system/role'
import { adjustPriceAdd } from '@/api/product/purchase'
export default function (emits: Function) {
  const { showOrLoading, loading, searchRef, formReset } = initData()
  const { getCompanyTypeList, formaNumber } = commoMethod()
  // 商品弹窗ref
  const goodsRef = ref()
  // 供应商弹窗ref
  const supplierRef = ref()
  // 组织列表
  const organizationList = ref()
  // 单位列表
  const unitList = ref()
  // 调价原因列表
  const causeList = ref()
  // 税率列表
  const taxRateList = ref()
  // 折扣类型列表
  const discoutTypeList = ref()
  // 查询店铺列表
  const shopList = ref()
  // 新增表单数据
  let addPurchaseForm = reactive<AddjustPriceType>(new AddjustPriceType())
  const formRules = reactive({
    skuCode: [
      { required: true, message: '请选择' }
    ],
    supplierName: [
      { required: true, message: '请选择' }
    ],
    organization: [
      { required: true, message: '请选择' }
    ],
    'adjustPriceRecordAddBO.price': [
      { required: true, message: '请输入' }
    ],
    'adjustPriceRecordAddBO.taxRate': [
      { required: true, message: '请选择' }
    ],
    'adjustPriceRecordAddBO.unit': [
      { required: true, message: '请选择' }
    ],
    'adjustPriceRecordAddBO.startTime': [
      { required: true, message: '请选择' }
    ],
    'adjustPriceRecordAddBO.endTime': [
      { required: true, message: '请选择' }
    ],
  })
  // 获取数据字典
  const showAddPurchse = async () => {
    showOrLoading.value = true
    organizationList.value = await getCompanyTypeList('ADJUST_PRICE_ORGANIZATION')
    unitList.value = await getCompanyTypeList('UNIT')
    causeList.value = await getCompanyTypeList('CAUSE')
    taxRateList.value = await getCompanyTypeList('TAX_RATE')
    discoutTypeList.value = await getCompanyTypeList('DISCOUNT')
    queryShopList()
  }
  // 查询下拉启用店铺
  const queryShopList = async () => {
    try {
      const { value } = await getShopList()
      shopList.value = value
    } catch (error) {
      console.log(error)
    }
  }
  const onBeforeOk = async (done: Function) => {
    const valid = await searchRef.value.validate()
    if (valid) { return false }
    const addObj = addPurchaseForm.adjustPriceRecordAddBO
    if (addObj.minPrice || addObj.maxPrice) {
      if (!addObj.minPrice) {
        Message.error('请输入价格下限！')
        return false
      }
      if (!addObj.maxPrice) {
        Message.error('请输入价格上限！')
        return false
      }
      if (Number(addObj.minPrice) >= Number(addObj.maxPrice)) {
        Message.error('价格上限必须大于价格下限！')
        return false
      }
    }
    if (addObj.discount) {
      if (Number(addObj.discount) >= 100 || Number(addObj.discount) <= 0) {
        Message.error('折扣范围0~100之间')
        return false
      }
    }
    if (new Date(addObj.startTime).getTime() > new Date(addObj.endTime).getTime()) {
      Message.error('生效时间不能晚于失效时间')
      return false
    }
    try {
      loading.value = true
      const { code, message } = await adjustPriceAdd(addPurchaseForm)
      if (code != 0) {
        throw new Error(message)
      }
      Message.success('操作成功！')
      emits('reloadTable', {})
      showOrLoading.value = false
      return true
    } catch (error) {
      Message.error((error as Error).message)
      return false
    } finally {
      loading.value = false
      return false
    }
  }
  const handleAdd = (type: string) => {
    switch (type) {
      case 'goods': return goodsRef.value.showModal()
      case 'supplier':
        if(!addPurchaseForm.skuCode){
          return Message.error('请先添加商品')
        }
      return supplierRef.value.showModal()
    }
  }
  watch(() => showOrLoading.value, (nV) => {
    !nV && formReset()
  })
  // 勾选商品回显
  const onGoodsSelect = (data: goodsTableDataType) => {
    addPurchaseForm.specsModel = data.specsModel
    addPurchaseForm.specsTitle = data.specsTitle
    addPurchaseForm.skuCode = data.specsCode
    addPurchaseForm.spuCode = data.productCode
  }
  // 勾选供应商回显
  const onSupplierSelect = (data: SupplierTableDataType) => {
    addPurchaseForm.supplierCode = data.supplierCode
    addPurchaseForm.supplierName = data.supplierName
  }
  const formaInput = ($event: any, type: string, scope?: string) => {
    addPurchaseForm.adjustPriceRecordAddBO[type] = formaNumber($event)
  }
  return {
    formaInput,
    shopList,
    causeList,
    taxRateList,
    discoutTypeList,
    organizationList,
    unitList,
    onSupplierSelect,
    goodsRef,
    showOrLoading,
    loading,
    searchRef,
    formRules,
    addPurchaseForm,
    showAddPurchse,
    onBeforeOk,
    handleAdd,
    onGoodsSelect,
    supplierRef,
    queryShopList
  }
}