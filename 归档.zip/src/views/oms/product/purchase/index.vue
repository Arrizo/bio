<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-23 14:00:05
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-10 14:29:07
 * @FilePath: \oms-admin\src\views\oms\product\purchase\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE··
-->
<template>
  <div class="panel-height">
    <oms-panel :class="{'panel-height':!showTabs}">
      <template #header>
        <search :loading="showOrLoading" @on-search="initMethod"></search>
      </template>
      <list :loading="showOrLoading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize"
        @reload="initMethod" :purchase-list="purchaseListData" @show-record="showRecord"> </list>
    </oms-panel>
    <!-- 双击表格tabs栏目 -->
    <div class="shop-config" v-show="showTabs">
      <a-tabs default-active-key="1">
        <template #extra>
          <icon-close @click="showTabs = false" />
        </template>
        <a-tab-pane key="1" title="调价记录">
          <adjust-record ref="adjustRecordRef"></adjust-record>
        </a-tab-pane>
        <a-tab-pane key="2" title="日志">
          <oms-log ref="adjustRecordLogRef"></oms-log>
        </a-tab-pane>
      </a-tabs>
    </div>
  </div>
</template>
<script lang="ts" setup name="purchase-index">
import OmsPanel from '@/components/oms-panel/index.vue'
import List from './components/list/index.vue'
import Search from './components/search/index.vue'
import commoMethod from './commo-method/index'
import adjustRecord from './components/adjust-record/index.vue'
import adjustRecordLog from './components/adjust-record-log/index.vue'
import omsLog from '@/components/oms-log/index.vue'
const { showOrLoading,
  total,
  form,
  purchaseListData,
  initMethod,
  showRecord,
  adjustRecordRef,
  adjustRecordLogRef,
  showTabs } = commoMethod()
</script>
<style lang="less" scoped>
.panel-height{
  height: 100%;
}
.shop-config {
  background-color: #fff;
  height: 100%;

  :deep(.arco-tabs-nav) {
    padding: 10px 16px 0px 10px;
  }

  :deep(.arco-tabs-content) {
    padding-left: 16px;
    padding-right: 16px;
  }

  :deep(.arco-tabs-nav-extra) {
    border: 1px solid rgba(112, 112, 112, 0.3);
    border-radius: 50%;
    color: #707070;
    font-size: 11px;
    padding: 2px;
    cursor: pointer;
  }
}
</style>