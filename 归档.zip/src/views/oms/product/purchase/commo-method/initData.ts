/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-23 14:06:53
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-02-25 13:56:47
 * @FilePath: \oms-admin\src\views\oms\product\purchase\commo-method\initData.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import { reactive, ref } from 'vue'
import { PurchaseSeachType } from '@/types/product/purchase'
import { TableColumnData } from '@arco-design/web-vue'
export default function () {
  /**
   * 初始化一些公共数据
   */
  let form = reactive<PurchaseSeachType>(new PurchaseSeachType())
  const showOrLoading = ref<boolean>(false)
  const loading = ref<boolean>(false)
  const searchRef = ref()
  const initTableColumns = (list: Array<TableColumnData>) => {
    return ref<Array<TableColumnData>>(list)
  }
  const formReset = (ref?:any) => {
    (ref||searchRef).value.resetFields();
  }
  const total = ref<number>(0)
  // 通过泛型指定数据类型
  const initTableData = <T>() => {
    return ref<Array<T>>([])
  }
  return {
    form,
    formReset,
    total,
    searchRef,
    showOrLoading,
    loading,
    initTableData,
    initTableColumns
  }
}