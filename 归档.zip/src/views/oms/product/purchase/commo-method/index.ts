/*
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-23 14:07:00
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-29 10:20:52
 * @FilePath: \oms-admin\src\views\oms\product\purchase\commo-method\index.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import initData from "./initData"
import { PurchaseSeachType, PurchaseListType } from '@/types/product/purchase'
import { queryPurchaseList } from '@/api/product/purchase'
import { Message, TableRowSelection } from "@arco-design/web-vue"
import { reactive, ref } from 'vue'
import { getDictionaryList } from '@/hooks/useDictionary';
export default function () {
  // 导出所有公共数据
  let { showOrLoading, total, form, initTableData, searchRef, loading, formReset } = initData()
  // 初始化表格数据
  const purchaseListData = initTableData<PurchaseListType>()
  const showTabs = ref(false)
  const adjustRecordRef = ref()
  const adjustRecordLogRef = ref()

  // 获取表格数据
  const initMethod = async (data?: PurchaseSeachType) => {
    try {
      form = Object.assign(form, data)
      showOrLoading.value = true
      showTabs.value = false
      const { code, value, message } = await queryPurchaseList(form)
      if (code != 0) {
        throw new Error(message)
      }
      purchaseListData.value = value.result
      total.value = value.totalCount
      form.pageNum = value.pageNum
      form.pageSize = value.pageSize
    } catch (error) {
      Message.error((error as Error).message)
    } finally {
      showOrLoading.value = false
    }
  }
  // 重置表单
  const handleReset = () => {
    formReset()
  }
  const rowSelection = reactive<TableRowSelection>({
    type: 'radio',
    fixed: true,
  })
  const showModal = () => {
    showOrLoading.value = true
  }
  // 查询字典
  const getCompanyTypeList = async (type: string) => {
    try {
      return await getDictionaryList(type)
    } catch (error) {
      console.error(error)
    }
  }
  // 双击表格回调事件
  const showRecord = (data: PurchaseListType) => {
    adjustRecordRef.value.initDataInfo(data?.id)
    adjustRecordLogRef.value.init(data?.code, '采购调价', 'page')
    showTabs.value = true
  }
  // 输入框正则校验
  const formaNumber = (value: string, num: number = 4) => {
    value = value.replace(/[^\d.]/g, ""); // 清除"数字"和"."以外的字符
    value = value.replace(/^\./g, ""); // 验证第一个字符是数字
    value = value.replace(/\.{2,}/g, "."); // 只保留第一个, 清除多余的
    value = value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    value = value.replace(/^0{2,}/, "0"); // 只保留第一个0, 清除多余的
    if (num) {
      let regExp = new RegExp('^(\\-)*(\\d+)\\.(\\d{' + num + '}).*$')
      value = value.replace(regExp, '$1$2.$3');
    } else {
      value = value.replace(/^0(0+)|[^\d]+/g, '');
    }
    return value
  }
  // 查询商品列表
  return {
    formaNumber,
    adjustRecordLogRef,
    showRecord,
    showTabs,
    getCompanyTypeList,
    showOrLoading,
    total,
    form,
    initMethod,
    purchaseListData,
    searchRef,
    loading,
    handleReset,
    rowSelection,
    showModal,
    adjustRecordRef
  }
}