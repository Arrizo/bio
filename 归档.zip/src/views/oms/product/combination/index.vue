<!--
 * @ Author: zhangpeng
 * @ Create Time: 2023-03-03 08:44:50
 * @ Modified by: zhangpeng
 * @ Modified time: 2023-03-03 11:28:12
 * @ Description: 组合商品
 -->

<template>
  <!-- <a-row :gutter="10" style="height:100%; max-height:calc(100vh - 125px)">
    <a-col :span="24" style="height:100%">
      <a-split direction="vertical" v-model:size="splitSize" :disabled="splitDisabled" :style="{
        height: '100%',
        width: '100%',
        backgroundColor: 'white'}">
        <template #first>
          <oms-panel>
            <template #header>
              <search :loading="loading" @on-search="init"></search>
            </template>
            <div>
              <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
                @reload="init" @showDetail="handleDetailClick"></list>
            </div>
          </oms-panel>
        </template>
        <template #second>
          <detail v-if="detailVisible" :id="detailId" :combinationCode="combinationCode" @close="closeDetail"></detail>
        </template>
      </a-split>
    </a-col>
  </a-row> -->

  <a-row :gutter="10" style="height:100%;">
    <a-col :span="24" style="height:100%">
      <oms-panel>
        <template #header>
          <search :loading="loading" @on-search="init"></search>
        </template>
        <div>
          <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
            @reload="init" @showDetail="handleDetailClick"></list>
        </div>
      </oms-panel>
      <!-- 详情 -->
      <detail v-if="detailVisible" :id="detailId" :combinationCode="combinationCode" @close="closeDetail"></detail>
    </a-col>
  </a-row>
</template>

<script setup lang="ts" name="product-combination">
import OmsPanel from '@/components/oms-panel/index.vue'
import Search from './components/search.vue'
import List from './components/list.vue'
import Detail from './components/detail.vue'
import { Message } from '@arco-design/web-vue'
import { ref } from 'vue'
import { CombinationData, CombinationListForm, CombinationDetail } from '@/types/product/combination'
import { getCombinationList } from '@/api/product/combination'
import { deepClone } from '@/utils/helper'

const loading = ref<boolean>(false)
const list = ref<CombinationData[]>([])
const total = ref<number>(0)
const form = ref<CombinationListForm>(new CombinationListForm())
const detailVisible = ref<boolean>(false)
const detailId = ref(0)
const combinationCode = ref()
const splitSize = ref(1)
const splitDisabled = ref(true)

const init = async (data?: CombinationListForm) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true
    let params = deepClone(form.value)
    params.status = params.status === 'all' ? '' : params.status

    //为了让select显示全部
    if(params.auditStatus === 'all') params.auditStatus = ''
    if(params.status === 'all') params.status = ''

    const res = await getCombinationList(params)
    if (res.code != 0) {
      throw new Error(res.message)
    }
    list.value = res.value.result
    total.value = res.value.totalCount
  } catch (err) {
    Message.error((err as Error).message)
  } finally {
    setTimeout(() => {
      loading.value = false
    }, 400)
  }
}

//详情
const handleDetailClick = (data: CombinationDetail) => {
  console.log('%c [ data ]-71', 'font-size:13px; background:pink; color:#bf2c9f;', data)
  detailVisible.value = true
  detailId.value = data.id
  combinationCode.value = data.combinationCode

  // 开启分割模式
  splitSize.value = 0.5
  splitDisabled.value = false
}

//关闭详情
const closeDetail = () => {
  detailVisible.value = false
  // 关闭分割模式
  splitSize.value = 1
  splitDisabled.value = true
}
</script>