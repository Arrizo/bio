<template>
  <div class="combination-Detail">
    <a-tabs :style="{ width: '100%' }">
      <template #extra>
        <span class="iconfont icon-guanbianniu delStyle" @click="onClose"></span>
      </template>
      <a-tab-pane key="1" title="组合明细">
        <table-detail :id="props.id"></table-detail>
      </a-tab-pane>
      <a-tab-pane key="2" title="日志">
        <oms-log ref="logRef"></oms-log>
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script setup lang="ts" name="product-combination-Detail">
import { reactive, ref, watch, nextTick } from 'vue'
import TableDetail from './table-detail.vue'
import OmsLog from '@/components/oms-log/index.vue'

const props = defineProps({
  id: {
    type: Number,
    required: true
  },
  combinationCode: {
    type: String,
    required: true
  },

})

const logRef = ref()
watch(() => props.combinationCode,
  () => {
    nextTick(() => {
      logRef.value.init(props.combinationCode, "组合商品", "page")
    })
  }, {
  immediate: true,
})

const emits = defineEmits<{
  (e: "close"): void,
}>()

//关闭详情
const onClose = () => {
  emits('close')
}
</script>

<style lang="less">
.combination-Detail {
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 26px;
    color: rgba(112, 112, 112, 0.5);
    cursor: pointer;
  }

  .arco-tabs-content {
    padding-left: 16px;
    padding-right: 16px;
  }

  .arco-tabs-nav {
    padding: 0 16px;
  }
}
</style>