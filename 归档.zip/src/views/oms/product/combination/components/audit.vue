<!--
 * @ Author: zhangpeng
 * @ Create Time: 2023-02-20 13:58:59
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-14 09:49:48
 * @ Description: 组合商品表单
 -->
<template>
  <a-modal title="审核" width="500px" v-model:visible="showModal" title-align="start" :on-before-ok="onOk" unmountOnClose
    :esc-to-close="false" :mask-closable="false"  :on-before-cancel="handleClose" >

    <div class="form-tip" v-html="formTip"></div>

    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-form-item field="auditStatus" label="审核结果：" label-col-flex="100px"
        :rules="[{ required: true, message: '请选择审核结果' }]">
        <a-select placeholder="请选择" v-model="auditStatus">
          <a-option value="true">通过</a-option>
          <a-option value="false">不通过</a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="remark" label="备注：" label-col-flex="100px" :rules="checkRemark">
        <a-textarea :maxLength="200" v-limit-input="['#', '']" show-word-limit v-model.trim="form.remark"
          placeholder="限200字，如不通过则必填" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="product-combination-audit">
import { reactive, ref, computed } from 'vue'
import { auditByIdList } from '@/api/product/combination'
import { Message } from '@arco-design/web-vue'
import { AuditByIdListForm } from '@/types/product/combination'

const emits = defineEmits<{
  (e: "reload"): void
}>()

const showModal = ref(false)
const formRef = ref()
const auditStatus = ref('true')
const formTip = ref()
const form = ref<AuditByIdListForm>(new AuditByIdListForm())

//审核备注校验
const checkRemark = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (auditStatus.value == 'false' && (!value || value == "")) {
        callback("请输入审核备注")
        return
      }
    },
    required: auditStatus.value == 'false'
  },
])

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate()
  if (check) {
    return false
  }

  try {
    form.value.auditStatus = auditStatus.value === "true"
    const res = await auditByIdList(form.value)

    if (res.code != 0) {
      Message.error(res.message)
      return false
    }
    Message.success(`审核成功，审核${auditStatus.value === "true" ? '' : '不'}通过${res.value.successNum}条，忽略${res.value.skipNum}条`)
    emits("reload")
    handleClose()
    return true
  } catch (err) {
    Message.error((err as Error).message)
    return false
  }
}

/**
 * 打开编辑弹窗
 * @param lstId           id列表
 * @param isSingle        是否是单个组合后面的审核
 * @param combinationCode 组合编码
 */
const open = async (lstId: number[], isSingle: boolean = false, combinationCode: string = "") => {
  showModal.value = true
  form.value.lstId = lstId

  if (isSingle) {
    formTip.value = `确定审核 <span>${combinationCode}</span> 组合商品？`
  } else {
    formTip.value = `确定审核勾选的  <span>${lstId.length}</span> 个组合商品？`
  }
}

//关闭
const handleClose = async () => {
  showModal.value = false
  form.value = new AuditByIdListForm()
  auditStatus.value = 'true'
}

defineExpose({
  open
})
</script>
<style lang="less">
.form-tip {
  margin-bottom: 10px;

  &>span {
    color: rgb(var(--warning-6));
  }
}
</style>