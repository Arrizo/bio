<template>
  <a-modal title="添加商品" width="900px" v-model:visible="state.show" title-align="start" :on-before-ok="onOk"
    :on-before-cancel="handleClose" unmountOnClose :esc-to-close="false" :mask-closable="false">
    <!--  -->
    <oms-table :loading="loading" :total="total" :current="state.form.pageNum" :size="state.form.pageSize" @reload="onTableReload">
      <!-- 表单 -->
      <a-form ref="formRef" :model="state.form" layout="inline">
        <a-form-item field="code" label="编码：">
          <a-input v-limit-input v-model="state.form.code" allow-clear placeholder="请输入spu/sku编码" style="width:180px" />
        </a-form-item>
        <a-form-item field="name" label="名称：">
          <a-input v-limit-input v-model="state.form.name" allow-clear placeholder="请输入spu/sku名称" style="width:180px" />
        </a-form-item>
        <a-form-item field="remark" label="">
          <oms-search-btn :loading="loading" @search="fetchData" @clear="reset"></oms-search-btn>
        </a-form-item>
      </a-form>
      <!-- 表格 -->
      <a-table :data="(state.list as any)" :bordered="{ wrapper: false }" row-key="specCode" stripe
        :pagination="false" :row-selection="rowSelection" v-model:selectedKeys="selectedKeys"
        :span-method="objectSpanMethod" :scroll="{y:'320px'}" :style="{height: total?'320px':'393px'}">
        <template #columns>
          <a-table-column title="商品编码" :width="120" ellipsis tooltip>
            <template #cell="{ record }"> {{ record.productCode || '--' }} </template>
          </a-table-column>
          <a-table-column title="规格编码" :width="120" ellipsis tooltip>
            <template #cell="{ record }"> {{ record.specCode || '--' }} </template>
          </a-table-column>
          <a-table-column title="规格名称" :width="120" ellipsis tooltip>
            <template #cell="{ record }"> {{ record.specName || '--' }} </template>
          </a-table-column>
          <a-table-column title="规格型号" :width="120" ellipsis tooltip>
            <template #cell="{ record }"> {{ record.specModel || '--' }} </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </a-modal>
</template>

<script setup lang="ts" name="product-combination-edit-goods">
import { Message, TableRowSelection } from '@arco-design/web-vue'
import { reactive, ref } from 'vue'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import OmsTable from '@/components/oms-table/index.vue'
import { queryProductAndSpecList } from '@/api/product/purchase'
import { SpecListItem, ProductSpecItem } from '@/types/product/combination'

const rowSelection = reactive<TableRowSelection>({
  type: 'checkbox',
  showCheckedAll: true,
  onlyCurrent: false,
})

const emits = defineEmits(['reload', 'change'])

class goodsFormClass {
  code: string = ''
  name: string = ''
  pageNum: number = 1
  pageSize: number = 10
}

class Reactive {
  show: boolean = false
  list: SpecListItem[] = []
  form: goodsFormClass = new goodsFormClass()
  skuRandomCombination: boolean = false
}

const formRef = ref()
const total = ref()
const loading = ref<boolean>(false)
const selectedKeys = ref<string[]>([])
const state = reactive<Reactive>(new Reactive())

// 表格分页触发
const onTableReload = (data: { pageNum: number; pageSize: number }) => {
  state.form.pageNum = data.pageNum
  state.form.pageSize = data.pageSize
  fetchData()
}

/** 合并单元格 */
const objectSpanMethod = ({ record, columnIndex }) => {
  //未勾选sku随机组合，则直接返回
  if (!state.skuRandomCombination) return

  if (columnIndex === 0) {
    return {
      rowspan: record.rowSpan
    }
  }
}

/** 查询数据 */
const fetchData = async () => {
  try {
    loading.value = true
    const { code, message, value } = await queryProductAndSpecList(state.form)
    if (code != 0) {
      throw new Error(message)
    }
    var list = value.result
    var totalArr: any = []
    var arr: any = []
    list.forEach((item: ProductSpecItem, index: number) => {
      arr.push(item)
      if ((list[index + 1] && item.productCode !== list[index + 1].productCode) || !list[index + 1]) {
        arr.forEach((it: ProductSpecItem, ind: number) => {
          if (ind === 0) {
            it.rowSpan = arr.length
          } else {
            it.rowSpan = 0
          }
        })
        totalArr.push(...arr)
        arr = []
      }
    })

    state.list = totalArr.map((item: ProductSpecItem) => {
      var data = new SpecListItem()
      data.productCode = item.productCode
      data.productTitle = item.productTitle
      data.specCode = item.specsCode
      data.specModel = item.specsModel
      data.specName = item.specsTitle
      return data
    })

    total.value = value.totalCount
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}

/** 重置 */
const reset = () => {
  state.form = new goodsFormClass()
  fetchData()
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  if (!selectedKeys.value.length) {
    Message.error('请选择商品')
    return false
  }

  let list = []
  selectedKeys.value.map(specCode => {
    var res =  state.list.find(item => item.specCode === specCode)
    if(res) list.push(res)
  })

  handleClose()
  emits('change', list)
  return true
}

// 关闭
const handleClose = () => {
  state.show = false
  state.list = []
  selectedKeys.value = []
  total.value = 0
  state.form = new goodsFormClass()
}

/**
 * open弹窗
 * @param skuRandomCombination sku随机组合
 * @param originalSpecList 选中的列表数据
 */
const open = async (skuRandomCombination: boolean, originalSpecList: any) => {
  state.show = true
  state.skuRandomCombination = skuRandomCombination
  //回显
  selectedKeys.value = originalSpecList.map((item:any) => item.specCode)
}

defineExpose({
  open
})
</script>
<style lang="less" scoped>
.form-tip {
  color: rgb(var(--warning-6))
}

::v-deep(.arco-table-tr-empty .arco-table-td){
  height:354px
}
</style>