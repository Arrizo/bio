<template>
  <oms-table :loading="loading">
    <a-table :data="(list as any)" :pagination="false" hide-expand-button-on-empty row-key="id"
      :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="商品编码" :min-width="180" data-index="productCode"></a-table-column>
        <a-table-column title="规格编码" :min-width="180" data-index="specCode"></a-table-column>
        <a-table-column title="规格名称" :min-width="180" data-index="specName"></a-table-column>
        <a-table-column title="规格型号" :min-width="180" data-index="specModel"></a-table-column>
        <a-table-column title="数量" :min-width="180" data-index="number"></a-table-column>
        <a-table-column title="主商品" :min-width="180" data-index="masterProduct">
          <template #cell="{ record }"> {{ MasterProduct[record.masterProduct] || '--'  }} </template>
        </a-table-column>
        <a-table-column title="分摊比例/金额" :min-width="180" data-index="apportionmentRatio"></a-table-column>
      </template>
    </a-table>
  </oms-table>
</template>

<script setup lang="ts" name="product-combination-table-detail">
import { reactive, ref, watch } from 'vue'
import OmsTable from '@/components/oms-table/index.vue'
import { Message } from '@arco-design/web-vue'
import { getCombinationDetail } from '@/api/product/combination'
import { CombinationDetail, MasterProduct } from '@/types/product/combination'

let loading = ref(false)
const list = ref<CombinationDetail[]>()

const props = defineProps({
  id: {
    type: Number,
    required: true
  },
})

//拉取信息
const fetchData = async () => {
  try {
    loading.value = true
    const res = await getCombinationDetail(props.id)
    if (res.code != 0) {
      throw new Error(res.message)
    }
    list.value = res.value.specList
  } catch (err) {
    Message.error((err as Error).message)
    return false
  } finally {
    loading.value = false
  }

}

watch(
  () => props.id,
  () => {
    fetchData()
  }, {
  immediate: true,
}
)
</script>