<!--
 * @ Author: zhangpeng
 * @ Create Time: 2023-02-20 08:49:21
 * @ Modified by: zhangpeng
 * @ Modified time: 2023-02-25 13:57:14
 * @ Description: 组合商品-搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRef">
    <a-form-item field="combinationCode" label="组合编码：">
      <a-input v-limit-input v-model="form.combinationCode" @keyup.enter="handleSearch" placeholder="请输入组合编码"  allow-clear/>
    </a-form-item>
    <a-form-item field="combinationName" label="组合名称：">
      <a-input v-limit-input v-model="form.combinationName" @keyup.enter="handleSearch" placeholder="请输入组合名称"  allow-clear/>
    </a-form-item>
    <a-form-item field="auditStatus" label="审核状态：">
      <a-select placeholder="请选择" v-model="form.auditStatus" >
        <a-option value="all">全部</a-option>
        <a-option value="STASH">暂存</a-option>
        <a-option value="WAIT_AUDIT">待审核</a-option>
        <a-option value="AUDIT_PASS">通过</a-option>
        <a-option value="NO_PASS">不通过</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="form.status"  >
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="props.loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="product-combination-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { CombinationListForm } from '@/types/product/combination';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: "on-search", data: any): void;
}>();

const formRef = ref();
const form = ref<CombinationListForm>(new CombinationListForm());

// 搜索
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRef.value.resetFields();
  handleSearch();
}

onMounted(() => {
  handleSearch();
});
</script>