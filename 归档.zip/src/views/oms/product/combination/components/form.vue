<!--
 * @ Author: zhangpeng
 * @ Create Time: 2023-02-20 13:58:59
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 11:33:07
 * @ Description: 组合商品表单
 -->
<template>
  <a-modal :title="`${modal.type === 'add' ? '新增' : '编辑'}组合`" width="1100px" v-model:visible="modal.show"
    title-align="start" unmountOnClose :esc-to-close="false" :mask-closable="false">
    <a-form ref="formRef" :model="form" layout="inline">
      <a-form-item field="combinationCode" label="组合编码：" label-col-flex="90px">
        <a-input v-limit-input v-model="form.combinationCode" allow-clear :max-length="20" placeholder="系统自动生成" disabled
          @input="form.combinationCode = form.combinationCode.replace(/[^A-Za-z0-9-_]/g, '')" />
      </a-form-item>
      <a-form-item field="combinationName" label="组合名称：" label-col-flex="90px"
        :rules="[{ required: true, message: '请输入组合名称' }]">
        <a-input v-limit-input v-model="form.combinationName" placeholder="请输入（中文名称）" :max-length="200" allow-clear
          show-word-limit />
      </a-form-item>
      <a-form-item field="barcode" label="条码：" label-col-flex="90px">
        <a-input v-limit-input v-model="form.barcode" allow-clear :max-length="20" placeholder="请输入" />
      </a-form-item>
      <a-form-item field="storeId" label="店铺名称：" label-col-flex="90px" :rules="[{ required: true, message: '请选择店铺名称' }]">
        <a-select placeholder="请选择" v-model="form.storeId" allow-search>
          <a-option :label="item.storeName" :value="item.id" v-for="(item, index) in shopList"
            :key="`${index}-storeCode`"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="code" label="重量(g)：" label-col-flex="90px">
        <a-input-number v-model="form.weight as any" :min="0" allow-clear placeholder="请输入" :max="99999" :precision="4"
          :formatter="numFormatter" />
      </a-form-item>
      <a-form-item field="code" label="长宽高(cm)：" label-col-flex="90px">
        <a-space :size="8">
          <a-input-number v-model="form.length as any" :min="0" placeholder="长" class="form-input" hide-button :max="999"
            :precision="4" :formatter="numFormatter" />
          <a-input-number v-model="form.width as any" :min="0" placeholder="宽" class="form-input" hide-button :max="999"
            :precision="4" :formatter="numFormatter" />
          <a-input-number v-model="form.height as any" :min="0" placeholder="高" class="form-input" hide-button :max="999"
            :precision="4" :formatter="numFormatter" />
          <a-input-number v-model="volume" :min="0" placeholder="体积" class="form-input" hide-button :precision="4"
            :formatter="numFormatter" :max="999999999" />
        </a-space>
      </a-form-item>
      <a-form-item field="code" label="设置：" label-col-flex="90px" style="width:100%">
        <a-space :size="50">
          <a-checkbox v-model="form.prePackaging">预包装</a-checkbox>
          <a-checkbox v-model="form.skuRandomCombination" :disabled="modal.type === 'edit'" @change="onSkuRandomChange">
            <a-row align="center">
              sku随机组合
              <a-tooltip content="sku随机组合保存后不可修改">
                <i class="iconfont icon-wenhao" style="margin-top: 2px;margin-left:5px;color:#888" />
              </a-tooltip>
            </a-row>
          </a-checkbox>
        </a-space>
      </a-form-item>
      <a-form-item field="pictureList" label="商品主图：" label-col-flex="90px" style="width:100%">
        <div>
          <p style="font-size: 12px;color: #B1B1B1;margin:0;line-height: 32px;">
            最多上传5张图片，建议尺寸800*800px，每张不超过1M，支持格式jpg/png/gif，可拖动调整图片顺序。第一张为主图</p>
          <image-uploader v-model="form.pictureList" :limit="5" :size="1 * 1024 * 1024"></image-uploader>
        </div>
      </a-form-item>
      <a-form-item field="attachment" label="上传附件：" label-col-flex="90px">
        <file-uploader v-model="form.attachment" download file-type="3" :size="10 * 1024 * 1024"></file-uploader>
      </a-form-item>
    </a-form>

    <a-space :size="14" style="margin-bottom:10px">
      <a-button type="primary" @click="addGoods()"> 添加商品 </a-button>
    </a-space>

    <!-- 提示 -->
    <div class="form-tip" v-html="formTip"></div>

    <a-table :data="(form.specList as any)" :pagination="false" hide-expand-button-on-empty row-key="id"
      :bordered="{ wrapper: false }" :scroll="{ y: 160 }" stripe>
      <template #columns>
        <a-table-column title="商品编码" :width="110" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.productCode || '--' }} </template>
        </a-table-column>
        <a-table-column title="规格编码" :width="110" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.specCode || '--' }} </template>
        </a-table-column>
        <a-table-column title="规格名称" :width="140" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.specName || '--' }} </template>
        </a-table-column>
        <a-table-column title="规格型号" :width="140" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.specModel || '--' }} </template>
        </a-table-column>
        <a-table-column title="数量" :width="110" ellipsis tooltip>
          <template #cell="{ record }">
            <a-input-number v-limit-input v-model="record.number" :min="0" :max="99999" allow-clear placeholder="请输入"
              hide-button :formatter="formatter" />
          </template>
        </a-table-column>
        <a-table-column title="分摊比例%" :width="120" ellipsis tooltip>
          <template #cell="{ record }">
            <a-input-number v-limit-input v-model="record.apportionmentRatio" :min="0" :max="100" allow-clear
              placeholder="%" :precision="4" :formatter="numFormatter" hide-button />
          </template>
        </a-table-column>
        <a-table-column title="主商品" :width="180" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-checkbox :model-value="record.masterProduct === 1"
                @change="onMasterProductChange($event, record, 1)">主商品</a-checkbox>
              <a-checkbox :model-value="record.masterProduct === 2"
                @change="onMasterProductChange($event, record, 2)">赠品</a-checkbox>
            </a-space>
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="80" fixed="right">
          <template #cell="{rowIndex}">
            <a-space :size="14">
              <a-link status="danger" @click="remove(rowIndex)" type="text">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
    <template #footer>
      <a-space :size="14" style="margin-bottom:10px">
        <a-button @click="handleClose"> 取消 </a-button>
        <a-button type="outline" @click="onOk(2)"> 暂存 </a-button>
        <a-button type="primary" @click="onOk(1)"> 提交 </a-button>
      </a-space>
    </template>
  </a-modal>


  <!-- 新增/编辑商品 -->
  <!-- <edit-goods ref="addGoodsRef"></edit-goods> -->
  <AddGoods ref="addGoodsRef" @change="onGoodsChange"></AddGoods>

  <!-- 删除二次确认 -->
  <oms-warning ref="warningRef" :on-before-ok="handleRemove"></oms-warning>
</template>

<script setup lang="ts" name="product-combination-form">
import { reactive, ref, computed, h, nextTick } from 'vue'
import { addOrUpdate, getCombinationDetail, queryUserStore} from '@/api/product/combination'
import { Message, Modal } from '@arco-design/web-vue'
import { AddOrUpdateForm, SpecListItem } from '@/types/product/combination'
import { uniqueArray } from '@/utils/helper'
import { accAdd } from '@/utils/calculateUtil'
import AddGoods from './add-goods.vue'
import OmsTable from '@/components/oms-table/index.vue'
import OmsWarning from '@/components/oms-warning/index.vue'
import imageUploader from '@/components/image-uploader/index.vue'
import fileUploader from '@/components/file-uploader/index.vue'
import { ShopSelectItem } from '@/types/product/distribution'
import { IconExclamationCircleFill } from '@arco-design/web-vue/es/icon/index'

class EditModal {
  show: boolean = false
  type: "add" | "edit" = "add"
  volumeBak: number | undefined = undefined
}

const formRef = ref()
const addGoodsRef = ref()
const warningRef = ref()
const curRowIndex = ref()
const modal = reactive(new EditModal())
const emits = defineEmits(['reload'])
const form = ref<AddOrUpdateForm>(new AddOrUpdateForm())
const shopList = ref<ShopSelectItem[]>([])
const originalSpecList = ref<SpecListItem[]>([])

// 克隆
const clone = (obj: any) => {
  return JSON.parse(JSON.stringify(obj))
}

// 提示
const formTip = computed(() => {
  let res = "注：多个SKU组合时，请保持分摊比例总和为100%"
  if (form.value.skuRandomCombination) {
    res = "注：同一SPU不同规格随机组合时，请保持数量一致；不同spu组合请保持分摊比例总和为100%"
  }
  return res
})

// 体积
const volume = computed({
  get () {
    if (modal.volumeBak) {
      return modal.volumeBak
    } else {
      let length = form.value.length || 0
      let width = form.value.width || 0
      let height = form.value.height || 0
      return length * width * height || undefined
    }
  },
  set (value: number | undefined) {
    modal.volumeBak = value
  }
})

// 数量只能输入整数
const formatter = (value: any) => {
  const values = value.split('.')
  return values[0]
}

// 输入框只能输入前四位小数
const numFormatter = (value: any) => {
  var res = value.match(/(\d+)?\.?(\d{0,4})?/g)
  return res?.length ? res[0] : value
}

// 查询店铺列表
const handleQueryUserStore = async () => {
  try {
    let response = await queryUserStore()
    if (response?.success) {
      shopList.value = response?.value ?? []
    } else {
      Message.warning(response?.message || '查询店铺列表失败')
    }
  } catch (e) {
    console.error(e)
    Message.warning("查询店铺列表失败")
  }
}


/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const open = async (type: "add" | "edit", data: number) => {
  modal.type = type
  modal.show = true

  handleQueryUserStore()

  if (type === 'add') {
    form.value = new AddOrUpdateForm()
  }

  if (type === "edit") {
    try {
      const res = await getCombinationDetail(data)
      if (res.code != 0) {
        Message.error(res.message)
        return
      }

      //转数字。。。
      let value = res.value
      value.length = value.length ? Number(value.length) : ''
      value.width = value.width ? Number(value.width) : ''
      value.height = value.height ? Number(value.height) : ''
      value.volume = value.volume ? Number(value.volume) : ''
      value.weight = value.weight ? Number(value.weight) : ''
      originalSpecList.value = JSON.parse(JSON.stringify(value.specList))

      //处理sku随机组合
      if (res.value.skuRandomCombination) {
        var newList = mergeArray(originalSpecList.value, 'productCode')
        res.value.specList = newList
      }

      res.value.specList.map((item:any) => {
        item.number = item.number ? Number(item.number) : 0
        item.apportionmentRatio = item.apportionmentRatio ? Number(item.apportionmentRatio) : 0
      })

      form.value = res.value
      volume.value = res.value.volume
    } catch (err) {
      Message.error((err as Error).message)
    }
  }
}

// 添加/编辑
const addGoods = () => {
  addGoodsRef.value.open(form.value.skuRandomCombination, originalSpecList.value)
}

// 点击sku随机组合
const onSkuRandomChange = (value: any) => {
  if (form.value.specList.length) {
    const ModalContent = {
      setup () {
        return () => h('div', { style: { display: 'flex' } }, [
          h('div', { style: { 'margin-right': '10px' } }, [
            h(IconExclamationCircleFill, { style: { color: 'rgb(245, 154, 35)', fontSize: '30px' } })
          ]),
          h('div', {}, [
            h('div', { style: 'margin-bottom: 10px;' }, '组合商品明细表中已添加了商品，'),
            h('div', {}, '此操作会清除重新添加，是否继续？'),
          ]),
        ])
      },
    }
    Modal.open({
      title: '提示',
      titleAlign: 'start',
      content: () => h(ModalContent),
      onOk: async () => {
        form.value.specList = []
        originalSpecList.value = []
      },
      onCancel: async () => {
        //取消则需复原
        nextTick(() => {
          form.value.skuRandomCombination = !form.value.skuRandomCombination
        })
      }
    })
  }
}

// 删除
const remove = (index: number) => {
  curRowIndex.value = index
  warningRef.value.open({ title: "提示", content: `确定要删除？` })
}

// 执行删除
const handleRemove = async () => {
  form.value.specList.splice(curRowIndex.value, 1)
  originalSpecList.value.splice(curRowIndex.value, 1)
}

// 添加或编辑商品事件
const onGoodsChange = (list: SpecListItem[]) => {
  console.log('%c [ list ]-336', 'font-size:13px; background:pink; color:#bf2c9f;', list)
  //原始数据
  originalSpecList.value.push(...list)
  originalSpecList.value = uniqueArray(originalSpecList.value, "specCode")

  //sku随机组合
  if (form.value.skuRandomCombination) {
    var newList = mergeArray(originalSpecList.value, 'productCode')

    //找到原有数据进行填充
    newList.map((item:any)=>{
      var res = form.value.specList.find(obj=>obj.productCode === item.productCode)
      if(res){
        item.number = res.number
        item.masterProduct = res.masterProduct
        item.apportionmentRatio = res.apportionmentRatio
      }
    })

    form.value.specList = newList
  } else {
    form.value.specList!.push(...list)
  }
  form.value.specList = uniqueArray(form.value.specList, "specCode")

}

// 处理sku随机组合=>根据productCode合并数组里的specName和specModel
const mergeArray = (arr: any, field: string) => {
  const map = new Map()
  arr.forEach((obj: any) => {
    const key = obj[field]
    if (map.has(key)) {
      map.get(key).push(obj)
    } else {
      map.set(key, [obj])
    }
  })
  const result: any = []
  map.forEach((objs: any) => {
    const mergedObj = objs.reduce((obj: SpecListItem, cur: SpecListItem) => {
      obj.masterProduct = cur.masterProduct
      obj.productCode = cur.productCode
      obj.productTitle = cur.productTitle
      obj.number = cur.number ||  obj.number
      obj.masterProduct = cur.masterProduct ||  obj.masterProduct
      obj.apportionmentRatio = cur.apportionmentRatio ||  obj.apportionmentRatio
      obj.specCode += (obj.specCode ? ";" : "") + cur.specCode
      obj.specModel += (obj.specModel ? ";" : "") + cur.specModel
      obj.specName += (obj.specName ? ";" : "") + cur.specName
      return obj
    }, new SpecListItem())
    result.push(mergedObj)
  })
  return result
}



// 拆分数组，生成能提交的数据
const handleSpecList = (list: any) => {
  if (!list || !list.length) return []

  var newList = originalSpecList.value.map((item: SpecListItem) => {
    var res: SpecListItem | undefined = undefined
    if(form.value.skuRandomCombination){
      res = list.find((sub: SpecListItem) => sub.productCode === item.productCode)
    }else{
      res = list.find((sub: SpecListItem) => sub.specCode === item.specCode)
    }
    item.apportionmentRatio = res!.apportionmentRatio
    item.number = res!.number
    item.masterProduct = res!.masterProduct
    return item
  })

  return newList
}

// 主商品
const onMasterProductChange = (checked: any, record: any, type: number) => {
  if (checked) {
    if (type === 1) {
      //如果勾选了主商品
      form.value.specList.map((item: SpecListItem) => {
        //取消所有主商品
        if (item.masterProduct === 1) item.masterProduct = ''
      })
    }
    record.masterProduct = type
  } else {
    record.masterProduct = ""
  }
}

/**
 * 点击确定按钮前触发
 * @param submitType 提交类型 1提交 2暂存
 */
const onOk = async (submitType: number = 1) => {
  const check = await formRef.value.validate()
  if (check) {
    return false
  }

  let list = form.value.specList
  if (!list.length) {
    Message.error('请添加商品')
    return false
  }

  let checkNum = list.every((item) => !!(item.number))
  if (!checkNum) {
    Message.error('请填写数量')
    return false
  }

  let checkApportionmentRatio = list.every((item) => item.apportionmentRatio! >= 0)
  if (!checkApportionmentRatio) {
    Message.error('请填写分摊比例')
    return false
  }

  let apportionmentRatioTotal = list.reduce(function (total, current) {
    return accAdd(total, current!.apportionmentRatio!)
  }, 0)

  if (apportionmentRatioTotal < 100 || apportionmentRatioTotal > 100) {
    Message.error('请保持分摊比例总和为100%')
    return false
  }

  try {
    var data = clone(form.value)
    //体积
    if (modal.volumeBak) {
      data.volume = modal.volumeBak
    }
    //将原始specList添加number和apportionmentRatio再传进去
    data.specList = handleSpecList(data.specList)

    //转回接口需要的字符串。。。
    data.length = String(data.length || '')
    data.width = String(data.width || '')
    data.height = String(data.height || '')
    data.volume = String(data.volume || '')
    data.weight = String(data.weight || '')

    //提交还是暂存
    data.submitType = submitType

    //清理一下
    delete data.createTime
    delete data.updateTime

    const res = await addOrUpdate(data)
    if (res.code != 0) {
      Message.error(res.message)
      return false
    }
    Message.success(res.message)
    handleClose()
    emits("reload")
    return true
  } catch (err) {
    Message.error((err as Error).message)
    return false
  }
}
// 关闭弹框
const handleClose = () => {
  modal.show = false
  originalSpecList.value = []
  modal.volumeBak = undefined
  form.value = new AddOrUpdateForm()
}

defineExpose({
  open
})
</script>

<style lang="less" scoped>
:deep(.arco-form-item) {
  width: 320px
}

.form-input {
  padding-left: 5px;
  padding-right: 5px;
}

.form-tip {
  color: rgb(var(--warning-6))
}
</style>