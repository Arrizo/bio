<!--
 * @ Author: zhangpeng
 * @ Create Time: 2023-02-20 09:14:30
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-27 20:16:01
 * @ Description: 组合商品列表
 -->

<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onTableReload">
    <template #header-left>
      <a-space :size="14" style="margin-bottom:10px">
        <a-button type="primary" status="normal" @click="handleAddClick"
        v-permission="['oms:product:combination:add']"> 新增 </a-button>
        <a-button status="normal" @click="handleAuditClick" :disabled="selectedKeys.length <= 0"
        v-permission="['oms:product:combination:audit']"> 审核 </a-button>
      </a-space>
    </template>

    <a-table :data="(list as any)" :pagination="false" hide-expand-button-on-empty row-key="id"
      :bordered="{ wrapper: false }" :row-selection="rowSelection" :scroll="{ x: 1400 }" v-db-click="list"
      :db-call-back="handleDetailClick" v-model:selectedKeys="selectedKeys" stripe>
      <template #columns>
        <a-table-column title="组合编码" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.combinationCode || '--' }} </template>
        </a-table-column>
        <a-table-column title="组合名称" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.combinationName || '--' }} </template>
        </a-table-column>
        <a-table-column title="店铺" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.storeName || '--' }} </template>
        </a-table-column>
        <a-table-column title="sku随机" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.skuRandomCombination ? '是' : '否' }} </template>
        </a-table-column>
        <a-table-column title="预包装" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.prePackaging ? '是' : '否' }} </template>
        </a-table-column>
        <a-table-column title="备注" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.remark || '--' }} </template>
        </a-table-column>
        <a-table-column title="审核状态" :width="120" ellipsis tooltip>
          <template #cell="{ record }">
            <oms-tag :type="auditStatusTagObj[record.auditStatus]" v-if="record.auditStatus"
              :content="auditStatusObj[record.auditStatus]"></oms-tag>
              <div v-else>--</div>
            </template>
        </a-table-column>
        <a-table-column title="状态" :width="120">
          <template #cell="{ record, rowIndex }">
            <div v-permission="['system:role:status']">
              <a-switch v-model="(list as any)[rowIndex].status" @focus="onSwitchForce(record, rowIndex)">
                <template #checked>
                  启用
                </template>
                <template #unchecked>
                  禁用
                </template>
              </a-switch>
            </div>
            <div v-permission-else="['system:role:status']">{{ record.status ? '启用' : '禁用' }}</div>
          </template>
        </a-table-column>
        <a-table-column title="更新时间" :width="180" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.updateTime || '--' }} </template>
        </a-table-column>
        <a-table-column title="操作" :width="80" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link @click="handleAction('edit', record)" type="text"
              v-permission="['oms:product:combination:edit']"
              v-if="record.auditStatus !== 'WAIT_AUDIT'">编辑</a-link>
              <a-link @click="handleAction('audit', record)" type="text"
              v-permission="['oms:product:combination:audit']"
                v-if="record.auditStatus === 'WAIT_AUDIT'">审核</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑弹窗 -->
  <combination-form ref="combinationRef" @reload="emits('reload')"></combination-form>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleUpdateStatus"></oms-warning>

  <!-- 审核 -->
  <combination-audit ref="auditRef" @reload="(emits('reload'), selectedKeys=[])"></combination-audit>
</template>

<script setup lang="ts" name="product-combination-list">
import { reactive, ref } from 'vue'
import OmsTable from '@/components/oms-table/index.vue'
import OmsWarning from '@/components/oms-warning/index.vue'
import OmsTag from '@/components/oms-tag/index.vue'
import { getCombinationList, updateStatus } from '@/api/product/combination'
import { Message, TableRowSelection } from '@arco-design/web-vue'
import CombinationForm from "./form.vue"
import CombinationAudit from './audit.vue'
import { CombinationDetail } from '@/types/product/combination'

/**
 * 审核状态:STASH-暂存，WAIT_AUDIT-待审核，AUDIT_PASS-通过，NO_PASS-不通过
 */
 const auditStatusObj = {
  "AUDIT_PASS" : '通过',
  "NO_PASS" :'不通过',
  "STASH" :'暂存',
  "WAIT_AUDIT" :'待审核',
}

 const auditStatusTagObj = {
  "AUDIT_PASS" : 'normal',
  "NO_PASS" : 'warring',
  "STASH" : 'normal',
  "WAIT_AUDIT": 'progress',
}

const rowSelection: TableRowSelection = reactive({
  type: 'checkbox',
  showCheckedAll: true,
  checkStrictly: false   //是否开启严格选择模式 (default: true)
})

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  total: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
})

const emits = defineEmits(['reload', 'showDetail'])

const selectedKeys = ref<string[]>([])
const auditRef = ref()
const switchRef = ref()
const combinationRef = ref()
const statusData = reactive({
  id: NaN,
  index: NaN
})


// 「新增」按钮点击触发
const handleAddClick = () => {
  combinationRef.value.open("add")
}

// 「审核」按钮点击触发
const handleAuditClick = () => {
  auditRef.value.open(selectedKeys.value)
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: any, index: number) => {
  statusData.id = record?.id
  statusData.index = index
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` })
}

// 表格分页触发
const onTableReload = (data: { pageNum: number; pageSize: number }) => {
  emits('reload', data)
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleAction = async (type: "edit" | "audit", data?: CombinationDetail) => {
  switch (type) {
    case "edit":
      combinationRef.value.open("edit", data?.id)
      break
    case "audit":
      auditRef.value.open([data?.id], true, data?.combinationCode)
      break
    default:
      break
  }
}

// 修改状态
const handleUpdateStatus = async () => {
  try {
    const res = await updateStatus(statusData.id)
    if (res.code != 0) {
      throw new Error(res.message)
    }
    Message.success(res.message)
    emits("reload")
  } catch (err) {
    Message.error((err as Error).message)
    return false
  }
}

// 详情
const handleDetailClick = (data: CombinationDetail) => {
  emits('showDetail', data)
}

</script>