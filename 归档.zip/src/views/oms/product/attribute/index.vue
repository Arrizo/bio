<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-03 17:52:48
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-10 14:09:20
 * @FilePath: \oms-admin\src\views\oms\product\attribute\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <oms-panel style="height: 100%;">
    <template #header>
      <search :loading="loading" @on-search="initMethod"></search>
    </template>
    <list :loading="loading" :total="total" :attr-list="tableData" :page-num="form.pageNum" :page-size="form.pageSize"
      @reload="initMethod"></list>
  </oms-panel>
</template>
<script lang="ts" setup name="goods-brand">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue'
import List from './components/list.vue'
import commoMethod from './commoMethod'
const {
  form,
  total,
  loading,
  initMethod,
  tableData
} = commoMethod()
</script>