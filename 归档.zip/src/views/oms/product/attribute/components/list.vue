<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 10:46:56
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-09 17:25:43
 * @FilePath: \oms-admin\src\views\oms\basicdata\goods-brand\components\list\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onReload">
    <template #header-left>
      <a-button type="primary" status="normal" @click="handleAdd()" style="margin-bottom: 10px;" v-permission="['oms:product:attribute:add']">新增</a-button>
    </template>
    <a-table :data="attrList" :pagination="false" hide-expand-button-on-empty :scroll="{ y: 650, x: 1400 }" stripe
      :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
          <template #cell="{ rowIndex }">
            {{ rowIndex + 1 }}
          </template>
        </a-table-column>
        <a-table-column title="属性名称" :tooltip="true" ellipsis>
          <template #cell="{ record }">
            {{ record.attrName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="输入类型" :tooltip="true" ellipsis>
          <template #cell="{ record }">
            {{ record.inputTypeName  || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="数据字典" :tooltip="true" ellipsis>
          <template #cell="{ record }">
            {{ record.dictionaryName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="备注" :tooltip="true" ellipsis>
          <template #cell="{ record }">
            {{ record.remark || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="状态" :tooltip="true" :width="120" ellipsis>
          <template #cell="{ record }">
            <a-switch v-model="record.status" @focus="onSwitchForce(record)" v-permission="['oms:product:attribute:status']">
              <template #checked>
                启用
              </template>
              <template #unchecked>
                禁用
              </template>
            </a-switch>
          </template>
        </a-table-column>
        <a-table-column title="更新时间" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.updateTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="操作" :tooltip="true" :width="120" ellipsis fixed="right">
          <template #cell="{ record }">
            <a-space :size="10">
              <a-link type="text" @click="handleAdd(record)" v-permission="['oms:product:attribute:edit']" >编辑</a-link>
              <a-link type="text" @click="openLog(record)" v-permission="['oms:product:attribute:log']">日志</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
  <oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
  <oms-log ref="logRefs"></oms-log>
  <attr-modal ref="attrModalRef" @reloadTable="onReload"></attr-modal>
</template>
<script lang="ts" setup name="brand-list">
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import { ref } from 'vue'
import { AttributeDetailsType, AttributeSearchType } from '@/types/product/attribute'
import { setAttributeOnOrDrop } from '@/api/product/attribute'
import attrModal from '../components/attrModal.vue'
import { Message } from '@arco-design/web-vue';
import omsLog from '@/components/oms-log/index.vue';
const emits = defineEmits<{
  (e: "reload", data?: AttributeSearchType): void
}>()
// 勾选状态id
const statusId = ref()
const attrModalRef = ref()
const switchRef = ref()
const logRefs = ref()
interface PropsType {
  loading: boolean
  total: number
  pageNum: number
  pageSize: number
  attrList: Array<AttributeDetailsType>
}
const props = defineProps<PropsType>();
const onReload = (data?: AttributeSearchType) => {
  emits('reload', data)
}
const handleAdd = (record?: AttributeDetailsType) => {
  attrModalRef.value.queryBrandDetails(record?.id)
}
const beforeChange = async () => {
  try {
    const res = await setAttributeOnOrDrop(statusId.value)
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success('更新成功')
    emits('reload')
  } catch (err) {
    Message.error((err as Error).message);
  }
}
// 修改状态事件
const onSwitchForce = (record: any) => {
  statusId.value = record?.id + ''
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}
const openLog = (record: AttributeDetailsType) => {
  logRefs.value.init(record?.logCode, '商品属性')
}
</script>