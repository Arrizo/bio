<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 16:52:06
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-14 10:02:52
 * @FilePath: \oms-admin\src\views\oms\basicdata\goods-brand\components\brand-modal\index.vue
-->
<template>
  <a-modal :width="600" :title="titleName" v-model:visible="showBrandModal" title-align="start" :on-before-ok="onBeforeOk"
    :mask-closable="false">
    <a-form :model="form" auto-label-width ref="brandFormRef" :rules="formRules">
      <a-form-item label="属性名称：" field="attrName">
        <a-input v-model.trim="form.attrName" allow-clear placeholder="请输入" :max-length="20"></a-input>
      </a-form-item>
      <a-form-item label="类型：" field="inputType">
        <a-select v-model="form.inputType" allow-search placeholder="请输入" @change="changeType">
          <a-option :value="item.dictionaryValue" v-for="(item, index) in inputTppe" :key="`${index}-diction`">{{
            item.dictionaryTitle }}</a-option>
        </a-select>
      </a-form-item>
      <a-form-item label="数据字典：" :field="form.inputType=='dataDictionary'?'dictionaryType':''" v-if="form.inputType=='dataDictionary'">
        <a-select v-model="form.dictionaryType" allow-search placeholder="请输入">
          <a-option :value="item.dictionaryType" v-for="(item, index) in dictionaryName" :key="`${index}-type`">{{item.dictionaryName}}</a-option>
        </a-select>
      </a-form-item>
      <a-form-item label="备注：" field="remark">
        <a-textarea v-model.trim="form.remark" show-word-limit placeholder="请输入（限200个字）"
          :max-length="200"></a-textarea>
      </a-form-item>
    </a-form>
  </a-modal>
</template>
<script setup lang="ts" name="brand-modal">
import { ref, reactive, computed, watch } from 'vue'
import { AttributeDetailsType, AttributeSearchType } from '@/types/product/attribute'
import { attributeAddOrUpdate, getAttributeDetails } from '@/api/product/attribute'
import commoMethod from '@/views/oms/product/purchase/commo-method/index'
import { getNameList } from '@/api/system/dictionary'
import { Message } from '@arco-design/web-vue'
let form = reactive<AttributeDetailsType>(new AttributeDetailsType())
const { getCompanyTypeList } = commoMethod()
const showBrandModal = ref(false)
const brandFormRef = ref()
const dictionaryName = ref()
const inputTppe = ref()
const emits = defineEmits<{
  (e: "reloadTable", data?: AttributeSearchType): void
}>()
const formRules = reactive({
  attrName: [
    { required: true, message: '请输入属性' }
  ],
  inputType: [
    { required: true, message: '请选择类型' }
  ],
  dictionaryType: [
    { required: true, message: '请选择数据字典' }
  ],
})
const titleName = computed(() => `${form.id ? '编辑' : '新增'}属性`)
// 关闭弹窗前数据检验
const onBeforeOk = async () => {
  const valid = await brandFormRef.value.validate()
  if (valid) { return false }
  const res = await attributeAddOrUpdate(form)
  if (res.code != 0) {
    Message.error(res.message)
    return false
  }
  Message.success('操作成功！')
  emits('reloadTable')
  return true
}
const queryNameList = async () => {
  try {
    const { code, value, message } = await getNameList()
    dictionaryName.value = value
  } catch (error) {
    console.log(error)
  }
}
watch(() => showBrandModal.value, async (nV) => {
  if (nV) {
    queryNameList()
    inputTppe.value = await getCompanyTypeList('INPUT_TYPE')
  }
  else {
    brandFormRef.value.clearValidate()
    brandFormRef.value.resetFields()
    form.inputType='dataDictionary'
  }
})
const changeType=(val:any)=>{
  if(val=='text'){
    form.dictionaryType=''
  }
}
const queryBrandDetails = async (id?: any) => {
  showBrandModal.value = true
  form.id = id ?? ''
  try {
    if (id) {
      const { code, value, message } = await getAttributeDetails(id)
      if (code != 0) {
        throw new Error(message)
      }
      Object.assign(form, value)
    }
  } catch (error) {
    Message.error((error as Error).message)
  }
}
defineExpose({
  queryBrandDetails
})
</script>