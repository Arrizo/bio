<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-22 16:32:18
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-13 16:54:26
 * @FilePath: \oms-admin\src\views\oms\product\brand\components\search\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-form :model="form" layout="inline" ref="searchRef">
    <a-form-item field="attrName" label="属性名称：">
      <a-input v-model.trim="form.attrName" placeholder="请输入属性" allow-clear :max-length="20" :style="{ width: '200px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="form.status" :style="{ width: '200px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>
<script setup lang="ts" name="goods-brand-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { AttributeSearchType } from '@/types/product/attribute'
import { deepClone } from '@/utils/helper';
import { onMounted } from 'vue'
import commoMethod from '../commoMethod'
const emits = defineEmits<{
  (e: "on-search", data: AttributeSearchType): void;
}>();
const props = defineProps<{ loading: boolean }>();
const { form, searchRef } = commoMethod()
const handleSearch = () => {
  const newForm = deepClone(form)
  if (newForm.status === 'all') { newForm.status = '' }
  emits('on-search', newForm)
}
const handleReset = () => {
  searchRef.value.resetFields();
  handleSearch();
}
onMounted(() => {
  handleSearch()
})
</script>