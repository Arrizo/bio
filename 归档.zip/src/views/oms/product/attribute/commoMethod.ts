import { ref, watch, reactive } from 'vue'
import { AttributeSearchType, AttributeDetailsType } from '@/types/product/attribute'
import { getAttributeList } from '@/api/product/attribute'
import { Message } from '@arco-design/web-vue';
export default function () {
  const loading = ref(false)
  const showModal = ref(false)
  const searchRef = ref()
  const total = ref(0)
  let form = reactive<AttributeSearchType>(new AttributeSearchType())
  const tableData = ref<Array<AttributeDetailsType>>([])
  const initMethod = async (data?: AttributeSearchType) => {
    try {
      form = Object.assign(form, data)
      loading.value = true
      const { code, value, message } = await getAttributeList(form)
      if (code != 0) {
        throw new Error(message)
      }
      tableData.value = value.result
      total.value = value.totalCount;
      form.pageNum = value.pageNum;
      form.pageSize = value.pageSize;
    } catch (error) {
      Message.error((error as Error).message);
    } finally {
      loading.value = false
    }

  }
  return {
    searchRef,
    total,
    form,
    showModal,
    loading,
    initMethod,
    tableData
  }
}