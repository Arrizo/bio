<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-20 09:14:30
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-27 20:15:55
 * @ Description: 商品分类列表
 -->

<template>
  <oms-table :loading="loading">
    <template #header-left>
      <a-button v-permission="['oms:product:category:add']" type="primary" status="normal" @click="handleAddClick"
        style="margin-bottom: 10px;"> 新增分类 </a-button>
    </template>

    <a-table :data="(list as any)" :pagination="false" hide-expand-button-on-empty row-key="id"
      :bordered="{ wrapper: false }" :scroll="{ x: 1400 }">
      <!-- 重写展开图标 -->
      <template #expand-icon='{ expanded }'>
        <icon-caret-down v-if="expanded" style="font-size: 32;" />
        <icon-caret-right v-else style="font-size: 32;" />
      </template>
      <template #columns>
        <a-table-column title="序号" :width="100">
          <template #cell="{ rowIndex }"> {{ rowIndex + 1 }} </template>
        </a-table-column>
        <a-table-column title="品类名称" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.title || '--' }} </template>
        </a-table-column>
        <a-table-column title="品类编码" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.code || '--' }} </template>
        </a-table-column>
        <a-table-column title="排序号" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.sort }} </template>
        </a-table-column>
        <a-table-column title="备注" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.remark || '--' }} </template>
        </a-table-column>
        <a-table-column title="状态" ellipsis tooltip :width="120">
          <template #cell="{ record, rowIndex }">
            <div v-permission="['oms:product:category:status']">
              <a-switch v-model="record.status" @focus="onSwitchForce(record, rowIndex)">
                <template #checked>
                  启用
                </template>
                <template #unchecked>
                  禁用
                </template>
              </a-switch>
            </div>
            <div v-permission-else="['oms:product:category:status']">{{ record.status ? '启用' : '禁用' }}</div>
          </template>
        </a-table-column>
        <a-table-column title="更新时间" ellipsis tooltip :width="180">
          <template #cell="{ record }"> {{ record.updateTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="操作" :width="100" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link v-permission="['oms:product:category:edit']" @click="handleActoin('edit', record)"
                type="text">编辑</a-link>
              <a-link v-permission="['oms:product:category:log']" @click="handleActoin('log', record)"
                type="text">日志</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑弹窗 -->
  <category-form ref="categoryFormRef" @reload="emits('reload')"></category-form>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleDropRole"></oms-warning>

  <!-- 日志 -->
  <oms-log ref="logRef"></oms-log>
</template>

<script setup lang="ts" name="product-category-list">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import OmsLog from '@/components/oms-log/index.vue';
import categoryForm from "./form.vue";
import { Message } from '@arco-design/web-vue';
import { updateStatus } from '@/api/product/category';

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const logRef = ref();
const switchRef = ref();
const categoryFormRef = ref();
const statusData = reactive({
  id: NaN,
  index: NaN,
  status: false
});

// 「新增」按钮点击触发
const handleAddClick = () => {
  categoryFormRef.value.handleShowModal("add");
};

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: any, index: number) => {
  statusData.id = record?.id;
  statusData.index = index;
  statusData.status = record?.status;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "edit" | "log", data?: any) => {
  if (type === "edit") {
    categoryFormRef.value.handleShowModal("edit", data);
    return;
  }
  logRef.value.init(data?.logCode, "商品分类");
};

// 修改状态
const handleDropRole = async () => {
  try {
    const res = await updateStatus({
      id: statusData.id,
      status: !statusData.status
    });
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}
</script>