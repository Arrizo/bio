<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-20 13:58:48
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 09:19:36
 * @ Description: 分类表单
 -->

<template>
  <a-modal :title="editModal.type === 'add' ? '新增' : '编辑'" width="800px" v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" unmountOnClose :esc-to-close="false" :mask-closable="false">
    <a-form ref="formRef" :model="form" layout="horizontal" style="margin-left: -10px;">
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item label="品类编码：" label-col-flex="86px">
            <a-input v-limit-input disabled v-model="form.code" />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="title" label="品类名称：" label-col-flex="86px"
            :rules="[{ required: true, message: '请输入品类名称' }]">
            <a-input v-limit-input v-model="form.title" placeholder="请输入" :max-length="20" allow-clear
              show-word-limit />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="12">
          <a-form-item field="pid" label="上级品类：" label-col-flex="86px">
            <a-cascader check-strictly :field-names="{ value: 'id', label: 'title' }" :options="list" v-model="form.pid"
              placeholder="请选择" allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="sort" label="排序号：" label-col-flex="86px">
            <a-input-number hide-button :min="1" :max="999" v-model="form.sort" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="24">
          <a-form-item field="remark" label="备注：" label-col-flex="86px">
            <a-textarea v-model="form.remark" placeholder="请输入" :max-length="200" show-word-limit />
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="product-category-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { CategoryForm, CategoryListItem } from '@/types/product/category';
import { getList, addCategory, editCategory } from '@/api/product/category';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const list = ref<CategoryListItem[]>([]);
const form = ref<CategoryForm>(new CategoryForm());

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  if (form.value?.title.length < 2) {
    Message.error("品类名称的长度在2-20之间");
    return false;
  }

  try {
    const api = editModal.type === 'add' ? addCategory : editCategory;
    const res = await api(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

const queryLastList = async () => {
  try {
    const res = await getList({ status: "", title: "" });
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value;

    function doArr(arr: any) {
      for (let i = 0; i < arr.length; i++) {
        if (arr[i]?.children && arr[i].children.length !== 0) {
          doArr(arr[i]?.children);
        }
        if (arr[i].id === form.value.id) {
          arr[i].disabled = true;
          break;
        }
      }
    }

    doArr(list.value);
  } catch (err) {
    Message.error((err as Error).message);
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: CategoryListItem) => {
  editModal.type = type;
  editModal.show = true;

  if (type === 'add') {
    form.value = new CategoryForm();
  }

  if (type === "edit") {
    form.value.id = data.id;
    form.value.title = data.title || '';
    form.value.sort = data.sort;
    form.value.code = data.code || '';
    form.value.remark = data.remark || '';
    form.value.pid = data.pid || '';
  }
  queryLastList();
}

defineExpose({
  handleShowModal
});
</script>