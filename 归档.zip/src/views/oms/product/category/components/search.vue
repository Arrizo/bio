<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-20 08:49:21
 * @ Modified by: Sam
 * @ Modified time: 2023-03-09 08:52:53
 * @ Description: 商品分类-搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="title" label="品类：">
      <a-input v-limit-input v-model="form.title" @keyup.enter="handleSearch" placeholder="请输入" allow-clear />
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="form.status" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="product-category-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { CategorySearcForm } from '@/types/product/category';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: "on-search", data: any): void;
}>();

const formRes = ref();
const form = ref<CategorySearcForm>(new CategorySearcForm());

// 搜索
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

onMounted(() => {
  handleSearch();
});
</script>