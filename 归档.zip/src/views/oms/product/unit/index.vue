<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-20 08:44:50
 * @ Modified by: Sam
 * @ Modified time: 2023-02-27 11:28:12
 * @ Description: 计量单位
 -->

<template>
  <a-row :gutter="10" style="height:100%">
    <a-col :span="24" style="height:100%">
      <oms-panel style="height:100%">
        <template #header>
          <search :loading="loading" @on-search="init"></search>
        </template>
        <div>
          <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
            @reload="init"></list>
        </div>
      </oms-panel>
    </a-col>
  </a-row>
</template>

<script setup lang="ts" name="product-unit">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import { Message } from '@arco-design/web-vue';
import { ref } from 'vue';
import { UnitItem, UnitSearchForm } from '@/types/product/unit';
import { getList } from '@/api/product/unit';
import { deepClone } from '@/utils/helper';

const loading = ref<boolean>(false);
const list = ref<UnitItem[]>([]);
const total = ref<number>(0);
const form = ref<UnitSearchForm>(new UnitSearchForm());

const init = async (data?: UnitSearchForm) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.status = params.status === 'all' ? '' : params.status;
    const res = await getList(params);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    setTimeout(() => {
      loading.value = false;
    }, 400);
  }
}
</script>