<!--
 * @ Author: Sam
 * @ Create Time: 2023-02-20 13:58:59
 * @ Modified by: Sam
 * @ Modified time: 2023-03-14 10:24:54
 * @ Description: 计量单位表单
 -->
<template>
  <a-modal :title="`${editModal.type === 'add' ? '新增' : '编辑'}单位`" width="500px" v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" unmountOnClose :esc-to-close="false" :mask-closable="false">
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-form-item field="code" label="单位编码：" label-col-flex="100px" :rules="[{ required: true, message: '请输入单位编码' }]">
        <a-input v-limit-input :disabled="editModal.type === 'edit'" @keyup.enter="onOk" v-model.trim="form.code"
          placeholder="请输入" allow-clear  :max-length="20" show-word-limit/>
      </a-form-item>
      <a-form-item field="name" label="单位名称：" label-col-flex="100px" :rules="[{ required: true, message: '请输入单位名称' }]">
        <a-input v-limit-input @keyup.enter="onOk" v-model.trim="form.name" placeholder="请输入（中文名称）" :max-length="20"
          allow-clear show-word-limit />
      </a-form-item>
      <a-form-item field="remark" label="备注：" label-col-flex="100px">
        <a-textarea v-limit-input v-model.trim="form.remark" placeholder="请输入" :max-length="200" show-word-limit />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="product-unit-form">
import { reactive, ref } from 'vue';
import { addUnit, editUnit, queryDetail } from '@/api/product/unit';
import { Message } from '@arco-design/web-vue';
import { UnitForm } from '@/types/product/unit';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const form = ref<UnitForm>(new UnitForm());

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const api = editModal.type === 'add' ? addUnit : editUnit;
    const res = await api(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: number) => {
  editModal.type = type;
  editModal.show = true;

  if (type === 'add') {
    form.value = new UnitForm();
  }

  if (type === "edit") {
    try {
      const res = await queryDetail(data);
      if (res.code != 0) {
        Message.error(res.message);
        return;
      }
      form.value = res.value;
    } catch (err) {
      Message.error((err as Error).message);
    }
  }
}

defineExpose({
  handleShowModal
});
</script>