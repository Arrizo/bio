<template>
  <div>
    <a-row :gutter="10">
      <a-col :span="24">
        <oms-panel>
          <template #header>
            <search :shopList="(shopList as any)" :loading="loading" @on-search="init"></search>
          </template>
          <div>
            <list @reload="init" @record="handleRecordClick" :page-num="form.pageNum" :shopList="shopList" :page-size="form.pageSize"
              :totalCount="totalCount" :loading="loading" :list="list"></list>
          </div>
        </oms-panel>
        <!-- 调价记录 -->
        <price-record v-if="recordVisible" :shopList="shopList" :distributionData="distributionData" @close="closeRecord"></price-record>
      </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts" name="product-distribution">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import PriceRecord from './components/record.vue';
import { Message } from '@arco-design/web-vue';
import { onMounted, ref } from 'vue';
import { deepClone } from '@/utils/helper';
import { DistributionReq, DistributionType, ShopSelectItem } from '@/types/product/distribution';
import { queryPage, queryUserStore } from '@/api/product/distribution';
const form = ref<DistributionReq>(new DistributionReq());
const loading = ref<boolean>(false);
const list = ref();
const recordVisible = ref<boolean>(false);//调价记录
const distributionData = ref<DistributionType>(new DistributionType())
const totalCount = ref();
/**
 * 初始化查询菜单数据
 * @param form
 */

const init = async (data: DistributionReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.status = params.status === 'all' ? '' : params.status;
    params.auditStatus = params.auditStatus === 'all' ? '' : params.auditStatus;
    const res = await queryPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

const shopList = ref<ShopSelectItem[]>([]);
const queryShopList = async () => {
  try {
    let response = await queryUserStore();
    if (response?.success) {
      shopList.value = response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询店铺列表失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询店铺列表失败");
  }
}

//调价记录
const handleRecordClick = (data: DistributionType) => {
  recordVisible.value = true;
  distributionData.value = data;
}

//关闭调价记录
const closeRecord = () => {
  recordVisible.value = false;
}

onMounted(() => {
  queryShopList();
});
</script>