// 搜索

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="lstStoreCode" label="店铺：">
      <!-- <a-select placeholder="请选择" multiple v-model='form.lstStoreCode' :max-tag-count="1" allow-search allow-clear>
        <a-option v-for="(item) in shopList" :label="item.storeName" :value="item.storeCode"></a-option>
      </a-select> -->

      <oms-multiple-select :maxTagCount="1" v-model="form.lstStoreCode" :option-list="(shopList as any)" value="storeCode" label="storeName"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="code" label="编码：">
      <a-input v-limit-input v-model.trim="form.code" @keyup.enter="handleSearch" placeholder="请输入" />
    </a-form-item>
    <a-form-item field="name" label="名称：">
      <a-input v-limit-input v-model.trim="form.name" @keyup.enter="handleSearch" placeholder="请输入" />
    </a-form-item>
    <a-form-item field="auditStatus" label="审核状态：">
      <a-select placeholder="请选择" v-model="(form.auditStatus as string)" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option :value="1">待审核</a-option>
        <a-option :value="2">通过</a-option>
        <a-option :value="3">不通过</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="(form.status as string)" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="product-category-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { DistributionReq, ShopSelectItem } from '@/types/product/distribution';
import { onMounted, ref } from 'vue';
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"

const props = defineProps({
  loading: { type: Boolean, default: false },
  shopList: { type: Array<ShopSelectItem>, default: () => [] }
});

const emits = defineEmits<{
  (e: "on-search", data: DistributionReq): void;
}>();

const formRes = ref();
const form = ref<DistributionReq>(new DistributionReq());

// 搜索
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

onMounted(() => {
  handleSearch();
});
</script>