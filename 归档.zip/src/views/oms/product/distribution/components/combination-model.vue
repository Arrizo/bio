<template>
  <a-modal v-model:visible="combinationModal.show" :mask-closable="false" title="选择组合" :width="800" title-align="start"
    :on-before-ok="onBeforeOk" @cancel="closeModel" unmount-on-close>
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form :model="combinationForm" layout="inline" ref="searchRef">
      <a-form-item field="combinationCode" label="编码：">
        <a-input v-model.trim="combinationForm.combinationCode" placeholder="spu/sku编码" allow-clear :max-length="20"
          :style="{ width: '200px' }" @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="combinationName" label="名称：">
        <a-input v-model.trim="combinationForm.combinationName" placeholder="spu/sku名称" allow-clear :max-length="20"
          :style="{ width: '200px' }" @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
    </a-form>
    <!-- </template> -->
    <oms-table :loading="loading" :simplePagination="true" :total="totalCount" :current="combinationForm.pageNum" :size="combinationForm.pageSize"
      @reload="onReload">
      <a-table v-model:selected-keys="selectedkeys" :data="goodsTableData" :pagination="false"
        @selection-change="selectionChange" hide-expand-button-on-empty :scroll="{ y: 340, }" stripe row-key="id"
        :bordered="{ wrapper: false }" :row-selection="rowSelection" @row-click="rowClick">
        <template #columns>
          <a-table-column title="组合编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.combinationCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="组合名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.combinationName || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="sku随机" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.skuRandomCombination?'是':'否' }}
            </template>
          </a-table-column>
          <a-table-column title="备注" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.remark || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </a-modal>
</template>
<script lang="ts" setup name="combination-goods">
import { getCombinationPage } from '@/api/product/distribution';
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { AuditStatus, CombinationReq, CombinationTableDataType } from '@/types/product/distribution';
import { Message, TableData, TableRowSelection } from "@arco-design/web-vue"
import OmsTable from '@/components/oms-table/index.vue';
import { reactive, ref, watch } from 'vue';
interface CombinationModal {
  show: boolean;
}
const combinationModal = reactive<CombinationModal>({
  show: false,
});
const rowSelection = reactive<TableRowSelection>({
  type: 'radio',
  fixed: true,
})

const emits = defineEmits<{
  (e: "on-select", data: CombinationTableDataType): void;
}>();
const loading = ref<boolean>(false)
const searchRef = ref();
const totalCount = ref(0)
// 表格数据
const goodsTableData = ref<CombinationTableDataType[]>([])
// 选中的数据
const selectGoodsTableData = ref<CombinationTableDataType>(new CombinationTableDataType())
const selectedkeys = ref()
let combinationForm = ref<CombinationReq>(new CombinationReq())

const handleSearch = async () => {
  try {
    loading.value = true
    const { code, message, value } = await getCombinationPage(combinationForm.value)
    if (code != 0) {
      throw new Error(message)
    }
    totalCount.value = value.totalCount;
    combinationForm.value.pageNum = value.pageNum;
    combinationForm.value.pageSize = value.pageSize;
    goodsTableData.value = value.result;
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  combinationForm.value.pageNum = data.pageNum;
  combinationForm.value.pageSize = data.pageSize;
  handleSearch();
};

const closeModel = ()=>{
  goodsTableData.value = [];
  selectedkeys.value = [];
  totalCount.value=0;
  combinationForm.value.combinationCode = '';
  searchRef.value.resetFields();
}

const handleReset = () => {
  searchRef.value.resetFields();
  selectedkeys.value = [];
  handleSearch()
}

const selectionChange = (rowKeys: Array<string | number>) => {
  selectGoodsTableData.value = goodsTableData.value.find(i => i.id == rowKeys[0]) ?? {}
}
const rowClick = (row: TableData) => {
  selectedkeys.value = [row.id]
  selectGoodsTableData.value = goodsTableData.value.find(i => i.id == row.id) ?? {}
}
const onBeforeOk = () => {
  emits('on-select', selectGoodsTableData.value);
  closeModel()
  return true
}
/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (data:string) => {
  combinationForm.value=new CombinationReq();
  combinationModal.show = true;
  combinationForm.value.auditStatus=AuditStatus.AuditPass;
  combinationForm.value.status = true;
  if(data){
    combinationForm.value.combinationCode = data;
    handleSearch();
    setTimeout(() => {
      let idx = goodsTableData.value.findIndex((item)=> item.combinationCode ===data)
      if (idx>-1) {
        rowClick(goodsTableData.value[idx]);
        selectedkeys.value = [goodsTableData.value[idx].id]
      }
      
    }, 200);
  }
}

defineExpose({
  handleShowModal
});
</script>