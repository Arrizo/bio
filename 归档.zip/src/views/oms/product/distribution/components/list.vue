// 列表
<template>
  <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
    <template #header-left>
      <a-space style="margin-bottom: 10px;">
        <a-button type="primary" v-permission="['oms:product:distribution:add']" status="normal"
          @click="handleClick('add')"> 新增铺货
        </a-button>
        <a-button status="normal" v-permission="['oms:product:distribution:import']" @click="handleClick('import')"> 导入
        </a-button>
        <a-button :disabled="!selectedKeys.length" status="normal"
          v-permission="['oms:product:distribution:examineDistribution']" @click="handleClick('examine-distribution')">
          审核铺货
        </a-button>
        <a-button status="normal" v-permission="['oms:product:distribution:examinePrice']"
          @click="handleClick('examine-price')"> 调价审核
        </a-button>
        <a-button status="normal" v-permission="['oms:product:distribution:examineConfrim']"
          @click="handleClick('confrim')"> 调价确认
        </a-button>
      </a-space>
    </template>

    <a-table ref="tableRef" v-db-click="list" :db-call-back="handleRecordClick" stripe :bordered="{ wrapper: false }"
      :data="(list as any)" :pagination="false" row-key="id" :row-selection="{
        type: 'checkbox',
        showCheckedAll: true
      }" :scroll="{ x: 1400 }" v-model:selectedKeys="selectedKeys">
      <template #columns>
        <a-table-column title="店铺名称" :width="180" ellipsis tooltip data-index="storeName"></a-table-column>
        <a-table-column title="店铺编码" :width="180" ellipsis tooltip data-index="storeCode"></a-table-column>
        <a-table-column title="平台商品id" :width="180" ellipsis tooltip data-index="platformProductId"></a-table-column>
        <a-table-column title="平台商品名称" :width="180" ellipsis tooltip data-index="platformProductName"></a-table-column>
        <a-table-column title="平台规格id" :width="180" ellipsis tooltip data-index="platformSkuId">
          <template #cell="{ record }">{{ record.platformSkuId || '--' }}</template>
        </a-table-column>
        <a-table-column title="平台规格名称" :width="180" ellipsis tooltip data-index="platformSkuName">
          <template #cell="{ record }">{{ record.platformSkuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="商品编码" :width="180" ellipsis tooltip data-index="skuCode"></a-table-column>
        <a-table-column title="商品名称" :width="180" ellipsis tooltip data-index="skuName">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="是否组合" :width="120" ellipsis tooltip data-index="combination">
          <template #cell="{ record, rowIndex }">
            {{ record.combination ? '是' : '否' }}
          </template>
        </a-table-column>
        <a-table-column cell-class="paddingR40" title="首次铺货价(元)" :width="170" align="right" ellipsis tooltip data-index="price">
          <template #cell="{ record }">{{ record.price || '--' }}</template>
        </a-table-column>
        <a-table-column title="业务类型" :width="140" ellipsis tooltip data-index="businessTypeName">
          <template #cell="{ record }">{{ record.businessTypeName || '--' }}</template>
        </a-table-column>
        <a-table-column title="审核状态" :width="140" ellipsis tooltip data-index="auditStatus">
          <template #cell="{ record, rowIndex }">
            <oms-tag :type="['progress', 'normal', 'warring'][(record.auditStatus) - 1]" v-if="record.auditStatus"
              :content="['待审核', '通过', '不通过'][(record.auditStatus) - 1]"></oms-tag>
          </template>
        </a-table-column>
        <a-table-column title="备注" :width="180" ellipsis tooltip data-index="remark">
          <template #cell="{ record }">{{ record.remark || '--' }}</template>
        </a-table-column>
        <a-table-column title="状态" :width="120" ellipsis tooltip data-index="status">
          <template #cell="{ record, rowIndex }">
            <a-switch v-permission="['oms:product:distribution:status']" v-model="record.status"
              @focus="onSwitchForce(record, rowIndex)">
              <template #checked>
                启用
              </template>
              <template #unchecked>
                禁用
              </template>
            </a-switch>
          </template>
        </a-table-column>
        <a-table-column title="更新时间" :width="180" data-index="updateTime">
          <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="操作" :width="130" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link v-if="record.auditStatus !== 1" v-permission="['oms:product:distribution:edit']"
                @click="handleClick('edit', record)" type="text">编辑</a-link>
              <a-link v-if="record.auditStatus === 2" v-permission="['oms:product:distribution:prices']"
                @click="handleClick('prices', record)" type="text">申请调价</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑弹窗 -->
  <distribution-form ref="distributionFormRef" @reload="emits('reload')"></distribution-form>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleStatus"></oms-warning>

  <!-- 导入 -->
  <oms-import ref="importRef" @clear="clearValue" :uploadSize="10" :isCheckParams="isCheckParams" uploadUrlName="铺货关系导入模板"
    :uploadUrl="uploadUrl" :importApi="importApi" @onSuccess="emits('reload')">
    <template #select>
      <div class="importSelectStyle">
        <span class="red">*</span>店铺：
        <a-select style="width:92%;" placeholder="请选择" v-model='storeId' allow-search allow-clear @change="changeSelect">
          <a-option v-for="(item) in props.shopList" :label="item.storeName" :value="item.id"></a-option>
        </a-select>
      </div>
    </template>
  </oms-import>

  <!-- 审核铺货 -->
  <examine-modal ref="examineDistribution" @reload="emits('reload')" @close="selectClose"></examine-modal>

  <!-- 调价审核 -->
  <examine-price-model ref="examineRef"></examine-price-model>

  <!-- 日志 -->
  <oms-log ref="logRef"></oms-log>
</template>

<script setup lang="ts" name="product-distribution-list">
import OmsTag from '@/components/oms-tag/index.vue'
import { computed, reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import OmsLog from '@/components/oms-log/index.vue'
import distributionForm from "./form.vue";
import ExamineModal from './examine-modal.vue';
import ExaminePriceModel from './examine-price-model.vue';
import { Message } from '@arco-design/web-vue';
import OmsImport from '@/components/oms-import/index.vue'
import { DistributionReq, DistributionType, ShopSelectItem } from '@/types/product/distribution';
import { updateStatus, uploadMapping } from '@/api/product/distribution';

const props = defineProps({
  list: { type: Array<DistributionType>, default: () => [] },
  shopList: { type: Array<ShopSelectItem>, default: () => [] },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  loading: { type: Boolean, default: false },
});
const selectedKeys = ref<string[]>([]);
const currentId = ref();
const logCode = ref('');
const logRef = ref();
const examineDistribution = ref();
const form = ref<DistributionReq>(new DistributionReq());
const uploadUrl = ref(`${import.meta.env.VITE_API_FILE_URL}/bp-auth-service/template/productManage/铺货关系导入模板.xlsx`);
const importApi = ref();
let storeId = ref();
const isCheckParams = ref([{
  isRequired: true,
  name: 'storeId',
  errMessage: '请选择店铺',
  value: storeId.value
}])
const emits = defineEmits<{
  (e: "reload", data?: DistributionReq): void,
  (e: "record", data: DistributionType): void,
  (e: "details", data?: DistributionReq): void,
}>();

const distributionFormRef = ref();
const switchRef = ref();
const importRef = ref();
const tableRef = ref();
const examineRef = ref()

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};

// 「新增」按钮点击触发
const handleClick = (type: string, record?: DistributionType) => {
  switch (type) {
    case 'add'://新增
      distributionFormRef.value.handleShowModal(type, props.shopList, record?.id);
      break;
    case 'edit'://编辑
      distributionFormRef.value.handleShowModal(type, props.shopList, record?.id);
      break;
    case 'prices'://申请调价
      distributionFormRef.value.handleShowModal(type, props.shopList, record?.id);
      break;
    case 'import'://导入
      importRef.value.visible = true;
      importApi.value = uploadMapping;
      break;
    case 'examine-distribution'://审核铺货
      if (selectedKeys.value.length == 0) return Message.error('请选择需要处理的数据！');
      examineDistribution.value.handleShowModal('examine-distribution', selectedKeys.value);
      break;
    case 'examine-price'://调价审核
      examineRef.value.handleShowModal('examine-price', props.shopList);
      break;
    case 'confrim'://调价确认
      examineRef.value.handleShowModal('confrim', props.shopList);
      break;
    // case 'log'://日志
    //   logRef.value.init(`${record?.storeCode}${record?.platformProductId}${record?.skuCode}`, '铺货关系', "modal", "调价日志");
    //   break;
    default:
      break;
  }

};


//调价记录
const handleRecordClick = (data: DistributionType) => {
  emits('record', data)
}

//取消选中效果
const selectClose = () => {
  selectedKeys.value = []
  tableRef.value.selectAll(false);
}


// 开关获取焦点触发二次确认
const onSwitchForce = async (record: DistributionType, index: number) => {
  currentId.value = record?.id;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}


// 修改状态

const handleStatus = async () => {
  try {
    const res = await updateStatus(currentId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}


const changeSelect = (val: any) => {
  isCheckParams.value[0].value = val;
}
//清空插槽里面的值
const clearValue = () => {
  storeId.value = ''
}

// 返回列表
const list = computed(() => {
  return props.list as Array<DistributionType>
})
</script>
<style lang="less" scoped>

.importSelectStyle {
  display: flex;
  align-items: center;
  margin-bottom: 24px;

  .red {
    color: rgb(245, 63, 63);
    font-size: 20px;
    position: absolute;
    // 位置可以根据自己的样式自行调整
    top: 26px;
    left: 20px;
  }
}

// .importSelectStyle p::before {
//   content: "*";
//   color: rgb(245, 63, 63);
//   font-size: 24px;
//   margin-right: 4px;
// }
</style>