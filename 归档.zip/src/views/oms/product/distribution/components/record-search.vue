// 搜索

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="businessType" label="业务类型：" label-col-flex="90px">
      <a-select style="width:248px" placeholder="请选择" v-model="form.businessType">
        <a-option value="all">全部</a-option>
        <a-option v-for="(item) in businessTypeList" :label="item.dictionaryTitle" :value="item.dictionaryValue"></a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="auditStatus" label="状态：" label-col-flex="90px">
      <a-select style="width:256px" placeholder="请选择" v-model="form.auditStatus">
        <a-option value="all">全部</a-option>
        <a-option v-for="(item) in statusList" :label="item.label" :value="item.value"></a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="code" label="铺货单价：" class="distributionInputGroup" label-col-flex="90px">
      <a-input-group>
        <a-input-number v-model.trim="form.minPrice" :style="{ width: '91px' }" placeholder="最小值" />
        <span style="padding: 0 8px;color:#b1b1b1;">-</span>
        <a-input-number  v-model.trim="form.maxPrice" :style="{ width: '91px' }" placeholder="最大值" />
      </a-input-group>
    </a-form-item>
    <a-form-item field="name" label="时间：" label-col-flex="90px">
      <a-range-picker show-time :placeholder="['生效时间', '失效时间']" v-model='timePicker' format="YYYY-MM-DD HH:mm:ss"
        @change="timeChange" />
    </a-form-item>

    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="product-category-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { getDictionaryList } from '@/hooks/useDictionary';
import { PriceRecordReq } from '@/types/product/distribution';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { onMounted, ref } from 'vue';
const businessTypeList = ref<DictionaryTitleType[]>();
const props = defineProps({
  loading: { type: Boolean, default: false },
});
const statusList = [ {
  value: '1',
  label: '待审核'
}, {
  value: '2',
  label: '审核不通过'
}, {
  value: '3',
  label: '待确认'
}, {
  value: '4',
  label: '确认不通过'
}, {
  value: '5',
  label: '上线'
}, {
  value: '6',
  label: '下线'
},]
const emits = defineEmits<{
  (e: "on-search", data: PriceRecordReq): void;
}>();

const formRes = ref();
const form = ref<PriceRecordReq>(new PriceRecordReq());
const timePicker = ref();
const priceGroup = ref()
// 搜索
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  timePicker.value = [];
  form.value.effectiveTime = '';
  form.value.invalidTime = '';
  form.value.maxPrice=undefined;
  form.value.minPrice=undefined;
  handleSearch();
}

//时间选择
const timeChange = (val: any) => {
  form.value.effectiveTime = val?.[0] ?? "";
  form.value.invalidTime = val?.[1] ?? "";
}

onMounted(async () => {
  //获取业务类型
  businessTypeList.value = await getDictionaryList('BUSINESS_TYPE')
});
</script>
<style lang="less">
.distributionInputGroup{
  .arco-input-wrapper:hover{
    border-color: rgb(var(--primary-7)) !important;
  }
}
</style>