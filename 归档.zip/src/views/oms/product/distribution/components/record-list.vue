<!-- 商品管理->铺货关系->调价记录列表 -->
<template>
  <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">

    <a-table stripe :scroll="{ x: 1400 }" :data="(list as any)" :pagination="false" :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
          <template #cell="{ rowIndex }">
            {{ rowIndex + 1 }}
          </template>
        </a-table-column>
        <a-table-column title="铺货单价(元)" ellipsis align="right"  cell-class="paddingR40" tooltip :width="180" data-index="price">
        </a-table-column>
        <a-table-column title="业务类型" ellipsis tooltip :width="180" data-index="businessTypeName"></a-table-column>
        <a-table-column title="生效时间" :width="180" data-index="effectiveTime"></a-table-column>
        <a-table-column title="失效时间" :width="180" data-index="invalidTime"></a-table-column>
        <a-table-column title="备注说明" ellipsis tooltip :width="180" data-index="remark"></a-table-column>
        <a-table-column title="更新时间" :width="180" data-index="updateTime"></a-table-column>
        <a-table-column title="状态" :width="180" data-index="auditStatus">
          <template #cell="{ record }">
            <oms-tag :type="tagStatus(record.auditStatus)"
              :content="['暂存', '待审核', '审核不通过', '待确认', '确认不通过', '上线', '下线'][record.auditStatus]"></oms-tag>
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="120" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link v-permission="['oms:product:distribution:examine']" v-if="record.auditStatus === 1" type="text"
                @click="handleAction('examine', record)">审核</a-link>
              <a-link v-permission="['oms:product:distribution:up']" v-if="record.auditStatus === 6" type="text"
                @click="handleAction('status', record)">上线</a-link>
              <a-link v-permission="['oms:product:distribution:down']" v-if="record.auditStatus === 5" type="text"
                @click="handleAction('status', record)">下线</a-link>
              <a-link v-permission="['oms:product:distribution:confrim']" v-if="record.auditStatus === 3" type="text"
                @click="handleAction('confrim', record)">确认</a-link>
              <a-link v-permission="['oms:product:distribution:editRecord']"
                v-if="record.auditStatus === 2 || record.auditStatus === 4" type="text"
                @click="handleAction('edit', record)">编辑</a-link>
              <a-link type="text" v-permission="['oms:product:distribution:logRecord']"
                @click="handleAction('log', record)">日志</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>

    <!-- 日志 -->
    <oms-log ref="logRef"></oms-log>

    <!-- 上下线 -->
    <onoroff-model ref="onoroffRef" @reload="emits('reload-details')"></onoroff-model>

    <!-- 审核铺货 -->
    <examine-modal ref="examineDistribution" @reload="emits('reload-details')"></examine-modal>

    <!-- 编辑--调价申请弹窗 -->
    <distribution-form ref="distributionFormRef" @reload="emits('reload-details')"></distribution-form>
  </oms-table>
</template>

<script setup lang="ts" name="system-dictionary-list">
import { ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsLog from '@/components/oms-log/index.vue'
import OnoroffModel from './onoroff-model.vue';
import ExamineModal from './examine-modal.vue';
import distributionForm from "./form.vue";
import OmsTag from '@/components/oms-tag/index.vue'
import { DictionarySearchForm } from '@/types/system/dictionary';
import { PriceRecordType, ShopSelectItem } from '@/types/product/distribution';
const form = ref<DictionarySearchForm>(new DictionarySearchForm());

const props = defineProps({
  list: { type: Array, default: () => [] },
  mpId: { type: Number, default: null },
  loading: { type: Boolean, default: false },
  shopList: { type: Array<ShopSelectItem>, default: () => [] },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload-details", data?: DictionarySearchForm): void,
}>();
const logRef = ref();
const distributionFormRef = ref();
const examineDistribution = ref();
const onoroffRef = ref();
const logType = ref('');
const logCode = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload-details", form.value)
};

const tagStatus = (val: number) => {
  switch (val) {
    case 0:
      return 'normal'
      break;
    case 1:
      return 'progress'
      break;
    case 2:
      return 'warring'
      break;
    case 3:
      return 'progress'
      break;
    case 4:
      return 'warring'
      break;
    case 5:
      return 'normal'
      break;
    case 6:
      return 'efficacy'
      break;
    default:
      break;
  }
}

//操作
const handleAction = (type: string, record: PriceRecordType) => {
  switch (type) {
    case 'edit'://编辑---调价申请
      distributionFormRef.value.handleShowModal('prices_edit', props.shopList, record.id, props.mpId);
      break;
    case 'log'://日志
      logRef.value.init(record.logCode, "铺货关系调价", "modal", "调价日志");
      break;
    case 'examine'://审核
      examineDistribution.value.handleShowModal('examine-prices', [record.id]);
      break;
    case 'confrim'://确认
      examineDistribution.value.handleShowModal('confrim', [record.id]);
      break;
    case 'status'://上下线
      onoroffRef.value.handleShowModal(record.auditStatus, record.id);
      break;

    default:
      break;
  }
}

</script>