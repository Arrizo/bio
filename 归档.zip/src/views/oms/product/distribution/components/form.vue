
<template>
  <a-modal :mask-closable="false" :title="titleName" width="800px" v-model:visible="editModal.show" :ok-loading="loading"
    title-align="start" :on-before-ok="onOk" unmountOnClose ok-text="提交">
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item v-if="editModal.type === 'add'" field="storeId" label="店铺：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请选择店铺' }]">
            <a-select placeholder="请选择" v-model='form.storeId' allow-search @change="updateOwner">
              <a-option v-for="(item) in editModal.shopList" :label="item.storeName" :value="item.id"></a-option>
            </a-select>
          </a-form-item>
          <!-- 编辑回显绑定code -->
          <a-form-item v-if="editModal.type !== 'add'" field="storeCode" label="店铺：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请选择店铺' }]">
            <a-select
              :disabled="editModal.type === 'edit' || editModal.type === 'prices' || editModal.type === 'prices_edit'"
              placeholder="请选择" v-model='form.storeCode' allow-search @change="updateOwner">
              <a-option v-for="(item) in editModal.shopList" :label="item.storeName" :value="item.storeCode"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="owner"
            :label="editModal.type === 'prices' || editModal.type === 'prices_edit' ? '店铺经理：' : '负责人：'"
            label-col-flex="120px">
            <a-input disabled v-model.trim="form.owner" placeholder="请输入" />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="12">
          <a-form-item field="combination" label="是否组合：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请选择是否组合' }]">
            <a-select
              :disabled="editModal.type === 'edit' || editModal.type === 'prices' || editModal.type === 'prices_edit'"
              placeholder="请选择" v-model="(form.combination as string)" allow-search
              @change="changeCombination">
              <a-option value="true">是</a-option>
              <a-option value="false">否</a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="responsibleDept" label="负责部门：" label-col-flex="120px">
            <a-input :disabled="editModal.type === 'prices' || editModal.type === 'prices_edit'"
              v-model.trim="form.responsibleDept" placeholder="请输入" :max-length="200" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="platformProductId" label="平台商品id：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请输入平台商品id' }]">
            <a-input
              :disabled="editModal.type === 'edit' || editModal.type === 'prices' || editModal.type === 'prices_edit'"
              v-model.trim="form.platformProductId" placeholder="请输入" :max-length="100" allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="platformProductName" label="平台商品名称：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请输入平台商品名称' }]">
            <a-input :disabled="editModal.type === 'prices' || editModal.type === 'prices_edit'"
              v-model.trim="form.platformProductName" placeholder="请输入" :max-length="200" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="platformSkuId" label="平台规格id：" label-col-flex="120px">
            <a-input
              :disabled="editModal.type === 'edit' || editModal.type === 'prices' || editModal.type === 'prices_edit'"
              v-model.trim="form.platformSkuId" placeholder="请输入" :max-length="100" allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="platformSkuName" label="平台规格名称：" label-col-flex="120px">
            <a-input :disabled="editModal.type === 'prices' || editModal.type === 'prices_edit'"
              v-model.trim="form.platformSkuName" placeholder="请输入" :max-length="200" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10">
        <a-col :span="12">
          <a-form-item field="skuCode" label="商品/组合编码：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请输入商品/组合编码' }]">
            <a-input readonly @click.stop="chooseProduct"
              :disabled="editModal.type === 'edit' || editModal.type === 'prices' || editModal.type === 'prices_edit'"
              v-model.trim="form.skuCode" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="skuName" label="商品/组合名称：" label-col-flex="120px">
            <a-input disabled v-model.trim="form.skuName" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10" v-if="editModal.type !== 'edit'">
        <a-col :span="12">
          <a-form-item field="price" label="铺货单价：" label-col-flex="120px" required :rules="rulesPrice">
            <a-input-number v-model.trim="form.price" :precision="4" :min="0" :max="100000" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="businessType" label="业务类型：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请选择业务类型' }]">
            <a-select placeholder="请选择" allow-search v-model="form.businessType">
              <a-option v-for="(item) in businessTypeList" :label="item.dictionaryTitle"
                :value="item.dictionaryValue"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="10" v-if="editModal.type !== 'edit'">
        <a-col :span="12">
          <a-form-item field="effectiveTime" label="生效时间：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请选择生效时间' }]">
            <a-date-picker v-model="form.effectiveTime" style="width: 100%; " show-time format="YYYY-MM-DD HH:mm:ss" />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item field="invalidTime" label="失效时间：" label-col-flex="120px" required
            :rules="[{ required: true, message: '请选择失效时间' }]">
            <a-date-picker v-model="form.invalidTime" style="width: 100%; " show-time format="YYYY-MM-DD HH:mm:ss" />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="24">
          <a-form-item field="remark" label="备注：" label-col-flex="120px">
            <a-textarea v-model.trim="form.remark" placeholder="请输入" :max-length="200" show-word-limit />
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
    <!-- 选择商品 -->
    <goods-mode :specs-code="form.skuCode" ref="goodsRef" @on-select="selectGoods"></goods-mode>
    <!-- 选择组合 -->
    <combination-model ref="combinationRef" @on-select="selectCombination"></combination-model>
  </a-modal>
</template>

<script setup lang="ts" name="product-distribution-form">
import { computed, reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { AddPricesReq, CombinationTableDataType, DistributionEditFrom, DistributionFrom, ShopSelectItem } from '@/types/product/distribution';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { deepClone } from '@/utils/helper';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { addDistribution, addPrices, editDistribution, editPrices, queryDetail, queryPricesDetail } from '@/api/product/distribution';
import CombinationModel from './combination-model.vue';
import GoodsMode from '../../purchase/components/goods/index.vue'
import { goodsTableDataType } from '@/types/product/purchase';
const businessTypeList = ref<DictionaryTitleType[]>();
interface EditModal {
  show: boolean;
  type: string;
  shopList: Array<ShopSelectItem>,
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  shopList: [],
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();
const goodsRef = ref();
const formRef = ref();
const loading = ref<boolean>(false)
const form = ref<DistributionFrom>(new DistributionFrom());
const editForm = ref<DistributionEditFrom>(new DistributionFrom());
const pricesForm = ref<AddPricesReq>(new AddPricesReq());
const combinationRef = ref()

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  loading.value = true;
  try {
    let obj = {
      'add': addDistribution,
      'edit': editDistribution,
      'prices': addPrices,
      'prices_edit': editPrices
    }
    const apiType = obj[editModal.type];

    let params = {}
    params = deepClone(form.value)
    if (editModal.type === 'edit') {
      editForm.value.platformProductName = form.value.platformProductName;
      editForm.value.platformSkuName = form.value.platformSkuName;
      editForm.value.remark = form.value.remark;
      editForm.value.responsibleDept = form.value.responsibleDept;
      params = deepClone(editForm.value)
    } else if (editModal.type === 'prices' || editModal.type === 'prices_edit') {//申请调价/编辑调价
      pricesForm.value.businessType = form.value.businessType;
      pricesForm.value.effectiveTime = form.value.effectiveTime;
      pricesForm.value.invalidTime = form.value.invalidTime;
      pricesForm.value.price = form.value.price;
      pricesForm.value.remark = form.value.remark;
      params = deepClone(pricesForm.value)
    }
    const res = await apiType(params);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  } finally {
    loading.value = false;
  }
}

const chooseProduct = () => {
  if (editModal.type !== 'add') {
    return false;
  }
  console.log('[ jinlai ] >')
  if (!form.value.combination) {
    return Message.error('请选择是否组合');
  }
  // 组合
  if (form.value.combination === 'true') {
    combinationRef.value.handleShowModal(form.value.skuCode ? form.value.skuCode : '');
    return
  }
  //商品
  goodsRef.value.showModal();
}

//选择组合
const selectCombination = (data: CombinationTableDataType) => {
  form.value.skuCode = data.combinationCode ?? '';
  form.value.skuName = data.combinationName;
}

//选择商品
const selectGoods = (data: goodsTableDataType) => {
  form.value.skuCode = data.specsCode ?? '';
  form.value.skuName = data.specsTitle;
}

//切换是否组合值
const changeCombination = () => {
  form.value.skuCode = '';
  form.value.skuName = '';
}


/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: string, shopList: ShopSelectItem[], data: number, mpId?: number) => {
  editModal.type = type;
  editModal.show = true;
  editModal.shopList = shopList;

  form.value = new DistributionFrom();
  if (type === 'add' || type === 'prices') {
    //获取业务类型
    businessTypeList.value = await getDictionaryList('BUSINESS_TYPE')
  } else if (type === "edit" || type === 'prices_edit') {
    //获取业务类型
    businessTypeList.value = await getValidDictionaryList('BUSINESS_TYPE')
  }

  if (type === "edit" || type === 'prices' || type === 'prices_edit') {

    editForm.value.id = data;
    pricesForm.value.mpId = mpId ? mpId : data;//申请调价
    pricesForm.value.id = mpId ? data : undefined;//编辑调价
    try {
      const apiType = type === 'prices_edit' ? queryPricesDetail : queryDetail;
      const res = await apiType(data);
      if (res.code != 0) {
        Message.error(res.message);
        return;
      }
      let params = res.value;
      form.value.storeId = params.storeId ?? null;
      form.value.storeCode = params.storeCode ?? '';
      form.value.owner = params.owner ?? '';
      form.value.responsibleDept = params.responsibleDept ?? '';
      form.value.platformProductId = params.platformProductId ?? '';
      form.value.platformProductName = params.platformProductName ?? '';
      form.value.platformSkuId = params.platformSkuId ?? '';
      form.value.platformSkuName = params.platformSkuName ?? '';
      form.value.price = Number(params.price);
      form.value.skuCode = params.skuCode ?? '';
      form.value.skuName = params.skuName ?? '';
      form.value.remark = params.remark ?? '';
      form.value.businessType = params.businessType ?? '';
      form.value.combination = params.combination + '';
      form.value.effectiveTime = params.effectiveTime;
      form.value.invalidTime = params.invalidTime;
    } catch (err) {
      Message.error((err as Error).message);
    }
  }
}

//获取店铺负责人
const updateOwner = (value: any) => {
  let idx = editModal.shopList.findIndex((item) => item.id === value)
  form.value.owner = editModal.shopList[idx].owner??'';
}
// 筛选title
const titleName = computed(() => {
  switch (editModal.type) {
    case 'add':
      return '新增铺货关系'
      break;
    case 'edit':
      return '编辑铺货关系'
      break;
    case 'prices':
      return '铺货关系调价申请'
      break;
    case 'prices_edit':
      return '铺货关系调价申请'
      break;
    default:
      break;
  }
})
//校验铺货单价
const rulesPrice = computed(() => [
  {
    validator: (value: any, callback: any) => {
      let val = value + '';
      if (val == "" || val === 'NaN' || val === 'undefined') {
        callback("请输入铺货单价");
        return
      }
      if (val) {
        return new Promise<void>((resolve) => {
          const priceReg = /^\d+(\.\d{1,4})?$/;
          if (!priceReg.test(value)) callback("请输入正确的铺货单价");
          resolve();
        });
      }
    },
    required: true
  },
]);
defineExpose({
  handleShowModal
});
</script>