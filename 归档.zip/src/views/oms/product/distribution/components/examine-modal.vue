<!-- 商品管理->铺货关系->审核表单组件 -->
<template>
  <a-modal :mask-closable="false" :title="titleName" width="500px" v-model:visible="examineModal.show" title-align="start"
    :on-before-ok="onOk" @cancel="onCancel" unmountOnClose :ok-loading="loading">
    <a-form :model="form" ref="formRef" layout="horizontal">
      <div class="formStyle marginB10"
        v-if="examineModal.type === 'batch-examine' || examineModal.type === 'batch-confrim'">
        确定{{examineModal.type === 'batch-examine'?'审核':'确认'}}已选中的
        <span>{{ form.lstId.length }}</span> 条铺货关系？
      </div>
     
      <a-form-item field="auditStatus" :label="labelName()" label-col-flex="100px" required
        :rules="checkStatus">
        <a-select placeholder="请选择" v-model="(form.auditStatus as string)" allow-search>
          <a-option value="true">通过</a-option>
          <a-option value="false">不通过</a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="remark" label="备注" label-col-flex="100px" :rules="checkRemark">
        <a-textarea :maxLength="200" v-limit-input="['#', '']" show-word-limit v-model.trim="form.remark"
          placeholder="限200字，如不通过则必填" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-distribution-examine">
import { computed, reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { auditMapping, auditPrice } from '@/api/product/distribution';
import { AuditMappingFrom } from '@/types/product/distribution';
// 字典编辑表单弹窗
interface ExamineModal {
  show: boolean;
  type: string;
  data?: any
}
const examineModal = reactive<ExamineModal>({
  show: false,
  type: '',
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void;
  (e: "close"): void
}>();
//审核备注校验
const checkRemark = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (form.value.auditStatus == 'false' && (!value || value == "")) {
        callback("请输入审核备注");
        return
      }
    },
    required: form.value.auditStatus == 'false'
  },
]);
//审核备注校验
const checkStatus = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (!value || value == "") {
        callback(`请选择${['batch-confrim', 'confrim'].includes(examineModal.type)?'确认':'审核'}结果`);
        return
      }
    },
    required: true
  },
]);
const form = ref<AuditMappingFrom>(new AuditMappingFrom());
const formRef = ref();
const loading = ref<boolean>(false);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  if (form.value.auditStatus == 'false' && !form.value.remark) {
    Message.error('请输入备注');
    return false;
  }
  loading.value = true;
  try {
    const apiType = examineModal.type === 'examine-distribution' ? auditMapping : auditPrice;
    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    emits("close");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  } finally {
    loading.value = false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { emits("close"); form.value = new AuditMappingFrom(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: string, data: number[]) => {
  examineModal.show = true;
  examineModal.type = type;
  form.value = new AuditMappingFrom();
  form.value.lstId = data;

  if (examineModal.type === 'examine-distribution') {
    form.value.auditNode = '审核铺货'
  } else if (examineModal.type === 'examine-prices' || examineModal.type === 'batch-examine') {
    form.value.auditNode = '调价审核'
  } else {
    form.value.auditNode = '调价确认'
  }
}
// 筛选title
const titleName = computed(() => {
  switch (examineModal.type) {
    case 'examine-distribution':
      return '审核铺货'
      break;
    case 'examine-prices':
      return '审核铺货调价'
      break;
    case 'batch-examine':
      return '批量审核'
      break;
    case 'batch-confrim':
      return '批量确认'
      break;
    case 'confrim':
      return '确认铺货调价'
      break;
    default:
      break;
  }
})

const labelName = () => {
  return ['batch-confrim', 'confrim'].includes(examineModal.type) ? '确认结果：' : '审核结果：'
}

defineExpose({
  handleShowModal
});
</script>
<style lang="less" scoped>
.marginB10 {
  margin-bottom: 20px;
}

.marginB7 {
  margin-bottom: 2px;
}

.formStyle {
  font-size: 13px;
  color: #3A3A3A;

  span {
    color: rgb(245, 63, 63);
  }
}

.signColor {
  color: #999999;
  font-size: 12px;
}
</style>