<!-- 商品管理->铺货关系->审核表单组件 -->
<template>
  <a-modal :mask-closable="false" title="提示" width="500px" v-model:visible="onoroffModal.show" title-align="start" :on-before-ok="onOk"
    @cancel="onCancel" unmountOnClose :ok-loading="loading">
    <a-form :model="form" ref="formRef" layout="horizontal">
      <div class="marginB10">
        确定把铺货关系调整状态调整为
        <span :class="onoroffModal.auditStatus === 6 ? 'up' : 'down'">{{ onoroffModal.auditStatus === 6 ? '上线' : '下线'
        }}</span>？
      </div>
      <div class="marginB10 signColor">调整后会影响订单业务，请谨慎操作。</div>

      <a-form-item field="remark" label="备注说明：" label-col-flex="90px">
        <a-textarea :maxLength="200" v-limit-input="['#', '']" show-word-limit v-model.trim="form.remark"
          placeholder="请输入" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="system-distribution-examine">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { onOrOff } from '@/api/product/distribution';
import { AuditMappingFrom } from '@/types/product/distribution';
// 字典编辑表单弹窗
interface OnoroffModal {
  show: boolean;
  auditStatus: number;
  data?: any
}
const onoroffModal = reactive<OnoroffModal>({
  show: false,
  auditStatus: 0,
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void;
}>();

const form = ref<AuditMappingFrom>(new AuditMappingFrom());
const formRef = ref();
const loading = ref<boolean>(false);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  loading.value = true;
  try {
    const res = await onOrOff(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  } finally {
    loading.value = false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { form.value = new AuditMappingFrom(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (auditStatus: number, data: number) => {
  onoroffModal.show = true;
  onoroffModal.auditStatus = auditStatus;
  form.value.auditStatus = auditStatus !== 5;
  form.value.auditNode = '上线下线'
  form.value.id = data;
}

defineExpose({
  handleShowModal
});
</script>
<style lang="less" scoped>
.marginB10 {
  margin-left: 10px;
  font-size: 13px;
  color: #3A3A3A;
}

.up {
  color: #3E6CFE;
  ;
}

.down {
  color: rgb(245, 63, 63);
}

.signColor {
  color: #999999;
  font-size: 12px;
  margin-bottom: 10px;
}
</style>