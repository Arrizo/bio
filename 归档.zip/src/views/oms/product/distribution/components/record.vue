<template>
  <div class="distribution-record">
    <a-tabs :style="{ width: '100%' }" :active-key="tabValue" @change="changeTab">
      <template #extra>
        <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
      </template>
      <!-- 调价记录 -->
      <a-tab-pane key="price" title="调价记录">
        <record-search :loading="loading" @on-search="recordInit"></record-search>
        <record-list :mpId="form.mpId" :page-num="form.pageNum" :page-size="form.pageSize" :shopList="shopList"
          @reload-details="recordInit" :totalCount="totalCount" :loading="loading" :list="list"></record-list>
      </a-tab-pane>
      <!-- 调价记录 -->
      <a-tab-pane key="log" title="日志">
        <oms-log ref="logRef"></oms-log>
      </a-tab-pane>
    </a-tabs>
    <!-- <div class="distribution-record-title">
      <div class="name">调价记录</div>
      <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
    </div>
    <record-search :loading="loading" @on-search="recordInit"></record-search>
    <record-list :mpId="form.mpId" :page-num="form.pageNum" :page-size="form.pageSize" :shopList="shopList"
      @reload-details="recordInit" :totalCount="totalCount" :loading="loading" :list="list"></record-list> -->
  </div>
</template>

<script setup lang="ts" name="product-distribution-record">
import RecordSearch from './record-search.vue';
import RecordList from './record-list.vue';
import { ref, watch } from 'vue';
import { queryPricePage } from '@/api/product/distribution';
import { Message } from '@arco-design/web-vue';
import { deepClone } from '@/utils/helper';
import OmsLog from '@/components/oms-log/index.vue'
import { DistributionType, PriceRecordReq, PriceRecordType, ShopSelectItem } from '@/types/product/distribution';
let show = ref(false);
let loading = ref(false);
let totalCount = ref();
let list = ref<PriceRecordType[]>()
const form = ref<PriceRecordReq>(new PriceRecordReq());
const props = defineProps({
  distributionData: {
    type: Object, default: new DistributionType()
  },
  shopList: { type: Array<ShopSelectItem>, default: () => [] },
});
const emits = defineEmits<{
  (e: "close"): void,
}>();
const tabValue = ref('price');
const logRef = ref();
const changeTab = (val: any) => {
  tabValue.value = val;
  if (tabValue.value === 'log') {
    let code = `${props.distributionData?.storeCode}${props.distributionData?.platformProductId}${props.distributionData?.skuCode}`
    logRef.value.init(code, '铺货关系', "page", "调价日志");
  }
}

//调价记录请求数据
const recordInit = async (data: PriceRecordReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.auditStatus = params.auditStatus === 'all' ? '' : params.auditStatus;
    params.businessType = params.businessType === 'all' ? '' : params.businessType;

    const res = await queryPricePage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}


//关闭详情
const closeDetails = () => {
  emits('close')
}


watch(
  () => props.distributionData.id,
  () => {
    if (props.distributionData.id) {
      form.value.mpId = props.distributionData.id;
      tabValue.value = 'price';
      recordInit(form.value);
    }
  }, {
  immediate: true,
  deep: true
}
);

</script>

<style lang="less" scoped>
.distribution-record{
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  :deep(.arco-tabs-content) {
    padding-left: 16px;
    padding-right: 16px;
  }

  :deep(.arco-tabs-nav) {
    padding: 0 16px;
  }
}
// .distribution-record {
//   background-color: #fff;
//   padding: 15px 17px 20px 17px;

//   .distribution-record-title {
//     display: flex;
//     justify-content: space-between;
//     align-items: center;
//     padding-bottom: 16px;

//     .name {
//       color: #3A3A3A;
//       font-weight: bold;
//       font-size: 13px;
//     }
//   }

//   .delStyle {
//     font-size: 18px;
//     color: #707070;
//     cursor: pointer;
//   }

//   .arco-tabs-content {
//     padding-left: 16px;
//     padding-right: 16px;
//   }

//   .arco-tabs-nav {
//     padding: 0 16px;
//   }

//   .arco-form .arco-select {
//     width: 208px;
//   }
// }
</style>