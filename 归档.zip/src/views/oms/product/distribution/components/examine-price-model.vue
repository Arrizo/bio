<template>
  <a-modal :mask-closable="false" @close="handleCancel"
    :title="editModal.type === 'examine-price' ? '铺货关系调价审核' : '铺货关系调价确认'" width="82.5%" v-model:visible="editModal.show"
    title-align="start" unmountOnClose>
    <a-form :model="form" layout="inline" ref="formRes" class="examine-price-model">
      <a-form-item field="lstStoreCode" label="店铺：">
        <a-select style="width:208px;" placeholder="请选择" multiple v-model='form.lstStoreCode' :max-tag-count="1"
          allow-search allow-clear>
          <a-option v-for="(item) in editModal.shopList" :label="item.storeName" :value="item.storeCode"></a-option>
        </a-select>
      </a-form-item>
      <a-form-item field="code" label="编码：">
        <a-input v-limit-input v-model.trim="form.code" @keyup.enter="handleSearch" placeholder="请输入" />
      </a-form-item>
      <a-form-item field="name" label="名称：">
        <a-input v-limit-input v-model.trim="form.name" @keyup.enter="handleSearch" placeholder="请输入" />
      </a-form-item>
      <a-form-item field="businessType" label="业务类型：">
        <a-select placeholder="请选择" style="width:208px;" v-model="form.businessType" allow-search allow-clear>
          <a-option value="all">全部</a-option>
          <a-option v-for="(item) in businessTypeList" :label="item.dictionaryTitle" :value="item.dictionaryValue"></a-option>
        </a-select>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
    </a-form>
    <oms-table :loading="loading" :total="totalCount" :current="form.pageNum" :size="form.pageSize" @reload="onReload">
      <template #header-left>
       <div class="btnFlex">
        <a-space :size="28">
          <a-button :disabled="!selectedKeys.length" v-permission="['oms:product:distribution:batchExamine']"
            v-if="editModal.type === 'examine-price'" type="primary" status="normal"
            @click="handleAction('batch-examine')"> 批量审核
          </a-button>
          <a-button :disabled="!selectedKeys.length" v-permission="['oms:product:distribution:batchConfrim']"
            v-if="editModal.type === 'confrim'" type="primary" status="normal" @click="handleAction('batch-confrim')">
            批量确认
          </a-button>
        </a-space>
          <div class="confirmTig" v-if="editModal.type !== 'examine-price'">
            确认通过后铺货关系调价记录自动上线，请谨慎操作</div>
       </div>
      </template>

      <a-table ref="tableRef" stripe :bordered="{ wrapper: false }" :data="(list as any)" :pagination="false" row-key="id"
        :row-selection="{
          type: 'checkbox',
          showCheckedAll: true
        }" :scroll="{ x: 300, y: 342 }" v-model:selectedKeys="selectedKeys">
        <template #columns>
          <a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
            <template #cell="{ rowIndex }">
              {{ rowIndex + 1 }}
            </template>
          </a-table-column>
          <a-table-column title="店铺名称" :width="180" ellipsis tooltip data-index="storeName">
            <template #cell="{ record }">{{ record.storeName || '--' }}</template>
          </a-table-column>
          <a-table-column title="平台商品id" :width="180" ellipsis tooltip data-index="platformProductId">
            <template #cell="{ record }">{{ record.platformProductId || '--' }}</template>
          </a-table-column>
          <a-table-column title="平台商品名称" :width="180" ellipsis tooltip data-index="platformProductName">
            <template #cell="{ record }">{{ record.platformProductName || '--' }}</template>
          </a-table-column>
          <a-table-column title="平台规格id" :width="180" ellipsis tooltip data-index="platformSkuId">
            <template #cell="{ record }">{{ record.platformSkuId || '--' }}</template>
          </a-table-column>
          <a-table-column title="平台规格名称" :width="180" ellipsis tooltip data-index="platformSkuName">
            <template #cell="{ record }">{{ record.platformSkuName || '--' }}</template>
          </a-table-column>
          <a-table-column title="商品编码" :width="180" ellipsis tooltip data-index="skuCode">
            <template #cell="{ record }">{{ record.skuCode || '--' }}</template>
          </a-table-column>
          <a-table-column title="商品名称" :width="180" ellipsis tooltip data-index="skuName">
<template #cell="{ record }">{{ record.skuName || '--' }}</template>
          </a-table-column>
          <a-table-column title="是否组合" :width="100" ellipsis tooltip data-index="combination">
            <template #cell="{ record, rowIndex }">
              {{ record.combination ? '是' : '否' }}
            </template>
          </a-table-column>
          <a-table-column title="价格(元)" cell-class="paddingR40" :width="130" ellipsis tooltip data-index="price" align="right">
            <template #cell="{ record }">{{ record.price || '--' }}</template>
          </a-table-column>
          <a-table-column title="业务类型" :width="120" ellipsis tooltip data-index="businessTypeName">
            <template #cell="{ record }">{{ record.businessTypeName || '--' }}</template>
          </a-table-column>

          <a-table-column title="生效时间" :width="180" ellipsis tooltip data-index="effectiveTime">
          </a-table-column>
          <a-table-column title="失效时间" :width="180" data-index="invalidTime">
          </a-table-column>
          <a-table-column title="操作" :width="80" fixed="right">
            <template #cell="{ record }">
              <a-space :size="28">
                <a-link v-if="editModal.type === 'examine-price'" @click="handleAction('examine', record)"
                  type="text">审核</a-link>
                <a-link v-if="editModal.type === 'confrim'" @click="handleAction('confrim', record)"
                  type="text">确认</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
    <template #footer>
      <a-space :size="14">
        <a-button @click="handleCancel">关闭</a-button>
      </a-space>
    </template>
    <!-- 审核铺货 -->
    <examine-modal ref="examineDistribution" @reload="handleSearch" @close="selectClose"></examine-modal>
  </a-modal>
</template>

<script setup lang="ts" name="product-category-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { AuditPageReq, AuditPageType, ShopSelectItem } from '@/types/product/distribution';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { queryAuditPage } from '@/api/product/distribution';
import { Message } from '@arco-design/web-vue';
import { deepClone } from '@/utils/helper';
import ExamineModal from './examine-modal.vue';

interface EditModal {
  show: boolean;
  type: string;
  shopList: Array<ShopSelectItem>;
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "examine",
  shopList: [],
  data: null
});

const businessTypeList = ref<DictionaryTitleType[]>();
const list = ref<AuditPageType[]>()
const selectedKeys = ref<string[] | number[]>([])
const formRes = ref();
const form = ref<AuditPageReq>(new AuditPageReq());
const loading = ref<boolean>(false);
const totalCount = ref();
const tableRef = ref();
const examineDistribution = ref()

const emits = defineEmits<{
  (e: "close"): void
}>();
// 搜索
const handleSearch = async () => {
  try {

    loading.value = true;
    let params = deepClone(form.value);
    params.businessType = params.businessType === 'all' ? '' : params.businessType;
    const res = await queryAuditPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    form.value.pageNum = res.value.pageNum;
    form.value.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
};

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: string, shopList: ShopSelectItem[], data: number) => {
  editModal.type = type;
  form.value.auditStatus = type === 'examine-price' ? 1 : 3
  editModal.show = true;
  editModal.shopList = shopList;
  //获取业务类型
  businessTypeList.value = await getDictionaryList('BUSINESS_TYPE')
  handleSearch();
}


// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  handleSearch();
};

//操作按钮
const handleAction = (type: string, data?: AuditPageType) => {
  switch (type) {
    case 'batch-examine'://批量审核
      if (selectedKeys.value.length == 0) return Message.error('请选择需要处理的数据！');
      examineDistribution.value.handleShowModal('batch-examine', selectedKeys.value);
      break;
    case 'examine'://审核
      examineDistribution.value.handleShowModal('examine-prices', [data?.id]);
      break;
    case 'batch-confrim'://批量确认
      if (selectedKeys.value.length == 0) return Message.error('请选择需要处理的数据！');
      examineDistribution.value.handleShowModal('batch-confrim', selectedKeys.value);
      break;
    case 'confrim'://确认
      examineDistribution.value.handleShowModal('confrim', [data?.id]);
      break;
    default:
      break;
  }

}


//取消选中效果
const selectClose = () => {
  selectedKeys.value = []
  tableRef.value.selectAll(false);
}

//关闭
const handleCancel = () => {
  editModal.show = false;
  handleReset();
  emits("close");
}


defineExpose({
  handleShowModal
});
</script>
<style lang="less" scoped>
.btnFlex{
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}
.confirmTig{
  color: #FF9E20;
  font-size: 12px;
  margin-left: 15px;
}
</style>