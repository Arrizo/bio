<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-13 14:19:00
 * @ Modified by: Sam
 * @ Modified time: 2023-03-28 17:12:32
 * @ Description: 拆分策略-表单
 -->
<template>
  <a-modal :title="`${editModal.type === 'add' ? '新增' : '编辑'}策略`" width="500px" v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" unmountOnClose :esc-to-close="false" :mask-closable="false">
    <div style="padding: 0 6px 0 2px;">
      <a-form ref="formRef" :model="form">
        <a-form-item field="title" label="策略名称：" label-col-flex="90px" :rules="[{ required: true, message: '请输入策略名称' }]">
          <a-input v-limit-input show-word-limit :max-length="100" v-model="form.title" placeholder="请输入" allow-clear />
        </a-form-item>
        <a-form-item field="remark" label="备注：" label-col-flex="90px">
          <a-input v-limit-input show-word-limit :max-length="200" v-model="form.remark" placeholder="请输入" allow-clear />
        </a-form-item>
      </a-form>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="strategy-split-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { StrategyForm, StrategyType } from '@/types/strategy/strategy';
import { addStrategy, updateStrategy } from '@/api/strategy/strategy';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const formRef = ref();
const form = ref<StrategyForm>(new StrategyForm());

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const api = editModal.type === 'add' ? addStrategy : updateStrategy;
    form.value.strategyType = StrategyType.Cfcl;
    const res = await api(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: any) => {
  editModal.type = type;
  editModal.show = true;

  if (type === 'add') {
    form.value = new StrategyForm();
  }

  if (type === "edit") {
    try {
      form.value.id = data.id;
      form.value.remark = data.remark;
      form.value.strategyType = data.strategyType;
      form.value.companyCode = data.companyCode;
      form.value.title = data.title;
    } catch (err) {
      Message.error((err as Error).message);
    }
  }
}

defineExpose({
  handleShowModal
});
</script>

<style lang="less" scoped>
.form-title {
  color: #3A3A3A;
  font-size: 13px;
  font-weight: bold;
  line-height: 17px;
}
</style>