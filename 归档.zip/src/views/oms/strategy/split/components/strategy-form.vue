<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-16 14:16:08
 * @ Modified by: Sam
 * @ Modified time: 2023-03-28 14:10:31
 * @ Description: 拆分策略配置-表单
 -->

<template>
  <a-modal title="策略配置" width="846px" v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk"
    unmountOnClose :esc-to-close="false" :mask-closable="false" modal-class="strategy-form-modal">
    <div style="padding: 0 6px;">
      <p class="form-title" style="margin-top: 0;margin-bottom: 16px;">基本信息</p>
      <a-row>
        <a-form ref="formRef" :model="form" layout="inline">
          <a-col :span="12">
            <a-form-item label="策略编码：" label-col-flex="100px">
              <a-input disabled v-model="strategyData.code"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="策略名称：" label-col-flex="100px">
              <a-input disabled v-model="strategyData.title"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="splitMethod" label="拆分方式：" label-col-flex="100px"
              :rules="[{ required: true, message: '请选择拆分方式' }]">
              <a-select v-model="form.splitMethod" placeholder="请选择">
                <a-option v-for="v in splitMethodList" :label="v.dictionaryTitle" :value="v.dictionaryValue"></a-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="splitNum" :label="`拆分${typeObj[form.splitMethod]?.title}：`" label-col-flex="100px"
              :rules="[{ required: true, message: `请输入拆分${typeObj[form.splitMethod]?.title}` }]">
              <a-input-number v-limit-input hide-button :min="form.splitMethod === 'number' ? 0 : 0.01" :precision="form.splitMethod === 'number' ? 0 : 2"
                v-model="form.splitNum" placeholder="请输入" allow-clear>
                <template #append>
                  {{ typeObj[form.splitMethod]?.unit }}
                </template>
              </a-input-number>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="sort" label="优先级：" label-col-flex="100px"
              :rules="[{ required: true, message: '请输入优先级' }]">
              <a-input-number v-limit-input v-model="form.sort" placeholder="请输入" :min="1" :max="9999999" allow-clear />
            </a-form-item>
          </a-col>
        </a-form>
      </a-row>

      <p class="form-title" style="margin-top: 20px;">策略条件</p>
      <oms-strategy ref="omsStrategyRef" :id="form.id" :edit-type="editModal.type" :type="StrategyType.Cfcl"
        height="100px" max-height="100px"></oms-strategy>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="split-strategy-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import omsStrategy from "@/components/oms-strategy/index.vue"
import { SplitForm } from '@/types/strategy/split';
import { addOrUpdateSplit, getSplitDetail } from '@/api/strategy/split';
import { getDictionaryTitle } from '@/api/system/dictionary';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { StrategyType } from '@/types/strategy/order';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const omsStrategyRef = ref();
const formRef = ref();
const strategyData = ref();
const form = ref<SplitForm>(new SplitForm());
const splitMethodList = ref<DictionaryTitleType[]>([]);
const typeObj = {
  number: { title: "数量", unit: "个" },
  volume: { title: "体积", unit: "cm³" },
  weight: { title: "重量", unit: "g" }
}

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    form.value.strategyId = strategyData.value.id;
    form.value.strategyConfigList = omsStrategyRef.value.getValue();

    const res = await addOrUpdateSplit(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: any, strategyInfo: any) => {
  strategyData.value = strategyInfo;
  editModal.type = type;
  editModal.show = true;


  if (type === 'add') {
    form.value = new SplitForm();
  }

  if (type === "edit") {
    try {
      const res = await getSplitDetail(data.id);
      if (res.code != 0) {
        return Message.error(res.message);
      }
      form.value = res.value;
    } catch (err) {
      Message.error((err as Error).message);
    }
  }

  // 查询拆分相关字典数据
  try {
    const res = await getDictionaryTitle("SPLIT_METHOD");
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }

    splitMethodList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

defineExpose({
  handleShowModal
});
</script>

<style lang="less" scoped>
:deep(.arco-input-append) {
  width: 32px;
  background-color: #F6F6F6 !important;
  border: 1px solid #EDEDED;
  color: #3A3A3A;
  padding: 0;
  justify-content: center;
  font-size: 13px;
}
</style>

<style lang="less" >
.strategy-form-modal {
  .form-title {
    color: #3A3A3A;
    font-size: 13px;
    font-weight: bold;
    line-height: 17px;
  }

  .arco-form-layout-inline .arco-form-item {
    margin-bottom: 20px;
  }

  .arco-modal-body {
    padding: 24px 28px 24px 38px !important;
  }

  .arco-modal-footer {
    margin-top: 20px;
  }
}
</style>