<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-17 14:05:53
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-27 20:17:09
 * @ Description: 拆分策略-策略列表
 -->

<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onTableReload">
    <template #header-left>
      <a-button  v-permission="['oms:strategy:split:add']" type="primary" status="normal" @click="handleAddClick" style="margin-bottom: 10px;"> 新增 </a-button>
    </template>

    <a-table v-db-click="list" stripe :db-call-back="handleDbClick" :data="(list as any)" :pagination="false"
      hide-expand-button-on-empty row-key="id" :bordered="{ wrapper: false }" :scroll="{ x: 1400 }">
      <template #columns>
        <a-table-column title="策略编码" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.code || '--' }} </template>
        </a-table-column>
        <a-table-column title="策略名称" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.title || '--' }} </template>
        </a-table-column>
        <a-table-column title="备注" ellipsis tooltip>
          <template #cell="{ record }"> {{ record.remark || '--' }} </template>
        </a-table-column>
        <a-table-column title="状态" :width="120">
          <template #cell="{ record, rowIndex }">
            <div v-permission="['oms:strategy:split:status']">
              <a-switch v-model="(list as any)[rowIndex].status" @focus="onSwitchForce(record, rowIndex)">
                <template #checked>
                  启用
                </template>
                <template #unchecked>
                  禁用
                </template>
              </a-switch>
            </div>
            <div v-permission-else="['oms:strategy:split:status']">{{ record.status ? '启用' : '禁用' }}</div>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" ellipsis tooltip :width="180">
          <template #cell="{ record }"> {{ record.createTime || '--' }} </template>
        </a-table-column>
        <a-table-column title="修改时间" ellipsis tooltip :width="180">
          <template #cell="{ record }"> {{ record.updateTime || '--' }} </template>
        </a-table-column>
        <a-table-column title="操作" :width="100" fixed="right">
          <template #cell="{ record }">
            <a-space :size="14">
              <a-link  v-permission="['oms:strategy:split:edit']" v-if="!record.status" @click="handleActoin('edit', record)" type="text">编辑</a-link>
              <a-link  v-permission="['oms:strategy:split:del']" v-if="!record.status" @click="handleActoin('del', record)" status="danger" type="text">删除</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 新增/编辑 -->
  <strategy-form ref="formRef" @reload="emits('reload')"></strategy-form>

  <!-- 修改状态二次确认 -->
  <oms-warning ref="switchRef" :on-before-ok="handleUpdateStatus"></oms-warning>

  <!-- 删除二次确认 -->
  <oms-warning ref="delRef" :on-before-ok="handleDelete"></oms-warning>
</template>

<script setup lang="ts" name="strategy-split-list">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import strategyForm from "./form.vue";
import { Message } from '@arco-design/web-vue';
import { statusDocReview, delDocReview } from '@/api/strategy/order';

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  total: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload", data?: any): void,
  (e: "on-db-click", data: any): void,
}>();

const delRef = ref();
const delId = ref();
const switchRef = ref();
const formRef = ref();
const statusData = reactive({
  id: NaN,
  index: NaN,
  status: false
});

// 「新增」按钮点击触发
const handleAddClick = () => {
  formRef.value.handleShowModal("add");
};

/** 行双击触发 */
const handleDbClick = (data: any) => {
  emits("on-db-click", data)
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: any, index: number) => {
  statusData.id = record?.id;
  statusData.index = index;
  statusData.status = record?.status;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
}

// 表格分页触发
const onTableReload = (data: { pageNum: number; pageSize: number }) => {
  emits('reload', data);
}

/**
 * 操作处理
 * @param type
 * @param data
 */
const handleActoin = async (type: "edit" | "del", data: any) => {
  if (type === "edit") {
    formRef.value.handleShowModal("edit", data);
    return;
  }
  if (type === 'del') {
    delId.value = data?.id || NaN;
    delRef.value.open();
    return;
  }
};

// 修改状态
const handleUpdateStatus = async () => {
  try {
    const res = await statusDocReview({
      id: statusData.id,
      status: !statusData.status
    });
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delDocReview(delId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}
</script>