<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-13 10:14:39
 * @ Modified by: Sam
 * @ Modified time: 2023-03-27 15:47:15
 * @ Description: 拆分策略-搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="code" label="策略编码：">
      <a-input v-limit-input @keyup.enter="handleSearch(false)" v-model.trim="form.code" allow-clear placeholder="请输入" />
    </a-form-item>
    <a-form-item field="title" label="策略名称：">
      <a-input v-limit-input @keyup.enter="handleSearch(false)" v-model.trim="form.title" allow-clear placeholder="请输入" />
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="(form.status as string)" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="strategy-split-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { DocReviewSearchForm } from '@/types/strategy/order';
import { deepClone } from '@/utils/helper';
import { onMounted, ref } from 'vue';

const props = defineProps({
  loading: { type: Boolean, default: false }
});

const emits = defineEmits<{
  (e: "on-search", data: any, isReset: boolean): void;
}>();

const formRes = ref();
const form = ref<DocReviewSearchForm>(new DocReviewSearchForm());

const handleSearch = (isReset: boolean = false) => {
  const data = deepClone(form.value);
  data.status = form.value.status === 'all' ? '' : form.value.status;

  emits("on-search", data, isReset)
};

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch(true);
}

onMounted(() => {
  handleSearch();
});
</script>