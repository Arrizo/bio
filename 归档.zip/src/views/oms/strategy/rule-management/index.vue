<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:27:28
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-22 15:48:17
 * @ Description:规则管理
 -->

<template>
  <div class="panel-height">
    <oms-panel>
      <template #header>
        <search :loading="loading" :temList="temList" @on-search="initData"></search>
      </template>
      <list :loading="loading" :temList="temList" @details="handleDetailsClick" :totalCount="totalCount"
        :page-num="form.pageNum" :page-size="form.pageSize" :list="list" @reload="initData">
      </list>
    </oms-panel>
    <!-- 详情 -->
    <rule-details v-if="detailsVisible" :ruleId="detailsId" @close="closeDetails"></rule-details>
  </div>
</template>
<script setup lang="ts" name="strategy-export-import">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue'
import List from './components/list.vue'
import RuleDetails from './components/details.vue'
import { queryPage, queryTemSelect } from '@/api/strategy/rule-mangement';
import { Message } from '@arco-design/web-vue';
import { onMounted, ref } from 'vue';
import { deepClone } from '@/utils/helper';
import { RuleManagementReq, RuleManagementType, TemType } from '@/types/strategy/rule-mangement';
const form = ref<RuleManagementReq>(new RuleManagementReq());
const loading = ref<boolean>(false);
const list = ref<RuleManagementType[]>();
const totalCount = ref();
const detailsVisible = ref<boolean>(false);
const detailsId = ref()
const temList = ref<TemType[]>()
/**
 * 初始化查询菜单数据
 * @param form
 */

const initData = async (data: RuleManagementReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.templateId = params.templateId === 'all' ? '' : params.templateId;

    const res = await queryPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

//详情
const handleDetailsClick = (data: RuleManagementType) => {
  detailsVisible.value = true;
  detailsId.value = data.id;
}
//关闭详情
const closeDetails = () => {
  detailsVisible.value = false;
}

//查询模版名称 
const queryTemList = async () => {
  try {
    const res = await queryTemSelect();

    if (res.code != 0) {
      throw new Error(res.message);
    }
    temList.value = res.value ?? [];
  } catch (err) {
    Message.error((err as Error).message);
  }
}
onMounted(async () => {
  queryTemList();
});
</script>
<style lang="less" scoped>
.panel-height {
  height: 100%;
}
</style>
