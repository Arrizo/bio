<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-20 15:27:09
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-24 11:41:15
 * @ Description:新增拦截配置
 -->


<template>
  <a-modal :mask-closable="false" title="拦截配置" width="400px" v-model:visible="editModal.show" title-align="start"
    :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-form-item label="订单状态：" prop="statusName" label-col-flex="100px" required
        :rules="[{ required: true, message: '请输入订单状态' }]">
        <a-input placeholder="请输入" v-model.trim="form.statusName" allow-clear :max-length="50" style="width: 208px">
        </a-input>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="strategy-rule-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { addStatus } from '@/api/strategy/rule-mangement';
// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any,
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});


const emits = defineEmits<{
  (e: "reload-list"): void
}>();

class StatusType {
  id: number = 0;
  statusName: string = ''
}

const form = ref<StatusType>(new StatusType());
const formRef = ref();
const loading = ref<boolean>(false);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  loading.value = true;
  try {

    const res = await addStatus(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload-list");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (id: number) => {
  form.value = new StatusType();
  editModal.show = true;
  form.value.id = id;

}

defineExpose({
  handleShowModal
});
</script>
<style lang="less" scoped></style>