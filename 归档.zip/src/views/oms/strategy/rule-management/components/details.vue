<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-17 16:35:11
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-24 11:26:55
 * @ Description:规则详情（实物）
 -->

<template>
  <div class="rule-details">
    <div class="rule-details-title">
      <a-tabs :style="{ width: '100%' }" :active-key="tabValue" @change="changeTab">
        <template #extra>
          <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
        </template>
        <a-tab-pane key="rule-configuration" title="规则配置">
          <div class="ruleDispose">
            <a-checkbox-group v-model="list_temp">
              <a-checkbox v-for="(item, index) in showContentlOption" :value="item.value" :key="`d-${index}`" disabled>{{
                item.label }}</a-checkbox>
            </a-checkbox-group>
          </div>
        </a-tab-pane>
        <a-tab-pane key="interception-configuration" title="拦截配置">
          <interception-configuration :list="statusList" :totalCount="statusTotalCount" :ruleId="props.ruleId"
            @reload-list="getStatusInfo" @details-info="getInfo"></interception-configuration>
        </a-tab-pane>
        <a-tab-pane key="confirm-product" title="确认商品" v-if="form.customerService">
          <confirm-product :list="spuList" :totalCount="spuTotalCount" :ruleId="props.ruleId"
            @reload-list="getProductInfo"></confirm-product>
        </a-tab-pane>
      </a-tabs>
    </div>
  </div>
</template>

<script setup lang="ts" name="system-rule-details">
import { onMounted, ref, watch } from 'vue';
import { Message } from '@arco-design/web-vue';
import ConfirmProduct from './confirm-product.vue'
import InterceptionConfiguration from './interception-configuration.vue'
import { getRuleDetail, listSpu, listStatus } from '@/api/strategy/rule-mangement';
import { RuleDetailsType, RuleSpuReq, RuleStatusReq } from '@/types/strategy/rule-mangement';

const props = defineProps({
  ruleId: {
    type: Number, default: null
  },
});
const emits = defineEmits<{
  (e: "close"): void,
}>();
const loading = ref<boolean>(false);
const form = ref<RuleDetailsType>(new RuleDetailsType())
const tabValue = ref('rule-configuration');
// 拦截配置相关参数
const statusForm = ref<RuleStatusReq>(new RuleStatusReq());
const statusList = ref();
const statusTotalCount = ref()
// 确认商品相关参数
const spuForm = ref<RuleSpuReq>(new RuleSpuReq());
const spuList = ref();
const spuTotalCount = ref();

//选中的值
let list_temp = ref<Array<number | string>>([]);
const showContentlOption = [
  {
    label: "拆分单元格",
    value: "splitCell",
    disabled: false,
  },
  {
    label: "拆分详细地址",
    value: "splitAddress",
    disabled: false,
  },
  {
    label: "拆分省市区",
    value: "splitToArea",
    disabled: false,
  },
  {
    label: "组合地址",
    value: "joinAddress",
    disabled: false,
  },
  {
    label: "取省市+详细地址区",
    value: "fetchCityDetailsDistrict",
    disabled: false,
  },
  {
    label: "补充市区",
    value: "addMissAddress",
    disabled: false,
  },
  {
    label: "组合支付时间",
    value: "combPayTime",
    disabled: false,
  },
  {
    label: "计算单价",
    value: "computeUnitPrice",
    disabled: false,
  },
  {
    label: "拦截无运单订单",
    value: "interceptExpressNo",
    disabled: false,
  },
  {
    label: "虚拟收件信息",
    value: "virtualInfo",
    disabled: false,
  },
  {
    label: "客服确认",
    value: "customerService",
    disabled: false,
  },
];

//切换tab
const changeTab = (val: any) => {
  tabValue.value = val;
  if (val === 'interception-configuration') {
    statusForm.value.pageNum = 1;
    statusForm.value.pageSize = 10;
    getStatusInfo()
  } else if (val === 'confirm-product') {
    spuForm.value.ruleId = props.ruleId;
    spuForm.value.pageNum = 1;
    spuForm.value.pageSize = 10;
    getProductInfo();
  }
}

//关闭详情
const closeDetails = () => {
  emits('close')
}

//确认商品列表查询
const getProductInfo = async (data: RuleSpuReq = {}) => {
  try {
    spuForm.value = { ...spuForm.value, ...data }
    loading.value = true;
    let params = JSON.parse(JSON.stringify(spuForm.value));
    const res = await listSpu(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    spuList.value = res.value.result;
    spuTotalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

//拦截配置列表查询
const getStatusInfo = async (data: RuleStatusReq = {}) => {
  try {
    statusForm.value = { ...statusForm.value, ...data }
    loading.value = true;
    let params = JSON.parse(JSON.stringify(statusForm.value));
    const res = await listStatus(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    statusList.value = res.value.result;
    statusTotalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
    for (let i = 0; i < statusList.value.length; i++) {
        const item: any = statusList.value[i];
        item.statusValue = form.value.lstOrderStatus?.includes(item.statusName)
      }
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

//查询规则配置数据
const getInfo = async () => {
  try {
    loading.value = true;

    const res = await getRuleDetail(props.ruleId);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    form.value = JSON.parse(JSON.stringify(res.value));
    getCheckboxValue();
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}


//checkbox数据整理

const getCheckboxValue = () => {
  list_temp.value = [];
  let checkboxValue = {
    splitAddress: form.value.splitAddress,
    splitToArea: form.value.splitToArea,
    joinAddress: form.value.joinAddress,
    splitCell: form.value.splitCell,
    virtualInfo: form.value.virtualInfo,
    interceptExpressNo: form.value.interceptExpressNo,
    combPayTime: form.value.combPayTime,
    fetchCityDetailsDistrict: form.value.fetchCityDetailsDistrict,
    computeUnitPrice: form.value.computeUnitPrice,
    addMissAddress: form.value.addMissAddress,
    customerService: form.value.customerService,
  };

  for (let key in checkboxValue) {
    if ((checkboxValue as any)[key]) {
      list_temp.value.push(key);
    }
  }
};

watch(
  () => props.ruleId,
  () => {
    if (props.ruleId) {
      tabValue.value = 'rule-configuration';
      getInfo();
    }
  }, {
  immediate: true,
  deep: true
});
</script>

<style lang="less" >
.rule-details {
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  .arco-tabs-content {
    padding-left: 16px;
    padding-right: 16px;
  }

  .arco-tabs-nav {
    padding: 0 16px;
  }

  .ruleDispose {
    margin-left: 36px;
    width: 628px;
    padding: 10px 0;

    .arco-checkbox-group {
      .arco-checkbox:nth-child(1) {
        width: 100%;
      }

      .arco-checkbox:nth-child(2),
      .arco-checkbox:nth-child(3),
      .arco-checkbox:nth-child(4) {
        margin-top: 14px;
        margin-bottom: 6px;
      }

      .arco-checkbox:nth-child(3) {
        padding: 0 110px 0 140px;
      }

      .arco-checkbox:nth-child(5),
      .arco-checkbox:nth-child(6),
      .arco-checkbox:nth-child(7) {
        margin-bottom: 6px;
      }

      .arco-checkbox:nth-child(6) {
        padding-left: 104px;
        width: 50%;
      }

      .arco-checkbox:nth-child(8) {
        margin-top: 14px;
        padding: 0 128px 0 140px;
      }

      .arco-checkbox:nth-child(8),
      .arco-checkbox:nth-child(9),
      .arco-checkbox:nth-child(10) {
        margin-bottom: 6px;
      }

      .arco-checkbox:nth-child(10) {
        margin-top: 14px;
        padding-left: 127px;
      }

      .arco-checkbox:nth-child(11) {
        padding-left: 102px;
      }
    }
  }
}
</style>