<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-20 15:27:27
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 09:24:57
 * @ Description:新增商品
 -->
<template>
  <a-modal v-model:visible="formModal.show" :mask-closable="false" title="新增" :width="900" title-align="start"
    :on-before-ok="onBeforeOk" @cancel="closeModel" unmount-on-close>
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form :model="form" layout="inline" ref="searchRef">
      <a-form-item field="code" label="商品编码：">
        <a-input v-model="form.code" placeholder="请输入" allow-clear :style="{ width: '200px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="title" label="商品名称：">
        <a-input v-model.trim="form.title" placeholder="请输入" allow-clear :max-length="200" :style="{ width: '200px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
    </a-form>
    <!-- </template> -->
    <oms-table :loading="loading" :simplePagination="true" :total="totalCount" :current="form.pageNum"
      :size="form.pageSize" @reload="onReload">
      <a-table :bordered="{ wrapper: false }" stripe ref="tableRef" :data="(list as any)" :pagination="false" row-key="id"
        :row-selection="{
          type: 'checkbox',
          showCheckedAll: true
        }" :scroll="{ y: 330 }" @select="selectionChange" v-model:selectedKeys="selectedKeys">
        <template #columns>
          <a-table-column title="商品编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="商品名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </a-modal>
</template>
<script lang="ts" setup name="strategy-rule-production-form">
import { getList } from '@/api/product/goods';
import { addSpu } from '@/api/strategy/rule-mangement';
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { Message } from "@arco-design/web-vue"
import OmsTable from '@/components/oms-table/index.vue';
import { reactive, ref } from 'vue';
import { GoodsSearchForm } from '@/types/product/goods';
import { SaveRule } from '@/types/strategy/rule-mangement';
interface FormModal {
  show: boolean;
}
const formModal = reactive<FormModal>({
  show: false,
});

const emits = defineEmits<{
  (e: "reload-list"): void;
}>();
const loading = ref<boolean>(false);
const addLoading = ref<boolean>(false);
const searchRef = ref();
const totalCount = ref(0);
const tableRef = ref();
const list = ref();
const ruleId = ref(0)
const saveForm = ref<SaveRule>(new SaveRule());

type selectArrType = {
  id: number;
  ruleId: number;
  productCode: string;
  productName: string;
}
const selectArr = ref<selectArrType[]>([])

const selectedKeys = ref<string[]>([]);
let form = ref<GoodsSearchForm>(new GoodsSearchForm())
const handleSearch = async () => {
  try {
    loading.value = true
    let params = JSON.parse(JSON.stringify(form.value));
    params.auditStatus = params.auditStatus === 'all' ? '' : params.auditStatus;
    params.dispatch = params.dispatch === 'all' ? '' : params.dispatch;
    params.k3PushStatus = params.k3PushStatus === 'all' ? '' : params.k3PushStatus;
    params.wmsSyncStatus = params.wmsSyncStatus === 'all' ? '' : params.wmsSyncStatus;
    const { code, message, value } = await getList(params)
    if (code != 0) {
      throw new Error(message)
    }
    totalCount.value = value.totalCount;
    list.value = value.result;
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value = { ...form.value, ...data }
  handleSearch();
};

const closeModel = () => {
  list.value = [];
  tableRef.value.selectAll(false);
  selectedKeys.value = [];
  searchRef.value.resetFields();
  selectArr.value = [];
}

const handleReset = () => {
  searchRef.value.resetFields();
  tableRef.value.selectAll(false);
  handleSearch()
}

//选择数据进行处理
const selectionChange = (rowKeys: Array<number | string>) => {
  let obj = {
    id: 0,
    ruleId: ruleId.value,
    productCode: "",
    productName: "",
  }
  //添加商品
  for (let i = 0; i < list.value.length; i++) {
    const itm = list.value[i];
    for (let j = 0; j < rowKeys.length; j++) {
      const jtm = rowKeys[j];
      if (itm.id === jtm) {//相等则添加
        obj.id = Number(jtm);
        obj.productCode = itm.productCode;
        obj.productName = itm.productTitle;
        selectArr.value.push(obj)
      }
    }
  }
  // 添加的商品集与选中的集合取交集
  saveForm.value.lstRuleSpu = handleCountClient(selectArr.value.filter((item) => rowKeys.includes(item.id)))
}
// 去重
const handleCountClient = (arr: any[]) => {
  const obj = {}
  const peon = arr.reduce((cur, next) => {
    obj[next.id] ? '' : obj[next.id] = true && cur.push(next)
    return cur
  }, [])
  return peon
}

const onBeforeOk = async () => {
  if (!saveForm.value.lstRuleSpu?.length) {
    Message.error('请选择需要添加的商品');
    return false;
  }
  addLoading.value = true;
  try {

    const res = await addSpu(saveForm.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    addLoading.value = false;
    // tableRef.value.selectAll(false);
    emits("reload-list");
    selectedKeys.value = [];
    selectArr.value = [];
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    addLoading.value = false;
    return false;
  }
}
/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (id: number) => {
  form.value = new GoodsSearchForm();
  saveForm.value = new SaveRule();
  formModal.show = true;
  form.value.status = 'true';
  ruleId.value = id;
  saveForm.value.id = id;
  // handleSearch()
}

defineExpose({
  handleShowModal
});
</script>