<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-17 18:32:16
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-24 11:42:39
 * @ Description:拦截配置
 -->
<template>
  <div>
    <oms-table :simplePagination="true" :loading="loading" :total="totalCount" :current="form.pageNum" @reload="onReload"
      :size="form.pageSize">
      <template #header-left>
        <a-space :size="14" style="margin-bottom:10px;">
          <a-button v-permission="['oms:strategy:ruleManagement:addStatus']" type="primary" status="normal"
            @click="handleAddClick('add')"> 新增
          </a-button>
        </a-space>
      </template>
      <template #header-right>
        <a-input style="margin-bottom:10px;" allow-clear v-model.trim="form.statusName" :style="{ width: '200px' }" placeholder="输入订单状态"
          @keyup.enter="emits('reload-list', form)" @clear="emits('reload-list')">
          <template #suffix>
            <span class="iconfont icon-icon_sousuo sousuoStyle" @click="emits('reload-list', form)"></span>
          </template>
        </a-input>
      </template>

      <a-table :bordered="{ wrapper: false }" stripe ref="tableRef" :data="(list as any)" :pagination="false"
        :scroll="{ x: 300, y: 228 }">
        <template #columns>
          <a-table-column title="订单状态" ellipsis tooltip :width="260" data-index="statusName">
          </a-table-column>
          <a-table-column title="拦截订单" :width="120" data-index="city">
            <template #cell="{ record, rowIndex }">
              <a-switch v-permission="['oms:strategy:ruleManagement:status']" v-model="record.statusValue"
                @focus="onSwitchForce(record, rowIndex)">
                <template #checked>
                  启用
                </template>
                <template #unchecked>
                  拦截
                </template>
              </a-switch>
            </template>
          </a-table-column>
          <a-table-column title="创建时间" :width="180" data-index="createTime"></a-table-column>
          <a-table-column title="创建人" :width="180" data-index="creator"></a-table-column>
          <a-table-column title="操作" :width="60" fixed="right">
            <template #cell="{ record, rowIndex }">
              <a-space :size="28">
                <a-link v-permission="['oms:strategy:ruleManagement:delStatus']" status="danger"
                  @click="handleAddClick('del', record.id)" type="text">删除</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>

    <!-- 新增/编辑 -->
    <configuration-form ref="ConfigurationRef" @reload-list="emits('reload-list')"></configuration-form>

    <!-- 删除二次确认 -->
    <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>

    <!-- 拦截禁用启用二次确认 -->
    <oms-warning ref="switchRef" :on-before-ok="handleStatus"></oms-warning>
  </div>
</template>

<script setup lang="ts" name="rule-management-interception-configuration">
import { onMounted, ref, watch } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import ConfigurationForm from './configuration-form.vue'
import { Message } from '@arco-design/web-vue';
import { RuleStatusReq } from '@/types/strategy/rule-mangement';
import { delStatus, enableStatus } from '@/api/strategy/rule-mangement';

const props = defineProps({
  ruleId: {
    type: Number, default: null
  },
  list: { type: Array, default: () => [] },
  totalCount: { type: Number, default: 0 },
});
const form = ref<RuleStatusReq>(new RuleStatusReq());

const ConfigurationRef = ref();
const warnignRef = ref();
const tableRef = ref();
const loading = ref<boolean>(false);
const currentId = ref();
const switchRef = ref();
const currentName = ref('')
const emits = defineEmits<{
  (e: "reload-list", data?: RuleStatusReq): void,
  (e:'details-info'): void,
}>();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value = { ...form.value, ...data }
  emits("reload-list", form.value)
};

// 按钮点击触发
const handleAddClick = (type: string, id?: number) => {
  if (type === 'del') {
    currentId.value = id;
    warnignRef.value.open();
    return;
  }
  ConfigurationRef.value.handleShowModal(props.ruleId);
};

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delStatus(currentId.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits('reload-list');
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

// 开关获取焦点触发二次确认
const onSwitchForce = async (record: any, index: number) => {
  currentName.value=record.statusName;
  switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.statusValue ? '已启用' : '已拦截'}？` });
}
const handleStatus =async () => {
  try {
    const res = await enableStatus({ruleId: props.ruleId, statusName: currentName.value});
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits('details-info')
    emits('reload-list');
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

</script>
<style lang="less" scoped>
.sousuoStyle {
  cursor: pointer;
}
</style>
