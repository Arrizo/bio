<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:32:19
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-24 11:35:18
 * @ Description:规则管理搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="templateId" label="模版名称：">
      <a-select placeholder="请选择" v-model='form.templateId' allow-search allow-clear>
        <a-option value="all">全部</a-option>
        <a-option v-for="(item) in temList" :label="item.name" :value="item.id"></a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="name" label="规则名称：">
      <a-input @keyup.enter="handleSearch" :max-length="100" v-limit-input="['#', '']" v-model.trim="form.name" allowClear
        placeholder="请输入" />
    </a-form-item>

    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="strategy-rule-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { RuleManagementReq, TemType } from '@/types/strategy/rule-mangement';
import { onMounted, ref } from 'vue';
const props = defineProps({
  loading: { type: Boolean, default: false },
  temList: { type: Array<TemType>, default: () => [] }
});
const formRes = ref();
const emits = defineEmits<{
  (e: "on-search", data: RuleManagementReq): void;
}>();

const form = ref<RuleManagementReq>(new RuleManagementReq());
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  form.value.templateId = 'all'
  handleSearch();
}
onMounted(async () => {
  handleSearch();
});
</script>