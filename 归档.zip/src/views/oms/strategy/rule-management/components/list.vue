<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:32:29
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-28 14:54:23
 * @ Description:规则管理列表
 -->

<template>
  <div>
    <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
      <template #header-left>
        <a-space :size="14">
          <a-button style="margin-bottom: 10px;" v-permission="['oms:strategy:ruleManagement:add']" type="primary"
            status="normal" @click="handleAction('add')"> 新增规则 </a-button>
          <a-button :disabled="!selectedKeys.length" style="margin-bottom: 10px;"
            v-permission="['oms:strategy:ruleManagement:batchDel']" status="normal" @click="handleAction('batch-del')">
            批量删除 </a-button>
        </a-space>
      </template>

      <a-table ref="tableRef" v-db-click="list" :db-call-back="handleRuleClick" stripe :data="(list as any)"
        :pagination="false" :bordered="{ wrapper: false }" row-key="id" :row-selection="{
          type: 'checkbox',
          showCheckedAll: true
        }" :scroll="{ x: 1400 }" v-model:selectedKeys="selectedKeys">
        <template #columns>
          <a-table-column title="店铺名称" ellipsis tooltip  data-index="storeName">
            <template #cell="{ record }">{{ record.storeName || '--' }}</template>
          </a-table-column>
          <a-table-column title="业务类型" ellipsis tooltip  data-index="ruleType">
            <template #cell="{ record }">
              {{ record.ruleType == 1 ? '订单导入-实物' : '订单导入-虚拟' }}
            </template>
          </a-table-column>
          <a-table-column title="规则名称" ellipsis tooltip  data-index="ruleName">
            <template #cell="{ record }">{{ record.ruleName || '--' }}</template>
          </a-table-column>
          <a-table-column title="模版名称" ellipsis tooltip  data-index="templateName">
            <template #cell="{ record }">{{ record.templateName || '--' }}</template>
          </a-table-column>
          <a-table-column title="备注" ellipsis tooltip  data-index="remark">
            <template #cell="{ record }">{{ record.remark || '--' }}</template>
          </a-table-column>
          <a-table-column title="外对商户ID" ellipsis tooltip  data-index="outMerchantId">
            <template #cell="{ record }">{{ record.outMerchantId || '--' }}</template>
          </a-table-column>
          <a-table-column title="创建时间" :width="180" data-index="createTime">
            <template #cell="{ record }">{{ record.createTime || '--' }}</template>
          </a-table-column>
          <a-table-column title="修改时间" :width="180" data-index="updateTime">
            <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
          </a-table-column>
          <a-table-column title="操作" :width="120" fixed="right">
            <template #cell="{ record }">
              <a-space :size="14">
                <a-link v-permission="['oms:strategy:ruleManagement:edit']" @click="handleAction('edit', record.id)"
                  type="text">编辑</a-link>
                <a-link v-permission="['oms:strategy:ruleManagement:del']" status="danger"
                  @click="handleAction('del', record.id)" type="text">删除</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>

    <!-- 菜单新增/编辑弹窗 -->
    <form-vue ref="PackagingFromRef" @reload="emits('reload')"></form-vue>

    <!-- 修改状态二次弹框 -->
    <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>

  </div>
</template>

<script setup lang="ts" name="strategy-rule-list">
import { computed, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import FormVue from "./form.vue"
import { Message } from '@arco-design/web-vue';
import { RuleManagementReq, RuleManagementType, TemType } from '@/types/strategy/rule-mangement';
import { delRule } from '@/api/strategy/rule-mangement';
const form = ref<RuleManagementReq>(new RuleManagementReq());

const props = defineProps({
  list: { type: Array, default: () => [] },
  temList: { type: Array<TemType>, default: () => [] },
  loading: { type: Boolean, default: false },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload", data?: RuleManagementReq): void,
  (e: "details", data: RuleManagementType): void,
}>();
const selectedKeys = ref<number[]>([]);
const PackagingFromRef = ref();
const warnignRef = ref();//批量删除
const tableRef = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};

// 「新增菜单」按钮点击触发
const handleAction = (type: string, id?: number) => {
  switch (type) {
    case 'add'://新增
      PackagingFromRef.value.handleShowModal(type, null, props.temList);
      break;
    case 'edit'://编辑
      PackagingFromRef.value.handleShowModal(type, id, props.temList);
      break;
    case 'batch-del'://批量删除
      if (selectedKeys.value.length == 0) return Message.error('请选择需要处理的数据！');
      warnignRef.value.open();
      break;
    case 'del'://删除
      selectedKeys.value = [];
      if (id) selectedKeys.value.push(id);
      warnignRef.value.open();
      break;
    default:
      break;
  }
};

//双击行
const handleRuleClick = (data: RuleManagementType) => {
  //实物跳转详情
  if (data.ruleType === 1) {
    emits('details', data)
  }
}


// 删除操作
const handleDelete = async () => {
  try {
    const res = await delRule(selectedKeys.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
    tableRef.value.selectAll(false);
    selectedKeys.value = []
  } catch (err) {
    Message.error((err as Error).message);
    tableRef.value.selectAll(false);
    return false;
  }
}

// 返回列表
const list = computed(() => {
  return props.list as Array<RuleManagementType>
})
</script>