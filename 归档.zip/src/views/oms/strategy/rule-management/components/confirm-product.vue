<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-17 18:33:06
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-22 17:01:30
 * @ Description:确认商品
 -->
<template>
  <div>
    <oms-table :simplePagination="true" :loading="loading" :total="totalCount" :current="form.pageNum" :size="form.pageSize"
      @reload="onReload">
      <template #header-left>
        <a-space :size="14" style="margin-bottom:10px;">
          <a-button v-permission="['oms:strategy:ruleManagement:addSpu']" type="primary" status="normal"
            @click="handleAddClick('add', '')"> 新增
          </a-button>
          <a-button v-permission="['oms:strategy:ruleManagement:importSpu']" status="normal"
            @click="handleAddClick('import', '')"> 导入 </a-button>
          <a-button :disabled="!selectedKeys.length" v-permission="['oms:strategy:ruleManagement:batchDelSpu']" status="normal"
            @click="handleAddClick('batchDel', '')"> 批量删除 </a-button>
        </a-space>
      </template>
      <template #header-right>
        <a-input allow-clear style="margin-bottom:10px;" v-model="form.key" :style="{ width: '200px' }" placeholder="输入编码/名称"
          @keyup.enter="emits('reload-list', form)">
          <template #suffix>
            <span class="iconfont icon-icon_sousuo sousuoStyle" @click="emits('reload-list', form)"></span>
          </template>
        </a-input>
      </template>

      <a-table :bordered="{ wrapper: false }" stripe ref="tableRef" :data="(list as any)" :pagination="false" row-key="id"
        :row-selection="{
          type: 'checkbox',
          showCheckedAll: true
        }" :scroll="{ x: 300,y:228 }" v-model:selectedKeys="selectedKeys">
        <template #columns>
          <a-table-column title="商品编码" :width="180" data-index="productCode">
          </a-table-column>
          <a-table-column title="商品名称" :width="180" data-index="productName"></a-table-column>
          <a-table-column title="创建时间" :width="180" data-index="createTime"></a-table-column>
          <a-table-column title="创建人" :width="180" data-index="creator"></a-table-column>
          <a-table-column title="操作" :width="60" fixed="right">
            <template #cell="{ record, rowIndex }">
              <a-space :size="28">
                <a-link v-permission="['oms:strategy:ruleManagement:delSpu']" status="danger"
                  @click="handleAddClick('del', rowIndex)" type="text">删除</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>

    <!-- 新增/编辑 -->
    <production-from ref="ProductionRef" @reload-list="emits('reload-list')"></production-from>

    <!-- 删除二次确认 -->
    <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>

    <!-- 导入 -->
    <oms-import ref="importRef" uploadUrlName="订单确认商品导入模板" :uploadUrl="uploadUrl" :importApi="importApi"
      :paramsObj="importParams" @onSuccess="uploadFile">
    </oms-import>
  </div>
</template>

<script setup lang="ts" name="system-express-list">
import { ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import OmsImport from '@/components/oms-import/index.vue'
import ProductionFrom from './production-form.vue'
import { Message } from '@arco-design/web-vue';
import { RuleSpuReq } from '@/types/strategy/rule-mangement';
import { delSpu, uploadSpu } from '@/api/strategy/rule-mangement';
const selectedKeys = ref<string[]>([]);

const props = defineProps({
  list: {
    type: Array, default: () => []
  },
  totalCount: {
    type: Number, default: 0
  },
  ruleId: {
    type: Number, default: null
  },
  loading: { type: Boolean, default: false },
});
const form = ref<RuleSpuReq>(new RuleSpuReq());
const emits = defineEmits<{
  (e: "reload-list", data?: RuleSpuReq): void,
}>();
const uploadUrl = ref(`${import.meta.env.VITE_API_FILE_URL}/bp-auth-service/template/productManage/订单确认商品导入模板.xls`)
const ProductionRef = ref();
const warnignRef = ref();
const importRef = ref();
const tableRef = ref();
const importParams = ref<any>({});
const importApi = ref()
// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value = { ...form.value, ...data }
  emits("reload-list", form.value)
};


// 「新增字典项」按钮点击触发
const handleAddClick = (type: string, index: string) => {
  //批量删除
  if (type === 'batchDel') {
    if (selectedKeys.value.length == 0) return Message.error('请选择需要删除的数据！');
    warnignRef.value.open();
    return;
  }
  if (type === 'del') {
    selectedKeys.value = [];
    selectedKeys.value.push(props.list[index].id);
    warnignRef.value.open();
    return;
  }
  if (type === 'import') {
    importRef.value.visible = true;
    importApi.value = uploadSpu;
    let obj = {
      ruleId: props.ruleId
    }
    importParams.value = obj;
    return;
  }
  ProductionRef.value.handleShowModal(props.ruleId);
};

// 删除操作
const handleDelete = async () => {
  try {
    const res = await delSpu(selectedKeys.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload-list");
    tableRef.value.selectAll(false);
    selectedKeys.value = []
  } catch (err) {
    Message.error((err as Error).message);
    tableRef.value.selectAll(false);
    return false;
  }
}


//上传文件
const uploadFile = async (data: any) => {
  emits("reload-list");
}


</script>
<style lang="less" scoped>
.sousuoStyle {
  cursor: pointer;
}
</style>