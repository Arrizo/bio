<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:32:36
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-28 14:58:43
 * @ Description:规则管理表单
 -->

<template>
  <a-modal class="ruleForm" :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="1055px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form ref="formRef" :model="form" layout="horizontal">
      <!-- 基本信息 -->
      <!-- <p style="font-weight: bold">基本信息</p> -->
      <a-row>
        <a-col :span="8">
          <a-form-item label="业务类型：" field="ruleType" label-col-flex="100px" required
            :rules="[{ required: true, message: '请选择业务类型' }]">
            <a-select placeholder="请选择" v-model='form.ruleType' style="width: 208px">
              <a-option label="订单导入-实物" :value="1"></a-option>
              <a-option label="订单导入-虚拟" :value="9"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item label="店铺名称：" field="storeId" label-col-flex="100px" required
            :rules="[{ required: true, message: '请选择店铺名称' }]">
            <a-select placeholder="请选择" v-model='form.storeId' allow-search allow-clear style="width: 208px" @change="getStoreName">
              <a-option v-for="(item) in shopList" :disabled="!item.status" :label="item.storeName"
                :value="item.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item label="规则名称：" field="ruleName" label-col-flex="100px" required
            :rules="[{ required: true, message: '请输入规则名称' }]">
            <a-input placeholder="请输入" v-model.trim="form.ruleName" :max-length="100" style="width: 208px" allow-clear>
            </a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="8">
          <a-form-item label="模版名称：" field="templateId" label-col-flex="100px" required
            :rules="[{ required: true, message: '请选择模版名称' }]">
            <a-select placeholder="请选择" v-model='form.templateId' allow-clear allow-search style="width: 208px">
              <a-option v-for="(item) in temList" :label="item.name" :value="item.id"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item label="对外商户ID：" field="outMerchantId" label-col-flex="100px">
            <a-input placeholder="请输入" v-model.trim="form.outMerchantId" :max-length="50" style="width: 208px">
            </a-input>
          </a-form-item>
        </a-col>
        <a-col :span="8">
          <a-form-item label="备注：" field="remark" label-col-flex="100px">
            <a-input placeholder="请输入" v-model.trim="form.remark" :max-length="200" style="width: 208px" allow-clear>
            </a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <!-- 规则配置 -->
      <p class="form-title" style="margin-top: 20px;" v-if="form.ruleType == 1">规则配置</p>
      <div class="ruleDispose" v-if="form.ruleType == 1">
        <a-checkbox-group v-model="list_temp" @change="changeShowContentlOption">
          <a-checkbox v-for="(item, index) in showContentlOption" :value="item.value" :key="`d-${index}`"
            :disabled="item.disabled">{{ item.label }}</a-checkbox>
        </a-checkbox-group>
      </div>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="strategy-rule-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import { SaveRule, TemType } from '@/types/strategy/rule-mangement';
import { getRuleDetail, saveRule } from '@/api/strategy/rule-mangement';
import { ShopSelectItem } from '@/types/product/distribution';
import { getShopList } from '@/api/system/role';
// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any,
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});


const emits = defineEmits<{
  (e: "reload"): void
}>();


const showContentlOption = [
  {
    label: "拆分单元格",
    value: "splitCell",
    disabled: false,
  },
  {
    label: "拆分详细地址",
    value: "splitAddress",
    disabled: false,
  },
  {
    label: "拆分省市区",
    value: "splitToArea",
    disabled: false,
  },
  {
    label: "组合地址",
    value: "joinAddress",
    disabled: false,
  },
  {
    label: "取省市+详细地址区",
    value: "fetchCityDetailsDistrict",
    disabled: false,
  },
  {
    label: "补充市区",
    value: "addMissAddress",
    disabled: false,
  },
  {
    label: "组合支付时间",
    value: "combPayTime",
    disabled: false,
  },
  {
    label: "计算单价",
    value: "computeUnitPrice",
    disabled: false,
  },
  {
    label: "拦截无运单订单",
    value: "interceptExpressNo",
    disabled: false,
  },
  {
    label: "虚拟收件信息",
    value: "virtualInfo",
    disabled: false,
  },
  {
    label: "客服确认",
    value: "customerService",
    disabled: false,
  },
];

//选中的值
let list_temp = ref<Array<number | string>>([]);
const form = ref<SaveRule>(new SaveRule());
const temList = ref<TemType[]>()
const formRef = ref();
const loading = ref<boolean>(false);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  loading.value = true;
  try {

    const res = await saveRule(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", id: number, list: TemType[]) => {
  editModal.type = type;
  editModal.show = true;
  temList.value = list;
  queryShopList();
  if (type === 'add') {
    form.value = new SaveRule();
    showContentlOption.map(item => item.disabled = false);
    list_temp.value = []
  }
  if (type === "edit") {
    //获取详情 
    getDetailsInfo(id)
    getCheckboxValue();
  }
}


const shopList = ref<ShopSelectItem[]>([]);
const queryShopList = async () => {
  try {
    let response = await getShopList();
    if (response?.success) {
      shopList.value = response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询店铺列表失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询店铺列表失败");
  }
}

//checkbox数据整理

const getCheckboxValue = () => {
  list_temp.value = [];
  let checkboxValue = {
    splitAddress: form.value.splitAddress,
    splitToArea: form.value.splitToArea,
    joinAddress: form.value.joinAddress,
    splitCell: form.value.splitCell,
    virtualInfo: form.value.virtualInfo,
    interceptExpressNo: form.value.interceptExpressNo,
    combPayTime: form.value.combPayTime,
    fetchCityDetailsDistrict: form.value.fetchCityDetailsDistrict,
    computeUnitPrice: form.value.computeUnitPrice,
    addMissAddress: form.value.addMissAddress,
    customerService: form.value.customerService,
  };

  for (let key in checkboxValue) {
    if ((checkboxValue as any)[key]) {
      list_temp.value.push(key);
    }
  }
};
// 拆分详细地址 与 拆分省市区、组合地址、取省市+详细地址区、补充市区、拦截无运单订单、虚拟收件信息 互斥
// 拆分省市区 与 拆分详细地址、取省市+详细地址区、补充市区 互斥
// 组合地址 与 拆分详细地址 互斥
// 取省市+详细地址区 与 拆分详细地址、取省市+详细地址区 互斥
// 补充市区 与 拆分详细地址、拆分省市区、拦截无运单订单、虚拟收件信息 互斥
// 拦截无运单订单 与 拆分详细地址、补充市区 互斥，且选中拦截无运单订单自动选中 虚拟收件信息
const changeShowContentlOption = (row: any) => {
  let arr = [2, 3, 4, 5, 8, 9];
  let arrSec = [1, 4, 5];
  let arrThir = [1];
  let arrFour = [1, 5];
  let arrFri = [1, 2];
  let arrSix = [1, 2, 8, 9];
  //第4个checkbox  与拆分详细地址互斥并且与虚拟收件信息联动
  if (row.includes("interceptExpressNo")) {
    list_temp.value.push("virtualInfo");
    // let idx = list_temp.value.findIndex((item) => item == "addMissAddress");
    // list_temp.value.splice(idx, 1);
    // disabledAction(4, true);
    arrThir.map((item: string | number) => {
      disabledAction(item, row.includes("interceptExpressNo"));
    });
  }
  // 第一个checkbox
  if (row.includes("splitAddress")) {
    arr.map((item: string | number) => {
      disabledAction(item, row.includes("splitAddress"));
    });
  } else {
    arr.map((item: string | number) => {
      disabledAction(item, row.includes("splitAddress"));
    });
    // 第二个checkbox
    arrSec.map((item: string | number) => {
      disabledAction(item, row.includes("splitToArea"));
    });

    // 第三个checkbox
    if (row.includes("splitToArea")) {
      arrThir.map((item: string | number) => {
        disabledAction(item, true);
      });
    } else {
      if (row.includes("virtualInfo")) {
        //第五个checkbox
        arrFour.map((item: string | number) => {
          disabledAction(item, true);
        });
      } else {
        //第八个checkbox 与拆分详细地址、拆分省市区互斥
        if (row.includes("fetchCityDetailsDistrict")) {
          arrFri.map((item: string | number) => {
            disabledAction(item, true);
          });
        } else {
          if (row.includes("addMissAddress")) {
            //第十个checkbox 与拆分详细地址、拆分省市区、虚拟收件信息互斥
            arrSix.map((item: string | number) => {
              disabledAction(item, true);
            });
          } else {
            arrSix.map((item: string | number) => {
              disabledAction(item, row.includes("addMissAddress"));
            });
            arrFri.map((item: string | number) => {
              disabledAction(item, row.includes("fetchCityDetailsDistrict"));
            });
            //第五个checkbox
            arrFour.map((item: string | number) => {
              disabledAction(item, row.includes("virtualInfo"));
            });
            arrThir.map((item: string | number) => {
              disabledAction(item, row.includes("joinAddress"));
            });
          }
        }
      }
    }
  }

  //checkbox数据转换
  list_temp.value = JSON.parse(JSON.stringify(row));
  let arr_temp = [
    "splitAddress",
    "splitToArea",
    "joinAddress",
    "splitCell",
    "virtualInfo",
    "interceptExpressNo",
    "combPayTime",
    "fetchCityDetailsDistrict",
    "computeUnitPrice",
    "addMissAddress",
    "customerService",
  ];
  arr_temp.map((item) => ((form.value as any)[item] = false));
  row.map((item: string | number) => ((form.value as any)[item] = true));
};

//置灰属性，不让点击
const disabledAction = (index: any, val: boolean) => {
  showContentlOption[index].disabled = val;
};

//获取详情数据
const getDetailsInfo = async (id: number) => {
  try {
    const res = await getRuleDetail(id);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    //详情拿到的数据
    form.value.ruleName = res.value.ruleName;
    form.value.ruleType = res.value.ruleType;
    form.value.templateId = res.value.templateId;
    form.value.storeId = res.value.storeId;
    form.value.remark = res.value.remark;
    form.value.outMerchantId = res.value.outMerchantId;
    form.value.splitAddress = res.value.splitAddress;
    form.value.splitToArea = res.value.splitToArea;
    form.value.joinAddress = res.value.joinAddress;
    form.value.splitCell = res.value.splitCell;
    form.value.virtualInfo = res.value.virtualInfo;
    form.value.interceptExpressNo = res.value.interceptExpressNo;
    form.value.combPayTime = res.value.combPayTime;
    form.value.fetchCityDetailsDistrict = res.value.fetchCityDetailsDistrict;
    form.value.computeUnitPrice = res.value.computeUnitPrice;
    form.value.addMissAddress = res.value.addMissAddress;
    form.value.customerService = res.value.customerService;
    form.value.id = res.value.id;
  } catch (e) {
    console.error(e);
  }
}

const getStoreName = (val: any) => {
  let idx = shopList.value.findIndex((item) => item.id === val)
  if (idx > -1 && !form.value.ruleName) {
    form.value.ruleName = shopList.value[idx].storeName;
  }
}


defineExpose({
  handleShowModal
});
</script>
<style lang="less" scoped>
.ruleForm {
  .ruleDispose {
    margin-left: 16px;
    width: 628px;

    .arco-checkbox-group {
      .arco-checkbox:nth-child(1) {
        width: 100%;
      }

      .arco-checkbox:nth-child(2),
      .arco-checkbox:nth-child(3),
      .arco-checkbox:nth-child(4) {
        margin-top: 14px;
        margin-bottom: 6px;
      }

      .arco-checkbox:nth-child(3) {
        padding: 0 110px 0 140px;
      }

      .arco-checkbox:nth-child(5),
      .arco-checkbox:nth-child(6),
      .arco-checkbox:nth-child(7) {
        margin-bottom: 6px;
      }

      .arco-checkbox:nth-child(6) {
        padding-left: 104px;
        width: 50%;
      }

      .arco-checkbox:nth-child(8) {
        margin-top: 14px;
        padding: 0 128px 0 140px;
      }

      .arco-checkbox:nth-child(8),
      .arco-checkbox:nth-child(9),
      .arco-checkbox:nth-child(10) {
        margin-bottom: 6px;
      }

      .arco-checkbox:nth-child(10) {
        margin-top: 14px;
        padding-left: 127px;
      }

      .arco-checkbox:nth-child(11) {
        padding-left: 102px;
      }
    }
  }

  .form-title {
    color: #3A3A3A;
    font-size: 13px;
    font-weight: bold;
    line-height: 17px;
  }
}
</style>