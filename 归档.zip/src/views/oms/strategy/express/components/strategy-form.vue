<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-16 14:16:08
 * @ Modified by: Sam
 * @ Modified time: 2023-03-28 14:07:41
 * @ Description: 快递策略配置-表单
 -->

<template>
  <a-modal title="策略配置" width="846px" v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk"
    unmountOnClose :esc-to-close="false" :mask-closable="false" modal-class="strategy-form-modal">
    <div style="padding: 0 6px;">
      <p class="form-title" style="margin-top: 0;margin-bottom: 16px;">基本信息</p>
      <a-row class="strategy-form-inner">
        <a-form ref="formRef" :model="form" layout="inline">
          <a-col :span="12">
            <a-form-item label="策略编码：" label-col-flex="100px">
              <a-input disabled v-model="strategyData.code"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="策略名称：" label-col-flex="100px">
              <a-input disabled v-model="strategyData.title"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="expressId" label="快递公司：" label-col-flex="100px"
              :rules="[{ required: true, message: '请选择快递公司' }]">
              <a-select v-model="form.expressId" placeholder="请选择">
                <a-option v-for="v in expressList" :label="v.expressName" :value="v.id"></a-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="sort" label="优先级：" label-col-flex="100px"
              :rules="[{ required: true, message: '请输入优先级' }]">
              <a-input-number v-limit-input :min="1" :max="9999999" v-model="form.sort" placeholder="请输入" allow-clear />
            </a-form-item>
          </a-col>
        </a-form>
      </a-row>

      <p class="form-title" style="margin-top: 20px;">策略条件</p>
      <oms-strategy ref="omsStrategyRef" :id="form.id" :edit-type="editModal.type" :type="StrategyType.Kdcl"
        height="100px" max-height="100px"></oms-strategy>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="express-strategy-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import omsStrategy from "@/components/oms-strategy/index.vue"
import { addExpressConfig, editExpressConfig, getExpressDetail } from '@/api/strategy/express';
import { StrategyType } from '@/types/strategy/order';
import { ExpressForm } from '@/types/strategy/express';
import { getDefaultExpressList } from '@/api/basicdata/warehouse';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const omsStrategyRef = ref();
const formRef = ref();
const strategyData = ref();
const form = ref<ExpressForm>(new ExpressForm());
const expressList = ref<{ expressName: string, id: number }[]>([]);

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const api = editModal.type === 'add' ? addExpressConfig : editExpressConfig;
    form.value.strategyId = strategyData.value.id;
    form.value.elements = omsStrategyRef.value.getValue();
    form.value.expressStrategyId = form.value.id;

    for (let i = 0; i < expressList.value.length; i++) {
      if (expressList.value[i].id === form.value.expressId) {
        form.value.expressTitle = expressList.value[i].expressName;
      }
    }

    const res = await api(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: any, strategyInfo: any) => {
  strategyData.value = strategyInfo;
  editModal.type = type;
  editModal.show = true;


  if (type === 'add') {
    form.value = new ExpressForm();
  }

  if (type === "edit") {
    try {
      const res = await getExpressDetail(data.id);
      if (res.code != 0) {
        return Message.error(res.message);
      }
      form.value = res.value;
    } catch (err) {
      Message.error((err as Error).message);
    }
  }

  // 查询拆分相关字典数据
  try {
    const res = await getDefaultExpressList();
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }

    expressList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

defineExpose({
  handleShowModal
});
</script>

<style lang="less">
.strategy-form-modal {
  .form-title {
    color: #3A3A3A;
    font-size: 13px;
    font-weight: bold;
    line-height: 17px;
  }

  .arco-form-layout-inline .arco-form-item {
    margin-bottom: 20px;
  }

  .arco-modal-body {
    padding: 24px 28px 24px 38px !important;
  }

  .arco-modal-footer {
    margin-top: 20px;
  }
}
</style>