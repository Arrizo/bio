<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-13 13:56:32
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-15 20:34:02
 * @ Description:导入导出模版
 -->

<template>
  <div class="panel-height">
    <oms-panel>
      <template #header>
        <search :loading="loading" @on-search="initData"></search>
      </template>
      <list :loading="loading" :totalCount="totalCount" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
        @reload="initData">
      </list>
    </oms-panel>
  </div>
</template>
<script setup lang="ts" name="strategy-export-import">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue'
import List from './components/list.vue'
import { queryPage } from '@/api/strategy/export-import';
import { Message } from '@arco-design/web-vue';
import { ref } from 'vue';
import { deepClone } from '@/utils/helper';
import { ExportImportListType, searchReq } from '@/types/strategy/export-import';
const form = ref<searchReq>(new searchReq());
const loading = ref<boolean>(false);
const list = ref<ExportImportListType[]>();
const totalCount = ref();
/**
 * 初始化查询菜单数据
 * @param form
 */

const initData = async (data: searchReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.taskType = params.taskType === 'all' ? '' : params.taskType;

    const res = await queryPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}
</script>
<style lang="less" scoped>
.panel-height {
  height: 100%;
}
</style>