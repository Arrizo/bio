<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:25:54
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-28 11:25:12
 * @ Description:导入导出模版列表
 -->

<template>
  <div>
    <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
      <template #header-left>
        <a-space :size="14">
          <a-button style="margin-bottom: 10px;" v-permission="['oms:strategy:exportImport:add']" type="primary"
            status="normal" @click="handleAction('add')"> 新增模板 </a-button>
          <a-button :disabled="!selectedKeys.length" style="margin-bottom: 10px;" v-permission="['oms:strategy:exportImport:batchDel']" status="normal"
            @click="handleAction('batch-del')"> 批量删除 </a-button>
        </a-space>
      </template>

      <a-table ref="tableRef" stripe :data="(list as any)" :pagination="false" :bordered="{ wrapper: false }" row-key="id"
        :row-selection="{
          type: 'checkbox',
          showCheckedAll: true
        }" :scroll="{ x: 1400 }" v-model:selectedKeys="selectedKeys">
        <template #columns>
          <a-table-column title="模板名称" ellipsis tooltip data-index="name">
            <template #cell="{ record }">{{ record.name || '--' }}</template>
          </a-table-column>
          <a-table-column title="作业类型" ellipsis tooltip data-index="taskType">
            <template #cell="{ record }">
              {{ ['导出', '导入'][record.taskType] || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="业务类型" ellipsis tooltip data-index="businessTypeName">
            <template #cell="{ record }">{{ record.businessTypeName || '--' }}</template>
          </a-table-column>
          <a-table-column title="备注" ellipsis tooltip data-index="remark">
            <template #cell="{ record }">{{ record.remark || '--' }}</template>
          </a-table-column>
          <a-table-column title="创建时间" :width="180" data-index="createdTime">
            <template #cell="{ record }">{{ record.createdTime || '--' }}</template>
          </a-table-column>
          <a-table-column title="修改时间" :width="180" data-index="modifiedTime">
            <template #cell="{ record }">{{ record.modifiedTime || '--' }}</template>
          </a-table-column>
          <a-table-column title="操作" :width="120" fixed="right">
            <template #cell="{ record }">
              <a-space :size="14">
                <a-link v-permission="['oms:strategy:exportImport:edit']" @click="handleAction('edit', record.id)"
                  type="text">编辑</a-link>
                <a-link v-permission="['oms:strategy:exportImport:del']" status="danger" @click="handleAction('del', record.id)"
                  type="text">删除</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>

    <!-- 菜单新增/编辑弹窗 -->
    <form-vue ref="PackagingFromRef" @reload="emits('reload')"></form-vue>

    <!-- 修改状态二次弹框 -->
    <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>

  </div>
</template>

<script setup lang="ts" name="strategy-export-import-list">
import { ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import OmsLog from '@/components/oms-log/index.vue'
import FormVue from "./form.vue"
import { Message } from '@arco-design/web-vue';
import { delTemplate } from '@/api/strategy/export-import';
import { ExportImportListType, searchReq } from '@/types/strategy/export-import';
const form = ref<searchReq>(new searchReq());

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload", data?: searchReq): void,
}>();
const selectedKeys = ref<number[]>([]);
const PackagingFromRef = ref();
const warnignRef = ref();//批量删除
const tableRef = ref();

const currentId = ref();
const logRef = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};

// 「新增菜单」按钮点击触发
const handleAction = (type: string, id?: number) => {
  switch (type) {
    case 'add'://新增
      PackagingFromRef.value.handleShowModal(type);
      break;
    case 'edit'://编辑
      PackagingFromRef.value.handleShowModal(type, id);
      break;
    case 'batch-del'://批量删除
      if (selectedKeys.value.length == 0) return Message.error('请选择需要处理的数据！');
      warnignRef.value.open();
      break;
    case 'del'://删除
      selectedKeys.value = [];
      if(id) selectedKeys.value.push(id);
      warnignRef.value.open();
      break;
    default:
      break;
  }
};


// 删除操作
const handleDelete = async () => {
  try {
    const res = await delTemplate(selectedKeys.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
    tableRef.value.selectAll(false);
    selectedKeys.value = []
  } catch (err) {
    Message.error((err as Error).message);
    tableRef.value.selectAll(false);
    return false;
  }
}
</script>