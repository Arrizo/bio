<template>
  <div>
    <!-- 左边列表 -->
    <div class="shuttle-box">
      <div class="shuttle-box-title">
        <div class="shuttle-box-title-left">
          <a-checkbox class="shuttleCheck" v-model="allVisbile" v-if="taskType == 0 && !templateName"
            :indeterminate="isIndeterminate" @change="handleCheckAllChange"></a-checkbox>
          <div>{{ shuttleName }}</div>
        </div>
        <div class="index-num">
          {{ checkSowNum(taskType == 0 && !templateName) }}/{{ itemLeft.length }}
        </div>
      </div>
      <!-- 内容区 -->
      <a-scrollbar class="shuttle-box-list">
        <div>
          <a-checkbox-group v-model="checkedValue" @change="handleCheckedSingleChange"
            v-if="taskType == 0 && !templateName">
            <a-checkbox class="shuttle-box-item" v-for="(item, index) in itemLeft" :key="`${index}-check`"
              :value="(item as any).templateFieldId">{{ substringName((item as any).innerTitle)
              }}<div class="required"
                v-if="((item as any).importRequired && props.taskType == 1) || (item as any).exportRequired && props.taskType == 0">
                <span>*</span>
              </div></a-checkbox>
          </a-checkbox-group>
          <!--  -->
          <a-radio-group v-else v-model="radioValue" @change="handleRadioValue" direction="vertical">
            <a-radio class="shuttle-box-item" v-for="(item, index) in itemLeft" :key="`${index}-radio`"
              :value="(item as any).templateFieldId">{{ substringName((item as any).innerTitle)
              }}<div class="required"
                v-if="((item as any).importRequired && props.taskType == 1) || (item as any).exportRequired && props.taskType == 0">
                <span>*</span>
              </div></a-radio>
          </a-radio-group>
        </div>
      </a-scrollbar>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { watch, ref } from "vue";
//props
const props = defineProps({
  // 穿梭框title：外部字段、内部字段
  shuttleName: {
    type: String,
    default: "",
  },
  // 穿梭框内容区数据
  itemLeft: {
    type: Array,
    default: () => [],
  },
  // 作业类型 导入1，导出0
  taskType: {
    type: Number,
    default: "",
  },
  // 上传的模板文件名称
  templateName: {
    type: String,
    default: "",
  },
});
const emits = defineEmits(["update"]);
const allVisbile = ref(false);
const isIndeterminate = ref(false);
const checkedValue = ref<Array<number | string>>([]);
let ids = ref<Array<number | string>>([]);
let checkedValueObj = ref<Array<any>>([]);
let radioValue = ref('');
let checkedCount = ref(0);
// 全选Checkbox，并处理数据
const handleCheckAllChange = (val: any) => {
  allVisbile.value = val;
  checkedValue.value = val ? ids.value : [];
  isIndeterminate.value = false;

  initValue();
};
// 单选Checkbox，并处理数据
const handleCheckedSingleChange = (value: string | any[]) => {
  checkedCount.value = value.length;
  allVisbile.value = checkedCount.value === ids.value.length;
  initValue();
  isIndeterminate.value =
    checkedCount.value > 0 && checkedCount.value < ids.value.length;
};

// 统一处理数据：过滤掉穿梭过去的数据
const initValue = () => {
  checkedValueObj.value = props.itemLeft.filter((item: any) => {
    return checkedValue.value.indexOf(item.templateFieldId) != -1;
  });
  let data = {
    shuttleName: props.shuttleName,
    checkedValueObj: checkedValueObj.value,
  };
  emits("update", data);
};
// 拿到当前选中那条数据Radio，并处理数据
const handleRadioValue = (e: any) => {
  checkedValueObj.value = [];
  let item = props.itemLeft.find((i: any) => i.templateFieldId == e)
  checkedValueObj.value.push(item);
  let data = {
    shuttleName: props.shuttleName,
    checkedValueObj: checkedValueObj.value,
  };
  emits("update", data);
};

// 选中数量：多选时，返回多选的数组length，单选时返回1，不选则返回0
const checkSowNum = (val: boolean) => {
  if (val) return checkedValue.value.length
  if (!val && radioValue.value !== '') return 1
  return 0
}
// 清空选中得值，抛出给父级处理所需要清空
const handleRest = () => {
  checkedValue.value = [];
  checkedValueObj.value = [];
  radioValue.value = "";
};
//穿梭过去后内部数据执行方法
const handleInsideSplitArray = async () => {
  for (let i = 0; i < checkedValue.value.length; i++) {
    const itm = checkedValue.value[i];
    let idx = props.itemLeft.findIndex(
      (item) => (item as any).templateFieldId == itm
    );
    if (idx > -1) {
      props.itemLeft.splice(idx, 1);
    }
  }
  isIndeterminate.value = false;
  allVisbile.value = false;
  setTimeout(() => {
    checkedValue.value = [];
  }, 100);
};
//穿梭过去后外部数据执行方法
const handleExternalSplitArray = async () => {
  let idx = props.itemLeft.findIndex(
    (item) => (item as any).templateFieldId == radioValue.value
  );

  if (idx > -1) {
    props.itemLeft.splice(idx, 1);
  }

  setTimeout(() => {
    radioValue.value = "";
  }, 100);

};
//穿梭过来后执行方法
const handleAddArry = (val: any) => {
  for (let i = 0; i < val.length; i++) {
    const itm = val[i];
    props.itemLeft.push({
      exportRequired: itm.exportRequired,
      importRequired: itm.importRequired,
      innerField: itm.innerField,
      innerTitle: itm.innerTitle,
      templateFieldId: itm.templateFieldId,
    });
  }
  props.itemLeft.sort(sortdatalist("templateFieldId"));
};
//通过 templateFieldId 排序
const sortdatalist = (propertyName: string) => {
  var datalist = (object1: any, object2: any) => {
    var value1 = object1[propertyName];
    var value2 = object2[propertyName];
    if (value1 < value2) {
      return -1;
    } else if (value1 > value2) {
      return 1;
    } else {
      return 0;
    }
  };
  return datalist;
};

//超出几个字省略号
const substringName = (value: string) => {
  if (!value) return;
  if (value.length > 14) {
    return value.slice(0, 14) + "...";
  }
  return value;
}


//监听prop.taskType
watch(
  () => props.itemLeft,
  (newValue, oldValue) => {
    if (props.itemLeft.length > 0) {
      ids.value = [];
      for (let i = 0; i < props.itemLeft.length; i++) {
        const item = props.itemLeft[i];
        ids.value.push((item as any).templateFieldId);
      }
    }
  },{
    deep:true,
    immediate:true
  }
);
defineExpose({
  handleCheckAllChange,
  handleInsideSplitArray,
  handleExternalSplitArray,
  handleAddArry,
  handleRest,
  checkedValueObj,
});
</script>

<style lang="less" scoped>
//整个穿梭框
.shuttle-box {
  width: 254px;
  border-radius: 4px;

  //标题
  .shuttle-box-title {
    background: #F8F8F8;
    padding: 0 16px 0 8px;
    height: 40px;
    line-height: 40px;
    display: flex;
    justify-content: space-between;
    font-size: 12px;

    .shuttle-box-title-left {
      display: flex;
      align-items: center;
      color: #3A3A3A;

      .shuttleCheck {
        margin-right: 10px;
      }
    }

    .index-num {
      color: #3A3A3A;
      font-size: 12px;
      font-weight: 400;
    }
  }

  //列表
  :deep(.shuttle-box-list) {
    height: 186px;
    overflow-y: auto;

    border-left: 1px solid #EFEFEF;
    border-bottom: 1px solid #EFEFEF;
    border-right: 1px solid #EFEFEF;

    .arco-checkbox-group .arco-checkbox {
      margin-right: 0px;
    }

    //一个列表item
    .shuttle-box-item {
      width: 228px;
      line-height: 1;
      padding: 10px 0px 10px 12px;
      font-size: 13px;

      // display: block;
      // overflow: hidden; // 溢出隐藏
      // white-space: nowrap; // 强制一行
      // text-overflow: ellipsis; // 文字溢出显示省略号


      .required {
        color: rgb(245, 63, 63);
        font-size: 20px;
        margin-left: 4px;
        display: flex;
        align-items: center;

        span {
          height: 10px;
        }

      }
    }
  }

  :deep(.arco-radio-label) {
    display: flex !important;
  }
}
</style>
