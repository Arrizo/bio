<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:25:54
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 16:10:07
 * @ Description:导入导出模版表单
 *  作业类型：控制第一第二个穿梭框的显示内容
 *        1、当作业类型为导出并未上传模版文件时，内部字段是可以多选做出映射关系；此时模版文件非必填，当模版文件存在，即外部字段有数据时，外部字段内部字段单选、必须一一对应做出映射关系，且校验是否存在必须导出映射
 *        2、作业类型为导入时，模版文件必填；外部字段，内部字段单选，外部字段内部字段必须一一对应做出映射关系，且校验是否存在必须导入映射
 *  业务类型：即获取内部字段数据；
 *  业务类型、作业类型的切换，模版文件更换，穿梭框的值都应做出相应的更新
 -->

<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="1005px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form ref="formRef" :model="form" layout="horizontal">
      <!-- 基本信息 -->
      <p class="form-title" style="margin-top: 0;">基本信息</p>
      <a-row>
        <a-col :span="12">
          <a-form-item label="作业类型：" label-col-flex="120px" field="taskType" required
            :rules="[{ required: true, message: '请选择作业类型' }]">
            <a-select placeholder="请选择" v-model='form.taskType' @change="getTaskFun" style="width: 208px">
              <a-option label="导入" :value="1" />
              <a-option label="导出" :value="0" />
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="业务类型：" field="businessTypeCode" label-col-flex="120px" required
            :rules="[{ required: true, message: '请选择业务类型' }]">
            <a-select placeholder="请选择" v-model='form.businessTypeCode' style="width: 208px"
              @change="changeTemplateFun">
              <a-option v-for="(item) in businessList" :label="item.dictionaryTitle"
                :value="item.dictionaryValue"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="12">
          <a-form-item label="表头开始行：" field="titleStartRow" label-col-flex="120px" required
            :rules="[{ required: true, message: '请输入表头开始行' }]">
            <a-input-number :min="1" :max="10" :precision="0" v-model="form.titleStartRow" clearable placeholder="请输入"
              style="width: 208px">
            </a-input-number>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="表头结束行：" field="titleEndRow" label-col-flex="120px" required
            :rules="[{ required: true, message: '请输入表头结束行' }]">
            <a-input-number :min="1" :max="10" :precision="0" v-model="form.titleEndRow" clearable placeholder="请输入"
              style="width: 208px">
            </a-input-number>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="12">
          <a-form-item label="模板文件：" field="uploadTemplateUrl" label-col-flex="120px"
            :rules="rulesFile">
            <div class="uploader-container" style="width: 208px">
              <file-uploader ref="uploaderFile" :disabled="!form.titleEndRow || !form.titleStartRow"
                v-model="form.uploadTemplateUrl" module="COMMON_FILE" :size="1024 * 1024 * 1" :fileType="2"
                accept=".xlsx,.xls" width="208px" @onSuccess="importUploadSuccess" @delSuccess="clearFile"
                :name="form.uploadTemplateName"></file-uploader>
            </div>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="模板名称：" field="name" label-col-flex="120px" required
            :rules="[{ required: true, message: '请输入模板名称' }]">
            <a-input v-model.trim="form.name" :max-length="100" style="width: 208px">
            </a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="12">
          <a-form-item label="备注：" field="newWarehouseNameTemp" label-col-flex="120px">
            <a-textarea placeholder="请输入" :maxLength="200" show-word-limit style="width: 208px" />
          </a-form-item>
        </a-col>
      </a-row>
      <!-- 字段配置 -->
      <p class="form-title" style="margin-top: 0px;">字段配置</p>
      <div class="form-shuttle-container">
        <shuttle :insideData="templateNewFieldList" :templateName="form.uploadTemplateName" :excelData="excelNewData"
          :mappingData="mappingResults" ref="shuttleRef" :uploadTemplateName="form.uploadTemplateName"
          :taskType="form.taskType"></shuttle>
      </div>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="strategy-export-import-form">
import { DictionaryType } from '@/types/system/dictionary';
import { computed, reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import fileUploader from '@/components/file-uploader/index.vue';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { SaveFromData, TemplateFieldType } from '@/types/strategy/export-import';
import { getDetail, getTemplateField, saveTemplate, uploadTemplate } from '@/api/strategy/export-import';
import Shuttle from "./shuttle.vue";
// @ts-ignore
import * as XLSX from 'xlsx/xlsx.mjs';
// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any,
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null,
});

//获取excel数据
let excelData = ref();//获取的表格数据
let excelNewData = ref();//处理后接受的表格数据

const emits = defineEmits<{
  (e: "reload"): void
}>();

const form = ref<SaveFromData>(new SaveFromData());
const templateFieldList = ref<TemplateFieldType[]>([]);//业务类型数据
const templateNewFieldList = ref<TemplateFieldType[]>([]);//处理好的业务类型数据
const businessList = ref<DictionaryType[]>();
const formRef = ref();
const loading = ref<boolean>(false);
let shuttleRef = ref();
let mappingResults = ref<Array<string>>([]);
/** 点击确定按钮时触发 */
const onOk = async () => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  if(form.value.titleStartRow>form.value.titleEndRow){
    Message.error('表头开始行不能大于表头结束行');
    return false;
  }

  let array = JSON.parse(JSON.stringify(shuttleRef.value!.mappingResults));
  let newArray = array.map(
    (item: {
      innerTitle: any;
      templateFieldId: any;
      importRequired: any;
      exportRequired: any;
      importRequire: any;
      exportRequire: any;
      name: any;
      seq: any;
      type: any;
    }) => {
      item.importRequire = item.importRequired == true ? 1 : 0;
      item.exportRequire = item.exportRequired == true ? 1 : 0;
      delete item.exportRequired;
      delete item.importRequired;
      delete item.name;
      delete item.seq;
      delete item.type;
      return item;
    }
  );
  if (newArray.length == 0) {
    Message.error('请做出相应映射关系');
    return false;
  }
  //内部数据e.templateNewFieldList
  //导出
  // taskArry返回当前内部字段是否存在必映射关系
  // taskArry1返回当前外部字段是否存在必映射关系
  let taskArry =
    templateNewFieldList.value.filter(
      (item) => item.exportRequired == true
    ) || [];
  let taskArry1 =
    templateNewFieldList.value.filter(
      (item) => item.importRequired == true
    ) || [];
  if (form.value.taskType == 0 && taskArry.length > 0) {
    Message.error('请做出相应导出映射关系');
    return false;
  }
  if (form.value.taskType == 1 && taskArry1.length > 0) {
    //导入
    Message.error('请做出相应导入映射关系');
    return false;
  }
  form.value.mapResult = JSON.stringify(newArray);
  loading.value = true;
  try {
    const apiType = editModal.type === 'add' ? saveTemplate : uploadTemplate;

    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => {
  formRef.value!.resetFields();
  form.value.uploadTemplateName = "";
  form.value.uploadTemplateUrl = "";
  form.value.name = "";
  templateFieldList.value = [];
  templateNewFieldList.value = [];
  mappingResults.value = [];
  excelData.value = [];
  excelNewData.value = [];
  shuttleRef.value!.clearData();
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", id: number) => {
  editModal.type = type;
  editModal.show = true;
  if (type === 'add') {
    form.value = new SaveFromData();
    templateNewFieldList.value=[];
    excelNewData.value=[];
    //查询业务类型
    businessList.value = await getDictionaryList('TEMPLATE_TYPE');
  }
  if (type === "edit") {
    //查询业务类型
    businessList.value = await getValidDictionaryList('TEMPLATE_TYPE');
    //获取详情 
    getDetailsInfo(id)
  }
}

//获取详情数据
const getDetailsInfo = async (id: number) => {
  try {
    const res = await getDetail(id);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    //详情拿到的数据
    form.value.name = res.value.name; //模板名称
    form.value.templateDescribe = res.value.templateDescribe; //模板描述
    form.value.taskType = res.value.taskType; //作业类型(1导入,0导出)
    form.value.businessTypeCode = res.value.businessTypeCode; //业务类型id
    form.value.titleEndRow = res.value.titleEndRow; //表头结束行
    form.value.titleStartRow = res.value.titleStartRow; //表头开始行
    form.value.uploadTemplateName = res.value.uploadTemplateName; //上传的模板文件名称
    form.value.uploadTemplateUrl = res.value.uploadTemplateUrl; //上传的模板文件路径
    form.value.originTableTitle = res.value.originTableTitle; //外部字段
    form.value.mapResult = res.value.mapResult; //映射结果
    await getTemplateFun(form.value.businessTypeCode);
    //处理映射结果回显
    mappingResults.value = JSON.parse(form.value.mapResult);
    //处理外部字段回显
    var newArry = form.value.originTableTitle.split("_split_split_");
    excelData.value = [];
    for (let i = 0; i < newArry.length; i++) {
      const item = newArry[i];
      excelData.value.push({
        name: item,
        templateFieldId: i,
      });
    }
    //内部字段回显templateFieldList
    let insideArr: any[] = [];
    for (let i = 0; i < mappingResults.value.length; i++) {
      const itm = mappingResults.value[i];
      insideArr.push((itm as any).innerTitle);
    }

    if (mappingResults.value.length > 0) {
      let newItemArray: any[] = [];
      for (let i = 0; i < mappingResults.value.length; i++) {
        const item = mappingResults.value[i];
        newItemArray.push((item as any).outField);
      }
      //处理映射好得外部字段数据
      excelNewData.value = JSON.parse(JSON.stringify(excelData.value)).filter((item: any) => {
        return newItemArray.every((itm) => itm != item.name);
      });
      templateNewFieldList.value = JSON.parse(JSON.stringify(templateFieldList.value)).filter(
        (item: any) => {
          return insideArr.every((itm) => itm != item.innerTitle);
        }
      );
    }

  } catch (e) {
    console.error(e);
  }
}

//作业类型切换时清空数据
const getTaskFun = () => {
  templateNewFieldList.value = templateFieldList.value?JSON.parse(JSON.stringify(templateFieldList.value)):[];
  excelNewData.value = excelData.value?JSON.parse(JSON.stringify(excelData.value)):[];
  shuttleRef.value!.clearData();
};

//根据业务类型获取模板类型对应的内部字段
const getTemplateFun = async (val: any) => {
  try {
    const res = await getTemplateField(val as string);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    templateFieldList.value = res?.value ?? [];
  } catch (e) {
    console.error(e);
  }
};
//更换业务类型
const changeTemplateFun = async (val: any) => {
  await getTemplateFun(val);
  templateNewFieldList.value = JSON.parse(JSON.stringify(templateFieldList.value));
  // 清空映射结果且外部字段恢复成全部数据
  shuttleRef.value!.clearData();
  mappingResults.value = [];
  excelNewData.value = excelData.value?JSON.parse(JSON.stringify(excelData.value)):[];
}

const importUploadSuccess = (uploadObj: any) => {
  var fileReader = new FileReader();
  fileReader.onload = (ev) => {
    try {
      const data = ev.target!.result;
      const workbook = XLSX.read(data, {
        type: "binary",
      }); // 读取数据
      const wsname = workbook.SheetNames[0]; // 取第一张表
      //const ws = XLSX.utils.sheet_to_json(workbook.Sheets[wsname]); // 生成json表格内容
      // const ws1 = XLSX.utils.sheet_to_slk(workbook.Sheets[wsname]) // 输出表格对应位置是什么值
      // const ws2 = XLSX.utils.sheet_to_html(workbook.Sheets[wsname]) // 生成HTML输出
      // const ws3 = XLSX.utils.sheet_to_csv(workbook.Sheets[wsname]) // 生成分隔符分隔值输出
      // const ws4 = XLSX.utils.sheet_to_formulae(workbook.Sheets[wsname]) // 生成公式列表（具有值回退）
      // const ws5 = XLSX.utils.sheet_to_txt(workbook.Sheets[wsname]) // 生成UTF16格式的文本
      let xlsx = workbook.Sheets[wsname];
      handleArray(xlsx);
      form.value.uploadTemplateName = uploadObj.fileObj.file.name;
      if(!form.value.name) form.value.name = form.value.uploadTemplateName?.split('.')[0]
      form.value.uploadTemplateUrl = uploadObj.uploadTemplateUrl;
      //
    } catch (e) {
      return false;
    }
  };
  fileReader.readAsBinaryString(uploadObj.fileObj.file);
};
const handleArray = (xlsx: any) => {
  //excelData.value = Object.keys(val[0]);
  var arr = [];
  var id = 0;
  for (var key in xlsx) {
    if (key.startsWith("!")) continue;

    var r = key.match(/\d+$/gi)![0];
    if (Number(r) == form.value.titleStartRow) {
      var item = {
        id: id,
        name: xlsx[key].v,
        show: true,
      };
      arr.push(item);
      ++id;
    }
  }
  //拿到表格字段
  excelData.value = arr;
  // 上传完后表格字段不需处理，即直接赋值
  excelNewData.value = excelData.value;
  //清空映射结果，且内部字段还原
  mappingResults.value = [];
  shuttleRef.value!.mappingResults = [];
  templateNewFieldList.value = JSON.parse(JSON.stringify(templateFieldList.value));
  form.value.originTableTitle = "";
  if (form.value.businessTypeCode) {// 拿取内部字段数据
    getTemplateFun(form.value.businessTypeCode);
  }
  for (var i = 0; i < arr.length; i++) {
    if (i === arr.length - 1) {
      form.value.originTableTitle += arr[i].name;
      return;
    }
    form.value.originTableTitle += arr[i].name + "_split_split_";
  }
};

//校验手机号码
const rulesFile = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (form.value.taskType==1 && (!value || value == "")) {
        callback("请上传模版文件");
        return
      }
    },
    required: form.value.taskType==1
  },
]);

//删除文件情况外部字段
const clearFile=()=>{
  //表格字段
  excelData.value = [];
  excelNewData.value = excelData.value;
}

defineExpose({
  handleShowModal
});
</script>
<style lang="less" scoped>
.form-shuttle-container {
  width: 100%;
  overflow-x: auto;
  padding-left: 36px;
}

.form-title {
  color: #3A3A3A;
  font-size: 13px;
  font-weight: bold;
  line-height: 17px;
}
</style>