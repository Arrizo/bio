<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-15 20:25:54
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-28 11:25:16
 * @ Description:导入导出模版搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="name" label="模板名称：">
      <a-input @keyup.enter="handleSearch" :max-length="100" v-limit-input="['#', '']" v-model.trim="form.name" allowClear
        placeholder="请输入" />
    </a-form-item>
    <a-form-item field="taskType" label="作业类型：">
      <a-select placeholder="请选择" v-model='form.taskType' allow-clear>
        <a-option label="导入" value="1" />
        <a-option label="导出" value="0" />
      </a-select>
    </a-form-item>

    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="strategy-export-import-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { searchReq } from '@/types/strategy/export-import';
import { onMounted, ref } from 'vue';
const props = defineProps({
  loading: { type: Boolean, default: false }
});
const formRes = ref();
const emits = defineEmits<{
  (e: "on-search", data: searchReq): void;
}>();

const form = ref<searchReq>(new searchReq());
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}
onMounted(async () => {
  handleSearch();
});
</script>