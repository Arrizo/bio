<template>
  <div class="shuttle">
    <!-- 左边列表 -->
    <template v-if="taskType == 1">
      <shuttle-item :itemLeft="externalData" :taskType="taskType" ref="externalRef" :templateName="templateName"
        shuttleName="外部字段" @update="handleUpdata"></shuttle-item>
      <shuttle-item shuttleName="内部字段" :taskType="taskType" ref="insideRef" :templateName="templateName"
        :itemLeft="insideData" @update="handleUpdata"></shuttle-item>
    </template>
    <template v-if="taskType == 0">
      <shuttle-item shuttleName="内部字段" :taskType="taskType" ref="insideRef" :templateName="templateName"
        :itemLeft="insideData" @update="handleUpdata"></shuttle-item>
      <shuttle-item :itemLeft="externalData" :templateName="templateName" ref="externalRef" :taskType="taskType"
        shuttleName="外部字段" @update="handleUpdata"></shuttle-item>
    </template>
    <!-- 左右操作按钮 -->
    <div class="shuttle-click">
      <template v-if="
        (taskType == 0 &&
          insideCheckedValueObj &&
          insideCheckedValueObj.length > 0) ||
        (taskType == 1 &&
          insideCheckedValueObj &&
          insideCheckedValueObj.length > 0 &&
          externalCheckedValueObj &&
          externalCheckedValueObj.length > 0)
      ">
        <div class="btn btnBg" @click="goRight"><icon-right /></div>
      </template>
      <template v-else>
        <div class="btn btnDisabled"><icon-right /></div>
      </template>
      <template v-if="checkedMappingValue && checkedMappingValue.length > 0">
        <div class="btn btnBg" @click="goLeft"><icon-left /></div>
      </template>
      <template v-else>
        <div class="btn btnDisabled"><icon-left /></div>
      </template>
    </div>
    <!-- 右边列表 -->
    <div class="shuttle-box">
      <div class="shuttle-box-title">
        <div class="shuttle-box-title-left">
          <a-checkbox v-model="allMappingVisbile" :indeterminate="isMappingIndeterminate"
            @change="handleMappingAllChange"></a-checkbox>
          <div class="shuttleName">映射结果</div>
        </div>
        <div class="index-num">
          {{ checkedMappingValue ? checkedMappingValue.length : 0 }}/{{
            mappingResults ? mappingResults.length : 0
          }}
        </div>
      </div>
      <a-scrollbar class="shuttle-box-list">
        <a-checkbox-group v-model="checkedMappingValue" @change="mappingSingleChange">
          <a-checkbox class="shuttle-box-item" v-for="(item, index) in mappingResults" :key="`${index}-check`"
            :value="item.templateFieldId">
            <a-tooltip :content="item.name"> {{ substringName(item.name) }}</a-tooltip>
          </a-checkbox>
        </a-checkbox-group>
      </a-scrollbar>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { watch, onMounted, ref } from "vue";
import shuttleItem from "./shuttle-item.vue";
//props
const props = defineProps({
  //内部字段，即业务类型所获取的数据
  insideData: {
    type: Array,
    default: () => [],
  },
  //外部字段，即获取上传模版文件表格数据
  excelData: {
    type: Array,
    default: () => [],
  },
  // 作业类型默认导入1，导出0
  taskType: {
    type: Number,
    default: 1,
  },
  // 上传的模板文件名称
  templateName: {
    type: String,
    default: "",
  },
  // 上传的模板文件名称
  uploadTemplateName: {
    type: String,
    default: "",
  },
  //映射结果
  mappingData: {
    type: Array,
    default: () => [],
  },
});
const insideRef = ref(); // 内部数据ref
const externalRef = ref(); // 外部数据ref
const checkedMappingValue = ref();// 选中的数据，用来判断穿梭到左边的按钮是否置灰
let externalData = ref<Array<any>>([]);// 用来接收外部字段即表格数据格式化成我们所需的数据格式
let mappingResults = ref<Array<any>>([]);// 映射结果数组
let checkedCount = ref(0);// 多选选中的数量，显示在穿梭框表头
let allMappingVisbile = ref(false); // 全选全不选
let isMappingIndeterminate = ref(false); // 控制checkbox是否为半选状态
let insideCheckedValueObj = ref();// 选中的数据，用来判断穿梭到右边的按钮是否置灰；作业类型为导出时，只要判断当前数据有值便可穿梭
let mappingCheckObj = ref<Array<string>>([]);
let externalCheckedValueObj = ref<Array<string>>([]);// 选中的数据，用来判断穿梭到右边的按钮是否置灰；作业类型为导入时，判断内外部数据都有值便可穿梭
// 穿梭到左边，即取消映射关系
const goLeft = async () => {
  //数组排序
  let newArrayTotal = JSON.parse(
    JSON.stringify(
      mappingResults.value.filter((item) => {
        return checkedMappingValue.value.indexOf(item.templateFieldId) != -1;
      })
    )
  );
  // 处理外部字段数据
  let newArrayTotal1 = JSON.parse(
    JSON.stringify(
      mappingResults.value.filter((item) => {
        return checkedMappingValue.value.indexOf(item.templateFieldId) != -1;
      })
    )
  );
  // 处理数组，删掉name，outField字段
  let arrayInside = newArrayTotal.map((item: { name: any; outField: any }) => {
    delete item.name;
    delete item.outField;
    return item;
  });
  let arrayExternal = [];
  // 修改key值，并删除多余字段
  if (props.uploadTemplateName) {
    arrayExternal = newArrayTotal1.map(
      (
        item: {
          name: any;
          innerTitle: any;
          outTemplateFieldId: any;
          templateFieldId: any;
          exportRequired: any;
          importRequired: any;
          outField: any;
        },
        index: any
      ) => {
        item.innerTitle = item.outField;
        item.templateFieldId = item.outTemplateFieldId;
        delete item.name;
        delete item.exportRequired;
        delete item.importRequired;
        delete item.outField;
        return item;
      }
    );
  }
  // 将处理好的内外外部字段添加到当前数组当中
  insideRef.value!.handleAddArry(arrayInside);
  externalRef.value!.handleAddArry(arrayExternal);
  // 映射结果数组移除掉取消映射的数据
  for (let i = 0; i < checkedMappingValue.value.length; i++) {
    const itm = checkedMappingValue.value[i];
    let idx = mappingResults.value.findIndex(
      (item: any) => (item as any).templateFieldId == itm
    );
    if (idx > -1) {
      mappingResults.value.splice(idx, 1);
    }
  }
  // 操作完成后，清空选中的值，并将checkbox半选状态取消掉
  insideRef.value!.handleRest();
  externalRef.value!.handleRest();
  checkedMappingValue.value = [];
  allMappingVisbile.value = false;
};
// 穿梭到右边，即做出映射关系
const goRight = async () => {
  // return
  if (externalRef.value!.checkedValueObj.length == 0) {
    //作业类型为导出时且外部字段无值，映射结果渲染的name所拼接的值则为内部字段本身的拼接
    insideRef.value!.checkedValueObj.map((item: any) => {
      mappingResults.value.push({
        name: (item as any).innerTitle + "=>" + (item as any).innerTitle,
        exportRequired: item.exportRequired,
        importRequired: item.importRequired,
        outField: item.innerTitle,
        innerField: item.innerField,
        innerTitle: item.innerTitle,
        templateFieldId: item.templateFieldId,
      });
    });
    //移除
    insideRef.value!.handleInsideSplitArray();
  } else {
    // 深拷贝，防止后续操作改变原有数据
    let array = JSON.parse(JSON.stringify(externalRef.value!.checkedValueObj));
    // 修改key值
    let newList = array.map((item: { innerTitle: any; templateFieldId: any }) => {
      (item as any)["outField"] = (item as any).innerTitle;
      (item as any)["outTemplateFieldId"] = (item as any).templateFieldId;
      delete item.innerTitle;
      delete item.templateFieldId;
      return item;
    });
    let addArr = insideRef.value!.checkedValueObj.map((v: any, i: string | number) => ({
      ...v,
      ...newList[i],
    }));
    // 添加到映射结果mappingResults.value中
    mappingResults.value = mappingResults.value.concat(addArr);
    // 作业类型不同，映射结果渲染的name所拼接的顺序不一样
    for (let i = 0; i < mappingResults.value.length; i++) {
      const vo = mappingResults.value[i];
      vo["name"] =
        props.taskType == 1
          ? vo.outField + "=>" + vo.innerTitle
          : vo.innerTitle + "=>" + vo.outField;
    }
    // 内外部字段映射后两个穿梭框所做的数据处理
    insideRef.value!.handleExternalSplitArray();
    externalRef.value!.handleExternalSplitArray();
  }
  setTimeout(() => {
    //穿梭过来或者过去后清空当前选中需要穿梭的数据
    insideRef.value!.handleRest();
    externalRef.value!.handleRest();
    checkedMappingValue.value = [];
    insideCheckedValueObj.value = [];
    externalCheckedValueObj.value = [];
  }, 100);

};

// 全选
const handleMappingAllChange = (val: any) => {
  allMappingVisbile.value = val;
  isMappingIndeterminate.value = false;
  checkedMappingValue.value = val ? exportIds(mappingResults.value) : [];
};
// 处理数据拿到checkbox选中的绑定id
const exportIds = (val: any) => {
  let ids = [];
  for (let i = 0; i < val.length; i++) {
    const item = val[i];
    ids.push((item as any).templateFieldId);
  }
  return ids;
};
// 多选
const mappingSingleChange = (value: string | any[]) => {
  checkedCount.value = value.length;
  allMappingVisbile.value = checkedCount.value === mappingResults.value.length;
  isMappingIndeterminate.value =
    checkedCount.value > 0 && checkedCount.value < mappingResults.value.length;

  initValue();
};
//统一处理数据
const initValue = () => {
  for (let i = 0; i < checkedMappingValue.value.length; i++) {
    const itm = checkedMappingValue.value[i];
    let idx = mappingResults.value.findIndex((item: any) => (item as any).name == itm);
    if (idx > -1) {
      mappingCheckObj.value.push((mappingResults.value as any)[idx]);
    }
  }
};

//超出14个字省略号
const substringName = (value: string) => {
  if (!value) return;
  if (value.length > 14) {
    return value.slice(0, 14) + "...";
  }
  return value;
}
// 拿到除掉穿梭掉的内外部数据
const handleUpdata = (data: any) => {
  if (data.shuttleName == "内部字段") {
    insideCheckedValueObj.value = data.checkedValueObj;
  } else {
    externalCheckedValueObj.value = data.checkedValueObj;
  }
};
//清空映射结果，抛给表单需要时做处理
const clearData = () => {
  mappingResults.value = [];
};
defineExpose({
  clearData,
  mappingResults,
});
//监听prop.excelData，存在时处理成所需格式
watch(
  () => props.excelData,
  (newValue, oldValue) => {
    if (newValue) {
      externalData.value = [];
      for (let i = 0; i < newValue.length; i++) {
        const itm = newValue[i];
        externalData.value.push({
          templateFieldId: i,
          innerTitle: (itm as any).name,
        });
      }
    }
  }
);
watch(
  () => props.mappingData,
  (newValue, oldValue) => {
    if (newValue.length) {
      mappingResults.value = [];
     // 处理映射结果数据，用于回显；
      for (let i = 0; i < newValue.length; i++) {
        const itm = newValue[i];
        mappingResults.value.push({
          name:
            props.taskType == 1
              ? (itm as any).outField + "=>" + (itm as any).innerTitle
              : (itm as any).innerTitle + "=>" + (itm as any).outField,
          exportRequired: (itm as any).exportRequire == "0" ? false : true,//作业类型为导出时，当前字段是否必须做映射关系；
          importRequired: (itm as any).importRequire == "0" ? false : true,//作业类型为导入时，当前字段是否必须做映射关系；
          outField: (itm as any).outField,
          innerField: (itm as any).innerField,
          innerTitle: (itm as any).innerTitle,
          templateFieldId: (itm as any).templateFieldId,
          outTemplateFieldId: (itm as any).outTemplateFieldId,
        });
      }
    }
  }
);
</script>

<style lang="less" scoped>
.shuttle {
  width: 861px;
  padding: 10px 0 50px 0;
  display: flex;
  justify-content: space-between;

  //整个穿梭框
  .shuttle-box {
    width: 254px;
    border-radius: 4px;

    //标题
    .shuttle-box-title {
      color: #303133;
      background: #F8F8F8;
      padding: 0 16px 0 8px;
      height: 40px;
      line-height: 40px;
      display: flex;
      justify-content: space-between;
      font-size: 12px;

      .shuttle-box-title-left {
        display: flex;
        align-items: center;
        color: #3A3A3A;

        .shuttleName {
          margin-left: 10px;
        }
      }

      .index-num {
        color: #3A3A3A;
        font-size: 12px;
        font-weight: 400;
      }
    }

    //列表
    :deep(.shuttle-box-list) {
      height: 186px;
      overflow-y: auto;

      border-left: 1px solid #EFEFEF;
      border-bottom: 1px solid #EFEFEF;
      border-right: 1px solid #EFEFEF;
      .arco-checkbox-group .arco-checkbox{
      margin-right: 0px;
    }

      //一个列表item
      .shuttle-box-item {
        width: 228px;
        line-height: 1;
        padding: 10px 0px 10px 12px;
        font-size: 13px;
      }
    }
  }

  //左右穿梭按钮
  .shuttle-click {
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;

    .btn:nth-child(1) {
      margin-bottom: 8px;
    }

    .btn {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      opacity: 1;
      text-align: center;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .btnBg {
      cursor: pointer;
      background: #EEF2FF;
      color: #3E6CFE;
    }

    .btnDisabled {
      background: #F7F8FA;
      color: #C4C4C4;
    }
  }
}
</style>
