<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-16 14:16:08
 * @ Modified by: Sam
 * @ Modified time: 2023-03-28 17:40:00
 * @ Description: 配货策略配置-表单
 -->

<template>
  <a-modal title="策略配置" width="846px" v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk"
    unmountOnClose :esc-to-close="false" :mask-closable="false" modal-class="strategy-form-modal">
    <div style="padding: 0 6px;">
      <p class="form-title" style="margin-top: 0;margin-bottom: 16px;">基本信息</p>
      <a-row>
        <a-form ref="formRef" :model="form" layout="inline">
          <a-col :span="12">
            <a-form-item label="策略编码：" label-col-flex="100px">
              <a-input disabled v-model="strategyData.code"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item label="策略名称：" label-col-flex="100px">
              <a-input disabled v-model="strategyData.title"></a-input>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="warehouseId" label="虚拟仓库：" label-col-flex="100px"
              :rules="[{ required: true, message: '请选择虚拟仓库' }]">
              <a-select v-model="form.warehouseId" placeholder="请选择" @change="onWarehouseChange">
                <a-option v-for="v in companyList" :label="v.warehouseName" :value="v.id"></a-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="expressStrategyId" label="快递策略：" label-col-flex="100px"
              :rules="[{ required: true, message: '请选择快递策略' }]">
              <a-select v-model="form.expressStrategyId" placeholder="请选择">
                <a-option v-for="v in selectList" :label="v.title" :value="v.id"></a-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="level" label="优先级：" label-col-flex="100px"
              :rules="[{ required: true, message: '请输入优先级' }]">
              <a-input-number v-limit-input :min="1" :max="9999999" v-model="form.level" placeholder="请输入" allow-clear />
            </a-form-item>
          </a-col>
        </a-form>
      </a-row>

      <p class="form-title" style="margin-top: 20px;">策略条件</p>
      <oms-strategy ref="omsStrategyRef" :id="form.id" :edit-type="editModal.type" :type="StrategyType.Phcl"
        height="100px" max-height="100px"></oms-strategy>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="delivery-strategy-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import omsStrategy from "@/components/oms-strategy/index.vue"
import { DeliveryForm } from '@/types/strategy/delivery';
import { getDictionaryTitle } from '@/api/system/dictionary';
import { DictionaryTitleType } from '@/types/system/dictionary';
import { StrategyType } from '@/types/strategy/order';
import { addDeliverysConfig, editDeliverysConfig, getDeliveryDetail, querySelectByModel, queryVirtualByCompany } from '@/api/strategy/delivery';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const omsStrategyRef = ref();
const formRef = ref();
const strategyData = ref();
const form = ref<DeliveryForm>(new DeliveryForm());
const companyList = ref<{ warehouseName: string, warehouseCode: string, id: string }[]>([]);
const selectList = ref<{ id: string, title: string }[]>([]);

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }

  try {
    const api = editModal.type === 'add' ? addDeliverysConfig : editDeliverysConfig;
    form.value.strategyId = strategyData.value.id;
    form.value.lstStrategyConfigAdd = omsStrategyRef.value.getValue();

    const res = await api(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

const onWarehouseChange = (v: any) => {
  for (let i = 0; i < companyList.value.length; i++) {
    if (companyList.value[i].id === v) {
      form.value.warehouseName = companyList.value[i].warehouseName;
      break;
    }
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: any, strategyInfo: any) => {
  strategyData.value = strategyInfo;
  editModal.type = type;
  editModal.show = true;


  if (type === 'add') {
    form.value = new DeliveryForm();
  }

  if (type === "edit") {
    try {
      const res = await getDeliveryDetail(data.id);
      if (res.code != 0) {
        return Message.error(res.message);
      }
      form.value = res.value;
      form.value.id = data.id;
    } catch (err) {
      Message.error((err as Error).message);
    }
  }

  // 查询拆分相关字典数据
  try {
    const companyRes = await queryVirtualByCompany(strategyInfo.companyCode);
    const selectRes = await querySelectByModel(StrategyType.Kdcl);

    if (companyRes.code != 0 || selectRes.code != 0) {
      Message.error(companyRes.message || selectRes.message);
      return false;
    }

    companyList.value = companyRes.value;
    selectList.value = selectRes.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}

defineExpose({
  handleShowModal
});
</script>

<style lang="less">
.strategy-form-modal {
  .form-title {
    color: #3A3A3A;
    font-size: 13px;
    font-weight: bold;
    line-height: 17px;
  }

  .arco-form-layout-inline .arco-form-item {
    margin-bottom: 20px;
  }

  .arco-modal-body {
    padding: 24px 28px 24px 38px !important;
  }

  .arco-modal-footer {
    margin-top: 20px;
  }
}
</style>