<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-20 14:45:38
 * @ Modified by: Sam
 * @ Modified time: 2023-03-20 17:11:13
 * @ Description: 查询快递策略
 -->

<template>
  <a-modal title="快递策略" width="500px" v-model:visible="modal.show" title-align="start" :footer="false" unmountOnClose
    :esc-to-close="false" :mask-closable="false">
    <oms-table :loading="loading" :total="total" :current="searchForm.pageNum" :size="searchForm.pageSize"
      @reload="queryPage" simplePagination>
      <a-table :data="(list as any)" :pagination="false" hide-expand-button-on-empty row-key="id"
        :bordered="{ wrapper: false }">
        <template #columns>
          <a-table-column title="快递名称" ellipsis tooltip>
            <template #cell="{ record }"> {{ record.expressTitle || '--' }} </template>
          </a-table-column>
          <a-table-column title="优先级" ellipsis tooltip>
            <template #cell="{ record }"> {{ record.sort}} </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </a-modal>
</template>

<script setup lang="ts" name="express-form">
import { reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { Message } from '@arco-design/web-vue';
import { ExpressListItem, ExpressSearchForm } from '@/types/strategy/express';
import { getPage } from '@/api/strategy/express';

interface Modal {
  show: boolean;
}
const modal = reactive<Modal>({
  show: false,
});

const loading = ref<boolean>(false);
const list = ref<ExpressListItem[]>([]);
const searchForm = ref<ExpressSearchForm>(new ExpressSearchForm());
const total = ref<number>(0);

const open = (expressStrategyId: number) => {
  modal.show = true;
  queryPage({ strategyId: expressStrategyId });
}

/**
 * 查询配置列表
 * @param data
 */
const queryPage = async (data?: any) => {
  try {
    loading.value = true;
    searchForm.value = { ...searchForm.value, ...data };
    const res = await getPage(searchForm.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

defineExpose({
  open
});
</script>