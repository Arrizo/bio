<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-13 09:51:51
 * @ Modified by: Sam
 * @ Modified time: 2023-03-16 10:17:28
 * @ Description: 策略管理-审单策略
 -->

<template>
  <a-row :gutter="10" style="height: 100%;">
    <a-col :span="24" style="height: 100%;">
      <oms-panel style="height: 100%;">
        <template #header>
          <search :loading="loading" @on-search="init"></search>
        </template>
        <div>
          <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" :list="list"
            @reload="init"></list>
        </div>
      </oms-panel>
    </a-col>
  </a-row>
</template>

<script setup lang="ts" name="strategy-order-index">
import { ref } from 'vue';
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import { deepClone } from '@/utils/helper';
import { Message } from '@arco-design/web-vue';
import { DocReviewListItem, DocReviewSearchForm, StrategyType } from '@/types/strategy/order';
import { getDocReviewList } from '@/api/strategy/order';

const loading = ref<boolean>(false);
const list = ref<DocReviewListItem[]>([]);
const total = ref<number>(0);
const form = ref<DocReviewSearchForm>(new DocReviewSearchForm());

/**
 * 初始化查询菜单数据
 * @param data
 */
const init = async (data?: DocReviewSearchForm) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.status = params.status === 'all' ? '' : params.status;
    params.strategyType = StrategyType.Sdcl;

    const res = await getDocReviewList(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    total.value = res.value.totalCount;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    setTimeout(() => {
      loading.value = false;
    }, 400);
  }
}
</script>