<!--
 * @ Author: Sam
 * @ Create Time: 2023-03-13 14:19:00
 * @ Modified by: Sam
 * @ Modified time: 2023-03-28 17:12:25
 * @ Description: 审单策略-表单
 -->
<template>
  <a-modal :title="`${editModal.type === 'add' ? '新增' : '编辑'}策略`" width="846px" v-model:visible="editModal.show"
    title-align="start" :on-before-ok="onOk" unmountOnClose :esc-to-close="false" :mask-closable="false" modal-class="strategy-form-modal">
    <div style="padding: 0 6px;">
      <p class="form-title" style="margin-top: 0;margin-bottom: 16px;">基本信息</p>
      <a-row>
        <a-form ref="formRef" :model="form" layout="inline">
          <a-col :span="12">
            <a-form-item field="title" label="策略名称：" label-col-flex="100px"
              :rules="[{ required: true, message: '请输入策略名称' }]">
              <a-input v-limit-input v-model="form.title" show-word-limit :max-length="100"
                placeholder="请输入" allow-clear />
            </a-form-item>
          </a-col>
          <a-col :span="12">
            <a-form-item field="remark" label="备注：" label-col-flex="100px">
              <a-input v-limit-input v-model="form.remark" show-word-limit :max-length="200"
                placeholder="请输入" allow-clear />
            </a-form-item>
          </a-col>
        </a-form>
      </a-row>
      <p class="form-title" style="margin-top: 20px;">策略条件</p>
      <oms-strategy ref="omsStrategyRef" :id="form.id" :edit-type="editModal.type" :type="StrategyType.Sdcl"
        v-model="form.elements"></oms-strategy>
    </div>
  </a-modal>
</template>

<script setup lang="ts" name="strategy-order-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import omsStrategy from "@/components/oms-strategy/index.vue"
import { DocReviewForm, StrategyType } from '@/types/strategy/order';
import { addDocReview, updateDocReview } from '@/api/strategy/order';
import { deepClone } from '@/utils/helper';

interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const omsStrategyRef = ref();
const formRef = ref();
const form = ref<DocReviewForm>(new DocReviewForm());

/** 点击确定按钮前触发 */
const onOk = async (done: Function) => {
  const check = await formRef.value.validate();
  if (check) {
    return false;
  }


  try {
    const api = editModal.type === 'add' ? addDocReview : updateDocReview;
    form.value.elements = omsStrategyRef.value.getValue();
    const res = await api(form.value);

    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    return false;
  }
}

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: any) => {
  editModal.type = type;
  editModal.show = true;

  if (type === 'add') {
    form.value = new DocReviewForm();
  }

  if (type === "edit") {
    try {
      form.value = deepClone(data);
    } catch (err) {
      Message.error((err as Error).message);
    }
  }
}

defineExpose({
  handleShowModal
});
</script>


<style lang="less">
.strategy-form-modal {
  .form-title {
    color: #3A3A3A;
    font-size: 13px;
    font-weight: bold;
    line-height: 17px;
  }

  .arco-form-layout-inline .arco-form-item {
    margin-bottom: 20px;
  }

  .arco-modal-body {
    padding: 24px 28px 24px 38px !important;
  }

  .arco-modal-footer {
    margin-top: 20px;
  }
}
</style>