<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-22 16:32:18
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-14 10:24:08
 * @FilePath: \oms-admin\src\views\oms\product\brand\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <oms-panel style="height: 100%;">
    <template #header>
      <search :loading="loading" @on-search="initMethod"></search>
    </template>
    <list :loading="loading" :total="total" :brand-list="listData" :page-num="form.pageNum" :page-size="form.pageSize"
      @reload="initMethod"></list>
  </oms-panel>
</template>
<script lang="ts" setup name="condition-index">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue'
import List from './components/list.vue'
import { ConditionSearchTpye, ConditionListType } from '@/types/strategy/condition'
import { ref, reactive } from 'vue'
import { Message } from '@arco-design/web-vue'
import {queryConditionList} from '@/api/strategy/condition'
const loading = ref<boolean>(false)
const total = ref<number>(0)
const listData = ref<Array<ConditionListType>>([])
let form = reactive<ConditionSearchTpye>(new ConditionSearchTpye())
const initMethod = async (data?: ConditionSearchTpye) => {
  try {
    form = Object.assign(form, data)
    loading.value = true
    const { code, value, message } = await queryConditionList(form)
    if (code != 0) {
      throw new Error(message)
    }
    listData.value = value.result
    total.value = value.totalCount;
    form.pageNum = value.pageNum;
    form.pageSize = value.pageSize;
  } catch (error) {
    Message.error((error as Error).message);
  } finally {
    loading.value = false
  }

}
</script>