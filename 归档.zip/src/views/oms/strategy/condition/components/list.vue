<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 10:46:56
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-28 13:41:51
 * @FilePath: \oms-admin\src\views\oms\basicdata\goods-brand\components\list\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
	<oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onBrandReload">
		<template #header-left>
			<a-button type="primary" status="normal" @click="handleAdd()" style="margin-bottom:10px"
				v-permission="['oms:strategy:condition:add']">新增字段</a-button>
		</template>
		<a-table :data="brandList" :pagination="false" hide-expand-button-on-empty :scroll="{ y: 650, x: 1400 }" stripe
			:bordered="{ wrapper: false }">
			<template #columns>
				<a-table-column title="字段名称" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.fieldName || '' }}
					</template>
				</a-table-column>
				<a-table-column title="中文名称" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.chineseName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="显示名称" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.displayName || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="类型" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.type || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="参数值" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.paramValue || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="应用模块" :tooltip="true" ellipsis>
					<template #cell="{ record }">
						{{ record.applicationModel || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="状态" :tooltip="true" :width="120" ellipsis>
					<template #cell="{ record }">
						<span v-permission="['oms:strategy:condition:statusUpdata']">
							<a-switch v-model="record.status" @focus="handleEvent(record, 'status')">
								<template #checked>
									启用
								</template>
								<template #unchecked>
									禁用
								</template>
							</a-switch>
						</span>
					</template>
				</a-table-column>
				<a-table-column title="创建时间" :tooltip="true" :width="180" ellipsis>
					<template #cell="{ record }">
						{{ record.createTime || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="修改时间" :tooltip="true" :width="180" ellipsis>
					<template #cell="{ record }">
						{{ record.updateTime || '--' }}
					</template>
				</a-table-column>
				<a-table-column title="操作" :tooltip="true" :width="130" ellipsis fixed="right">
					<template #cell="{ record }">
						<a-space :size="10">
							<a-link type="text" v-if="!record.status" @click="handleAdd(record)" v-permission="['oms:strategy:condition:edit']">编辑</a-link>
							<a-link type="text" status="danger" @click="handleEvent(record, 'delete')" v-permission="['oms:strategy:condition:delete']">删除</a-link>
							<a-link type="text" @click="openLog(record)" v-permission="['oms:strategy:condition:log']">日志</a-link>
						</a-space>
					</template>
				</a-table-column>
			</template>
		</a-table>
	</oms-table>
	<oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
	<condition-modal ref="conditionModalRef" @reloadTable="emits('reload')"></condition-modal>
	<oms-log ref="logRefs"></oms-log>
</template>
<script lang="ts" setup name="condition-list">
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import omsLog from '@/components/oms-log/index.vue'
import conditionModal from './condition-modal.vue';
import { ref } from 'vue'
import { Message } from '@arco-design/web-vue'
import { updateStatus, conditionDel } from '@/api/strategy/condition'
import { ConditionSearchTpye, ConditionListType } from '@/types/strategy/condition'
const emits = defineEmits<{
	(e: "reload", data?: ConditionSearchTpye): void
}>()
interface PropsType {
	loading: boolean
	total: number
	pageNum: number
	pageSize: number
	brandList: Array<ConditionListType>
}
const props = defineProps<PropsType>();
// 勾选状态id
const statusId = ref()
// 修改状态ref
const switchRef = ref()
// 日志ref
const logRefs = ref()
// 新增或编辑品牌ref
const conditionModalRef = ref()
// 弹窗类型删除or修改转态
const omsWarningType = ref()
const onBrandReload = (data?: any) => {
	emits('reload', data)
}
// 新增仓库
const handleAdd = (record?: ConditionListType) => {
	conditionModalRef.value.queryBrandDetails(record?.id ?? '')
}
// 删除
const handleEvent = (record: ConditionListType, type: string) => {
	omsWarningType.value = type
	statusId.value = record?.id + ''
	if (type == 'delete') {
		switchRef.value.open()
	} else {
		switchRef.value.open({ title: "提示", content: `确定将状态更改为${!record.status ? '已启用' : '已禁用'}？` });
	}

}
// 显示日志
const openLog = (record: ConditionListType) => {
	logRefs.value.init(record.logCode, '策略条件')
}
const beforeChange = async () => {
	try {
		let res = null
		if (omsWarningType.value == 'delete') {
			res = await conditionDel(statusId.value)
		} else {
			res = await updateStatus(statusId.value)
		}
		const { code, message } = res
		if (code != 0) {
			throw new Error(message);
		}
		Message.success(omsWarningType.value == 'delete'?'删除成功':'更新成功')
		onBrandReload()
	} catch (err) {
		Message.error((err as Error).message);
	}
}
</script>