<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-22 16:32:18
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-14 13:36:13
 * @FilePath: \oms-admin\src\views\oms\product\brand\components\search\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-form :model="form" layout="inline" ref="searchRef" auto-label-width>
    <a-form-item field="fieldName" label="字段名称：">
      <a-input v-model.trim="form.fieldName" placeholder="请输入字段名称" allow-clear :max-length="20"
        :style="{ width: '200px' }" @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="name" label="名称：">
      <a-input v-model.trim="form.name" placeholder="请输入中文/显示名称" allow-clear :max-length="20" :style="{ width: '200px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="status" label="应用模块：">
      <oms-multiple-select v-model="form.lstApplicationModel" :maxTagCount="1" value="dictionaryValue" label="dictionaryTitle" :option-list="lstApplicationList"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="status" label="状态：">
      <a-select placeholder="请选择" v-model="form.status" :style="{ width: '200px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="true">已启用</a-option>
        <a-option value="false">已禁用</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>
<script setup lang="ts" name="condition-list-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { ConditionSearchTpye } from '@/types/strategy/condition'
import { ref, onMounted, reactive } from 'vue'
import omsMultipleSelect from '@/components/oms-multiple-select/index.vue'
import { deepClone } from '@/utils/helper';
import commitMethod from '@/views/oms/product/purchase/commo-method/index'
const props = defineProps<{ loading: boolean }>();
const { getCompanyTypeList } = commitMethod()
const emits = defineEmits<{
  (e: "on-search", data: ConditionSearchTpye): void;
}>();
const form = reactive<ConditionSearchTpye>(new ConditionSearchTpye())
const searchRef = ref()
const lstApplicationList = ref()
const handleReset = () => {
  searchRef.value.resetFields();
  form.lstApplicationModel=[]
  handleSearch();
}
const handleSearch = () => {
  const newForm = deepClone(form)
  if (newForm.status === 'all') { newForm.status = '' }
  emits('on-search', newForm)
}
const queryDictionary = async () => {
  lstApplicationList.value = await getCompanyTypeList('STRATEGY_MODEL')
}
onMounted(() => {
  handleSearch()
  queryDictionary()
})

</script>