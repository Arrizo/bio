<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 16:52:06
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-28 10:19:27
 * @FilePath: \oms-admin\src\views\oms\basicdata\goods-brand\components\brand-modal\index.vue
-->
<template>
  <a-modal :width="700" :title="titleName" v-model:visible="showBrandModal" title-align="start" :on-before-ok="onBeforeOk"
    :mask-closable="false" :ok-loading="loading">
    <a-form :model="form" auto-label-width ref="formRef" :rules="formRules">
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="字段名称：" field="fieldName">
            <a-input v-model.trim="form.fieldName" allow-clear placeholder="请输入字段名称" :disabled="form.exit"
              :max-length="100" v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="中文名称：" field="chineseName">
            <a-input v-model.trim="form.chineseName" allow-clear placeholder="请输入中文名称" :max-length="50"
              v-limit-input></a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="显示名称：" field="displayName">
            <a-input v-model.trim="form.displayName" allow-clear placeholder="请输入显示名称" :max-length="20"
              v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="类型：" field="type">
            <a-select v-model="form.type" placeholder="请选择类型" :disabled="form.exit">
              <a-option v-for="(item, index) in typeList" :key="`${index}-type`" :value="item.dictionaryValue">{{
                item.dictionaryTitle }}</a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="60">
        <a-col :span="12">
          <a-form-item label="参数值：" field="paramValue" :rules="[{ required: isRequire, message: '请输入' }]">
            <a-input v-model.trim="form.paramValue" allow-clear placeholder="请输入" :disabled="form.exit"
              v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="应用模块：" field="lstApplicationModel">
            <oms-multiple-select v-model="form.lstApplicationModel" :maxTagCount="1" value="dictionaryValue"
              :disabled="form.exit" label="dictionaryTitle" :option-list="lstApplicationList"></oms-multiple-select>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
  </a-modal>
</template>
<script setup lang="ts" name="condition-modal">
import { Message } from '@arco-design/web-vue'
import { ConditionListType } from '@/types/strategy/condition'
import { queryConditionDetail, updateCondition, addCondition } from '@/api/strategy/condition'
import omsMultipleSelect from '@/components/oms-multiple-select/index.vue'
import commitMethod from '@/views/oms/product/purchase/commo-method/index'
import { reactive, watch, ref, computed } from 'vue'
const emits = defineEmits<{
  (e: "reloadTable"): void
}>()
const formRef = ref()
const loading = ref(false)
const { getCompanyTypeList } = commitMethod()
let form = reactive<ConditionListType>(new ConditionListType())
const showBrandModal = ref<boolean>(false)
const lstApplicationList = ref()
const typeList = ref()
const titleName = computed(() => {
  return `${form.id ? '编辑' : '新增'}字段`
})
const formRules = reactive({
  fieldName: [
    { required: true, message: '请输入字段名称' }
  ],
  chineseName: [
    { required: true, message: '请输入中文名' }
  ],
  type: [
    { required: true, message: '请选择类型' }
  ],
  lstApplicationModel: [
    { required: true, message: '请选择应用模块' }
  ],
  paramValue: [
    { required: true, message: '请输入' }
  ],
})
const queryBrandDetails = async (id?: string) => {
  showBrandModal.value = true
  try {
    if (id) {
      const { code, value, message } = await queryConditionDetail(id)
      if (code != 0) {
        throw new Error(message)
      }
      Object.assign(form, value)
    }
  } catch (error) {
    Message.error((error as Error).message)
  }
}
// 关闭弹窗前数据检验
const onBeforeOk = async (done: Function) => {
  const valid = await formRef.value.validate()
  if (valid) { return false }
  // if (isRequire.value && !form.paramValue) {
  //   Message.error('请输入参数值')
  //   return false
  // }
  try {
    loading.value = true
    let res = null
    if (form.id) {
      res = await updateCondition(form)
    } else {
      res = await addCondition(form)
    }
    const { code, message } = res
    if (code != 0) {
      throw new Error(message)
    }
    Message.success('操作成功！')
    emits('reloadTable')
    return true
  } catch (error) {
    Message.error((error as Error).message)
    return false
  } finally {
    loading.value = false
  }
}
const queryDictionary = async () => {
  lstApplicationList.value = await getCompanyTypeList('STRATEGY_MODEL')
  typeList.value = await getCompanyTypeList('STRATEGY_CONDITION_TYPE')
}
watch(() => showBrandModal.value, (nV) => {
  if (nV) {
    queryDictionary()
  } else {
    formRef.value.clearValidate()
    formRef.value.resetFields()
    form.id = ''
    form.exit = false
    form.paramValue = ''
  }
})
const isRequire = computed(() => ['selectSingle', 'selectMultiple', 'popMultiple'].includes(form.type))
defineExpose({
  queryBrandDetails
})
</script>
<style lang="less" scoped>
.upload-wrap {
  display: flex;
  flex-direction: column;

  // margin-top: 8px;
  .title {
    color: #B1B1B1;
    font-size: 12px;
  }
}</style>