<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-16 17:47:29
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-23 16:46:22
 * @ Description:包装方案搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="materialCode" label="包材编码：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.materialCode" allowClear
        placeholder="请输入" />
    </a-form-item>
    <a-form-item field="spuCode" label="商品编码：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.spuCode" allowClear
        placeholder="请输入" />
    </a-form-item>
    <a-form-item field="skuCode" label="规格编码：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.skuCode" allowClear
        placeholder="请输入" />
    </a-form-item>
    <a-form-item field="skuName" label="规格名称：">
      <a-input @keyup.enter="handleSearch" v-limit-input="['#', '']" v-model.trim="form.skuName" allowClear
        placeholder="请输入" />
    </a-form-item>
    <a-form-item field="lstWarehouseId" label="适用仓库：">
      <oms-multiple-select style="width: 208px;" :maxTagCount="1" v-model="form.lstWarehouseId" :option-list="(warehouseList as any)" value="id"
        label="warehouseName"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="lstStoreId" label="适用店铺：">
      <oms-multiple-select style="width: 208px;" :maxTagCount="1" v-model="form.lstStoreId" :option-list="(shopList as any)" value="id"
        label="storeName"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="lstExpressId" label="适用快递：">
      <oms-multiple-select style="width: 208px;" :maxTagCount="1" v-model="form.lstExpressId" :option-list="(expressList as any)" value="id"
        label="expressName"></oms-multiple-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="strategy-packaging-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { DictionaryType } from '@/types/system/dictionary';
import { onMounted, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"
import { getDictionaryList } from '@/hooks/useDictionary';
import { PackagingReq } from '@/types/strategy/packaging';
import { ShopSelectItem } from '@/types/product/distribution';
const props = defineProps({
  loading: { type: Boolean, default: false },
  shopList: { type: Array<ShopSelectItem>, default: () => [] },
  expressList: { type: Array, default: () => [] },
  warehouseList: { type: Array, default: () => [] },
});
const formRes = ref();
const emits = defineEmits<{
  (e: "on-search", data: PackagingReq): void;
}>();

const form = ref<PackagingReq>(new PackagingReq());
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}
onMounted(async () => {
  handleSearch();
});
</script>