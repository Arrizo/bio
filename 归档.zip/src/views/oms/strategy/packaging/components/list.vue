<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-16 17:47:29
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-28 09:25:08
 * @ Description:包装方案列表
 -->

<template>
  <div class="packaging-container">
  <oms-table :loading="loading" :total="totalCount" :current="form.pageNum" :size="form.pageSize" @reload="onReload">
      <template #header-left>
        <a-space :size="14">
          <a-button style="margin-bottom: 10px;" v-permission="['oms:strategy:packaging:add']" type="primary"
            status="normal" @click="handleAction('add')"> 新增 </a-button>
          <!-- <a-button style="margin-bottom: 10px;" v-permission="['oms:strategy:packaging:import']" type="outline"
                    status="normal" @click="handleAction('import')"> 导入 </a-button>
                  <a-button style="margin-bottom: 10px;" v-permission="['oms:strategy:packaging:export']" status="normal"
                    @click="handleAction('export')"> 导出 </a-button> -->
          <a-button style="margin-bottom: 10px;" :disabled="!selectedKeys.length"
            v-permission="['oms:strategy:packaging:batchDel']" status="normal" @click="handleAction('batch-del')"> 批量删除
          </a-button>
        </a-space>
      </template>

      <a-table ref="tableRef" stripe :data="(list as any)" :pagination="false" :bordered="{ wrapper: false }" row-key="id"
        :row-selection="{
          type: 'checkbox',
          showCheckedAll: true
        }" :scroll="{ x: 1400 }" v-model:selectedKeys="selectedKeys">
        <template #columns>
          <a-table-column title="商品编码" ellipsis tooltip :width="180" data-index="spuCode">
            <template #cell="{ record }">{{ record.spuCode || '--' }}</template>
          </a-table-column>
          <a-table-column title="规格编码" ellipsis tooltip :width="180" data-index="skuCode">
            <template #cell="{ record }">{{ record.skuCode || '--' }}</template>
          </a-table-column>
          <a-table-column title="规格名称" ellipsis tooltip :width="180" data-index="skuName">
            <template #cell="{ record }">{{ record.skuName || '--' }}</template>
          </a-table-column>
          <a-table-column title="包材编码" ellipsis tooltip :width="180" data-index="materialCode">
            <template #cell="{ record }">{{ record.materialCode || '--' }}</template>
          </a-table-column>
          <a-table-column title="包材名称" ellipsis tooltip :width="180" data-index="materialName">
            <template #cell="{ record }">{{ record.materialName || '--' }}</template>
          </a-table-column>
          <a-table-column title="包材尺寸(cm)" ellipsis tooltip :width="180">
            <template #cell="{ record }">
              {{ record.length
              }}{{ record.width ? '*' + record.width :
  record.width }}{{ record.height ? '*' + record.height : record.height }}
            </template>
          </a-table-column>
          <a-table-column title="图片" ellipsis tooltip :width="180">
            <template #cell="{ record }">
              <a-image width="44" height="44" :src="record.picture">
                <template #error>
                  <div class="empty-picture">
                    <i class="iconfont icon-shangpinzhanweitu"></i>
                  </div>
                </template>
              </a-image>
            </template>
          </a-table-column>
          <a-table-column title="包材重量(kg)" ellipsis tooltip :width="180" data-index="materialWeight">
            <template #cell="{ record }">{{ record.materialWeight || '--' }}</template>
          </a-table-column>
          <a-table-column title="商品毛重(kg)" ellipsis tooltip :width="180" data-index="grossWeight">
            <template #cell="{ record }">{{ record.grossWeight || '--' }}</template>
          </a-table-column>
          <a-table-column title="包装重量(kg)" ellipsis tooltip :width="180" data-index="packageWeight">
            <template #cell="{ record }">{{ record.packageWeight || '--' }}</template>
          </a-table-column>
          <a-table-column title="适用仓库" ellipsis tooltip :width="180" data-index="warehouseName">
            <template #cell="{ record }">{{ record.warehouseName || '--' }}</template>
          </a-table-column>
          <a-table-column title="适用店铺" ellipsis tooltip :width="180" data-index="storeName">
            <template #cell="{ record }">{{ record.storeName || '--' }}</template>
          </a-table-column>
          <a-table-column title="适用快递" ellipsis tooltip :width="180" data-index="expressName">
            <template #cell="{ record }">{{ record.expressName || '--' }}</template>
          </a-table-column>
          <a-table-column title="创建时间" :width="180" data-index="createTime">
            <template #cell="{ record }">{{ record.createTime || '--' }}</template>
          </a-table-column>
          <a-table-column title="修改时间" :width="180" data-index="updateTime">
            <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
          </a-table-column>
          <a-table-column title="操作" :width="180" fixed="right">
            <template #cell="{ record }">
              <a-space :size="14">
                <a-link v-permission="['oms:strategy:packaging:edit']" @click="handleAction('edit', record)"
                  type="text">编辑</a-link>
                <a-link v-permission="['oms:strategy:packaging:del']" status="danger" @click="handleAction('del', record)"
                  type="text">删除</a-link>
                <a-link v-permission="['oms:strategy:packaging:log']" @click="handleAction('log', record)"
                  type="text">日志</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>

    <!-- 菜单新增/编辑弹窗 -->
    <packaging-form-vue ref="PackagingFromRef" @reload="emits('reload')"></packaging-form-vue>

    <!-- 修改状态二次弹框 -->
    <oms-warning ref="warnignRef" :on-before-ok="handleDelete"></oms-warning>

    <!-- 导入 -->
    <oms-import ref="importRef" :uploadSize="10" uploadUrlName="包装导入模板" :uploadUrl="uploadUrl" :importApi="importApi"
      @onSuccess="emits('reload')">
    </oms-import>

    <!-- 日志 -->
    <oms-log ref="logRef"></oms-log>
  </div>
</template>

<script setup lang="ts" name="strategy-packaging-list">
import { computed, reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import OmsLog from '@/components/oms-log/index.vue'
import OmsImport from '@/components/oms-import/index.vue'
import PackagingFormVue from "./form.vue"
import { Message } from '@arco-design/web-vue';
import { ShopSelectItem } from '@/types/product/distribution';
import { PackagingReq, PackagingType } from '@/types/strategy/packaging';
import { delPackaging } from '@/api/strategy/packaging';
const form = ref<PackagingReq>(new PackagingReq());

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  totalCount: { type: Number, default: 0 },
  shopList: { type: Array<ShopSelectItem>, default: () => [] },
  expressList: { type: Array, default: () => [] },
  warehouseList: { type: Array, default: () => [] },
});

const emits = defineEmits<{
  (e: "reload", data?: PackagingReq): void,
  (e: "details", data: PackagingType): void,
}>();
const selectedKeys = ref<number[]>([]);
const PackagingFromRef = ref();
const warnignRef = ref();//批量删除
const tableRef = ref()
// 导入
const importRef = ref();
const uploadUrl = ref(`${import.meta.env.VITE_API_FILE_URL}/bp-auth-service/template/productManage/铺货关系导入模板.xlsx`);
const importApi = ref();

const currentId = ref();
const logRef = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};

// 「新增菜单」按钮点击触发
const handleAction = (type: string, record?: PackagingType) => {
  switch (type) {
    case 'add'://新增
      PackagingFromRef.value.handleShowModal(type, null, props.shopList, props.expressList, props.warehouseList);
      break;
    case 'edit'://编辑
      PackagingFromRef.value.handleShowModal(type, record?.id, props.shopList, props.expressList, props.warehouseList);
      break;
    case 'import'://导入
      importRef.value.visible = true;
      break;
    case 'export'://导出
      if (selectedKeys.value.length == 0) return Message.error('请选择需要处理的数据！');
      break;
    case 'batch-del'://批量删除
      if (selectedKeys.value.length == 0) return Message.error('请选择需要处理的数据！');
      warnignRef.value.open();
      break;
    case 'del'://删除
      selectedKeys.value = [];
      if (record?.id) selectedKeys.value.push(record?.id);
      warnignRef.value.open();
      break;
    case 'log'://日志
      logRef.value.init(record?.logCode, '包装方案');
      break;
    default:
      break;
  }
};


// 删除操作
const handleDelete = async () => {
  try {
    const res = await delPackaging(selectedKeys.value);
    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    emits("reload");
    tableRef.value.selectAll(false);
    selectedKeys.value = []
  } catch (err) {
    Message.error((err as Error).message);
    tableRef.value.selectAll(false);
    return false;
  }
}
</script>
<style lang="less" scoped>
.packaging-container{
  :deep(.arco-table .arco-table-cell){
    padding: 5px 16px;
  }
}
.empty-picture {
  width: 44px;
  height: 44px;
  background-color: #fff;
  border: 1px solid #EDEDED;
  border-radius: 2px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: row;

  .icon-shangpinzhanweitu {
    color: #EDEDED;
  }
}
</style>