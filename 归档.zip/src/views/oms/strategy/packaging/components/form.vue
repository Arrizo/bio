<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-16 17:47:29
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-28 09:18:44
 * @ Description:包装方案表单
 -->

<template>
  <a-modal :mask-closable="false" :title="editModal.type === 'add' ? '新增' : '编辑'" width="729px"
    v-model:visible="editModal.show" title-align="start" :on-before-ok="onOk" @cancel="onCancel" unmountOnClose>
    <a-form ref="formRef" :model="form" layout="horizontal">
      <a-row>
        <a-col :span="12">
          <a-form-item label-col-flex="110px" label="规格编码：" field="skuCode" required
            :rules="[{ required: true, message: '请输入规格编码' }]">
            <a-input :max-length="50" @input="form.skuCode = form.skuCode.replace(/[\u4e00-\u9fa5]/g, '')" style="width:208px" v-model="form.skuCode" @blur="handleSkuBlur" clearable placeholder="请输入">
            </a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label-col-flex="110px" label="规格名称：">
            <a-input style="width:208px" v-model="form.skuName" disabled>
            </a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="12">
          <a-form-item label-col-flex="110px" label="包材编码：" field="materialCode" required
            :rules="[{ required: true, message: '请输入包材编码' }]">
            <a-input :max-length="50" @input="form.materialCode = form.materialCode.replace(/[\u4e00-\u9fa5]/g, '')" style="width:208px" v-model="form.materialCode" @blur="handlePackBlur" clearable placeholder="请输入">
            </a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label-col-flex="110px" label="包材名称：">
            <a-input style="width:208px" v-model="form.materialName" disabled>
            </a-input>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="12">
          <a-form-item label-col-flex="110px" label="包材尺寸(cm)：">
            <a-input style="width:208px" v-model="measurement" disabled>
            </a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label-col-flex="110px" label="包材重量(kg)：">
            <a-input-number style="width:208px" v-model="form.materialWeight" disabled>
            </a-input-number>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-col :span="12">
          <a-form-item label-col-flex="110px" label="商品毛重(kg)：">
            <a-input-number style="width:208px" v-model="form.grossWeight" disabled>
            </a-input-number>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label-col-flex="110px" label="包装重量(kg)：">
            <a-input-number style="width:208px" v-model="form.packageWeight" disabled>
            </a-input-number>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row>
        <a-form-item label-col-flex="110px" label="适用仓库：" field="lstWarehouseId" required
          :rules="[{ required: true, message: '请选择适用仓库' }]">
          <oms-multiple-select style="width:98%" :maxTagCount="1" v-model="form.lstWarehouseId" :option-list="(warehouseList as any)"
            value="id" label="warehouseName"></oms-multiple-select>
        </a-form-item></a-row>
      <a-row>
        <a-form-item label-col-flex="110px" label="适用店铺：" >
          <oms-multiple-select style="width:98%" :maxTagCount="1" v-model="form.lstStoreId" :option-list="(shopList as any)" value="id"
            label="storeName"></oms-multiple-select>
        </a-form-item></a-row>
      <a-row>
        <a-form-item label-col-flex="110px" label="适用快递：" >
          <oms-multiple-select style="width:98%" :maxTagCount="1" v-model="form.lstExpressId" :option-list="(expressList as any)" value="id"
            label="expressName"></oms-multiple-select>
        </a-form-item></a-row>
      <a-row>
        <a-form-item label-col-flex="110px" label="包材图片：">
          <div>
            <p style="font-size: 12px;color: #B1B1B1;margin:0;line-height: 32px;">
              点击上传或修改图片，只能上传单个png/jpg/bmp/gif文件，限制最大1Mb</p>
            <image-uploader v-model="form.picture" :limit="1" :size="1 * 1024 * 1024"
              module="PRODUCT_COMPRESSED_FILE"></image-uploader>
          </div>
        </a-form-item></a-row>
    </a-form>
  </a-modal>
</template>

<script setup lang="ts" name="strategy-packaging-form">
import { reactive, ref } from 'vue';
import { Message } from '@arco-design/web-vue';
import imageUploader from '@/components/image-uploader/index.vue';
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"
import { PackagingFrom } from '@/types/strategy/packaging';
import { addPackaging, editPackaging, findPackageSku, findSkuScheme, queryDetail } from '@/api/strategy/packaging';
import { ShopSelectItem } from '@/types/product/distribution';
// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const form = ref<PackagingFrom>(new PackagingFrom());
const formRef = ref();
const loading = ref<boolean>(false);
const measurement = ref('');//包材尺寸
const shopList = ref<ShopSelectItem[]>([]);
const warehouseList = ref();
const expressList = ref();
/** 点击确定按钮时触发 */
const onOk = async (done: Function) => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  
  loading.value = true;
  try {
    const apiType = editModal.type === 'add' ? addPackaging : editPackaging;

    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  }

}

//点击规格编码
const handleSkuBlur = async () => {
  if (!form.value.skuCode) return
  try {
    let response = await findSkuScheme(form.value.skuCode);
    if (response?.success) {
      if(!response.value) return Message.error('规格编码为无效编码，请检查');
      form.value.skuName = response.value.skuName ?? '';
      form.value.grossWeight = response.value.grossWeight ?? null;//商品毛重
      form.value.spuCode = response.value.spuCode ?? '';
      //包装重量=商品毛重+包材重量(只要包材重量为null或者undefined包装重量不展示)
      if (form.value.materialWeight != null || form.value.materialWeight != undefined) {
        let grossWeight=form.value.grossWeight ? form.value.grossWeight : 0
        form.value.packageWeight = grossWeight + form.value.materialWeight;
      }

    } else {
      Message.warning(response?.message || '查询规格信息失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询规格信息失败");
  }
}

//点击包材编码
const handlePackBlur = async () => {
  if (!form.value.materialCode) return
  try {
    let response = await findPackageSku(form.value.materialCode);
    if (response?.success) {
      if(!response.value) return Message.error('包材编码为无效编码，请检查');
      form.value.materialName = response.value?.materialName ?? '';
      const { length, height, width } = response.value;
      const arr = [length, width, height];
      form.value.length = length;
      form.value.height = height;
      form.value.width = width;
      measurement.value = arr.filter(item => item).join("*");
      form.value.materialWeight = response.value.materialWeight ?? null;
      //包装重量=商品毛重+包材重量(只要包材重量为null或者undefined包装重量不展示)
      if (form.value.materialWeight != null || form.value.materialWeight != undefined) {
        let grossWeight=form.value.grossWeight ? form.value.grossWeight : 0
        form.value.packageWeight = grossWeight + form.value.materialWeight;
      }
    } else {
      Message.warning(response?.message || '查询包材信息失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询包材信息失败");
  }
}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

const getDetailsInfo = async (id: number) => {
  try {
    let response = await queryDetail(id);
    if (response?.success) {
      form.value.skuCode = response.value.skuCode ?? "";
      form.value.skuName = response.value.skuName ?? "";
      form.value.materialCode = response.value.materialCode ?? "";
      form.value.materialName = response.value.materialName ?? "";
      const { length, height, width } = response.value;
      const arr = [length, width, height];
      measurement.value = arr.filter(item => item).join("*");
      form.value.materialWeight = response.value.materialWeight ?? null;
      form.value.grossWeight = response.value.grossWeight ?? null;
      form.value.packageWeight = response.value.packageWeight ?? [];
      form.value.lstWarehouseId = response.value.lstWarehouseId ?? [];
      form.value.lstStoreId = response.value.lstStoreId ?? [];
      form.value.lstExpressId = response.value.lstExpressId ?? [];
      form.value.picture = response.value.picture ?? '';
    } else {
      Message.warning(response?.message || '查询详情信息失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询详情信息失败");
  }
}
/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", id: number, list: ShopSelectItem[], list1: any[], list2: any) => {
  editModal.type = type;
  editModal.show = true;
  shopList.value = list;
  expressList.value = list1;
  warehouseList.value = list2;
  form.value = new PackagingFrom();
  measurement.value = '';

  if (type === "edit") {
    form.value.id = id;
    getDetailsInfo(id)
  }
}



defineExpose({
  handleShowModal
});
</script>