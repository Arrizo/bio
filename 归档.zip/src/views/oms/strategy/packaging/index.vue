<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-13 10:00:28
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-22 18:04:09
 * @ Description:包装方案
 -->

<template>
  <div class="panel-height">
    <oms-panel>
      <template #header>
        <search :shopList="shopList" :expressList="expressList" :warehouseList="warehouseList" :loading="loading"
          @on-search="initData"></search>
      </template>
      <list :shopList="shopList" :expressList="expressList" :warehouseList="warehouseList" :loading="loading"
        :totalCount="totalCount" :list="list" @reload="initData">
      </list>
    </oms-panel>
  </div>
</template>
<script setup lang="ts" name="strategy-packaging">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue'
import List from './components/list.vue'
import { findExpressAndStatus, queryPage, queryStoreAndStatus, queryWarehouseAndStatus } from '@/api/strategy/packaging';
import { Message } from '@arco-design/web-vue';
import { onMounted, ref } from 'vue';
import { deepClone } from '@/utils/helper';
import { PackagingReq, PackagingType } from '@/types/strategy/packaging';
import { ShopSelectItem } from '@/types/product/distribution';
const form = ref<PackagingReq>(new PackagingReq());
const loading = ref<boolean>(false);
const list = ref<PackagingType[]>();
const totalCount = ref();
/**
 * 初始化查询菜单数据
 * @param form
 */

const initData = async (data: PackagingReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);

    const res = await queryPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

const shopList = ref<ShopSelectItem[]>([]);
const warehouseList = ref();
const expressList = ref();
//适用仓库
const queryWareList = async () => {
  try {
    let response = await queryWarehouseAndStatus();
    if (response?.success) {
      warehouseList.value = response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询仓库失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询仓库失败");
  }
}
//适用店铺
const queryShopList = async () => {
  try {
    let response = await queryStoreAndStatus();
    if (response?.success) {
      shopList.value = response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询店铺失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询店铺失败");
  }
}
//适用快递
const queryExpList = async () => {
  try {
    let response = await findExpressAndStatus();
    if (response?.success) {
      expressList.value = response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询快递失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询快递失败");
  }
}

onMounted(() => {
  queryWareList();
  queryShopList();
  queryExpList();
});
</script>
<style lang="less" scoped>
.panel-height {
  height: 100%;
}
</style>