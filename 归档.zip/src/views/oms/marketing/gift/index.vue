<template>
  <div class="panel-height">
    <oms-panel :class="{ 'panel-height': !showTabs }">
      <template #header>
        <search :loading="loading" @on-search="initMethod"></search>
      </template>
      <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" @reload="initMethod"
        :data-list="dataList" @show-record="showRecord"> </list>
    </oms-panel>
    <!-- 双击表格tabs栏目 -->
    <div class="shop-config" v-show="showTabs">
      <a-tabs default-active-key="1">
        <template #extra>
          <icon-close @click="showTabs = false" />
        </template>
        <a-tab-pane key="1" title="活动商品 ">
          <activity-goods tabsType="activity" :goods-list="activityGoodsList" ref="activityGoodsRef"
            :total="activityGoodsForm.total" :readonly="true" :page-num="activityGoodsForm.pageNum"
            :page-size="activityGoodsForm.pageSize" @reload="reloadTable($event, activityGoodsForm)">
          </activity-goods>
        </a-tab-pane>
        <a-tab-pane key="2" title="赠品明细">
          <activity-goods tabsType="gift" :goods-list="activityGiftList" ref="activityGoodsRef"
            :total="activityGiftForm.total" :readonly="true" :page-num="activityGiftForm.pageNum"
            @reload="reloadTable($event, activityGiftForm)" :page-size="activityGiftForm.pageSize">
          </activity-goods>
        </a-tab-pane>
        <a-tab-pane key="3" title="活动店铺">
          <activity-store :store-list="storeList" :readonly="true" ref="activityStoreRef"></activity-store>
        </a-tab-pane>
        <a-tab-pane key="4" title="活动条件">
          <oms-strategy ref="omsStrategyRef" :id="strategyId" edit-type="detail" :type="StrategyType.Zphd"></oms-strategy>
        </a-tab-pane>
        <a-tab-pane key="5" title="操作日志">
          <oms-log ref="omsLogRef"></oms-log>
        </a-tab-pane>
      </a-tabs>
    </div>
  </div>
</template>
<script lang="ts" setup name="gift-index">
import commonData from '../commonData/initData'
import OmsPanel from '@/components/oms-panel/index.vue'
import { ref, reactive } from 'vue'
import Search from './components/search.vue'
import List from './components/list.vue'
import ActivityGoods from './components/activity-goods.vue'
import { StrategyType } from "@/types/strategy/order";
import OmsStrategy from '@/components/oms-strategy/index.vue'
import ActivityStore from './components/activity-store.vue'
import {
  GiftSearchType,
  GiftListType,
  ActivityGiftitemType,
  ActivityStoreitemType,
  GiftActityGoodsSearch,
  ActivityGoodsitemType
} from '@/types/marketing/gift'
import {
  queryPresentActivityPage,
  queryPresentActivityStore,
  queryPresentActivityProductPage
} from '@/api/marketing/gift'
import { Message } from "@arco-design/web-vue"
import omsLog from '@/components/oms-log/index.vue'
const showTabs = ref<boolean>(false)
const omsLogRef = ref()
const { loading, total } = commonData()
// 活动商品列表参数
const activityGoodsForm = reactive<GiftActityGoodsSearch>(new GiftActityGoodsSearch())
activityGoodsForm.type = 'ACTIVITY_PRODUCT'
// 赠品商品列表参数
const activityGiftForm = reactive<GiftActityGoodsSearch>(new GiftActityGoodsSearch())
activityGiftForm.type = 'PRESENT_PRODUCT'
const strategyId = ref()
const storeList = ref<Array<ActivityStoreitemType>>([])
// 活动商品列表
const activityGoodsList = ref<Array<ActivityGoodsitemType>>([])
// 赠品商品列表
const activityGiftList = ref<Array<ActivityGiftitemType>>([])

let form = reactive<GiftSearchType>(new GiftSearchType())
const dataList = ref<Array<GiftListType>>([])
const initMethod = async (data?: GiftSearchType) => {
  try {
    Object.assign(form, data)
    loading.value = true
    const { code, message, value } = await queryPresentActivityPage(form)
    if (code != 0) {
      throw new Error(message)
    }
    dataList.value = value.result
    total.value = value.totalCount
    form.pageNum = value.pageNum
    form.pageSize = value.pageSize
    showTabs.value = false
    loading.value = false
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
// 双击表格回调事件
const showRecord = (data: GiftListType) => {
  omsLogRef.value.init(data?.activityCode, '赠品活动', 'page')
  queryActivityStore(data.id)
  strategyId.value = Number(data?.id)
  activityGoodsForm.activityId = data.id
  activityGiftForm.activityId = data.id
  queryActivityGoods(activityGoodsForm)
  queryActivityGoods(activityGiftForm)
  showTabs.value = true
}
const reloadTable = (data: any, params: GiftActityGoodsSearch) => {
  queryActivityGoods(Object.assign(params, data))
}
// 查询活动商品
const queryActivityGoods = async (data: GiftActityGoodsSearch) => {
  try {
    const { code, value, message } = await queryPresentActivityProductPage(data)
    if (code != 0) {
      throw new Error(message)
    }
    data.pageNum = value.pageNum
    data.pageSize = value.pageSize
    data.total = value.totalCount
    if (data.type == 'ACTIVITY_PRODUCT') {
      activityGoodsList.value = value.result
    } else {
      activityGiftList.value = value.result
    }
  } catch (error) {
    Message.error((error as Error).message)
  }
}

// 查询活动店铺
const queryActivityStore = async (id: string) => {
  try {
    const { code, message, value } = await queryPresentActivityStore(id)
    if (code != 0) {
      throw new Error(message)
    }
    storeList.value = value
  } catch (error) {
    Message.error((error as Error).message)
  }
}
</script>
<style lang="less" scoped>
.panel-height {
  height: 100%;
}

.shop-config {
  background-color: #fff;
  height: 100%;

  :deep(.arco-tabs-nav) {
    padding: 10px 16px 0px 10px;
  }

  :deep(.arco-tabs-content) {
    padding-left: 16px;
    padding-right: 16px;
  }

  :deep(.arco-tabs-nav-extra) {
    border: 1px solid rgba(112, 112, 112, 0.3);
    border-radius: 50%;
    color: #707070;
    font-size: 11px;
    padding: 2px;
    cursor: pointer;
  }
}
</style>