<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 15:02:33
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-29 10:54:46
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\goods\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal v-model:visible="showModal" :width="900" title-align="start" :on-before-ok="onBeforeOk" :mask-closable="false"
    title="选择规格" class="spec-modal-class">
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form :model="form" layout="inline" ref="formRef">
      <a-form-item field="products" label="商品编码：">
        <a-input v-model="form.products" placeholder="多个逗号或者空格隔开" allow-clear :style="{ width: '180px' }"
          @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="specs" label="规格编码：">
        <a-input v-model="form.specs" placeholder="多个逗号或者空格隔开" allow-clear :style="{ width: '180px' }"
          @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="productTitle" label="商品名称：">
        <a-input v-model.trim="form.productTitle" placeholder="请输入" allow-clear :style="{ width: '180px' }"
          @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="specTitle" label="规格名称：">
        <a-input v-model.trim="form.specTitle" placeholder="请输入" allow-clear :style="{ width: '180px' }"
          @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleReset('search')" @clear="handleReset"></oms-search-btn>
    </a-form>
    <!-- </template> -->
    <oms-table :loading="loading" :total="total" :current="form.pageNum" :size="form.pageSize" @reload="reloadTable"
      :simple-pagination="true" class="gift-table">
      <a-table v-model:selected-keys="selectedkeys" :data="dataList" :pagination="false"
        @selection-change="selectionChange" hide-expand-button-on-empty :scroll="{ y: 390 }" stripe row-key="specCode"
        :bordered="{ wrapper: false }" :row-selection="rowSelection">
        <template #columns>
          <a-table-column title="商品编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="商品名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.specCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.specTitle || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
    <!-- </oms-panel> -->
  </a-modal>
</template>
<script lang="ts" setup name="spec-modal">
import OmsTable from '@/components/oms-table/index.vue';
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { reactive, ref, watch } from 'vue'
import commonData from '../../commonData/initData'
import { SpecSearchType } from '@/types/marketing/gift'
import { querySpecProductPage } from '@/api/marketing/gift'
import { Message, TableRowSelection } from '@arco-design/web-vue'
import { deepClone } from '@/utils/helper';
const { formRef, formReset, loading, showModal, total } = commonData()
const dataList = ref<Array<SpecSearchType>>([])
const selectGoodsTableData = ref<Array<SpecSearchType>>([])
const allGoodsTableData = ref<Array<SpecSearchType>>([])
// 表格选中的key值
const selectedkeys = ref()
const rowSelection = reactive<TableRowSelection>({
  type: 'checkbox',
  fixed: true,
  showCheckedAll: true
})
let form = reactive<SpecSearchType>(new SpecSearchType())
let searchForm = reactive<SpecSearchType>(new SpecSearchType())
interface PropsType {
  specCodeList: Array<string>
}
const props = defineProps<PropsType>();
const emits = defineEmits<{
  (e: "on-select", data?: Array<SpecSearchType>): void;
}>();

const handleSearch = async () => {
  try {
    loading.value = true
    let newForm = deepClone(searchForm)
    newForm.products = newForm.products.split(/\s+|\,/g).filter(Boolean).join(',')
    newForm.specs = newForm.specs.split(/\s+|\,/g).filter(Boolean).join(',')
    const { code, message, value } = await querySpecProductPage(newForm)
    if (code != 0) {
      throw new Error(message)
    }
    dataList.value = value.result
    form.pageNum = value.pageNum
    form.pageSize = value.pageSize
    total.value = value.totalCount
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
const reloadTable = (data: any) => {
  searchForm = Object.assign(searchForm, data)
  handleSearch()
}
const handleReset = (type?: any) => {
  form.pageNum = 1
  form.pageSize = 10
  !type && formReset()
  searchForm = Object.assign(searchForm, form)
  handleSearch()
}
const selectionChange = (rowKeys: Array<string | number>) => {
  if (rowKeys.length) {
    allGoodsTableData.value.push(...dataList.value)
  }
}
const onBeforeOk = () => {
  selectGoodsTableData.value = allGoodsTableData.value?.filter(i => selectedkeys.value.includes(i.specCode))
  if (!selectGoodsTableData.value.length) {
    Message.error('请选择数据')
    return false
  }

  emits('on-select', selectGoodsTableData.value)
  return true
}
watch(() => showModal.value, (nV) => {
  if (nV) {
    // handleReset()
  } else {
    formReset()
    form.pageNum = 1
    form.pageSize = 10
    total.value = 0
    dataList.value = []
    selectedkeys.value = []
    selectGoodsTableData.value = []
    allGoodsTableData.value = []
  }
})
defineExpose({
  showModal
})
</script>
<style lang="less">
.spec-modal-class {
  .arco-modal-body {
    height: 624px;
  }
}
</style>
