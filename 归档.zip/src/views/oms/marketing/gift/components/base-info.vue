<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-15 10:07:00
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-25 17:15:32
 * @FilePath: \oms-admin\src\views\oms\marketing\gift\components\gift-modal\components\base-info.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
	<a-form :model="form" :rules="formRules" auto-label-width ref="formRef" class="base-form">
		<a-row :gutter="90">
			<a-col :span="12">
				<a-form-item label="活动名称：" field="activityName">
					<a-input v-model.trim="form.activityName" placeholder="请输入" v-limit-input allow-clear
						:max-length="100"></a-input>
				</a-form-item>
			</a-col>
			<a-col :span="12">
				<a-form-item label="优先级：" field="sort">
					<a-input-number v-model.trim="form.sort" :parser="parser" placeholder="请输入" v-limit-input allow-clear :min="0" :max="9999999" />
				</a-form-item>
			</a-col>
		</a-row>
		<a-row :gutter="90">
			<a-col :span="12">
				<a-form-item label="开始时间：" field="startTime">
					<a-date-picker showTime v-model="form.startTime" style="width: 334px;" />
				</a-form-item>
			</a-col>
			<a-col :span="12">
				<a-form-item label="结束时间：" field="endTime">
					<a-date-picker showTime v-model="form.endTime" style="width: 334px;" />
				</a-form-item>
			</a-col>
		</a-row>
		<a-row :gutter="10">
			<a-col :span="7">
				<a-form-item label="活动时间：" field="activityTimeType">
					<a-select placeholder="请选择" v-model="form.activityTimeType" allow-search>
						<a-option v-for="(item, index) in timeTypeList" :key="`${index}-type`" :value="item.dictionaryValue">{{
							item.dictionaryTitle }}</a-option>
					</a-select>
				</a-form-item>
			</a-col>
			<a-col :span="5">
				<a-form-item :hide-label="true" field="activityTimeDimensionality">
					<a-select placeholder="请选择" v-model="form.activityTimeDimensionality" allow-search
						@change="changeDimen">
						<a-option v-for="(item, index) in timeDimensionList" :key="`${index}-type`" :value="item.dictionaryValue">{{
							item.dictionaryTitle }}</a-option>
					</a-select>
				</a-form-item>
			</a-col>
			<a-col :span="12">
				<a-form-item field="time" :hide-label="true" v-if="fieldName == 'time'">
					<a-range-picker showTime v-model="form.time" @change="onChange" />
				</a-form-item>
				<a-form-item field="time" :hide-label="true" v-if="fieldName == 'timeDay'">
					<a-time-picker type="time-range" v-model="form.time" style="width: 100%;" @change="onChange" />
				</a-form-item>
				<a-form-item field="numbers" :hide-label="true" v-if="fieldName == 'numbers'">
					<oms-multiple-select v-model="form.numbers" :maxTagCount="3" value="dictionaryValue" label="dictionaryTitle"
						:option-list="numbersList"></oms-multiple-select>
				</a-form-item>
			</a-col>
		</a-row>
		<a-row :gutter="90">
			<a-col :span="12">
				<a-form-item label="活动类型：" field="activityType">
					<a-select placeholder="请选择" v-model="form.activityType" allow-search @change="changeType">
						<a-option v-for="(item, index) in activitytypeList" :key="`${index}-type`" :value="item.dictionaryValue">{{
							item.dictionaryTitle }}</a-option>
					</a-select>
				</a-form-item>
			</a-col>
			<a-col :span="12">
				<a-row>
					<a-col :span="14">
						<a-form-item  label="金额范围：" field="minPrice"
							:rules="[{ required: form.activityType == 'sendWhenFull', message: '请输入' }]">
							<a-input v-model="form.minPrice" placeholder="请输入" v-limit-input
								@input="formateValue($event, 'minPrice')" allow-clear></a-input>
						</a-form-item>
					</a-col>
					<a-col :span="10">
						<a-form-item field="maxPrice" label="至"
							:label-col-style="{ 'flex-basis': '17px' }" class="max-price"
							:rules="[{ required: form.activityType == 'sendWhenFull', message: '请输入' }]">
							<a-input v-model="form.maxPrice" placeholder="请输入" allow-clear v-limit-input
								@input="formateValue($event, 'maxPrice')"></a-input>
						</a-form-item>
					</a-col>
				</a-row>
			</a-col>
		</a-row>
		<a-row :gutter="90">
			<a-col :span="12">
				<a-form-item label="活动范围：" field="scope">
					<a-select placeholder="请选择" v-model="form.scope" allow-search>
						<a-option value="ALL">所有商品</a-option>
						<a-option value="ANY_ONE">包含指定任一商品</a-option>
						<a-option value="SPECIFY_ALL">包含指定全部商品</a-option>
					</a-select>
				</a-form-item>
			</a-col>
			<a-col :span="12">
				<a-form-item label="赠送方式：" field="way">
					<a-select placeholder="请选择" v-model="form.way" allow-search>
						<a-option value="ALL_GIVING">全部送</a-option>
						<a-option value="ORDERLY">顺序送</a-option>
					</a-select>
				</a-form-item>
			</a-col>
		</a-row>
		<a-row :gutter="90">
			<a-col :span="24">
				<a-form-item label="备注：" field="remark">
					<a-textarea v-model.trim="form.remark" placeholder="请输入" :max-length="200" show-word-limit
						v-limit-input></a-textarea>
				</a-form-item>
			</a-col>
		</a-row>
		<a-row :gutter="90">
			<a-col :span="24">
				<a-form-item label="设置：" field="multiGifts">
					<a-checkbox v-model="form.multiGifts" style="margin-right:46px ;">倍数赠送</a-checkbox>
					<a-checkbox v-model="form.multipleGift">多重赠送</a-checkbox>
				</a-form-item>
			</a-col>
		</a-row>
	</a-form>
</template>
<script lang="ts" setup name="base-info">
import commonData from '../../commonData/initData'
import { reactive, ref, onMounted, computed, watch } from 'vue'
import { AddMarketingGiftType } from '@/types/marketing/gift'
import omsMultipleSelect from '@/components/oms-multiple-select/index.vue'
import { Message } from '@arco-design/web-vue';
import { initDataType } from '@/types/basicdata/shop'
const { formRef, formReset, getDictionaryTypeList, formaNumber } = commonData()
const activitytypeList = ref()
const timeTypeList = ref()
const timeDimensionList = ref()
const monthTypeList = ref()
const weekTypeList = ref()
interface PropsType {
	form: AddMarketingGiftType
}
const props = defineProps<PropsType>();
const initDictionary = async () => {
	// 时间活动类型
	timeTypeList.value = await getDictionaryTypeList('TIME_TYPE')
	// 时间维度类型
	timeDimensionList.value = await getDictionaryTypeList('TIME_DIMENSIONALITY')
	// 活动类型
	activitytypeList.value = await getDictionaryTypeList('ACTIVITY_TYPE')
	// 可选月份来自数据字典
	monthTypeList.value = await getDictionaryTypeList('MONTH')

	weekTypeList.value = await getDictionaryTypeList('WEEK')

}
const formRules = reactive({
	activityName: [
		{ required: true, message: '请输入' }
	],
	sort: [
		{ required: true, message: '请输入优先级' }
	],
	startTime: [
		{ required: true, message: '请选择时间' }
	],
	endTime: [
		{ required: true, message: '请选择时间' }
	],
	activityTimeType: [
		{ required: true, message: '请选择' }
	],
	activityTimeDimensionality: [
		{ required: true, message: '请选择' }
	],
	time: [
		{ required: true, message: '请选择' }
	],
	activityType: [
		{ required: true, message: '请选择' }
	],
	scope: [
		{ required: true, message: '请选择' }
	],
	way: [
		{ required: true, message: '请选择' }
	],
	numbers: [
		{ required: true, message: '请选择' }
	],
	'presentScheduleTimeAndDayBO.startTime': [
		{ required: true, message: '请选择' }
	],
})
const changeDimen = () => {
	props.form.numbers = []
	props.form.time = []
	props.form.presentScheduleTimeAndDayBO.startTime = ''
	props.form.presentScheduleTimeAndDayBO.endTime = ''
}
const formateValue = ($event: any, type: string) => {
	props.form[type] = formaNumber($event, 2)
}
const validMethod = async () => {
	let valid = await formRef.value.validate()
	if (valid) return valid
	// 满就赠或者两个都填
	if (props.form.activityType == 'sendWhenFull'||props.form.minPrice&&props.form.maxPrice) {
		if (Number(props.form.minPrice) >= Number(props.form.maxPrice)) {
			Message.error('上限数值需大于下限数值')
			valid = true
		}
	}
	if (new Date(props.form.startTime).getTime() >= new Date(props.form.endTime).getTime()) {
		Message.error('开始时间要早于结束时间')
		valid = true
	}
	const newNames = (numbersList.value as Array<initDataType>)
	props.form.numberNames = newNames.filter(i => props.form.numbers.includes(i?.dictionaryValue ?? '')).map(i => i?.dictionaryTitle ?? '')
	return valid
}
const changeType = () => {
	props.form.minPrice=''
	props.form.maxPrice=''
}
// 重置
const resetForm = () => {
	changeDimen()
	formReset()
	props.form.multipleGift = false
	formRef.value.clearValidate()
}
const parser = (value: any) => {
  return value.replace(/\./g, '')
}
const onChange = (value: any) => {
	props.form.presentScheduleTimeAndDayBO.startTime = value?.[0] ?? ''
	props.form.presentScheduleTimeAndDayBO.endTime = value?.[1] ?? ''
}
const numbersList = computed(() => props.form.activityTimeDimensionality == 'week' ? weekTypeList.value : monthTypeList.value)
const fieldName = computed(() => {
	if (props.form.activityTimeDimensionality == 'scheduleTime') {
		return 'time'
	} else if (props.form.activityTimeDimensionality == 'day') {
		return 'timeDay'
	} else if (['week', 'month'].includes(props.form.activityTimeDimensionality)) {
		return 'numbers'
	} else {
		return ''
	}
})
onMounted(() => initDictionary())
defineExpose({
	validMethod,
	resetForm
})
</script>
<style lang="less" scoped>
.base-form {
	padding: 18px;
	margin-top: 0px;
	.arco-form-item{
		// margin-bottom: 22px;
	}
}

:deep(.max-price .arco-form-item-label-required-symbol) {
	display: none;
}
</style>
