<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-15 14:17:49
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-25 16:21:12
 * @FilePath: \oms-admin\src\views\oms\marketing\gift\components\activity-store.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <oms-table :loading="loading" :current="form.pageNum" :size="form.pageSize"     class="gift-table">
    <template #header-left v-if="!readonly">
      <a-space :size="10" style="margin-bottom: 10px">
        <a-button type="primary" @click="addStore">新增店铺</a-button>
      </a-space>
    </template>
    <a-table :pagination="false" :data="dataList" hide-expand-button-on-empty :scroll="{ y: 390 }" stripe
      :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="店铺编码" :tooltip="true" :width="200" ellipsis>
          <template #cell="{ record }">
            {{ record.storeCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="店铺名称" :tooltip="true" :width="400" ellipsis>
          <template #cell="{ record }">
            {{ record.storeName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="操作" :tooltip="true" fixed="right" :width="50" ellipsis v-if="!readonly">
          <template #cell="{ record, rowIndex }">
            <a-link status="danger" @click="handleDel(rowIndex)">删除</a-link>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
  <store-modal ref="storeModalRef" :store-code="specCodeList" @on-select="onSelect"></store-modal>
</template>
<script lang="ts" setup name="activity-goods">
import OmsTable from '@/components/oms-table/index.vue';
import commonData from '../../commonData/initData'
import { GiftActityGoodsSearch } from '@/types/marketing/gift'
import storeModal from './store-modal.vue'
import { ref, reactive, computed, PropType, watch } from 'vue'
import { ActivityStoreitemType } from '@/types/marketing/gift'
import { Message } from '@arco-design/web-vue';
const props = defineProps(
  {
    readonly: {
      type: Boolean,
      default: false
    },
    storeList: {
      type: Array as PropType<ActivityStoreitemType[]>,
      default: () => []
    }
  }
);
const storeModalRef = ref()
const { loading } = commonData()
let form = reactive<GiftActityGoodsSearch>(new GiftActityGoodsSearch())
const dataList = ref<Array<ActivityStoreitemType>>([])
const initData = async () => {
}
const specCodeList = computed(() => dataList.value?.map(i => i.storeCode) ?? [])
const addStore = () => {
  storeModalRef.value.showModal = true
}
const onSelect = (row?: Array<ActivityStoreitemType>) => {
  row?.forEach(i => {
    if (!specCodeList.value.includes(i.storeCode)) dataList.value.push(i)
  })
}
const validMethod = () => {
  if (!dataList.value.length) {
    Message.error('请添加店铺')
    return true
  }
  return false
}
const handleDel = (index: number) => {
  dataList.value.splice(index, 1)
}
watch(() => props.storeList, (nV) => {
  dataList.value = nV
})
defineExpose({
  validMethod,
  dataList
})
</script>
