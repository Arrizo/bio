<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 15:02:33
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-27 10:52:11
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\goods\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal v-model:visible="showModal" :width="900" title-align="start" :on-before-ok="onBeforeOk" :mask-closable="false"
  class="spec-modal-class"
    title="选择店铺">
    <!-- <oms-panel> -->
    <!-- <template #header> -->
    <a-form :model="form" layout="inline" ref="formRef">
      <a-form-item field="storeCode" label="店铺编码：">
        <a-input v-model="form.storeCode" placeholder="请输入" allow-clear :style="{ width: '200px' }"
          @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="storeName" label="店铺名称：">
        <a-input v-model="form.storeName" placeholder="请输入" allow-clear :style="{ width: '200px' }"
          @keyup.enter="handleReset" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleReset('search')" @clear="handleReset"></oms-search-btn>
    </a-form>
    <!-- </template> -->
    <oms-table :loading="loading" :total="total" :current="form.pageNum" :size="form.pageSize" @reload="reloadTable"
    :simple-pagination="true" class="gift-table">
      <a-table v-model:selected-keys="selectedkeys" :data="dataList" :pagination="false"
        @selection-change="selectionChange" hide-expand-button-on-empty :scroll="{ y: 437 }" stripe row-key="storeCode"
        :bordered="{ wrapper: false }" :row-selection="rowSelection">
        <template #columns>
          <a-table-column title="店铺编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.storeCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="店铺名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.storeName || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
    <!-- </oms-panel> -->
  </a-modal>
</template>
<script lang="ts" setup name="spec-modal">
import OmsTable from '@/components/oms-table/index.vue';
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { reactive, ref, watch } from 'vue'
import commonData from '../../commonData/initData'
import { ActivityStoreitemType } from '@/types/marketing/gift'
import { queryStoreList } from '@/api/marketing/gift'
import { Message, TableRowSelection } from '@arco-design/web-vue'
const { formRef, formReset, loading, showModal, total } = commonData()
const dataList = ref<Array<ActivityStoreitemType>>([])
const selectGoodsTableData = ref<Array<ActivityStoreitemType>>([])
// 表格选中的key值
const selectedkeys = ref()
const rowSelection = reactive<TableRowSelection>({
  type: 'checkbox',
  fixed: true,
  showCheckedAll: true
})
let form = reactive<ActivityStoreitemType>(new ActivityStoreitemType())
let searchForm = reactive<ActivityStoreitemType>(new ActivityStoreitemType())
interface PropsType {
  storeCode: Array<string>
}
const props = defineProps<PropsType>();
const emits = defineEmits<{
  (e: "on-select", data?: Array<ActivityStoreitemType>): void;
}>();

const handleSearch = async () => {
  try {
    loading.value = true
    const { code, message, value } = await queryStoreList(searchForm)
    if (code != 0) {
      throw new Error(message)
    }
    dataList.value = value.result
    form.pageNum = value.pageNum
    form.pageSize = value.pageSize
    total.value = value.totalCount
    selectedkeys.value = []
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
const handleReset = (type?: any) => {
  form.pageNum = 1
  form.pageSize = 10
  !type && formReset()
  searchForm = Object.assign(searchForm, form)
  handleSearch()
}
const reloadTable = (data: any) => {
  searchForm = Object.assign(searchForm, data)
  handleSearch()
}
const selectionChange = (rowKeys: Array<string | number>) => {
  selectGoodsTableData.value = dataList.value.filter(i => rowKeys.includes(i.storeCode))
}
// const rowClick = (row: TableData) => {
//   debugger
//   selectedkeys.value = [row.specsCode]
//   selectGoodsTableData.value = dataList.value.find(i => i.specsCode == row.specsCode) ?? {}
// }
const onBeforeOk = () => {
  if (!selectGoodsTableData.value.length) {
    Message.error('请选择数据')
    return false
  }
  emits('on-select', selectGoodsTableData.value)
  return true
}
watch(() => showModal.value, (nV) => {
  if (nV) {
    // handleReset()
  }else{
    formReset()
    form.pageNum = 1
    form.pageSize = 10
    total.value = 0
    dataList.value = []
    selectGoodsTableData.value=[]
  }
})
defineExpose({
  showModal
})
</script>
<style lang="less">
.spec-modal-class{
  .arco-modal-body {
    height: 624px;
  }
}
</style>