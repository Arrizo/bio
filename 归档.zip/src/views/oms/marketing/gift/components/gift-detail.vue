<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-15 11:10:28
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-15 11:10:59
 * @FilePath: \oms-admin\src\views\oms\marketing\gift\components\gift-detail.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <oms-table :loading="loading" :current="form.pageNum" :size="form.pageSize">
    <template #header-left>
      <a-space :size="10">
      <a-button type="primary">选择规格</a-button>
      <a-button type="outline">导入</a-button>
    </a-space>
    </template>
    <a-table :pagination="false" :data="dataList" hide-expand-button-on-empty :scroll="{ x: 1150, y: 400 }" stripe
      :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="商品编码" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="商品名称" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格编码" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格名称" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="每次赠送" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="限制总数" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="操作" fixed="right" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
</template>
<script lang="ts" setup name="activity-goods">
import OmsTable from '@/components/oms-table/index.vue';
import commonData from '../../commonData/initData'
import { GiftActityGoodsSearch } from '@/types/marketing/gift'
import { ref, reactive } from 'vue'
const { loading } = commonData()
let form = reactive<GiftActityGoodsSearch>(new GiftActityGoodsSearch())
const dataList = ref()
const initData = async () => {

}
</script>
