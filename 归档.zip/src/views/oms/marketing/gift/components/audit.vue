<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 16:19:35
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-24 15:50:45
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\audit\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal :width="500" title="审核" v-model:visible="showModal" title-align="start" :on-before-ok="onBeforeOk"
    :mask-closable="false" :ok-loading="loading">
    <a-form :model="form" auto-label-width ref="formRef" :rules="formRules">
      <a-form-item label="审核结果：" field="auditStatus">
        <a-select v-model="form.auditStatus" placeholder="请选择">
          <a-option :value="1">通过</a-option>
          <a-option :value="0">不通过</a-option>
        </a-select>
      </a-form-item>
      <a-form-item label="备注：" field="remark" :rules="[{required:!form.auditStatus,message:'请输入'}]">
        <a-textarea v-model="form.remark" show-word-limit placeholder="请输入备注" :max-length="100"></a-textarea>
      </a-form-item>
    </a-form>
  </a-modal>
</template>
<script lang="ts" setup name="gift-audit">
import commonData from '../../commonData/initData'
import { reactive, watch, ref } from 'vue'
import { deepClone } from "@/utils/helper";
import { PurchaseAuditType } from '@/types/product/purchase'
import { auditGift } from '@/api/marketing/gift'
import { Message } from '@arco-design/web-vue'
import { deductionAudit } from '@/api/marketing/deduction'
const emits = defineEmits<{
  (e: "reload", data?: any): void
}>()
const form = reactive<PurchaseAuditType>(new PurchaseAuditType())
const auditType = ref()
const { loading, showModal, formRef, formReset } = commonData()
const formRules = reactive({
  auditStatus: [
    { required: true, message: '请选择' }
  ],
})
const onBeforeOk = async () => {
  const valid = await formRef.value.validate()
  let newForm = deepClone(form)
  newForm.auditStatus = Boolean(form.auditStatus)
  if (valid) { return false }
  // if (!form.auditStatus && !form.remark) {
  //   Message.error('请输入备注')
  //   return false
  // }
  try {
    loading.value = true
    let res = null
    // 策略审核
    if (auditType.value) {
      res = await deductionAudit(newForm)
    } else {
      res = await auditGift(newForm)
    }
    const { code, message } = res
    if (code != 0) {
      throw new Error(message)
    }
    Message.success('操作成功！')
    emits('reload')
    return true
  } catch (error) {
    Message.error((error as Error).message)
    return false
  } finally {
    loading.value = false
  }
}
watch(() => showModal.value, (nV) => {
  if (!nV) {
    formReset()
    form.remark = ''
  }
})
const open = (id: string, auditNode: string = '赠品审核', type?: string) => {
  form.id = id
  form.auditNode = auditNode
  auditType.value = type ?? ''
  showModal.value = true
}
defineExpose({
  open
})
</script>
<style lang="less" scoped>
.title {
  color: #3A3A3A;
  font-size: 13px;
  margin-bottom: 20px;
}
</style>