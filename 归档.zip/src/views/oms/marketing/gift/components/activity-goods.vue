<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-15 14:17:49
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-28 17:36:18
 * @FilePath: \oms-admin\src\views\oms\marketing\gift\components\activity-goods.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <oms-table :loading="loading" :current="pageNum" :size="pageSize" :total="total" @reload="reloadTable">
    <template #header-left v-if="!readonly">
      <a-space :size="10" style="margin-bottom: 10px">
        <a-button type="primary" @click="changeSpec">选择规格</a-button>
        <a-button type="outline" @click="handleImport">导入</a-button>
      </a-space>
    </template>
    <a-table :pagination="false" :data="dataList" hide-expand-button-on-empty :scroll="{ y: readonly ? 280 : 390 }"
      :draggable="readonly ? undefined : { type: 'handle', width: 24 }" :bordered="{ wrapper: false }"
      class="gift-table">
      <template #columns>
        <a-table-column title="商品编码" :tooltip="true" :width="80" ellipsis>
          <template #cell="{ record }">
            {{ record.productCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="商品名称" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ record.productTitle || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格编码" :tooltip="true" :width="80" ellipsis>
          <template #cell="{ record }">
            {{ record.specCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格名称" :tooltip="true" :width="80" ellipsis>
          <template #cell="{ record }">
            {{ record.specTitle || '--' }}
          </template>
        </a-table-column>
        <!-- 活动赠品字段 -->
        <a-table-column title="购买数量" :tooltip="true" :width="80" ellipsis v-if="tabsType == 'activity'">
          <template #cell="{ record }">
            <span v-if="readonly">{{ record.purchaseNumber }}</span>
            <a-input-number v-model.trim="record.purchaseNumber" hide-button :parser="parser" placeholder="请输入" :min="1"
              :max="99999" v-else />
          </template>
        </a-table-column>
        <!-- 赠品明细字段 -->
        <a-table-column title="每次赠送" :tooltip="true" :width="80" ellipsis v-if="tabsType == 'gift'">
          <template #cell="{ record }">
            <span v-if="readonly">{{ record.number }}</span>
            <a-input-number v-model.trim="record.number" hide-button :parser="parser" placeholder="请输入" :min="1"
              :max="99999" v-else />
          </template>
        </a-table-column>
        <!-- 赠品明细字段 -->
        <a-table-column title="限制总数" :tooltip="true" :width="80" ellipsis v-if="tabsType == 'gift'">
          <template #cell="{ record }">
            <span v-if="readonly">{{ record.limitedNumber }}</span>
            <a-input-number v-model.trim="record.limitedNumber" hide-button :parser="parser" placeholder="请输入" :min="1"
              :max="99999" v-else />
          </template>
        </a-table-column>
        <a-table-column title="操作" :tooltip="true" :width="50" ellipsis v-if="!readonly">
          <template #cell="{ record, rowIndex }">
            <a-link status="danger" @click="handleDel(rowIndex)">删除</a-link>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
  <spec-modal ref="specModalRef" :spec-code-list="specCodeList" @on-select="onGoodsSelect"></spec-modal>
  <oms-import ref="importRef"></oms-import>
  <oms-import ref="importRef" :uploadSize="5" uploadUrlName="导入" :uploadUrl="uploadUrlTemplate"
    :importApi="batchImport"></oms-import>
</template>
<script lang="ts" setup name="activity-goods">
import OmsTable from '@/components/oms-table/index.vue';
import commonData from '../../commonData/initData'
import OmsImport from '@/components/oms-import/index.vue';
import { ActivityGiftitemType, SpecSearchType, ActivityGoodsitemType } from '@/types/marketing/gift'
import { batchInputPresentActivityProduct } from '@/api/marketing/gift'
import specModal from './spec-modal.vue'
import { ref, reactive, computed, PropType, watch } from 'vue'
import { Message } from '@arco-design/web-vue';
const emits = defineEmits<{
  (e: "reload", data?: any): void
}>()
const props = defineProps(
  {
    pageNum: {
      type: Number,
      default: 1
    },
    pageSize: {
      type: Number,
      default: 10
    },
    total: {
      type: Number,
      default: 0
    },
    tabsType: String,
    scope: String,
    readonly: {
      type: Boolean,
      default: false
    },
    goodsList: {
      type: Array as PropType<(ActivityGiftitemType | ActivityGoodsitemType)[]>,
      default: () => []
    }
  }
);
// 自定义导入模板格式
const batchImport = async (data: FormData) => {
  const res = await batchInputPresentActivityProduct(data, props.tabsType)
  if (res.code != 0) return res
  if (res.value.success) {
    onGoodsSelect(res.value.presentActivityProductPageVOS)
    res.value = null
    return res
  } else {
    res.value = res.value.failUrl
    return res
  }
}
const specModalRef = ref()
const importRef = ref()
const { loading } = commonData()
const dataList = ref<Array<ActivityGiftitemType | ActivityGoodsitemType>>([])
// 已选规格列表
const specCodeList = computed(() => dataList.value?.map(i => i.specCode) ?? [])
const changeSpec = () => {
  specModalRef.value.showModal = true
}
const onGoodsSelect = (row?: Array<SpecSearchType>) => {
  let rowData = row as Array<ActivityGiftitemType>
  rowData?.forEach(i => {
    if (!specCodeList.value.includes(i.specCode)) {
      i.skuCode = i.specCode
      dataList.value.push(i)
    }
  })
}
const parser = (value: any) => {
  return value.replace(/\./g, '')
}
const validMethod = () => {
  // 选择任意商品时候，隐藏tabs栏目并可以不添加商品
  if (props.scope == 'ALL' && props.tabsType == 'activity') {
    return true
  }
  if (!dataList.value.length) {
    Message.error('请添加商品！')
    return true
  }
  for (let i = 0; i < dataList.value.length; i++) {
    let item = dataList.value[i]
    if (!item.purchaseNumber && props.tabsType == 'activity') {
      Message.error(`请输入第${i + 1}行购买数量`)
      return true
    }
    if (props.tabsType == 'gift') {
      if (!item.number) {
        Message.error(`请输入第${i + 1}行每次赠送数量`)
        return true
      }
      if (!item.limitedNumber) {
        Message.error(`请输入第${i + 1}行限制总数`)
        return true
      }
      if (Number(item.number) > Number(item.limitedNumber)) {
        Message.error(`第${i + 1}行限制总数要大于等于每次赠送数量`)
        return true
      }
    }
  }
  return false

}
const handleImport = () => {
  importRef.value.visible = true;
}
watch(() => props.goodsList, (nV) => {
  dataList.value = nV
})
const reloadTable = (data: any) => {
  emits('reload', data)
}
const handleDel = (index: number) => {
  dataList.value.splice(index, 1)
}
const uploadUrlTemplate = computed(() => props.tabsType == 'activity'
  ? `${import.meta.env.VITE_API_FILE_URL}/bp-auth-service/template/productManage/%E8%B5%A0%E5%93%81%E6%B4%BB%E5%8A%A8%E6%B4%BB%E5%8A%A8%E5%95%86%E5%93%81%E5%AF%BC%E5%85%A5%E6%A8%A1%E6%9D%BF.xlsx?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20230322%2F%2Fs3%2Faws4_request&X-Amz-Date=20230322T012643Z&X-Amz-Expires=432000&X-Amz-SignedHeaders=host&X-Amz-Signature=4396d3dc855f9c68520be94728c819ad5b049825d0ef0344ef81a92316edebf3`
  : `${import.meta.env.VITE_API_FILE_URL}/bp-auth-service/template/productManage/%E8%B5%A0%E5%93%81%E6%B4%BB%E5%8A%A8%E8%B5%A0%E5%93%81%E5%AF%BC%E5%85%A5%E6%A8%A1%E6%9D%BF.xlsx?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20230322%2F%2Fs3%2Faws4_request&X-Amz-Date=20230322T012623Z&X-Amz-Expires=432000&X-Amz-SignedHeaders=host&X-Amz-Signature=f4c0d08072d2be8f00e28c816eab31c776117d59cb086c17ca2c8964c0939b13`)
defineExpose({
  validMethod,
  dataList
})
</script>
<style lang="less">
.arco-table-hover
  .arco-table-tr-drag
  .arco-table-td:not(.arco-table-col-fixed-left):not(
    .arco-table-col-fixed-right
  ) {
  background-color: #fff;
}</style>
