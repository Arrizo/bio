<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-15 09:36:08
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-27 17:51:47
 * @FilePath: \oms-admin\src\views\oms\marketing\gift\components\gift-modal\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-modal v-model:visible="showModal" :width="824" :title="titleName" title-align="start" :mask-closable="false"
    modal-class="gift-modal">
    <a-tabs v-model:active-key="activeKey">
      <a-tab-pane key="1" title="基本信息">
        <base-info ref="baseInfoRef" :form="form"></base-info>
      </a-tab-pane>
      <a-tab-pane key="2" title="活动商品" v-if="form.scope != 'ALL'">
        <activity-goods tabsType="activity" :scope="form.scope" :goods-list="form.presentActivityProducAddBOS"
          ref="activityGoodsRef"></activity-goods>
      </a-tab-pane>
      <a-tab-pane key="3" title="赠品明细">
        <activity-goods tabsType="gift" :goods-list="form.presentActivityPresentAddBOS"
          ref="giftGoodsRef"></activity-goods>
      </a-tab-pane>
      <a-tab-pane key="4" title="活动店铺">
        <activity-store :store-list="form.stores" ref="activityStoreRef"></activity-store>
      </a-tab-pane>
      <a-tab-pane key="5" title="活动条件">
        <oms-strategy ref="omsStrategyRef" style="margin-left: 7px;" :id="form.id" :edit-type="form.id ? 'edit' : 'add'"
          :type="StrategyType.Zphd"></oms-strategy>
      </a-tab-pane>
    </a-tabs>
    <template #footer>
      <a-button @click="handleEvent('cancle')">取消</a-button>
      <a-button type="outline" :loading="loading" @click="handleEvent('submit', true)">暂存</a-button>
      <a-button type="primary" @click="handleEvent('submit', false)" :loading="loading">提交</a-button>
    </template>
  </a-modal>
</template>
<script lang="ts" setup name="gift-modal">
import { computed, ref, watch } from 'vue'
import OmsStrategy from '@/components/oms-strategy/index.vue'
import commonData from '../../../commonData/initData'
import { StrategyType, StrategyElement } from "@/types/strategy/order";
import ActivityGoods from '../activity-goods.vue'
import BaseInfo from '../base-info.vue'
import ActivityStore from '../activity-store.vue'
import { AddMarketingGiftType } from '@/types/marketing/gift'
import {
  productActivityAdd,
  productActivityEdit,
  queryPresentActivityDetail
} from '@/api/marketing/gift'
import { reactive } from 'vue'
import { Message } from '@arco-design/web-vue'
const emits = defineEmits<{
  (e: "reload", data?: any): void
}>()
let form = reactive<AddMarketingGiftType>(new AddMarketingGiftType())
const { showModal, loading } = commonData()
const baseInfoRef = ref()
const activityGoodsRef = ref()
const giftGoodsRef = ref()
const activityStoreRef = ref()
const omsStrategyRef = ref()
const activeKey = ref('1')
const isCopy = ref()

const initMethod = (id: string, type?: string) => {
  isCopy.value = !!type ?? false
  showModal.value = true
  form.id = id
  id && getAdctivityDetails(id)
}
const handleEvent = async (type: string, isSave?: boolean) => {
  switch (type) {
    case 'submit':
      if (await baseInfoRef.value.validMethod()) {
        return activeKey.value = '1'
      }
      if (activityGoodsRef.value?.validMethod()) {
        return activeKey.value = '2'
      }
      if (giftGoodsRef.value.validMethod()) {
        return activeKey.value = '3'
      }
      if (activityStoreRef.value.validMethod()) {
        return activeKey.value = '4'
      }
      if (checkCondition()) {
        return activeKey.value = '5'
      }
      form.presentActivityPresentAddBOS = giftGoodsRef.value.dataList
      // 活动范围是所有商品，不存活动商品
      if (form.scope == 'ALL') {
        form.presentActivityProducAddBOS = []
      } else {
        form.presentActivityProducAddBOS = activityGoodsRef.value.dataList
        if (isSomeActivityGoods())  return activeKey.value = '3'
      }
      form.stores = activityStoreRef.value.dataList
      form.lstStrategyConfigAdd = omsStrategyRef.value.getValue()
      form.isSave = isSave ?? false
      return addGift()
    case 'cancle':
      form = new AddMarketingGiftType()
      return showModal.value = false

  }
}
// 判断策略条件的校验
const checkCondition = () => {
  try {
    omsStrategyRef.value.getValue()
    return false
  } catch (error) {
    Message.error((error as Error).message)
    return true
  }
}
// 活动类型为赠同品活动商品跟赠品一致
const isSomeActivityGoods = () => {
  if (form.activityType == 'givingSameGift') {
    let giftCode = form.presentActivityPresentAddBOS.map(i => i.skuCode)
    let inequality = form.presentActivityProducAddBOS.some(item => !giftCode.includes(item.skuCode))
    if (inequality) {
      Message.error('若活动类型=赠同品，则赠品明细页面与活动商品选择规格一致')
      return true
    }
  }
}
const addGift = async () => {
  try {
    loading.value = true
    let res = null
    if (form?.id && !isCopy.value) {
      res = await productActivityEdit(form)
    } else {
      res = await productActivityAdd(form)
    }
    const { code, message, value } = res
    if (code != 0) {
      throw new Error(message);
    }
    Message.success('操作成功')
    showModal.value = false
    emits('reload')
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }

}
// 查询活动详情
const getAdctivityDetails = async (id: string) => {
  try {
    loading.value = true
    const { code, message, value } = await queryPresentActivityDetail(id)
    Object.assign(form, value)
    form.presentScheduleTimeAndDayBO = form.presentScheduleTimeAndDayBO || {}
    form.time = [form.presentScheduleTimeAndDayBO.startTime, form.presentScheduleTimeAndDayBO.endTime]
    form.minPrice = String(form.minPrice)
    form.maxPrice = String(form.maxPrice)
    form.numbers = form.numbers?.map(String) ?? []
    form.numberNames = form?.numberNames ?? []
    if (code != 0) {
      throw new Error(message);
    }
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
// 重置表格数据
watch(() => showModal.value, (nV) => {
  if (!nV) {
    form = reactive<AddMarketingGiftType>(new AddMarketingGiftType())
    form.id = 0    // 重置表格数据
    baseInfoRef.value.resetForm()
    form.scope == 'ALL' && (activityGoodsRef.value.dataList = [])
    giftGoodsRef.value.dataList = []
    activeKey.value = '1'
    omsStrategyRef.value.val = [new StrategyElement()]
  }
})
const titleName = computed(() => `${isCopy.value || !form.id ? '新增' : '编辑'}活动`)
const editType = computed(() => form.id ? 'edit' : 'add')
defineExpose({
  initMethod
})
</script>
<style lang="less">
.gift-table{
  .arco-table-tr-empty .arco-table-td{
    height: 370px;
  }
}
.gift-modal {
  .arco-modal-body {
    padding: 14px 32px 0px;
    height: 545px;

    .strategy-list {
      .strategy-item {
        margin-bottom: 20px;
      }

      height: 430px;
      overflow-x: hidden;
      overflow-y: auto;
      max-height: inherit;
      min-height: inherit;
    }
  }

  .arco-modal-footer {
    border-top: 0px;
  }
}
</style>