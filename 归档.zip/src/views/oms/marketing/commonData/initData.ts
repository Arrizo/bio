import { ref } from 'vue'
import { getDictionaryList } from '@/hooks/useDictionary';
import commoMethod from '@/views/oms/product/purchase/commo-method'
export default function () {
  /**
   * 声明公共变量
   */
  const showModal = ref<boolean>(false)
  const total = ref<number>(0)
  const loading = ref<boolean>(false)
  const formRef = ref()
  const { formaNumber } = commoMethod()
  /**
   * 公共方法
   */
  const formReset = (ref?: any) => {
    (ref || formRef).value.resetFields();
  }
  // 查询字典
  const getDictionaryTypeList = async (type: string) => {
    try {
      return await getDictionaryList(type)
    } catch (error) {
      console.error(error)
    }
  }
  return {
    formaNumber,
    showModal,
    total,
    loading,
    formReset,
    formRef,
    getDictionaryTypeList
  }
}