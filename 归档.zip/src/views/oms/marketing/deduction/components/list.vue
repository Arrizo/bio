
<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onReload">
    <template #header-left>
      <a-space :size="10" style="marginBottom:10px;">
        <a-button type="primary" @click="handler('add')" v-permission="['oms:marketing:deduction:add']">新增策略</a-button>
      </a-space>
    </template>
    <a-table :pagination="false" :data="dataList" hide-expand-button-on-empty :scroll="{ x: 1150, y: 500 }" stripe
      :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="策略编码" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.strategyCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="策略名称" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.strategyName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="店铺名称" :tooltip="true" :width="200" ellipsis>
          <template #cell="{ record }">
            {{ record.storeName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="时间类型" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ record.dateTypeName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="开始时间" :tooltip="true" :width="170" ellipsis>
          <template #cell="{ record }">
            {{ record.startTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="结束时间" :tooltip="true" :width="170" ellipsis>
          <template #cell="{ record }">
            {{ record.endTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="抵扣方式" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ record.deductionMethodName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="抵扣规则" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            1元={{ `${record.deductionNum}${record.deductionMethodName}`}}
          </template>
        </a-table-column>
        <a-table-column title="取舍规则" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.rejectionRuleName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="备注" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.remark || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="策略条件" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            <a-link v-permission="['oms:marketing:deduction:details']" type="text" @click="handler('condition', record)" v-if="record.fragmentSql">查看条件</a-link>
            <span v-else>--</span>
          </template>
        </a-table-column>
        <a-table-column title="审核状态 " :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            <oms-tag :type="audittTagType[record.auditStatus]" :content="AuditStatus[record.auditStatus]"></oms-tag>
          </template>
        </a-table-column>
        <a-table-column title="创建时间" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.createTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="修改时间" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.updateTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="170" fixed="right">
          <template #cell="{ record }">
            <a-space :size="10">
              <template v-if="record.auditStatus!='CANCELLATION'">
              <a-link type="text" @click="handler('sub', record)"
               v-if="['STASH','NO_PASS'].includes(record.auditStatus)"
                v-permission="['oms:marketing:deduction:submit']">提交</a-link>
              <a-link type="text" @click="handler('audit', record)"
               v-if="record.auditStatus=='WAIT_AUDIT'"
                v-permission="['oms:marketing:deduction:audi']">审核</a-link>
              <a-link type="text" @click="handler('edit', record)"
               v-if="record.auditStatus!='WAIT_AUDIT'"
                v-permission="['oms:marketing:deduction:edit']">修改</a-link>
              <a-link type="text" @click="handler('cancel', record)"
                v-permission="['oms:marketing:deduction:cancel']">作废</a-link>
              </template>
              <a-link type="text" @click="handler('log', record)"
                v-permission="['oms:marketing:deduction:log']">日志</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
  <!-- 修改状态 -->
  <oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
  <strategy-modal ref="strategyModalRef" @reload="emits('reload')"></strategy-modal>
  <audit ref="auditRef" @reload="emits('reload')"></audit>
  <oms-log ref="omsLogRef"></oms-log>
  <condition-modal ref="conditionModalRef"></condition-modal>
</template>
<script lang="ts" setup name="gift-list">
import OmsTable from '@/components/oms-table/index.vue';
import Audit from '../../gift/components/audit.vue'
import StrategyModal from './strategy-modal.vue'
import OmsWarning from '@/components/oms-warning/index.vue'
import OmsTag from '@/components/oms-tag/index.vue'
import omsLog from '@/components/oms-log/index.vue'
import ConditionModal from './condition-modal.vue'
import {  DeductionListType } from '@/types/marketing/deduction'
import { deductionSubmit, deductionOnOrDrop } from '@/api/marketing/deduction'
import { Message } from '@arco-design/web-vue'
import { ref } from 'vue'
const strategyModalRef = ref()
const switchRef = ref()
const auditRef = ref()
const params = ref()
const omsLogRef = ref()
const paramsType = ref()
const conditionModalRef = ref()
const emits = defineEmits<{
  (e: "reload", data?: any): void
}>()
const audittTagType = {
  'WAIT_AUDIT': 'progress',
  'AUDIT_PASS': 'normal',
  'NO_PASS': 'warring',
  'STASH': 'normal',
  'CANCELLATION': 'efficacy',
}
enum AuditStatus {
  "AUDIT_PASS" = '通过',
  "NO_PASS" = '不通过',
  "WAIT_AUDIT" = '待审核',
  "STASH" = '暂存',
  "CANCELLATION" = '已作废',
}
interface PropsType {
  loading: boolean
  total: number
  pageNum: number
  pageSize: number
  dataList: Array<DeductionListType>
}
const props = defineProps<PropsType>();
const handler = (type: string, record?: DeductionListType) => {
  paramsType.value = type
  switch (type) {
    case 'sub':
      params.value = record?.id
      return switchRef.value.open({ title: "提示", content: `此操作将提交选中数据审核, 是否继续？<div style='color:#999999'>提交后不可修改数据</div>` })
    case 'add': return strategyModalRef.value.initMethod()
    case 'cancel':
      params.value = record?.id
      return switchRef.value.open({ title: "提示", content: `此操作将作废选中数据, 是否继续？<div style='color:#999999'>数据作废后策略将不会被执行</div>` })
    case 'audit':
      return auditRef.value.open(record?.id, '抵扣策略', 'deduction')
    case 'edit': return strategyModalRef.value.initMethod(record?.id)
    case 'log': return omsLogRef.value.init(record?.strategyCode, '抵扣策略')
    case 'condition': return conditionModalRef.value.open(record?.id)
    default:
      break;
  }
}
const onReload = (data?: any) => {
  emits('reload', data)
}
const beforeChange = async () => {
  try {
    let res = null
    if (paramsType.value == 'sub') {
      res = await deductionSubmit(params.value)
    } else {
      res = await deductionOnOrDrop(params.value)
    }
    const { code, message, value } = res
    if (code != 0) {
      throw new Error(message);
    }
    Message.success('操作成功')
    emits('reload')
  } catch (error) {
    Message.error((error as Error).message)
  }
}
</script>