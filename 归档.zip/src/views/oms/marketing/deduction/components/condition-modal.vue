<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-17 16:52:06
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-22 11:30:42
 * @FilePath: \oms-admin\src\views\oms\basicdata\goods-brand\components\brand-modal\index.vue
-->
<template>
  <a-modal :width="740" title="查看条件" v-model:visible="showModal" title-align="start" :mask-closable="false"
    modalClass="condition-details">
    <oms-strategy ref="omsStrategyRef" :id="conditionId" edit-type="detail" :type="StrategyType.Dkcl"
      class="condition-details"></oms-strategy>
    <template #footer> <span></span> </template>
  </a-modal>
</template>
<script setup lang="ts" name="condition-modal">
import commonData from '../../commonData/initData'
import OmsStrategy from '@/components/oms-strategy/index.vue'
import { StrategyType } from "@/types/strategy/order";
import { ref } from 'vue'
const { showModal } = commonData()
const omsStrategyRef = ref()
const conditionId = ref()
const open = (id: any) => {
  showModal.value = true
  conditionId.value = id
}
defineExpose({
  open
})
</script>
<style lang="less">
.condition-details {
  border-top: 0px !important;
  .arco-modal-body{
    padding:12px 32px 0px;
    max-height: 415px;
    .strategy-list {
      height: auto;
      max-height: inherit;
      min-height: inherit;
    }
  }
  .arco-modal-footer{
    border-top:0px;
  }

}
</style>