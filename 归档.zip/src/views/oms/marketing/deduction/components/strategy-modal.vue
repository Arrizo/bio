<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-02-25 14:02:47
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-27 18:01:41
 * @FilePath: \oms-admin\src\views\oms\product\purchase\components\addPurchase\index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->


<template>
  <a-modal v-model:visible="showModal" :width="846" :title="titleName" title-align="start" :mask-closable="false"
    modalClass="strategy-modal">
    <div class="title">基本信息</div>
    <a-form :model="form" :rules="formRules" auto-label-width ref="formRef" style="padding: 14px 15px 15px;">
      <a-row :gutter="90">
        <a-col :span="12">
          <a-form-item label="策略名称：" field="strategyName">
            <a-input v-model.trim="form.strategyName" placeholder="请输入" allow-clear :max-length="100" v-limit-input></a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="店铺名称：" field="storeId">
            <a-select v-model="form.storeId" placeholder="请选择" allow-search>
              <a-option :label="item.storeName" :value="item.id" v-for="(item, index) in storeList"
                :key="`${index}-storeId`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="90">
        <a-col :span="12">
          <a-form-item label="时间类型：" field="dateType">
            <a-select v-model="form.dateType" allow-clear placeholder="请选择" allow-search>
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item, index) in timeType"
                :key="`${index}-dateType`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="开始时间：" field="startTime">
            <a-date-picker showTime v-model="form.startTime" style="width: 334px;" />
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="90">
        <a-col :span="12">
          <a-form-item label="结束时间：" field="endTime">
            <a-date-picker showTime v-model="form.endTime" style="width: 334px;" />
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="抵扣方式：" field="deductionMethod">
            <a-select v-model="form.deductionMethod" placeholder="请选择" allow-search>
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue" v-for="(item, index) in deductionType"
                :key="`${index}-deductionMethod`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="90">
        <a-col :span="12">
          <a-form-item label="抵扣规则：" field="deductionNum">
            <a-input placeholder="请输入" allow-clear v-model.trim="form.deductionNum" @input="formateValue" v-limit-input
              class="deductionNum">
              <template #prepend>
                1元 =
              </template>
              <template #append>
                {{ deductionNumName.find(i => i?.dictionaryValue == form.deductionMethod)?.dictionaryTitle??'积分' }}
              </template>
            </a-input>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="取舍规则：" field="rejectionRule">
            <a-select v-model="form.rejectionRule" placeholder="请选择" allow-search>
              <a-option :label="item.dictionaryTitle" :value="item.dictionaryValue"
                v-for="(item, index) in rejectionRuleType" :key="`${index}-deductionMethod`"></a-option>
            </a-select>
          </a-form-item>
        </a-col>
      </a-row>
      <a-row :gutter="90">
        <a-col :span="12">
          <a-form-item label="优先级：" field="sort">
            <a-input-number v-model.trim="form.sort" :parser="parser" placeholder="请输入" allow-clear :min="0" :max="1000000" v-limit-input/>
          </a-form-item>
        </a-col>
        <a-col :span="12">
          <a-form-item label="备注：" field="remark">
            <a-input v-model.trim="form.remark" allow-clear :max-length="200" placeholder="请输入" v-limit-input></a-input>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
    <div class="title">策略条件</div>
    <oms-strategy ref="omsStrategyRef" :id="form.id" :edit-type="editType" :type="StrategyType.Dkcl"></oms-strategy>
    <template #footer>
      <a-button @click="showModal = false">取消</a-button>
      <a-button type="outline" :loading="loading" @click="handleEvent('2')">暂存</a-button>
      <a-button type="primary" @click="handleEvent('1')" :loading="loading">提交</a-button>
    </template>
  </a-modal>
</template>
<script lang="ts" setup name="add-purchase">
import commonData from '../../commonData/initData'
import { reactive, ref, computed, watch } from 'vue'
import { AddDeductionListType } from '@/types/marketing/deduction'
import { deductionDetail, queryUserStore, addOrUpdate } from '@/api/marketing/deduction'
import OmsStrategy from '@/components/oms-strategy/index.vue'
import { StrategyType, StrategyElement } from "@/types/strategy/order";
import { Message } from '@arco-design/web-vue'
import { initDataType } from '@/types/basicdata/shop'
const { showModal, loading, getDictionaryTypeList, formRef, formaNumber, formReset } = commonData()
const emits = defineEmits<{
  (e: "reload", data?: any): void
}>()
let form = reactive<AddDeductionListType>(new AddDeductionListType())
const storeList = ref()
const timeType = ref()
const deductionType = ref()
const rejectionRuleType = ref()
const omsStrategyRef = ref()
const editType = ref()

const initMethod = (id?: any) => {
  form.id = id
  editType.value = id ? 'edit' : 'add'
  showModal.value = true
  id && getDeductionDetails(id)
  queryDictionaryType()
}
const formRules = reactive({
  strategyName: [
    { required: true, message: '请输入' }
  ],
  sort: [
    { required: true, message: '请输入' }
  ],
  deductionNum: [
    { required: true, message: '请输入' }
  ],
  storeId: [
    { required: true, message: '请选择' }
  ],
  startTime: [
    { required: true, message: '请选择时间' }
  ],
  endTime: [
    { required: true, message: '请选择时间' }
  ],
  dateType: [
    { required: true, message: '请选择' }
  ],
  rejectionRule: [
    { required: true, message: '请选择' }
  ],
  deductionMethod: [
    { required: true, message: '请选择' }
  ],

})
const getStoreList = async () => {
  try {
    const { code, message, value } = await queryUserStore()
    if (code != 0) {
      throw new Error(message);
    }
    storeList.value = value
  } catch (error) {
    Message.error((error as Error).message)
  }
}
const parser = (value: any) => {
  return value.replace(/\./g, '')
}
const queryDictionaryType = async () => {
  getStoreList()
  timeType.value = await getDictionaryTypeList('TIME_TYPE')
  deductionType.value = await getDictionaryTypeList('DEDUCTION_METHOD')
  rejectionRuleType.value = await getDictionaryTypeList('REJECTION_RULE')
}
// 查询活动详情
const getDeductionDetails = async (id: string) => {
  try {
    loading.value = true
    const { code, message, value } = await deductionDetail(id)
    Object.assign(form, value)
    form.deductionNum=String(form.deductionNum)
    if (code != 0) {
      throw new Error(message);
    }
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
const formateValue = ($event: any) => {
  form.deductionNum = formaNumber($event, 2)
}
watch(() => showModal.value, (nV) => {
  if (!nV) {
    formReset()
    form.id = 0
    omsStrategyRef.value.val = [new StrategyElement()]
  }
})
const handleEvent = async (type: string) => {
  const valid = await formRef.value.validate()
  if (valid) { return false }
  try {
    loading.value = true
    form.submitType = type
    // 检验规则列表
    omsStrategyRef.value.getValue()
    form.strategyConfigList = omsStrategyRef.value.getValue()
    const { code, message } = await addOrUpdate(form)
    if (code != 0) {
      throw new Error(message);
    }
    Message.success('操作成功！')
    emits('reload')
    showModal.value = false
  } catch (error) {
    Message.error((error as Error).message)
    return false
  } finally {
    loading.value = false
  }


}
const titleName = computed(() => `${form.id ? '编辑' : '新增'}策略`)
const deductionNumName = computed(() => (deductionType.value??[]) as Array<initDataType>)

defineExpose({
  initMethod
})
</script>
<style lang="less">
.strategy-modal {
  .arco-modal-body {
    padding: 22px 38px;
    height: 529px;
  }

  .arco-modal-footer {
    border-top: 0px;
    padding: 22px 31px 16px;
  }

  .strategy-list {
    height: auto;
    max-height: inherit;
    min-height: inherit;
  }
}

.title {
  font-size: 13px;
  color: #3A3A3A;
  font-weight: bold;
  line-height: 17px;
}

.deductionNum .arco-input-prepend,
.arco-input-append {
  background-color: #FAFAFA;
  border: 1px solid #EDEDED;
}

.deductionNum .arco-input-prepend {
  border-right: 0px;
}

.deductionNum .arco-input-append {
  border-left: 0px;
}
</style>
