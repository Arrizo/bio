<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-14 15:17:23
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-20 16:29:02
 * @FilePath: \oms-admin\src\views\oms\marketing\gift\components\search.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-form :model="form" layout="inline" ref="formRef">
    <a-form-item field="strategyCode" label="策略编码：">
      <a-input v-model="form.strategyCode" placeholder="请输入" allow-clear :max-length="100" :style="{ width: '200px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="strategyName" label="策略名称：">
      <a-input v-model="form.strategyName" placeholder="请输入" allow-clear :max-length="100" :style="{ width: '200px' }"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="auditStatus" label="审核状态：">
      <a-select placeholder="请选择审核状态" v-model="form.auditStatus" :style="{ width: '200px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="STASH">暂存</a-option>
        <a-option value="WAIT_AUDIT">待审核</a-option>
        <a-option value="AUDIT_PASS">通过</a-option>
        <a-option value="NO_PASS">未通过</a-option>
        <a-option value="CANCELLATION">已作废</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="time" label="有效期：" :wrapper-col-style="{ width: '380px' }">
      <a-range-picker showTime v-model="form.time" @change="onChange" />
    </a-form-item>
    <a-form-item field="deductionMethod" label="抵扣方式：">
      <a-select placeholder="请选择活动类型" v-model="form.deductionMethod" :style="{ width: '200px' }" allow-clear>
        <a-option v-for="(item, index) in typeList" :key="`${index}-type`"
          :value="item.dictionaryValue">{{ item.dictionaryTitle }}</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>
<script lang="ts" setup name="gift-search">
import { reactive, ref, onMounted } from 'vue'
import { DeductionSearchType } from '@/types/marketing/deduction'
import commonData from '../../commonData/initData'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { deepClone } from '@/utils/helper';
const props = defineProps<{ loading: boolean }>();
const typeList = ref()
const emits = defineEmits<{
  (e: "on-search", data: DeductionSearchType): void;
}>();
const { formReset, formRef, getDictionaryTypeList } = commonData()

let form = reactive<DeductionSearchType>(new DeductionSearchType())
const handleReset = () => {
  formReset()
  form.startTime = ''
  form.endTime = ''
  handleSearch()
}
const onChange = (value: any) => {
  form.startTime = value?.[0] ?? ''
  form.endTime = value?.[1] ?? ''
}
const handleSearch = () => {
  const newForm = deepClone(form)
  if (newForm.auditStatus == 'all') { newForm.auditStatus = '' }
  emits('on-search', newForm)
}
onMounted(async () => {
  typeList.value = await getDictionaryTypeList('DEDUCTION_METHOD')
  handleSearch()
})
</script>