<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 10:29:14
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 16:29:28
 * @ Description:列表
 -->

<template>
  <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
    <a-table ref="tableRef" stripe :bordered="{ wrapper: false }" :data="(list as any)" :pagination="false"
      :scroll="{ x: 1300 }">
      <template #columns>
        <a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
          <template #cell="{ rowIndex }">
            {{ rowIndex + 1 }}
          </template>
        </a-table-column>
        <a-table-column title="规格编码" ellipsis tooltip data-index="storeName">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="规格名称" ellipsis tooltip data-index="storeCode">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="规格型号" ellipsis tooltip data-index="storeCode">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="出入库数量" ellipsis tooltip data-index="platformProductId">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="出入库时间" :width="180" ellipsis tooltip data-index="platformProductName">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="单据类型" ellipsis tooltip data-index="platformSkuId">
          <template #cell="{ record }">{{ record.platformSkuId || '--' }}</template>
        </a-table-column>
        <a-table-column title="单据号" ellipsis tooltip data-index="platformSkuName">
          <template #cell="{ record }">{{ record.platformSkuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="虚拟仓库名称" ellipsis tooltip data-index="skuCode">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="说明" ellipsis tooltip data-index="skuName">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
</template>

<script setup lang="ts" name="stock-inventory-tracking-list">
import { ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { DistributionReq, DistributionType, ShopSelectItem } from '@/types/product/distribution';


const props = defineProps({
  list: { type: Array<DistributionType>, default: () => [] },
  shopList: { type: Array<ShopSelectItem>, default: () => [] },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  loading: { type: Boolean, default: false },
});
const form = ref<DistributionReq>(new DistributionReq());
let storeId = ref();
const emits = defineEmits<{
  (e: "reload", data?: DistributionReq): void,
  (e: "record", data: DistributionType): void,
  (e: "details", data?: DistributionReq): void,
}>();

const switchRef = ref();
const tableRef = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};


</script>
<style lang="less" scoped>

</style>