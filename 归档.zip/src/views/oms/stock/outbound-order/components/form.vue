<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-30 10:17:42
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-30 18:09:46
 * @ Description: 新增编辑
 -->

<template>
  <a-modal modal-class="outboundModal" :mask-closable="false" fullscreen
    :title="editModal.type === 'add' ? '新增出库单' : '编辑出库单'" v-model:visible="editModal.show" title-align="start"
    @close="onCancel" unmountOnClose>
    <a-form :model="form" ref="formRef" layout="horizontal">
      <!-- 基本信息 -->
      <p class="form-title" style="margin-top: 0;">基本信息</p>
      <a-grid :cols="3" :colGap="300">
        <a-grid-item>
          <a-form-item field="virtualWarehouseId" label="出库仓库：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请选择出库仓库' }]">
            <a-select placeholder="请选择" v-model="form.virtualWarehouseId">
              <a-option v-for="item in warehouseList" :label="(item as any).virtualWarehouseName"
                :value="(item as any).id"></a-option>
            </a-select>
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="outboundType" label="出库类型：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请选择出库类型' }]">
            <a-select placeholder="请选择" v-model="form.outboundType">
              <a-option v-for="item in outboundList" :label="item.dictionaryTitle" :value="item.id"></a-option>
            </a-select>
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="fromReceipt" label="源单类型：" label-col-flex="130px">
            <a-select v-model="form.fromReceipt" disabled>
              <a-option v-for="item in sourceList" :label="item.dictionaryTitle" :value="item.id"></a-option>
            </a-select>
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="fromCode" label="来源单号：" label-col-flex="130px" disabled>
            <a-input v-limit-input="['#', '']" v-model.trim="form.fromCode" :maxLength="50" allow-clear />
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="accountingOrg" label="结算组织：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请选择结算组织' }]">
            <a-select placeholder="请选择" v-model="form.accountingOrg">
              <a-option v-for="item in accountingList" :label="item.dictionaryTitle" :value="item.id"></a-option>
            </a-select>
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="businessDept" label="业务部门：" label-col-flex="130px">
            <a-input v-limit-input="['#', '']" v-model.trim="form.businessDept" :maxLength="50" placeholder="请输入"
              allow-clear />
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="concat" label="联系人：" label-col-flex="130px">
            <a-input v-limit-input="['#', '']" v-model.trim="form.concat" :maxLength="50" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="tel" label="联系电话：" :rules="rulesMobile" label-col-flex="130px" required>
            <a-input v-limit-input="['#', '']" :maxLength="11" v-model.trim="form.tel" placeholder="请输入" allow-clear />
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="expressArr" label="收货区域：" label-col-flex="130px">
            <a-cascader path-mode ref="cascaderRef" @change="changeArea"
              :field-names="{ value: 'id', label: 'regionName', children: 'child' }" :max-tag-count="1"
              v-model="expressArr" check-strictly :allow-clear="true" :options="expressLimitData"
              placeholder="请选择"></a-cascader>
          </a-form-item>
        </a-grid-item>
        <a-grid-item :span="3">
          <a-form-item field="address" label="详细地址：" label-col-flex="130px">
            <a-textarea v-limit-input v-model="form.address" placeholder="请输入" show-word-limit :max-length="200" />
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="autoInbound" label-col-flex="130px">
            <!-- 当入库单审核通过后，自动生成对应的入库单。若勾选自动创建入库单，则入库仓库必选 -->
            <a-checkbox v-model="form.autoInbound">自动创建入库单 <a-tooltip content="当入库单审核通过后，自动生成对应的入库单。若勾选自动创建入库单，则入库仓库必选"><i
                  class="iconfont icon-wenhao tigs"></i></a-tooltip></a-checkbox>
          </a-form-item>
        </a-grid-item>
        <a-grid-item>
          <a-form-item field="inboundVirWarehouseId" label="入库仓库：" label-col-flex="130px" required
            :rules="[{ required: true, message: '请选择入库仓库' }]">
            <a-select placeholder="请选择" v-model="form.inboundVirWarehouseId">
              <a-option v-for="item in warehouseList" :label="(item as any).virtualWarehouseName"
                :value="(item as any).id"></a-option>
            </a-select>
          </a-form-item>
        </a-grid-item>
        <a-grid-item :span="3">
          <a-form-item field="remark" label="备注：" label-col-flex="130px">
            <a-textarea v-limit-input v-model="form.remark" placeholder="请输入" show-word-limit :max-length="200" />
          </a-form-item>
        </a-grid-item>
        <a-grid-item :span="3">
          <a-form-item field="attachment" label="上传附件：" label-col-flex="130px">
            <div class="uploader-container">
              <file-uploader ref="uploaderFile" v-model="form.attachment" module="COMMON_FILE" :size="1024 * 1024 * 1"
                :fileType="2" accept=".pdf,.xls,.word,.png/jpg/bmp" width="280px"></file-uploader>
              <div class="sign">支持pdf/xls/word/png/jpg/bmp等格式</div>
            </div>
          </a-form-item>
        </a-grid-item>
      </a-grid>
      <!-- 商品信息 -->
      <p class="form-title" style="margin-top: 20px;">商品信息</p>
      <from-list></from-list>
    </a-form>
    <template #footer>
      <a-space :size="14">
        <a-button @click="onCancel">取消</a-button>
        <a-button type="outline" @click="onOk(2)">暂存</a-button>
        <a-button type="primary" @click="onOk(1)">确定</a-button>
      </a-space>
    </template>
  </a-modal>
</template>

<script setup lang="ts" name="system-outbound-order-form">
import { AddPidType, DictionaryType } from '@/types/system/dictionary';
import { computed, reactive, ref } from 'vue';
import { getNameList } from '@/api/system/dictionary';
import { Message } from '@arco-design/web-vue';
import FromList from './form-list.vue'
import fileUploader from '@/components/file-uploader/index.vue';
import { getDictionaryList, getValidDictionaryList } from '@/hooks/useDictionary';
import { OutboundOrderFrom } from '@/types/stock/outbound-order';
import { addList, updateList } from '@/api/stock/outbound-order';
import { getChildAddress } from '@/api/basicdata/express';
import { getActiveVirtualList } from '@/api/purchase/order';
// 字典编辑表单弹窗
interface EditModal {
  show: boolean;
  type: "add" | "edit";
  data?: any
}
const editModal = reactive<EditModal>({
  show: false,
  type: "add",
  data: null
});

const emits = defineEmits<{
  (e: "reload"): void
}>();

const form = ref<OutboundOrderFrom>(new OutboundOrderFrom());
const sourceList = ref<DictionaryType[]>();//来源类型
const accountingList = ref<DictionaryType[]>();//结算组织
const outboundList = ref<DictionaryType[]>();//出库类型
const formRef = ref();
const expressLimitData = ref();
const expressArr = ref()
const loading = ref<boolean>(false);
const warehouseList = ref([]);

const initWarehouseList = async () => {
  try {
    const res = await getActiveVirtualList();
    if (res.code != 0) {
      throw new Error(res.message);
    }
    warehouseList.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
}
/** 点击确定按钮时触发 */
const onOk = async (type: number) => {

  const check = await formRef.value.validate();
  if (check) {
    return false;
  }
  loading.value = true;
  try {
    const apiType = editModal.type === 'add' ? addList : updateList;

    const res = await apiType(form.value);
    if (res.code != 0) {
      Message.error(res.message);
      return false;
    }
    Message.success(res.message);
    loading.value = false;
    emits("reload");
    return true;
  } catch (err) {
    Message.error((err as Error).message);
    loading.value = false;
    return false;
  }

}

/** 点击取消、关闭按钮时触发 */
const onCancel = () => { formRef.value!.resetFields(); }

/**
 * 打开编辑弹窗
 * @param type 表单类型
 */
const handleShowModal = async (type: "add" | "edit", data: OutboundOrderFrom) => {
  editModal.type = type;
  editModal.show = true;
  //收货区域
  getProvinceList();
  //出库仓库
  initWarehouseList();
  if (type === 'add') {
    form.value = new OutboundOrderFrom();
    //获取源单类型
    sourceList.value = await getDictionaryList('ORDER_RECEIPT_TYPE');
    //获取结算组织
    accountingList.value = await getDictionaryList('AFFI_COMPANY');
    //获取出库类型
    outboundList.value = await getDictionaryList('STOCK_OUT_TYPE');
  }
  if (type === "edit") {
    //获取源单类型
    sourceList.value = await getValidDictionaryList('ORDER_RECEIPT_TYPE');
    //获取结算组织
    accountingList.value = await getValidDictionaryList('AFFI_COMPANY');
    //获取出库类型
    outboundList.value = await getValidDictionaryList('STOCK_OUT_TYPE');
    form.value = JSON.parse(JSON.stringify(data));
  }
}


//获取所有省份
const getProvinceList = async () => {
  try {
    const res = await getChildAddress();

    if (res.code != 0) {
      throw new Error(res.message);
    }
    expressLimitData.value = res.value;
  } catch (err) {
    Message.error((err as Error).message);
  }
};

//校验手机号码
const rulesMobile = computed(() => [
  {
    validator: (value: any, callback: any) => {
      if (!value || value == "") {
        callback("请输入手机号码");
        return
      }
      if (value) {
        return new Promise<void>((resolve) => {
          const mobileReg = /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;
          if (value.length !== 11 || !mobileReg.test(value)) callback("请输入正确的手机号码");
          resolve();
        });
      }
    },
    required: true
  },
]);


const changeArea = (val: any) => {
  form.value.provinceId = expressArr.value?.[0] ?? null;
  form.value.cityId = expressArr.value?.[1] ?? null;
  form.value.areaId = expressArr.value?.[2] ?? null;
};
defineExpose({
  handleShowModal
});
</script>
<style lang="less" >
.tigs {
  font-size: 15px;
  color: #888888;
}

.form-title {
  color: #3A3A3A;
  font-size: 13px;
  font-weight: bold;
  line-height: 17px;
}

.arco-modal-fullscreen .arco-modal-footer {
  border-top: 1px solid #ececec !important;
  padding: 13px 13px !important;
}

.uploader-container {
  margin-top: 4px;

  .sign {
    font-size: 12px;
    font-weight: 400;
    line-height: 16px;
    color: #999999;
    opacity: 1;
  }
}
</style>