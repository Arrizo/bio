<!-- 系统管理->数据字典->搜索组件 -->
<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-row style="width:100%">
      <a-col :span="6">
        <a-form-item class="group-form-item">
          <a-input-group>
            <a-select :options="['Option1', 'Option2', 'Option3']" :style="{ width: '90px' }" placeholder="first" />
            <a-input :style="{ width: '208px' }" placeholder="请输入" />
          </a-input-group>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="status" label="状态：">
          <a-select placeholder="请选择" v-model="form.stockReceiptStatus" allow-clear>
            <a-option value="all">全部</a-option>
            <a-option value="DRAFT">已启用</a-option>
            <a-option value="WAIT_AUDIT">已禁用</a-option>
            <a-option value="AUDIT_PASS">已启用</a-option>
            <a-option value="NO_PASS">已禁用</a-option>
            <a-option value="NOTIFIED">已启用</a-option>
            <a-option value="NOTIFICATION_FAILED">已禁用</a-option>
            <a-option value="CANCEL">已启用</a-option>
            <a-option value="COMPLETED">已禁用</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="status" label="出库状态：">
          <a-select placeholder="请选择" v-model="form.stockOptStatus" :style="{ width: '200px' }" allow-clear>
            <a-option value="all">全部</a-option>
            <a-option value="NO">已启用</a-option>
            <a-option value="PART">已禁用</a-option>
          </a-select>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="virWarehouseIds" label="出库仓库：">
        <!-- <oms-multiple-select :maxTagCount="1" v-model="form.virWarehouseIds" :option-list="(shopList as any)"
              value="storeCode" label="storeName"></oms-multiple-select> -->
        </a-form-item>
      </a-col>
    </a-row>
    <a-row style="width:100%">
      <a-col :span="6">
        <a-form-item class="group-form-item">
          <a-input-group>
            <a-select :options="['Option1', 'Option2', 'Option3']" :style="{ width: '90px' }" placeholder="first" />
            <a-input :style="{ width: '208px' }" placeholder="请输入" />
          </a-input-group>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="code" label="编码：">
          <a-input style="width: 208px;" v-limit-input v-model.trim="form.code" @keyup.enter="handleSearch"
            placeholder="请输入" />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="time" label="入库时间：" class="time">
          <a-range-picker showTime v-model="pickerTime" @change="onChange" />
        </a-form-item>
      </a-col>
      <a-col :span="1"></a-col>
      <a-col :span="2">
        <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset">
        </oms-search-btn>
      </a-col>
    </a-row>
  </a-form>
</template>

<script setup lang="ts" name="system-outbound-order-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { DictionaryType } from '@/types/system/dictionary';
import { onMounted, ref } from 'vue';
import { queryType } from '@/api/system/dictionary';
import { Message } from '@arco-design/web-vue';
import { getDictionaryList } from '@/hooks/useDictionary';
import { OutboundOrderReq } from '@/types/stock/outbound-order';
const props = defineProps({
  loading: { type: Boolean, default: false }
});
const formRes = ref();
const emits = defineEmits<{
  (e: "on-search", data: OutboundOrderReq): void;
}>();

const form = ref<OutboundOrderReq>(new OutboundOrderReq());
const typeList = ref<DictionaryType[]>();
const handleSearch = () => emits("on-search", form.value);
const pickerTime = ref()
// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

const onChange = (value: any) => {
  form.value.beginDate = value?.[0] ?? ''
  form.value.endDate = value?.[1] ?? ''
}

onMounted(async () => {
  handleSearch();
  //获取字典分类
  typeList.value = await getDictionaryList('DICTIONARY_CATEGORY')
});
</script>
<style lang="less" scoped>
.time {
  :deep(.arco-form-item-wrapper-col) {
    width: 400px;
  }
}

.group-form-item {
  :deep(.arco-form-item-label-col) {
    width: 0px;

  }

  :deep(.arco-form-item-wrapper-col .arco-form-item-content-wrapper .arco-form-item-content) {
    width: auto;
  }
}
</style>