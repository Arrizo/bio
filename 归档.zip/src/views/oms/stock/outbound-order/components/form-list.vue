<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 17:47:39
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-30 18:09:58
 * @ Description: 添加商品
 -->

<template>
  <div>
    <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
      <template #header-left>
        <a-button style="margin-bottom: 10px;" v-permission="['oms:system:dictionary:add']" type="primary" status="normal"
          @click="handleClick('add')"> 添加商品 </a-button>
      </template>

      <a-table stripe :scroll="{ x: 1400,y: 280 }" :data="(list as any)" :pagination="false" :bordered="{ wrapper: false }">
        <template #columns>
          <a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
            <template #cell="{ rowIndex }">
              {{ rowIndex + 1 }}
            </template>
          </a-table-column>
          <a-table-column title="商品编码" ellipsis tooltip data-index="dictionaryType">
            <template #cell="{ record }">{{ record.dictionaryType || '--' }}</template>
          </a-table-column>
          <a-table-column title="规格编码" ellipsis tooltip data-index="dictionaryName">
            <template #cell="{ record }">{{ record.dictionaryName || '--' }}</template>
          </a-table-column>
          <a-table-column title="规格名称" ellipsis tooltip data-index="dictionaryCategory">
            <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
          </a-table-column>
          <a-table-column title="规格型号" ellipsis tooltip data-index="dictionaryCategory">
            <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
          </a-table-column>
          <a-table-column title="批次号" ellipsis tooltip data-index="dictionaryCategory">
            <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
          </a-table-column>
          <a-table-column title="生效日期" ellipsis tooltip data-index="dictionaryCategory">
            <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
          </a-table-column>
          <a-table-column title="过期日期" ellipsis tooltip data-index="dictionaryCategory">
            <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
          </a-table-column>
          <a-table-column title="采购入库时间" ellipsis tooltip data-index="remark">
            <template #cell="{ record }">{{ record.remark || '--' }}</template>
          </a-table-column>
          <a-table-column title="计划出库数量" :width="180" data-index="updateTime">
            <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
          </a-table-column>
          <a-table-column title="价格" :width="180" data-index="updateTime">
            <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
          </a-table-column>
          <a-table-column title="操作" :width="120" fixed="right">
            <template #cell="{ record, rowIndex }">
              <a-space :size="14">
                <a-link @click="handleClick('del',rowIndex)" type="text" status="danger">删除</a-link>
              </a-space>
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </div>
</template>
 
<script setup lang="ts" name="system-outbound-order-form-list">
import { computed, reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import { Message } from '@arco-design/web-vue';
import { DictionaryItem, DictionarySearchForm } from '@/types/system/dictionary';
const form = ref<DictionarySearchForm>(new DictionarySearchForm());

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload", data?: DictionarySearchForm): void,
  (e: "details", data: DictionaryItem): void,
}>();
const switchRef = ref();
const DictionaryFromRef = ref();
const currentId = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};

// 「新增菜单」按钮点击触发
const handleClick = (type:string,index?: string) => {

};

</script>