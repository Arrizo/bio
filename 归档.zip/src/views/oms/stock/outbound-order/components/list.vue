<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 17:47:39
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-30 17:17:55
 * @ Description: 列表
 -->

<template>
 <div>
  <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
    <template #header-left>
      <a-button style="margin-bottom: 10px;" v-permission="['oms:system:dictionary:add']" type="primary" status="normal"
        @click="handleAddClick('add', '')"> 新增出库单 </a-button>
    </template>

    <a-table v-db-click="list" :db-call-back="handleDetailsClick" stripe :scroll="{ x: 1400 }" :data="(list as any)"
      :pagination="false" :bordered="{ wrapper: false }">
      <template #columns>
        <a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
          <template #cell="{ rowIndex }">
            {{ rowIndex + 1 }}
          </template>
        </a-table-column>
        <a-table-column title="出库单号" ellipsis tooltip data-index="dictionaryType">
          <template #cell="{ record }">{{ record.dictionaryType || '--' }}</template>
        </a-table-column>
        <a-table-column title="出库类型" ellipsis tooltip data-index="dictionaryName">
          <template #cell="{ record }">{{ record.dictionaryName || '--' }}</template>
        </a-table-column>
        <a-table-column title="状态" ellipsis tooltip data-index="dictionaryCategory">
          <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
        </a-table-column>
        <a-table-column title="出库状态" ellipsis tooltip data-index="dictionaryCategory">
          <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
        </a-table-column>
        <a-table-column title="单据来源" ellipsis tooltip data-index="dictionaryCategory">
          <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
        </a-table-column>
        <a-table-column title="来源单号" ellipsis tooltip data-index="dictionaryCategory">
          <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
        </a-table-column>
        <a-table-column title="出库仓库" ellipsis tooltip data-index="dictionaryCategory">
          <template #cell="{ record }">{{ record.dictionaryCategory || '--' }}</template>
        </a-table-column>
        <a-table-column title="备注" ellipsis tooltip data-index="remark">
          <template #cell="{ record }">{{ record.remark || '--' }}</template>
        </a-table-column>
        <a-table-column title="修改时间" :width="180" data-index="updateTime">
          <template #cell="{ record }">{{ record.updateTime || '--' }}</template>
        </a-table-column>
        <a-table-column title="操作" :width="120" fixed="right">
          <template #cell="{ record, rowIndex }">
            <a-space :size="14">
              <a-link v-permission="['oms:system:dictionary:edit']" @click="handleAddClick('edit', rowIndex)"
                type="text">编辑</a-link>
            <!-- <a-link v-permission="['oms:system:dictionary:edit']" @click="handleAddClick('edit', rowIndex)"
              type="text">审核</a-link>
              <a-link v-permission="['oms:system:dictionary:edit']" @click="handleAddClick('edit', rowIndex)"
              type="text">推送vms</a-link>
              <a-link v-permission="['oms:system:dictionary:edit']" @click="handleAddClick('edit', rowIndex)"
                type="text">重推vms</a-link> -->
              <a-link v-permission="['oms:system:dictionary:edit']" @click="handleAddClick('edit', rowIndex)" type="text"
                status="danger">取消</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>

  <!-- 菜单新增/编辑弹窗 -->
  <dictionary-form-vue ref="DictionaryFromRef" @reload="emits('reload')"></dictionary-form-vue>

  <!-- 修改状态二次弹框 -->
  <!-- <oms-warning ref="switchRef" ></oms-warning> -->
 </div>
</template>

<script setup lang="ts" name="system-outbound-order-list">
import { computed, reactive, ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import OmsWarning from '@/components/oms-warning/index.vue';
import DictionaryFormVue from "./form.vue"
import { Message } from '@arco-design/web-vue';
import { DictionarySearchForm } from '@/types/system/dictionary';
import { OutboundOrderType } from '@/types/stock/outbound-order';
const form = ref<DictionarySearchForm>(new DictionarySearchForm());

const props = defineProps({
  list: { type: Array, default: () => [] },
  loading: { type: Boolean, default: false },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
});

const emits = defineEmits<{
  (e: "reload", data?: DictionarySearchForm): void,
  (e: "details", data: OutboundOrderType): void,
}>();
const switchRef = ref();
const DictionaryFromRef = ref();
const currentId = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};

// 「新增菜单」按钮点击触发
const handleAddClick = (type: string, index: string) => {
  DictionaryFromRef.value.handleShowModal(type, type === 'edit' ? props.list[index] : '');
};

//详情
const handleDetailsClick = (data: OutboundOrderType) => {
  emits('details', data)
}

// 返回列表
const list = computed(() => {
  return props.list as Array<OutboundOrderType>
})
</script>
