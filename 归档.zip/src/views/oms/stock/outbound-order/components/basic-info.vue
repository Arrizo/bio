//基础信息
<template>
  <a-form class="supplier-basic-info" :model="form" layout="horizontal" style="width:100%">
    <a-grid :cols="4" :colGap="180">
      <a-grid-item>
        <a-form-item field="legalRepresentative" label="结算组织：" label-col-flex="130px">
          <a-input v-model="form.legalRepresentative" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="registeredCapital" label="业务部门：" label-col-flex="130px">
          <a-input v-model="form.legalRepresentative" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="incorporationTime" label="自动创建入库单：" label-col-flex="130px">
          <a-input v-model="form.incorporationTime" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="socialCreditCode" label="入库仓库：" label-col-flex="130px">
          <a-input v-model="form.socialCreditCode" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="regionName" label="入库单号：" label-col-flex="130px">
          <a-input v-model="form.regionName" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="regionName" label="制单人：" label-col-flex="130px">
          <a-input v-model="form.regionName" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item :span="2">
        <a-form-item field="regionName" label="附件：" label-col-flex="130px">
          <a-input v-model="form.regionName" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="regionName" label="联系人：" label-col-flex="130px">
          <a-input v-model="form.regionName" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="regionName" label="联系电话：" label-col-flex="130px">
          <a-input v-model="form.regionName" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="regionName" label="收货区域：" label-col-flex="130px">
          <a-input v-model="form.regionName" disabled />
        </a-form-item>
      </a-grid-item>
      <a-grid-item>
        <a-form-item field="detailAddr" label="详细地址：" label-col-flex="130px">
          <a-tooltip mini :content="form.detailAddr" v-if="form.detailAddr.length > 24">
            <div class="inputDisabled">{{ substringName(form.detailAddr, 23) }}</div>
          </a-tooltip>
          <a-input v-else v-model="form.detailAddr" disabled />
        </a-form-item>
      </a-grid-item>
    </a-grid>
  </a-form>
</template>
<script setup lang="ts" name="system-outbound-order-basic-info">
import { SupplierFrom } from '@/types/basicdata/supplier';

const props = defineProps({
  form: {
    type: Object, default: new SupplierFrom()
  },
});


//超出几个字省略号
const substringName = (value: string, num: number) => {
  if (!value) return;
  if (value.length > num) {
    return value.slice(0, num) + "...";
  }
  return value;
}
</script>
<style lang="less">
.supplier-basic-info {
  .arco-input-disabled {
    background-color: #F6F6F6;
  }

  .arco-input-append {
    background-color: #F6F6F6 !important;
  }

  .inputDisabled {
    padding: 7px 10px;
    background-color: #F6F6F6;
    width: 100%;
    border-radius: 2px;
  }
}
</style>