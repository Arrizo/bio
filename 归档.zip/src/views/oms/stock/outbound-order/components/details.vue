<template>
  <div class="outbound-details">
    <div class="outbound-details-title">
      <a-tabs :style="{ width: '100%' }" :active-key="tabValue" @change="changeTab">
        <template #extra>
          <span class="iconfont icon-guanbianniu delStyle" @click="closeDetails"></span>
        </template>
        <!-- 基本信息 -->
        <a-tab-pane key="basic-info" title="基本信息">
          <basic-info v-if="tabValue === 'basic-info'" :form="form"></basic-info>
        </a-tab-pane>
        <!-- 商品明细 -->
        <a-tab-pane key="product-details" title="商品明细">
          <product-details v-if="tabValue === 'product-details'" :form="form"></product-details>
        </a-tab-pane>
        <!-- 出库明细 -->
        <a-tab-pane key="delivery-details" title="出库明细">
          <delivery-details v-if="tabValue === 'delivery-details'" :form="form"></delivery-details>
        </a-tab-pane>
        <!-- 操作日志 -->
        <a-tab-pane key="operation-log" title="操作日志">
          <oms-log ref="logRef"></oms-log>
        </a-tab-pane>
      </a-tabs>
    </div>
  </div>
</template>

<script setup lang="ts" name="system-outbound-order-details">
import { onMounted, ref, watch } from 'vue';
import { queryList } from '@/api/system/dictionary';
import OmsLog from '@/components/oms-log/index.vue';
import BasicInfo from './basic-info.vue';
import ProductDetails from './product-details.vue';
import DeliveryDetails from './delivery-details.vue'
import { DictionaryListItem, DictionaryPropsForm, DictionarySearchListForm } from '@/types/system/dictionary';
import { Message } from '@arco-design/web-vue';
import { deepClone } from '@/utils/helper';
let show = ref(false);
let loading = ref(false);
let totalCount = ref();
let list = ref<DictionaryListItem[]>()
let dictionaryTypeId = ref();//字典ID，用来查询上级字典

const props = defineProps({
  dictionaryData: {
    type: Object, default: new DictionaryPropsForm()
  },
});
const emits = defineEmits<{
  (e: "close"): void,
}>();
const logRef = ref();
const tabValue = ref('basic-info');

const changeTab = (val: any) => {
  tabValue.value = val;
  if (tabValue.value === 'operation-log') {
    // logRef.value.init(props.supplierCode, '供应商', "page");
  }
}

onMounted(() => {
  dictionaryTypeId.value = props.dictionaryData.id + '';
  form.value.dictionaryType = props.dictionaryData.dictionaryType;
});


//关闭详情
const closeDetails = () => {
  emits('close')
}
const form = ref<DictionarySearchListForm>(new DictionarySearchListForm());

const getInfo = async (data: DictionarySearchListForm = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);

    const res = await queryList(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}


watch(
  () => props.dictionaryData.id,
  () => {
    if (props.dictionaryData.id) {
      dictionaryTypeId.value = props.dictionaryData.id + '';
      form.value.dictionaryType = props.dictionaryData.dictionaryType;
      getInfo(form.value);
    }
  }, {
  immediate: true,
  deep: true
}
);

</script>
<style lang="less" scoped>
.outbound-details {
  background-color: #fff;
  padding-bottom: 16px;

  .delStyle {
    font-size: 18px;
    color: #707070;
    cursor: pointer;
  }

  :deep(.arco-tabs-content) {
    padding-left: 16px;
    padding-right: 16px;
  }

  :deep(.arco-tabs-nav) {
    padding: 0 16px;
  }
}
</style>