<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-30 17:26:42
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-30 18:22:49
 * @ Description: 出库明细
 -->
<template>
  <div>
    <a-form :model="form" layout="inline" ref="searchRef">
      <a-form-item field="code" label="商品编码：">
        <a-input v-model="form.code" placeholder="请输入" allow-clear :style="{ width: '200px' }" @keyup.enter="handleSearch"
          v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="title" label="商品名称：">
        <a-input v-model.trim="form.title" placeholder="请输入" allow-clear :max-length="200" :style="{ width: '200px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <a-form-item field="title" label="批次号：">
        <a-input v-model.trim="form.title" placeholder="请输入" allow-clear :max-length="200" :style="{ width: '200px' }"
          @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-form-item>
      <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
    </a-form>
    <oms-table :loading="loading" :simplePagination="true" :total="totalCount" :current="form.pageNum"
      :size="form.pageSize" @reload="onReload">
      <a-table :bordered="{ wrapper: false }" stripe ref="tableRef" :data="(list as any)" :pagination="false"
        :scroll="{ y: 330 }">
        <template #columns>
          <a-table-column title="商品编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productCode || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格编码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格名称" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="规格型号" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="批次号" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="生产日期" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="过期日期" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="采购入库时间" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="库存类型" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="退库数量" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="单位" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="唯一码" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
          <a-table-column title="出库时间" :tooltip="true" ellipsis>
            <template #cell="{ record }">
              {{ record.productTitle || '--' }}
            </template>
          </a-table-column>
        </template>
      </a-table>
    </oms-table>
  </div>
</template>
<script lang="ts" setup name="system-outbound-order-delivery-details">
import { getList } from '@/api/product/goods';
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { Message } from "@arco-design/web-vue"
import OmsTable from '@/components/oms-table/index.vue';
import { reactive, ref } from 'vue';
import { GoodsSearchForm } from '@/types/product/goods';
interface FormModal {
  show: boolean;
}
const formModal = reactive<FormModal>({
  show: false,
});

const emits = defineEmits<{
  (e: "reload-list"): void;
}>();
const loading = ref<boolean>(false);
const searchRef = ref();
const totalCount = ref(0);
const tableRef = ref();
const list = ref();

let form = ref<GoodsSearchForm>(new GoodsSearchForm())
const handleSearch = async () => {
  try {
    loading.value = true
    let params = JSON.parse(JSON.stringify(form.value));
    params.auditStatus = params.auditStatus === 'all' ? '' : params.auditStatus;
    params.dispatch = params.dispatch === 'all' ? '' : params.dispatch;
    params.k3PushStatus = params.k3PushStatus === 'all' ? '' : params.k3PushStatus;
    params.wmsSyncStatus = params.wmsSyncStatus === 'all' ? '' : params.wmsSyncStatus;
    const { code, message, value } = await getList(params)
    if (code != 0) {
      throw new Error(message)
    }
    totalCount.value = value.totalCount;
    list.value = value.result;
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value = { ...form.value, ...data }
  handleSearch();
};



const handleReset = () => {
  searchRef.value.resetFields();
  tableRef.value.selectAll(false);
  handleSearch()
}


</script>