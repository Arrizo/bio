<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 10:02:07
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-30 16:40:54
 * @ Description:出库单
 -->

<template>
  <div>
    <a-row :gutter="10">
      <a-col :span="24">
        <oms-panel>
          <template #header>
            <search :loading="loading" @on-search="init"></search>
          </template>
          <div>
            <list @reload="init" @details="handleDetailsClick" :page-num="form.pageNum" :page-size="form.pageSize"
              :totalCount="totalCount" :loading="loading" :list="list"></list>
          </div>
        </oms-panel>
        <!-- 详情 -->
        <details v-if="detailsVisible" @close="closeDetails"></details>
      </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts" name="system-outbound-order">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import Details from './components/details.vue';
import { queryPage } from '@/api/stock/outbound-order';
import { DictionaryItem } from '@/types/system/dictionary';
import { Message } from '@arco-design/web-vue';
import { ref } from 'vue';
import { deepClone } from '@/utils/helper';
import { OutboundOrderReq } from '@/types/stock/outbound-order';
const form = ref<OutboundOrderReq>(new OutboundOrderReq());
const loading = ref<boolean>(false);
const list = ref<DictionaryItem[]>();
const totalCount = ref()
const detailsVisible = ref<boolean>(false);
const dictionaryData = ref<DictionaryItem>(new DictionaryItem())
/**
 * 初始化查询菜单数据
 * @param form
 */

const init = async (data: OutboundOrderReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    // params.status = params.status === 'all' ? '' : params.status;
    // params.dictionaryCategory = params.dictionaryCategory === 'all' ? '' : params.dictionaryCategory;

    const res = await queryPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
    //关闭详情
    closeDetails();
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

//详情
const handleDetailsClick = (data: DictionaryItem) => {
  detailsVisible.value = true;
  dictionaryData.value = data;
}

//关闭详情
const closeDetails = () => {
  detailsVisible.value = false;
}
</script>