<template>
  <oms-panel class="panel-height">
    <template #header>
      <search :loading="loading" @on-search="initMethod"></search>
    </template>
    <list :loading="loading" :total="total" :page-num="form.pageNum" :page-size="form.pageSize" @reload="initMethod"
      :data-list="dataList"> </list>
  </oms-panel>
</template>
<script lang="ts" setup name="gift-index">
import commonData from '@/views/oms/marketing/commonData/initData'
import OmsPanel from '@/components/oms-panel/index.vue'
import { ref, reactive } from 'vue'
import Search from './components/search.vue'
import List from './components/list.vue'
import { getList } from '@/api/stock/system-inventory'
import { SystemInventoryType, SystemInventoryList } from '@/types/stock/system-inventory'
import { Message } from "@arco-design/web-vue"
const { loading, total } = commonData()
let form = reactive<SystemInventoryType>(new SystemInventoryType())
const dataList = ref<Array<SystemInventoryList>>([])
const initMethod = async (data?: SystemInventoryType) => {
  try {
    Object.assign(form, data)
    loading.value = true
    const { code, message, value } = await getList(form)
    if (code != 0) {
      throw new Error(message)
    }
    dataList.value = value.result
    total.value = value.totalCount
    form.pageNum = value.pageNum
    form.pageSize = value.pageSize
    loading.value = false
  } catch (error) {
    Message.error((error as Error).message)
  } finally {
    loading.value = false
  }
}
</script>
<style lang="less" scoped>
.panel-height {
  height: 100%;
}

.shop-config {
  background-color: #fff;
  height: 100%;

  :deep(.arco-tabs-nav) {
    padding: 10px 16px 0px 10px;
  }

  :deep(.arco-tabs-content) {
    padding-left: 16px;
    padding-right: 16px;
  }

  :deep(.arco-tabs-nav-extra) {
    border: 1px solid rgba(112, 112, 112, 0.3);
    border-radius: 50%;
    color: #707070;
    font-size: 11px;
    padding: 2px;
    cursor: pointer;
  }
}
</style>