
<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onReload">
    <template #header-left v-if="false">
    </template>
    <a-table :pagination="false" :data="dataList" hide-expand-button-on-empty :scroll="{ x: 1150, y: 400 }" stripe
      :bordered="{ wrapper: false }" :row-selection="rowSelection">
      <template #columns>
        <a-table-column title="实体仓名称" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.warehouseName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="虚拟仓名称" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.virtualWarehouseName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="spu编码" :tooltip="true" :width="120" ellipsis>
          <template #cell="{ record }">
            {{ record.spuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="sku编码" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ record.skuCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格名称" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.skuTitle || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="规格型号" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.skuModel || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="库存数" :tooltip="true" :width="300" ellipsis>
          <template #cell="{ record }">
            {{ record.stockAmount || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="配货占用" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            <a-link type="text" @click="handlerEvent('cancel', record)">{{ record.deliveryQuantityAmount }}</a-link>
          </template>
        </a-table-column>
        <a-table-column title="其他占用" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            <a-link type="text" @click="handlerEvent('cancel', record)">{{ record.otherQuantityAmount }}</a-link>
          </template>
        </a-table-column>
        <a-table-column title="可用数" :tooltip="true" :width="120" ellipsis>
          <template #cell="{ record }">
            {{ record.quantityAmount || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="在途数" :tooltip="true" :width="90" ellipsis>
          <template #cell="{ record }">
            {{ record.transitQuantityAmount || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="180" fixed="right">
          <template #cell="{ record }">
            <a-space :size="10">
              <a-link type="text" @click="handlerEvent('locked', record)"
                v-permission="['oms:marketing:gift:cancel']">锁定</a-link>
              <a-link type="text" @click="handlerEvent('log', record)"
                v-permission="['oms:marketing:gift:copy']">日志</a-link>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
  <!-- 修改状态 -->
  <oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
  <oms-log ref="omsLogRef"></oms-log>
  <!-- <gift-modal ref="giftModalRef" @reload="emits('reload')"></gift-modal> -->
  <!-- <audit ref="auditRef" @reload="emits('reload')"></audit> -->
</template>
<script lang="ts" setup name="gift-list">
import { SystemInventoryList } from '@/types/stock/system-inventory'
import OmsTable from '@/components/oms-table/index.vue';
import omsLog from '@/components/oms-log/index.vue'
// import Audit from './audit.vue'
// import giftModal from './gift-modal/index.vue'
import OmsWarning from '@/components/oms-warning/index.vue'
import OmsTag from '@/components/oms-tag/index.vue'
import {
  cancellation,
  productActivitySubmit
} from '@/api/marketing/gift'
import { Message, TableRowSelection } from '@arco-design/web-vue'
import { ref, reactive } from 'vue'
const giftModalRef = ref()
const switchRef = ref()
const omsLogRef = ref()
const params = ref()
const paramsType = ref()
const emits = defineEmits<{
  (e: "reload", data?: any): void
  (e: "show-record", data: SystemInventoryList): void
}>()
const audittTagType = {
  'WAIT_AUDIT': 'progress',
  'AUDIT_PASS': 'normal',
  'NO_PASS': 'warring',
  'STASH': 'normal',
  'CANCELLATION': 'efficacy',
}
enum AuditStatus {
  "AUDIT_PASS" = '通过',
  "NO_PASS" = '不通过',
  "WAIT_AUDIT" = '待审核',
  "STASH" = '暂存',
  "CANCELLATION" = '已作废',
}
interface PropsType {
  loading: boolean
  total: number
  pageNum: number
  pageSize: number
  dataList: Array<SystemInventoryList>
}
const props = defineProps<PropsType>();
const getAdjustRecord = (data: SystemInventoryList) => {
  emits('show-record', data)
}
const onReload = (data: any) => {
  emits('reload', data)
}
const rowSelection = reactive<TableRowSelection>({
  type: 'checkbox',
  showCheckedAll: true
})
const handlerEvent = (type: string, record?: SystemInventoryList) => {
  paramsType.value = type
  switch (type) {
    case 'sub':
      params.value = record?.id
      return switchRef.value.open({ title: "提示", content: `此操作将提交选中数据审核, 是否继续？<div style='color:#999999'>提交后不可修改数据</div>` })
    case 'log': return omsLogRef.value.init(record?.id, '系统库存', 'page')
  }
}
const beforeChange = async () => {
  switch (paramsType.value) {
    case 'sub': return handerSub()
    case 'cancel': return handerCancel()
    default:
      break;
  }
}

</script>