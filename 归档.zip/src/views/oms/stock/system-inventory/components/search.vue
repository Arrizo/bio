<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-14 15:17:23
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-22 14:33:34
 * @FilePath: \oms-admin\src\views\oms\marketing\gift\components\search.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-form :model="form" layout="inline" ref="formRef">
    <a-form-item field="warehouseCodes" label="仓库：">
      <oms-multiple-select v-model="form.warehouseCodes" :maxTagCount="1" value="id" label="virtualWarehouseName"
        :option-list="activeVirtualList"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="spuSkuCode" label="编码：">
      <a-input v-model.trim="form.spuSkuCode" placeholder="请输入活动名称" allow-clear :max-length="100"
        @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="skuName" label="名称：">
      <a-input v-model.trim="form.skuName" placeholder="请输入活动名称" allow-clear :max-length="100" @keyup.enter="handleSearch"
        v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="stockStatus" label="库存状态：">
      <a-select placeholder="请选择审核状态" v-model="form.stockStatus">
        <a-option value="all">全部</a-option>
        <a-option value="LOCKED">已锁定</a-option>
        <a-option value="NORMAL">未锁定</a-option>
        <a-option value="PLUS">正库存</a-option>
        <a-option value="ZERO">零库存</a-option>
        <a-option value="MINUS">负库存</a-option>
      </a-select>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset">
      <a-button>导出</a-button>
    </oms-search-btn>
  </a-form>
</template>
<script lang="ts" setup name="gift-search">
import { reactive, ref, onMounted } from 'vue'
import { Message } from '@arco-design/web-vue'
import { SystemInventoryType } from '@/types/stock/system-inventory'
import commonData from '@/views/oms/marketing/commonData/initData'
import omsMultipleSelect from '@/components/oms-multiple-select/index.vue'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { deepClone } from '@/utils/helper';
import { getActiveVirtual } from '@/api/stock/system-inventory'
const props = defineProps<{ loading: boolean }>();
const activeVirtualList = ref()
const emits = defineEmits<{
  (e: "on-search", data: SystemInventoryType): void;
}>();
const { formReset, formRef } = commonData()

let form = reactive<SystemInventoryType>(new SystemInventoryType())
const handleReset = () => {
  formReset()
  handleSearch()
}
const handleSearch = () => {
  const newForm = deepClone(form)
  if (form.stockStatus === 'all') { newForm.stockStatus = '' }
  emits('on-search', newForm)
}
//查询虚拟仓列表
const activeVirtual = async () => {
  try {
    const { code, value, message } = await getActiveVirtual()
    if (code != 0) {
      throw new Error(message)
    }
    activeVirtualList.value = value
  } catch (error) {
    Message.error((error as Error).message)
  }
}
onMounted(async () => {
  activeVirtual()
  handleSearch()
})
</script>