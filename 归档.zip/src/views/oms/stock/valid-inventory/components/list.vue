<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 10:29:14
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 11:57:07
 * @ Description:列表
 -->

<template>
  <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
    <div class="stock-tig"><icon-exclamation-circle-fill class="stock-icon" />sku效期库存最后一次统计完成时间：<span>2023-08-10
        14:00:00</span>，每日统计一次。</div>
    <a-table ref="tableRef" stripe :bordered="{ wrapper: false }" :data="(list as any)" :pagination="false"
      :scroll="{ x: 1400 }">
      <template #columns>
        <a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
          <template #cell="{ rowIndex }">
            {{ rowIndex + 1 }}
          </template>
        </a-table-column>
        <a-table-column title="实体仓" :width="180" ellipsis tooltip data-index="storeName">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="虚拟仓" :width="180" ellipsis tooltip data-index="storeName">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="spu编码" :width="180" ellipsis tooltip data-index="storeCode">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="sku编码" :width="180" ellipsis tooltip data-index="storeCode">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="规格名称" :width="180" ellipsis tooltip data-index="platformProductId">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="规格型号" :width="180" ellipsis tooltip data-index="platformProductName">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="批次号" :width="180" ellipsis tooltip data-index="platformSkuId">
          <template #cell="{ record }">{{ record.platformSkuId || '--' }}</template>
        </a-table-column>
        <a-table-column title="生产日期" :width="180" ellipsis tooltip data-index="platformSkuName">
          <template #cell="{ record }">{{ record.platformSkuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="过期日期" :width="180" ellipsis tooltip data-index="skuCode">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="保质期(天)" :width="180" ellipsis tooltip data-index="skuName">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="状态" :width="180" ellipsis tooltip data-index="combination">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="距离到期天数" :width="180" ellipsis tooltip data-index="combination">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="库存类型" :width="180" ellipsis tooltip data-index="combination">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="库龄(天)" :width="180" ellipsis tooltip data-index="combination">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="库存数量" :width="180" ellipsis tooltip data-index="combination">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
        <a-table-column title="采购入库时间" :width="180" ellipsis tooltip data-index="combination">
          <template #cell="{ record }">{{ record.skuName || '--' }}</template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
</template>

<script setup lang="ts" name="stock-valid-inventory-list">
import { ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { DistributionReq, DistributionType, ShopSelectItem } from '@/types/product/distribution';


const props = defineProps({
  list: { type: Array<DistributionType>, default: () => [] },
  shopList: { type: Array<ShopSelectItem>, default: () => [] },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  loading: { type: Boolean, default: false },
});
const form = ref<DistributionReq>(new DistributionReq());
let storeId = ref();
const emits = defineEmits<{
  (e: "reload", data?: DistributionReq): void,
  (e: "record", data: DistributionType): void,
  (e: "details", data?: DistributionReq): void,
}>();

const switchRef = ref();
const tableRef = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};


</script>
<style lang="less" scoped>
.stock-tig {
  width: 100%;
  padding: 8px 12px;
  font-size: 13px;
  color: #3A3A3A;
  background: rgba(62, 108, 254, 0.02);
  border: 1px solid rgba(62, 108, 254, 0.2);
  opacity: 1;
  border-radius: 2px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;

  .stock-icon {
    color: #3E6CFE;
    font-size: 18px;
    margin-right: 6px;
  }

  span {
    color: #3E6CFE;
  }
}
</style>