<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 10:29:14
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 14:34:20
 * @ Description:搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-row style="width:100%">
      <a-col :span="6">
        <a-form-item field="lstStoreCode" label="实体仓：">
          <oms-multiple-select :maxTagCount="1" v-model="form.lstStoreCode" :option-list="(shopList as any)"
            value="storeCode" label="storeName"></oms-multiple-select>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="lstStoreCode" label="虚拟仓：">
          <oms-multiple-select :maxTagCount="1" v-model="form.lstStoreCode" :option-list="(shopList as any)"
            value="storeCode" label="storeName"></oms-multiple-select>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item class="group-form-item">
          <a-input-group>
            <a-select :options="['Option1', 'Option2', 'Option3']" :style="{ width: '90px' }" placeholder="first" />
            <a-input :style="{ width: '208px' }" placeholder="请输入" />
          </a-input-group>
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="status" label="库龄：">
          <a-select placeholder="请选择" v-model="form.lstStoreCode" :style="{ width: '200px' }" allow-clear>
            <a-option value="all">全部</a-option>
            <a-option value="true">已启用</a-option>
            <a-option value="false">已禁用</a-option>
          </a-select>
        </a-form-item>
      </a-col>
    </a-row>
    <a-row style="width:100%">
      <a-col :span="6">
        <a-form-item field="code" label="商品编码：">
          <a-input style="width: 208px;" v-limit-input v-model.trim="form.code" @keyup.enter="handleSearch" placeholder="请输入" />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="name" label="规格名称：">
          <a-input style="width: 208px;" v-limit-input v-model.trim="form.name" @keyup.enter="handleSearch" placeholder="请输入" />
        </a-form-item>
      </a-col>
      <a-col :span="6">
        <a-form-item field="time" label="入库时间：" class="time">
          <a-range-picker showTime v-model="pickerTime" @change="onChange" />
        </a-form-item>
      </a-col>
      <a-col :span="1"></a-col>
      <a-col :span="2">
        <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset">
        </oms-search-btn>
      </a-col>
    </a-row>
  </a-form>
</template>

<script setup lang="ts" name="stock-valid-inventory-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { DistributionReq, ShopSelectItem } from '@/types/product/distribution';
import { onMounted, ref } from 'vue';
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"

const props = defineProps({
  loading: { type: Boolean, default: false },
  shopList: { type: Array<ShopSelectItem>, default: () => [] }
});

const emits = defineEmits<{
  (e: "on-search", data: DistributionReq): void;
}>();

const formRes = ref();
const form = ref<DistributionReq>(new DistributionReq());
const pickerTime = ref()
// 搜索
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  pickerTime.value = []
  handleSearch();
}
const onChange = (value: any) => {
  // form.startTime = value?.[0] ?? ''
  // form.endTime = value?.[1] ?? ''
}
onMounted(() => {
  handleSearch();
});
</script>
<style lang="less" scoped>
.time {
  :deep(.arco-form-item-wrapper-col) {
    width: 400px;
  }
}

.group-form-item {
  :deep(.arco-form-item-label-col) {
    width: 0px;

  }

  :deep(.arco-form-item-wrapper-col .arco-form-item-content-wrapper .arco-form-item-content) {
    width: auto;
  }
}
</style>