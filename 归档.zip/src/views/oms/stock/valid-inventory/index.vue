<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 10:17:35
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 11:37:59
 * @ Description:效期库存
 -->
 <template>
  <div>
    <a-row :gutter="10">
      <a-col :span="24">
        <oms-panel>
          <template #header>
            <search :shopList="(shopList as any)" :loading="loading" @on-search="init"></search>
          </template>
          <div>
            <list @reload="init" :page-num="form.pageNum" :shopList="shopList" :page-size="form.pageSize"
              :totalCount="totalCount" :loading="loading" :list="list"></list>
          </div>
        </oms-panel>
        </a-col>
    </a-row>
  </div>
</template>

<script setup lang="ts" name="stock-valid-inventory">
import OmsPanel from '@/components/oms-panel/index.vue';
import Search from './components/search.vue';
import List from './components/list.vue';
import { Message } from '@arco-design/web-vue';
import { onMounted, ref } from 'vue';
import { deepClone } from '@/utils/helper';
import { DistributionReq, ShopSelectItem } from '@/types/product/distribution';
import { queryPage, queryUserStore } from '@/api/product/distribution';
const form = ref<DistributionReq>(new DistributionReq());
const loading = ref<boolean>(false);
const list = ref();
const totalCount = ref();
/**
 * 初始化查询菜单数据
 * @param form
 */

const init = async (data: DistributionReq = {}) => {
  try {
    form.value = { ...form.value, ...data }

    loading.value = true;
    let params = deepClone(form.value);
    params.status = params.status === 'all' ? '' : params.status;
    params.auditStatus = params.auditStatus === 'all' ? '' : params.auditStatus;
    const res = await queryPage(params);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    list.value = res.value.result;
    totalCount.value = res.value.totalCount;
    data.pageNum = res.value.pageNum;
    data.pageSize = res.value.pageSize;
  } catch (err) {
    Message.error((err as Error).message);
  } finally {
    loading.value = false;
  }
}

const shopList = ref<ShopSelectItem[]>([]);
const queryShopList = async () => {
  try {
    let response = await queryUserStore();
    if (response?.success) {
      shopList.value = response?.value ?? [];
    } else {
      Message.warning(response?.message || '查询店铺列表失败');
    }
  } catch (e) {
    console.error(e);
    Message.warning("查询店铺列表失败");
  }
}

onMounted(() => {
  queryShopList();
});
</script>
