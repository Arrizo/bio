
<template>
  <oms-table :loading="loading" :total="total" :current="pageNum" :size="pageSize" @reload="onReload">
    <template #header-left>
      <a-space :size="10" style="marginBottom:10px;">
        <a-button type="primary" @click="handler('add')" v-permission="['oms:marketing:gift:add']">新增虚拟调拨</a-button>
      </a-space>
    </template>
    <a-table :pagination="false" :data="dataList" hide-expand-button-on-empty :scroll="{ x: 1150, y: 400 }" stripe
      :bordered="{ wrapper: false }" v-db-click="dataList" :db-call-back="getAdjustRecord">
      <template #columns>
        <a-table-column title="调拨单号" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.activityCode || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="调出仓库" :tooltip="true" :width="150" ellipsis>
          <template #cell="{ record }">
            {{ record.activityName || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="调入仓库" :tooltip="true" :width="120" ellipsis>
          <template #cell="{ record }">
            {{ record.activityType || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="状态" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ record.sort || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="计划数量" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.startTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="实调数量" :tooltip="true" :width="180" ellipsis>
          <template #cell="{ record }">
            {{ record.endTime || '--' }}
          </template>
        </a-table-column>
        <a-table-column title="备注" :tooltip="true" :width="300" ellipsis>
          <template #cell="{ record }">
            {{ `${record.activityTimeType}：${record.activityTimeDimensionalityName}; ${getActivityTime(record)}` }}
          </template>
        </a-table-column>
        <a-table-column title="更新时间" :tooltip="true" :width="100" ellipsis>
          <template #cell="{ record }">
            {{ `${record.minPrice || 0.00}~${record.maxPrice}` }}
          </template>
        </a-table-column>
        <a-table-column title="操作" :width="180" fixed="right">
          <template #cell="{ record }">
            <a-space :size="10">
              <template v-if="record.auditStatus != 'CANCELLATION'">
                <a-link type="text" @click="handler('sub', record)"
                  v-if="['STASH', 'NO_PASS'].includes(record.auditStatus)"
                  v-permission="['oms:marketing:gift:submit']">提交</a-link>
                <a-link type="text" @click="handler('audit', record)" v-if="record.auditStatus == 'WAIT_AUDIT'"
                  v-permission="['oms:marketing:gift:audt']">审核</a-link>
                <a-link type="text" @click="handler('edit', record)"
                  v-if="['STASH', 'NO_PASS'].includes(record.auditStatus)"
                  v-permission="['oms:marketing:gift:edit']">修改</a-link>
                <a-link type="text" @click="handler('cancel', record)"
                  v-permission="['oms:marketing:gift:cancel']">作废</a-link>
                <a-link type="text" @click="handler('copy', record)"
                  v-permission="['oms:marketing:gift:copy']">复制</a-link>
              </template>
            </a-space>
          </template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
  <!-- 修改状态 -->
  <oms-warning ref="switchRef" :on-before-ok="beforeChange"></oms-warning>
  <gift-modal ref="giftModalRef" @reload="emits('reload')"></gift-modal>
  <audit ref="auditRef" @reload="emits('reload')"></audit>
</template>
<script lang="ts" setup name="gift-list">
import { GiftListType } from '@/types/marketing/gift'
import OmsTable from '@/components/oms-table/index.vue';
import Audit from './audit.vue'
import giftModal from './gift-modal/index.vue'
import OmsWarning from '@/components/oms-warning/index.vue'
import OmsTag from '@/components/oms-tag/index.vue'
import {
  cancellation,
  productActivitySubmit
} from '@/api/marketing/gift'
import { Message } from '@arco-design/web-vue'
import { ref } from 'vue'
const giftModalRef = ref()
const switchRef = ref()
const auditRef = ref()
const params = ref()
const paramsType = ref()
const emits = defineEmits<{
  (e: "reload", data?: any): void
  (e: "show-record", data: GiftListType): void
}>()
const audittTagType = {
  'WAIT_AUDIT': 'progress',
  'AUDIT_PASS': 'normal',
  'NO_PASS': 'warring',
  'STASH': 'normal',
  'CANCELLATION': 'efficacy',
}
enum AuditStatus {
  "AUDIT_PASS" = '通过',
  "NO_PASS" = '不通过',
  "WAIT_AUDIT" = '待审核',
  "STASH" = '暂存',
  "CANCELLATION" = '已作废',
}
interface PropsType {
  loading: boolean
  total: number
  pageNum: number
  pageSize: number
  dataList: Array<GiftListType>
}
const props = defineProps<PropsType>();
const getAdjustRecord = (data: GiftListType) => {
  emits('show-record', data)
}
const onReload = (data: any) => {
  emits('reload', data)
}
const getActivityTime = (record: GiftListType) => {
  if (['week', 'month'].includes(record.activityTimeDimensionality)) {
    return record?.numberNames??[].join(',')
  } else {
    return `${record.presentScheduleTimeAndDayBO?.startTime}-${record.presentScheduleTimeAndDayBO?.endTime}`
  }
}
const handler = (type: string, record?: GiftListType) => {
  paramsType.value = type
  switch (type) {
    case 'sub':
      params.value = record?.id
      return switchRef.value.open({ title: "提示", content: `此操作将提交选中数据审核, 是否继续？<div style='color:#999999'>提交后不可修改数据</div>` })
    case 'add': return giftModalRef.value.initMethod(0)
    case 'cancel':
      params.value = record?.id
      return switchRef.value.open({ title: "提示", content: `此操作将作废选中数据, 是否继续？<div style='color:#999999'>数据作废后策略将不会被执行</div>` })
    case 'audit':
      return auditRef.value.open(record?.id)
    case 'edit': return giftModalRef.value.initMethod(record?.id)
    case 'copy': return giftModalRef.value.initMethod(record?.id,type)
    default:
      break;
  }
}
const beforeChange = async () => {
  switch (paramsType.value) {
    case 'sub': return handerSub()
    case 'cancel': return handerCancel()
    default:
      break;
  }
}
// 提交
const handerSub = async () => {
  try {
    const { code, message, value } = await productActivitySubmit(params.value)
    if (code != 0) {
      throw new Error(message);
    }
    Message.success('操作成功')
    emits('reload')
  } catch (error) {
    Message.error((error as Error).message)
  }

}
// 作废
const handerCancel = async () => {
  try {
    const { code, message, value } = await cancellation(params.value)
    if (code != 0) {
      throw new Error(message);
    }
    Message.success('操作成功')
    emits('reload')
  } catch (error) {
    Message.error((error as Error).message)
  }
}
</script>