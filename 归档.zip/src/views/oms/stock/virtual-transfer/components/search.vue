<!--
 * @Author: chenzechao chenzc@jw99.net
 * @Date: 2023-03-14 15:17:23
 * @LastEditors: chenzechao chenzc@jw99.net
 * @LastEditTime: 2023-03-22 14:33:34
 * @FilePath: \oms-admin\src\views\oms\marketing\gift\components\search.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <a-form :model="form" layout="inline" ref="formRef">
    <a-form-item field="activityCode" label="调拨单号：">
      <a-input-group>
        <a-select>
        </a-select>
        <a-input v-model.trim="form.activityCode" placeholder="请输入活动编码" allow-clear :max-length="100"
          :style="{ width: '200px' }" @keyup.enter="handleSearch" v-limit-input></a-input>
      </a-input-group>
    </a-form-item>
    <a-form-item field="activityName" label="调出仓库：">
      <a-input v-model.trim="form.activityName" placeholder="请输入活动名称" allow-clear :max-length="100"
        :style="{ width: '200px' }" @keyup.enter="handleSearch" v-limit-input></a-input>
    </a-form-item>
    <a-form-item field="auditStatus" label="调入仓库：">
      <a-select placeholder="请选择审核状态" v-model="form.auditStatus" :style="{ width: '200px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="STASH">暂存</a-option>
        <a-option value="WAIT_AUDIT">待审核</a-option>
        <a-option value="AUDIT_PASS">通过</a-option>
        <a-option value="NO_PASS">未通过</a-option>
        <a-option value="CANCELLATION">已作废</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="activityType" label="状态：">
      <a-select placeholder="请选择活动类型" v-model="form.activityType" :style="{ width: '200px' }" allow-clear>
        <a-option v-for="(item, index) in typeList" :key="`${index}-type`"
          :value="item.dictionaryValue">{{ item.dictionaryTitle }}</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="way" label="商品编码：">
      <a-select placeholder="请选择" v-model="form.way" :style="{ width: '200px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="ALL_GIVING">全部送</a-option>
        <a-option value="ORDERLY">顺序送</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="way" label="商品名称：">
      <a-select placeholder="请选择" v-model="form.way" :style="{ width: '200px' }" allow-clear>
        <a-option value="all">全部</a-option>
        <a-option value="ALL_GIVING">全部送</a-option>
        <a-option value="ORDERLY">顺序送</a-option>
      </a-select>
    </a-form-item>
    <a-form-item field="time" label="有效时间：" :wrapper-col-style="{ width: '380px' }">
      <a-input-group>
        <a-select>
        </a-select>
        <a-range-picker showTime v-model="form.time" @change="onChange" />
      </a-input-group>
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset"></oms-search-btn>
  </a-form>
</template>
<script lang="ts" setup name="gift-search">
import { reactive, ref, onMounted } from 'vue'
import { GiftSearchType } from '@/types/marketing/gift'
import commonData from '@/views/oms/marketing/commonData/initData'
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { deepClone } from '@/utils/helper';
const props = defineProps<{ loading: boolean }>();
const typeList = ref()
const emits = defineEmits<{
  (e: "on-search", data: GiftSearchType): void;
}>();
const { formReset, formRef, getDictionaryTypeList } = commonData()

let form = reactive<GiftSearchType>(new GiftSearchType())
const handleReset = () => {
  formReset()
  form.startTime = ''
  form.endTime = ''
  handleSearch()
}
const onChange = (value: any) => {
  form.startTime = value?.[0] ?? ''
  form.endTime = value?.[1] ?? ''
}
const handleSearch = () => {
  const newForm = deepClone(form)
  if (newForm.way === 'all') { newForm.way = '' }
  if (newForm.activityType === 'all') { newForm.activityType = '' }
  if (newForm.auditStatus === 'all') { newForm.auditStatus = '' }
  emits('on-search', newForm)
}
onMounted(async () => {
  typeList.value = await getDictionaryTypeList('ACTIVITY_TYPE')
  handleSearch()
})
</script>