<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 10:29:14
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 17:16:30
 * @ Description:搜索
 -->

<template>
  <a-form :model="form" layout="inline" ref="formRes">
    <a-form-item field="warehouseCodes" label="实体仓：">
      <oms-multiple-select :maxTagCount="1" v-model="form.warehouseCodes" :option-list="(shopList as any)"
        value="storeCode" label="storeName"></oms-multiple-select>
    </a-form-item>
    <a-form-item field="spuSkuCode" label="编码：">
      <a-input v-limit-input v-model.trim="form.spuSkuCode" @keyup.enter="handleSearch" placeholder="请输入" />
    </a-form-item>
    <a-form-item field="skuName" label="名称：">
      <a-input v-limit-input v-model.trim="form.skuName" @keyup.enter="handleSearch" placeholder="请输入" />
    </a-form-item>
    <oms-search-btn :loading="loading" @search="handleSearch" @clear="handleReset">
      <a-button :disabled="exportLoading" @click="handleExport">
        导出</a-button>
    </oms-search-btn>
  </a-form>
</template>

<script setup lang="ts" name="stock-physical-inventory-search">
import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
import { onMounted, ref } from 'vue';
import omsMultipleSelect from "@/components/oms-multiple-select/index.vue"
import { PhysicalInventoryReq } from '@/types/stock/physical-inventory';
import { Message } from '@arco-design/web-vue';
import { exportStock } from '@/api/stock/physical-inventory';

const props = defineProps({
  loading: { type: Boolean, default: false },
  shopList: { type: Array, default: () => [] }
});

const emits = defineEmits<{
  (e: "on-search", data: PhysicalInventoryReq): void;
}>();

const formRes = ref();
const form = ref<PhysicalInventoryReq>(new PhysicalInventoryReq());
const exportLoading = ref<boolean>(false)
// 搜索
const handleSearch = () => emits("on-search", form.value);

// 重置搜索条件
const handleReset = () => {
  formRes.value.resetFields();
  handleSearch();
}

//导出
const handleExport = async () => {
  try {
    exportLoading.value = true;
    const res = await exportStock(form.value);

    if (res.code != 0) {
      throw new Error(res.message);
    }
    Message.success(res.message);
    exportLoading.value = false;
  } catch (err) {
    Message.error((err as Error).message);
    exportLoading.value = false;
  } finally {
    exportLoading.value = false;
  }
}

onMounted(() => {
  handleSearch();
});
</script>