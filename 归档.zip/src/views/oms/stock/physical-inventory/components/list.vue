<!--
 * @ Author: qiujiajia
 * @ Create Time: 2023-03-29 10:29:14
 * @ Modified by: qiujiajia
 * @ Modified time: 2023-03-29 17:21:52
 * @ Description:列表
 -->

<template>
  <oms-table :loading="loading" :total="totalCount" :current="pageNum" :size="pageSize" @reload="onReload">
    <div class="stock-tig"><icon-exclamation-circle-fill class="stock-icon" />查询统计时间：<span>2023-08-10
        14:00:00</span>，库存数据是动态变化的，列表统计结果数据仅代表截止查询时间参考</div>
    <a-table ref="tableRef" stripe :bordered="{ wrapper: false }" :data="(list as any)" :pagination="false"
      :scroll="{ x: 1300 }">
      <template #columns>
        <a-table-column title="序号" fixed="left" :tooltip="true" :width="60" ellipsis>
          <template #cell="{ rowIndex }">
            {{ rowIndex + 1 }}
          </template>
        </a-table-column>
        <a-table-column title="实体仓名称" ellipsis tooltip data-index="warehouseName">
          <template #cell="{ record }">{{ record.warehouseName || '--' }}</template>
        </a-table-column>
        <a-table-column title="spu编码" ellipsis tooltip data-index="spuCode">
          <template #cell="{ record }">{{ record.spuCode || '--' }}</template>
        </a-table-column>
        <a-table-column title="sku编码" ellipsis tooltip data-index="skuCode">
          <template #cell="{ record }">{{ record.skuCode || '--' }}</template>
        </a-table-column>
        <a-table-column title="规格名称" ellipsis tooltip data-index="skuTitle">
          <template #cell="{ record }">{{ record.skuTitle || '--' }}</template>
        </a-table-column>
        <a-table-column title="规格型号" ellipsis tooltip data-index="skuModel">
          <template #cell="{ record }">{{ record.skuModel || '--' }}</template>
        </a-table-column>
        <a-table-column title="库存数" ellipsis tooltip data-index="stockAmount">
          <template #cell="{ record }">{{ record.stockAmount || '--' }}</template>
        </a-table-column>
        <a-table-column title="配货占用" ellipsis tooltip data-index="deliveryQuantityAmount">
          <template #cell="{ record }">{{ record.deliveryQuantityAmount || '--' }}</template>
        </a-table-column>
        <a-table-column title="其他占用" ellipsis tooltip data-index="otherQuantityAmount">
          <template #cell="{ record }">{{ record.otherQuantityAmount || '--' }}</template>
        </a-table-column>
        <a-table-column title="可用数" ellipsis tooltip data-index="quantityAmount">
          <template #cell="{ record }">{{ record.quantityAmount || '--' }}</template>
        </a-table-column>
        <a-table-column title="在途数" ellipsis tooltip data-index="transitQuantityAmount">
          <template #cell="{ record }">{{ record.transitQuantityAmount || '--' }}</template>
        </a-table-column>
      </template>
    </a-table>
  </oms-table>
</template>

<script setup lang="ts" name="stock-physical-inventory-list">
import { ref } from 'vue';
import OmsTable from '@/components/oms-table/index.vue';
import { PhysicalInventoryReq, PhysicalInventoryType } from '@/types/stock/physical-inventory';


const props = defineProps({
  list: { type: Array<PhysicalInventoryType>, default: () => [] },
  totalCount: { type: Number, default: 0 },
  pageNum: { type: Number, default: 1 },
  pageSize: { type: Number, default: 10 },
  loading: { type: Boolean, default: false },
});
const form = ref<PhysicalInventoryReq>(new PhysicalInventoryReq());
const emits = defineEmits<{
  (e: "reload", data?: PhysicalInventoryReq): void,
  (e: "record", data: PhysicalInventoryType): void,
  (e: "details", data?: PhysicalInventoryReq): void,
}>();

const tableRef = ref();

// 表格数据重载（分页触发）
const onReload = (data: { pageNum: number; pageSize: number }) => {
  form.value.pageNum = data.pageNum;
  form.value.pageSize = data.pageSize;
  emits("reload", form.value)
};


</script>
<style lang="less" scoped>
.stock-tig {
  width: 100%;
  padding: 8px 12px;
  font-size: 13px;
  color: #3A3A3A;
  background: rgba(62, 108, 254, 0.02);
  border: 1px solid rgba(62, 108, 254, 0.2);
  opacity: 1;
  border-radius: 2px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;

  .stock-icon {
    color: #3E6CFE;
    font-size: 18px;
    margin-right: 6px;
  }

  span {
    color: #3E6CFE;
  }
}
</style>