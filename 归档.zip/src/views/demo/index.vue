<template>
  <div>
    <oms-panel title="搜索按钮组">
      <oms-search-btn></oms-search-btn>
    </oms-panel>

    <oms-panel title="带基础操作的表格面板">
      <oms-table
        :total="100"
        :loading="loading"
        :current="data.pageNum"
        :size="data.pageSize"
        @reload="init"
      >
        <a-table :columns="columns" :data="list" :pagination="false" />
      </oms-table>
    </oms-panel>

    <oms-panel title="自定义表格面板头部">
      <oms-table
        :total="100"
        :current="data.pageNum"
        :size="data.pageSize"
        @reload="init"
      >
        <template #header-left>
          <a-space>
            <a-button> 导入 </a-button>
            <a-button> 批量更新 </a-button>
          </a-space>
        </template>
        <template #header-right>
          <a-space>
            <a-button status="danger"> 删除 </a-button>
          </a-space>
        </template>
        <a-table :columns="columns" :data="list" :pagination="false" />
      </oms-table>
    </oms-panel>
  </div>
</template>

<script setup lang="ts">
  import OmsPanel from '@/components/oms-panel/index.vue';
  import OmsTable from '@/components/oms-table/index.vue';
  import OmsSearchBtn from '@/components/oms-search-btn/index.vue';
  import { reactive, ref } from 'vue';

  const data = reactive<{ pageNum: number; pageSize: number }>({
    pageNum: 1,
    pageSize: 10,
  });
  const loading = ref(false);

  const init = () => {
    loading.value = true;
    setTimeout(() => {
      loading.value = false;
    }, 800);
  };

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
    },
    {
      title: 'Salary',
      dataIndex: 'salary',
    },
    {
      title: 'Address',
      dataIndex: 'address',
    },
    {
      title: 'Email',
      dataIndex: 'email',
    },
  ];
  const list = reactive([
    {
      key: '1',
      name: 'Jane Doe',
      salary: 23000,
      address: '32 Park Road, London',
      email: 'jane.doe@example.com',
    },
    {
      key: '2',
      name: 'Alisa Ross',
      salary: 25000,
      address: '35 Park Road, London',
      email: 'alisa.ross@example.com',
    },
    {
      key: '3',
      name: 'Kevin Sandra',
      salary: 22000,
      address: '31 Park Road, London',
      email: 'kevin.sandra@example.com',
    },
    {
      key: '4',
      name: 'Ed Hellen',
      salary: 17000,
      address: '42 Park Road, London',
      email: 'ed.hellen@example.com',
    },
    {
      key: '5',
      name: 'William Smith',
      salary: 27000,
      address: '62 Park Road, London',
      email: 'william.smith@example.com',
    },
  ]);
</script>
