<template>
  <div class="login-form-wrapper">
    <div class="login-form-title">欢迎登录</div>
    <div class="login-form-bar"></div>
    <div class="login-form-error-msg">{{ errorMessage }}</div>
    <a-form ref="loginForm" :model="userInfo" class="login-form" layout="vertical" @submit="handleSubmit">
      <a-form-item field="account" :rules="rules.username"
        :validate-trigger="['change', 'blur']" hide-label>
        <a-input
          v-limit-input
          v-model.trim="userInfo.account"
          placeholder="请输入账号"
          allow-clear
          :class="{
            [`login-form-input-empty`]: !userInfo.account,
            [`login-form-input-normal`]: userInfo.account
          }">
          <template #prefix>
            <img src="@/assets/images/login/icon-user.png" class="login-form-icon-user">
          </template>
        </a-input>
      </a-form-item>
      <a-form-item field="password" :rules="rules.password"
        :validate-trigger="['change', 'blur']" hide-label>
        <a-input-password
          v-limit-input
          v-model.trim="userInfo.password"
          placeholder="请输入密码"
          allow-clear
          :max-length="16"
          :class="{
            [`login-form-input-empty`]: !userInfo.password,
            [`login-form-input-normal`]: userInfo.password
          }">
          <template #prefix>
            <img src="@/assets/images/login/icon-password.png" class="login-form-icon-password">
          </template>
        </a-input-password>
      </a-form-item>
      <a-space :size="14" direction="vertical" style="margin-top:26px">
        <a-button type="primary" html-type="submit" long :loading="loading">
          登录
        </a-button>
      </a-space>
    </a-form>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';
import { Message } from '@arco-design/web-vue';
import { ValidatedError } from '@arco-design/web-vue/es/form/interface';
import { useUserStore } from '@/store';
import useLoading from '@/hooks/loading';
import { LoginData } from '@/types/user';
import { Password } from '@/utils/regex';

const rules = {
  username: [
    { required: true, message: '请输入账号' }
  ],
  password: [
    { required: true, message: '请输入密码' },
    // { match: Password, message: '请输入长度10到16位且仅包含大小写字母、数字的密码' }
  ]
}

const router = useRouter();
const errorMessage = ref('');
const { loading, setLoading } = useLoading();
const userStore = useUserStore();

const loginConfig = ref({
  account: '',
  password: '',
});
const userInfo = reactive({
  account: loginConfig.value.account,
  password: loginConfig.value.password,
});

const handleSubmit = async ({
  errors,
  values,
}: {
  errors: Record<string, ValidatedError> | undefined;
  values: Record<string, any>;
}) => {
  if (loading.value) return;

  if (!errors) {
    setLoading(true);
    try {
      await userStore.login(values as LoginData);
      await userStore.info();
      await userStore.setRoute(userStore.menuListVOS)
      const { redirect, ...othersQuery } = router.currentRoute.value.query;
      router.push({
        name: "home_index",
        query: {
          ...othersQuery,
        },
      });
      Message.success('登录成功');
    } catch (err) {
      errorMessage.value = (err as Error).message;
    } finally {
      setLoading(false);
    }
  }
};
</script>

<style lang="less" scoped>
.login-form {

  &-wrapper {
    width: 320px;
  }

  &-bar {
    width: 30px;
    height: 4px;
    background: #3E6CFE;
    margin-top: 6px;
  }

  &-title {
    color: var(--color-text-1);
    font-weight: 500;
    font-size: 24px;
    line-height: 32px;
  }

  &-sub-title {
    color: var(--color-text-3);
    font-size: 16px;
    line-height: 24px;
  }

  &-error-msg {
    height: 32px;
    color: rgb(var(--red-6));
    line-height: 32px;
  }

  &-password-actions {
    display: flex;
    justify-content: space-between;
  }

  &-register-btn {
    color: var(--color-text-3) !important;
  }

  &-icon-user {
    width: 22px;
    height: 22px;
  }

  &-icon-password {
    width: 22px;
    height: 22px;
  }

  &::v-deep(.arco-input-wrapper) {
    height: 44px;
    border-radius: 4px;
  }

  &::v-deep(.arco-btn-primary) {
    height: 44px;
    line-height: 44px;
    font-size: 17px;
    font-weight: 400;
    border-radius: 4px;
  }

  &::v-deep(.arco-form-item-message) {
    margin-top: 5px;
    margin-bottom: 16px;
    font-size: 16px;
  }

  // 未输入内容
  &-input-empty {

    background-color: rgba(247, 247, 247, 1);

    &::v-deep(input:-webkit-autofill) {
      -webkit-box-shadow: 0 0 0px 1000px rgba(247, 247, 247, 1) inset;
    }

    &::v-deep(.arco-input) {
      font-size: 16px;
    }

    &::v-deep(input::placeholder) {
      color: rgba(156, 156, 156, 1);
    }

  }

  // 输入框获得焦点
  &::v-deep(.arco-input-focus) {

    background-color: white;
    border: 1px solid rgba(62, 108, 254, 1);

    &:hover {
      background-color: white;
      border: 1px solid rgba(62, 108, 254, 1) !important;
    }

    input:-webkit-autofill {
      -webkit-box-shadow: 0 0 0px 1000px white inset !important;
    }

  }

  // 输入了内容且格式校验符合要求
  &-input-normal {

    background-color: rgba(247, 247, 247, 1);

    &:hover {
      background-color: rgba(247, 247, 247, 1);
      border: 1px solid rgba(62, 108, 254, 1);
    }

    &::v-deep(input:-webkit-autofill) {
      -webkit-box-shadow: 0 0 0px 1000px rgba(247, 247, 247, 1) inset;
    }

  }

  // 格式校验不符合要求
  &::v-deep(.arco-input-error) {

    background-color: white !important;
    border: 1px solid rgba(255, 62, 62, 1) !important;

    &:hover {
      background-color: white;
      border: 1px solid rgba(62, 108, 254, 1) !important;
    }

    &::v-deep(input:-webkit-autofill) {
      -webkit-box-shadow: 0 0 0px 1000px white inset;
    }

  }
}
:deep(.login-form-error-msg) {
  height: 40px;
  line-height: 40px;
}
</style>
