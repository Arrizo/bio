<template>
  <div class="container">
    <div class="welcome">欢迎使用金文业务中台</div>
    <div class="content">
      <div class="content-inner">
        <div class="login-logo">
          <img src="@/assets/images/login/logo.png">
        </div>
        <LoginForm />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { useUserStore } from '@/store';
import { onMounted } from 'vue';
import LoginForm from './components/login-form.vue';

const userStore = useUserStore();

onMounted(() => {
  userStore.logout();
});
</script>

<style lang="less" scoped>
.container {
  display: flex;
  width: 100%;
  min-width: 1000px;
  height: 100vh;
  background: #F8F9FB;
  background-image: url(/src/assets/images/login/bg-login.png);
  background-size: 100% 100%;

  .welcome {
    font-size: 34px;
    color: white;
    white-space: nowrap;
    position: absolute;
    top: 19.5vh;
    left: 2.1vw;
    &::after {
      content: '';
      position: absolute;
      left: 0px;
      bottom: 0px;
      width: 64px;
      height: 2px;
      margin-bottom: -20px;
      background-color: white;
    }
  }

  .content {
    @top: 148;
    @total-height: 999;
    @top-percent: (@top / @total-height) * 100vh;
    @total-width: 1919;
    @gray-width: 1264;
    @form-width: 461px;
    @gray-percent: (@gray-width / @total-width) * 100%;
    position: relative;
    display: flex;
    justify-content: flex-end;
    width: 100%;
    margin-top: @top-percent;
    margin-right: calc((@gray-percent - @form-width)/2);

    .content-inner {
      display: flex;
      align-items: center;
      flex-direction: column;

      .login-logo {
        margin-bottom: 33px;
        img {
          width: 152px;
          height: 42px;
        }
      }

      .login-form-wrapper {
        width: 460px;
        background: #FFFFFF;
        padding: 60px 40px 64px 40px;
        box-shadow: 0px 3px 8px 0px rgba(123, 123, 123, 0.06);
      }
    }
  }
}

.logo {
  position: fixed;
  top: 24px;
  left: 22px;
  z-index: 1;
  display: inline-flex;
  align-items: center;

  &-text {
    margin-right: 4px;
    margin-left: 4px;
    color: var(--color-fill-1);
    font-size: 20px;
  }
}
</style>

<style lang="less" scoped>
// responsive
@media (max-width: @screen-lg) {
  .container {
    .banner {
      width: 25%;
    }
  }
}
</style>
