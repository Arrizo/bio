import Mock from 'mockjs';

import './user';

Mock.setup({
  timeout: '600-1000',
});
