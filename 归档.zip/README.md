# oms-admin

## 快速上手

oms-admin 业务中台采用字节跳动旗下开源中台解决方案——Arco Design Pro Vue，采用官方 arco cli 搭建。

在其基础上，删除了自带的 i18n 和 husky 等于业务无关插件。

相关链接：

- [开发文档](https://arco.design/vue/docs/start)
- [风格配置](https://arco.design/themes/home)
- [Pinia](https://pinia.web3doc.top/)
- [Vite](https://cn.vitejs.dev/)

### 项目启动

#### 安装依赖

使用`npm`、`yarn` 或 `cnpm` 安装依赖项

```bash
npm install
# or npm i
```

```bash
npm run start
```

### 构建&预览

使用 Vite 运行和构建，具体配置可查阅 [构建选项](https://cn.vitejs.dev/config/build-options.html) 和 [预览选项](https://cn.vitejs.dev/config/preview-options.html)

示例：

```bash
dev环境   npm run dev
test环境  npm run build
生产环境  npm run prod
uat 环境  npm run uat

npm run preview
```

### 提交代码

项目采用`commitlint` 和 `cz-customizable`优化仓库提交流程，在`commit`过程中选择「提交类型」和输入「提交信息」。
对应的提交选项配置文件：`.cz-config.js`

使用前，需要执行：

```bash
npm install -g commitlint
```

提交流程

```bash
git add <file>

npm run commit
# or git cz
# 选择类型、提交说明、Enter Y

git push
```

### SRC 目录结构

|── api # 接口服务<br>
|── assets # 静态资源<br>
| └── style 全局样式<br>
|── components # 通用业务组件<br>
|── config # 全局配置(包含 echarts 主题)<br>
| └── settings.json # 配置文件<br>
|── directives # 自定义指令集<br>
|── hooks # 全局 hooks<br>
|── layout # 布局<br>
|── mock # 模拟数据<br>
|── views # 页面模板<br>
|── router # 路由配置<br>
|── store # 状态管理中心<br>
|── types # Typescript 类型<br>
|── utils # 工具库<br>
|── App.vue # 视图入口<br>
|── main.ts # 入口文件<br>

### 网络请求

通用请求封装位于`src/api/interceptor.ts`

规范接口请求文件按模块划分，统一放在`src/api/`目录下，手动导入`axios`进行接口封装，示例：

```javascript
import axios from 'axios';

// 添加数据字典
export function addDictionary(data) {
  return axios.post('/system/dataDictionary/add', data);
}
```

虽然没有强制要求，建议使用`TS`约束数据类型，降低项目的整体可维护成本。示例：

```javascript
import axios from 'axios';
import { HttpResponse } from '@/types/global';
import { DictionaryForm } from '@/types/system/dictionary';

// 添加数据字典
export function addDictionary(data: DictionaryForm) {
  return axios.post < any, HttpResponse > ('/system/dataDictionary/add', data);
}
```

### 权限控制、路由

待完善
