module.exports = {
  allowBreakingChanges: ["Feat", "Fix"],
  types: [
    {
      name: "新增功能 (Feat)",
      value: "Feat",
    },
    {
      name: "修复缺陷 (Fix)",
      value: "Fix",
    },
    {
      name: "更新文档 (Docs)",
      value: "Docs",
    },
    {
      name: "优化代码、逻辑、样式(Optim)",
      value: "Optim",
    },
    {
      name: "更新构建 (Build)",
      value: "Build",
    },
    {
      name: "更新脚本 (CI)",
      value: "CI",
    },
    {
      name: "合并分支 (Merge)",
      value: "Merge",
    },
  ],
  messages: {
    type: "请选择提交类型",
    customScope: "请选择修改范围(可选)",
    subject: "请简要描述提交(必填)",
    body: "请输入详细描述(可选)",
    footer: "请输入要关闭的issue(可选)",
    confirmCommit: "确认以上信息提交?(y/n)",
  },
  allowCustomScopes: true,
  scopes: [{ name: "application" }, { name: "components" }, { name: "config" }],
  skipQuestions: ["body", "footer"],
  subjectLimit: 72,
};
